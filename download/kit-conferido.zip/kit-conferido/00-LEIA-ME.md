# Kit Conferido

Uma pasta de skills em português para o Claude Code, feitas para quem gerencia área de indústria.

Você copia a pasta para o seu computador, abre o Claude na pasta onde estão os seus arquivos e pede em português. Cada skill termina em arquivo gravado no seu disco: as divergências entre duas fontes, a tabela extraída de um documento, o índice da caixa de e-mail, o comparativo de cotações com a unidade normalizada. Nenhuma delas termina em conselho.

**Nesta versão as dez skills estão prontas.** A tabela abaixo diz o que cada uma entrega.

Elas atacam as tarefas que mais consomem tempo em área de indústria, medidas em campo: conferir duas fontes que deveriam dizer a mesma coisa, transformar documento em tabela, triar caixa de e-mail, comparar cotações que chegaram em unidades diferentes, refazer o relatório do mês, registrar desvio, conferir procedimento contra norma, medir o número do antes, indexar a pasta que ninguém acha.

**Rode a `ficha-da-area` primeiro.** Ela escreve `~/.kit-industrial/ficha-da-area.md`, o arquivo de contexto que as outras nove leem antes de começar, e é o que faz o Claude usar o nome que a sua casa dá às coisas em vez de perguntar de novo em cada conversa.

Autoria, permissão de uso e contato estão em `LICENSE.md`, nesta mesma pasta.

---

## Para quem é

Engenheiro, coordenador, supervisor e chefe de departamento em produção, PCP, qualidade, manutenção, engenharia e suprimentos. Serve para quem já tem o problema na mesa: planilha que não fecha com o sistema, ficha de apontamento preenchida à mão que alguém redigita, caixa de e-mail que consome a manhã, cotações que chegaram cada uma na sua unidade.

## Para quem não é

Para quem não tem o arquivo na mão, o kit não vai servir agora: as skills trabalham sobre o que já está exportado, digitalizado ou salvo, e não vão buscar nada. Também não serve para quem precisa de um sistema: as skills escrevem arquivo, não integram ERP e não acessam servidor de arquivos.

---

## Pré-requisito honesto

| O que | Por quê |
|---|---|
| Claude Code instalado | É onde as skills rodam. Não funciona no aplicativo de celular nem só no navegador |
| Plano pago do Claude | As skills leem arquivo inteiro e escrevem arquivo. Isso consome uso |
| Uma máquina em que você possa instalar programa e gravar arquivo | Se a sua estação é bloqueada pela TI, resolva isso antes de começar |
| Permissão para tirar arquivo da empresa da pasta de rede e abrir na sua máquina | A decisão é da sua empresa, não do kit. Confira a política de segurança da informação antes |
| Python 3.8 ou superior, para as dez skills | Os scripts usam apenas a biblioteca padrão, sem instalar nada além do Python. No macOS e no Linux ele quase sempre já está lá: teste com `python3 --version`. No Windows, teste com `py -3 --version` |

As dez skills trazem script, e ele nunca é opcional por completo. Quatro escolhem entre leitura e script pela tabela de volume que cada uma declara, e nelas o script passa a ser obrigatório acima do volume, sempre que o dado for sensível e sempre que a tarefa se repetir: `conferencia-entre-duas-fontes`, `comparativo-de-cotacoes`, `triagem-de-caixa-de-email` e `linha-de-base-antes-de-automatizar`. As outras seis rodam sempre por script, qualquer que seja o tamanho do material.

**Python no Windows.** `python3` normalmente não existe como comando, e `python` sem Python instalado abre a Microsoft Store em vez de responder a versão. Quem instala pelo site oficial recebe o atalho `py`, e é por ele que se testa e se roda:

```
py -3 --version
py -3 "$env:USERPROFILE\.claude\skills\conferencia-entre-duas-fontes\scripts\conferir.py" --help
```

Se `py` não for reconhecido, o Python não está instalado: instale pela página oficial e deixe marcada a opção de instalar o atalho `py`. Onde a skill mostrar `python3`, no Windows leia `py -3`.

---

## Como instalar

Se você nunca usou terminal, siga na ordem. São cinco passos e uma conferência.

**Passo 1. Abra o terminal.**

- macOS: pressione Command e barra de espaço, escreva `Terminal` e pressione Enter.
- Windows: abra o menu Iniciar, escreva `PowerShell` e pressione Enter.
- Linux: pressione Control, Alt e T.

Uma janela de texto abre. Tudo abaixo é escrito nela, uma linha por vez, sempre terminando com Enter.

**Passo 2. Instale o Claude Code, se ainda não tiver.**

Siga a página oficial de instalação da Anthropic. O kit não traz instalador e não instala nada por você. Para conferir se já está instalado, escreva `claude --version`. Se aparecer um número, está instalado.

**Passo 3. Descompacte a pasta do kit.**

Deixe a pasta em um lugar que você saiba achar, por exemplo `Documentos/kit-conferido`. No primeiro nível dela existem três itens, e só eles: este `00-LEIA-ME.md`, o `LICENSE.md` e a pasta `skills`, com uma pasta por skill. Se o descompactador tiver criado um nível a mais, entre nele até ver esses três itens lado a lado: esse é o nível que conta como pasta do kit nos passos seguintes.

**Passo 4. Copie as skills para a pasta pessoal de skills do Claude Code.**

No macOS e no Linux:

```
mkdir -p ~/.claude/skills
cp -R ~/Documents/kit-conferido/skills/* ~/.claude/skills/
```

No Windows, no PowerShell:

```
New-Item -ItemType Directory -Force "$env:USERPROFILE\.claude\skills"
Copy-Item "$env:USERPROFILE\Documents\kit-conferido\skills\*" "$env:USERPROFILE\.claude\skills\" -Recurse
```

Se o caminho da sua pasta for outro, troque `~/Documents/kit-conferido`, ou `$env:USERPROFILE\Documents\kit-conferido`, pelo caminho onde você descompactou.

**Passo 5. Crie a pasta da ficha da área e dos livros-caixa.**

No macOS e no Linux:

```
mkdir -p ~/.kit-industrial
```

No Windows, no PowerShell:

```
New-Item -ItemType Directory -Force "$env:USERPROFILE\.kit-industrial"
```

As skills procuram o arquivo `~/.kit-industrial/ficha-da-area.md` antes de começar, que no Windows é `$env:USERPROFILE\.kit-industrial\ficha-da-area.md`. Não existindo, cada skill declara na primeira linha "rodando sem ficha da área" e segue normalmente.

**Quem escreve esse arquivo é a skill `ficha-da-area`, e não você.** Vá com o terminal até a pasta onde estão os seus arquivos de trabalho, abra o `claude` e peça `monta a ficha da minha área`. Ela deriva o que dá do que você já tem na mão, um export, um procedimento antigo, o texto do site, um certificado ou a planilha do indicador, pergunta no máximo cinco coisas, e grava a ficha mais a página de lacunas declaradas. Escrever o arquivo à mão não é o caminho: o formato tem seis seções e uma marca de origem por linha, e o script reprova o que estiver fora disso.

Nessa mesma pasta ficam os livros-caixa: o `gabaritos-extracao.csv`, da skill de extração de documento para tabela, e o `gabaritos-registro-de-anomalia.csv`, da skill de registro de anomalia. Você não escreve esses arquivos: o script cria e alimenta sozinho, uma linha por rodada de gabarito. São eles que respondem se a skill já está liberada para o trabalho de verdade, e são eles que fazem essa resposta sobreviver ao fim da conversa. **Não apague nenhum dos dois.** Apagar equivale a dizer que a skill nunca foi conferida, e ela volta a pedir a rodada de gabarito antes de rodar em caso novo.

**Conferência, em duas partes.**

A primeira não depende do Claude e diz se a cópia e o Python estão certos. Rode a bateria de testes de uma das skills:

```
python3 ~/.claude/skills/conferencia-entre-duas-fontes/scripts/testar.py
```

No Windows, `py -3 "$env:USERPROFILE\.claude\skills\conferencia-entre-duas-fontes\scripts\testar.py"`. O esperado é terminar com zero casos falhos. Falhando, ou dizendo que não achou o arquivo, a cópia do passo 4 não deu certo.

A segunda diz se o Claude enxerga as skills. Vá com o terminal até a pasta onde estão os seus arquivos de trabalho, escreva `claude` e pressione Enter. Com duas planilhas na pasta, escreva: `confere essas duas planilhas, elas deveriam dizer a mesma coisa`. Se a skill disparar, a resposta começa dizendo se a ficha da área foi carregada, e termina informando o caminho dos arquivos que ela gravou. Se não disparar, confira se o arquivo existe: `~/.claude/skills/conferencia-entre-duas-fontes/SKILL.md` no macOS e no Linux, `$env:USERPROFILE\.claude\skills\conferencia-entre-duas-fontes\SKILL.md` no Windows.

---

## As dez skills e o que cada uma entrega

A `ficha-da-area` vale rodar primeiro, porque as outras nove leem o arquivo que ela escreve.

| Skill | O que entrega | Nesta versão |
|---|---|---|
| `conferencia-entre-duas-fontes` | Num diretório com a data: `nota-de-normalizacao.md`, `divergencias.csv`, `so-na-fonte-A.csv`, `so-na-fonte-B.csv` e `linhas-descartadas.csv`. Um sexto, `diferencas-de-formato.csv`, com `--formato-em-arquivo`. Na rodada `--so-nota`, que não compara, saem só a nota e as linhas descartadas | **Pronta** |
| `extracao-de-documento-para-tabela` | Num diretório com a data: `nota-de-extracao.md`, `tabela.csv` com valor, confiança e origem por campo, `a-conferir.csv` ordenada por confiança, `para-lancar.csv` para colar na planilha, e `violacoes-do-contrato.csv`. Mais o livro-caixa em `~/.kit-industrial/gabaritos-extracao.csv` | **Pronta** |
| `triagem-de-caixa-de-email` | `indice-triado-<data>.md`, ordenado pelo que vence primeiro, e `triagem-<data>.csv`. Antes deles, o rastro da leitura: `mensagens.csv`, `threads.csv`, `nao-lidos.csv` e `nota-de-leitura.md` | **Pronta** |
| `comparativo-de-cotacoes` | Num diretório com a data: `nota-de-normalizacao-de-unidade.md`, `comparativo.csv`, `nao-comparaveis.csv`, `pedido-com-unidade-travada.md` e `perguntas-aos-fornecedores.md`, com a pergunta pronta de cada linha que não fechou. Com a anonimização ligada, o `perguntas-aos-fornecedores.md` é o único arquivo do diretório que leva o nome real, porque é o que se envia ao fornecedor: tire-o antes de compartilhar a rodada. O de-para e o conteúdo das linhas descartadas saem fora do diretório | **Pronta** |
| `ficha-da-area` | `~/.kit-industrial/ficha-da-area.md`, derivada de um artefato que você já tem mais até cinco perguntas, com o vocabulário da casa e uma marca de origem por linha. Mais `lacunas-da-area-<data>.md`, com cada lacuna, a seção em que ela fica e as skills que rodam pior enquanto ela estiver aberta | **Pronta** |
| `relatorio-recorrente` | O `receita.json`, que é a regra do relatório em arquivo executável, mais o `receita-do-relatorio.md` em palavras. Deles sai `relatorio-<aaaa-mm>.csv` montado por script, mais `relatorio-<aaaa-mm>.nota-da-montagem.md` e `relatorio-<aaaa-mm>.linhas-fora-da-montagem.csv`. Em dois diretórios à parte: no do modo estrutura, `mudancas-de-estrutura.md` e `.csv`, `perfil-anterior.txt`, `perfil-atual.txt` e `linhas-nao-lidas.csv`; no do gabarito, `nota-do-refazer.md`, que compara o mês refeito com o aprovado célula a célula, mais `celulas-que-nao-batem.csv`, `diferencas-de-formato.csv`, `so-no-entregue.csv`, `so-no-refeito.csv` e `linhas-nao-lidas.csv` | **Pronta** |
| `registro-de-anomalia` | No formato que a sua empresa já usa, não num formato novo: `mapa-de-campos.md`, `linha-para-colar.csv` e `linha-para-colar.txt` para colar no seu sistema, `campos-pendentes.csv`, `reincidencia.csv` com o mesmo desvio já registrado antes, `historico-nao-varrido.csv` e `procedencia.txt`. Com `--modelo-em-linhas` os dois da linha viram um só, `linha-para-colar.md`. Com `--so-mapa` saem três. Com `--gabarito` sai também `conferencia-do-gabarito.md` | **Pronta** |
| `padrao-conferido-contra-norma` | Num diretório com a data: `nota-de-leitura.md`, `furos.csv` item por item com o que falta e onde, `a-conferir-na-sua-edicao.csv` com tudo que a skill não pode provar, `matriz-cobertura.csv`, e o `plano-de-correcao.md` com a pergunta pronta ao dono do documento. Com mais de um procedimento na rodada, mais `consolidado-da-rodada.csv` e `cobertura-por-clausula.csv`, que dizem quais cláusulas passaram por todos os documentos | **Pronta** |
| `linha-de-base-antes-de-automatizar` | Num diretório com a data: `plano-de-medicao.md`, `livro-caixa.csv`, `observacoes-fora-da-conta.csv` e a `ficha-do-antes.md`, que só sai com os seis requisitos atendidos: valor medido, data das observações, método de medição, esforço em horas, validador nomeado e a conferência contra um número que alguém já tinha. Na rodada da divergência, que acontece depois com o motor pronto: `cobertura-do-gabarito.md`, `divergencias-contra-gabarito.csv` e `linhas-fora-da-comparacao.csv` | **Pronta** |
| `indice-do-acervo-da-area` | O índice da pasta de documentos da área, um resumo por documento, com data, assunto e o caminho do arquivo de origem. Antes dele, o inventário da árvore inteira e o `termos-por-documento.csv`, com a data e as entidades de cada documento apuradas por máquina na sua própria estação, que é o que faz a pasta ficar pesquisável sem esperar leitura de tudo | **Pronta** |

**A regra que vale para as dez.** Toda skill roda primeiro sobre um caso que você já fez à mão, compara com o seu resultado e só é usada no trabalho de verdade depois que bater. Não é formalidade: é o que separa uma ferramenta de um chute bem formatado. Na extração e no registro de anomalia, essa liberação é registrada em arquivo, em `~/.kit-industrial/`, e sobrevive ao fim da conversa. Nas outras oito ela vale para a conversa em que você a fez.

---

## O que não subir

Antes de colar ou abrir um arquivo, olhe o que tem dentro dele. Estas cinco classes de dado ficam fora, e cada uma tem uma saída que funciona.

| Não sobe | O que fazer no lugar |
|---|---|
| CPF, RG, matrícula, nome de pessoa em avaliação, atestado, dado de saúde | Troque cada nome por `[pessoa 1]`, `[pessoa 2]` antes de colar, e guarde a correspondência em um arquivo que fica só na sua máquina. Para o registro de anomalia e para a linha de base, isso não muda nada: elas precisam saber que existe um dono, não quem é |
| Folha de pagamento, salário, bônus, remuneração individual | Não sobe, em nenhum modo. Se o assunto é custo, use custo por hora de área ou por equipamento, sem pessoa identificada |
| Preço de fornecedor identificado, proposta comercial recebida, tabela de desconto | Troque o nome por `Fornecedor A`, `Fornecedor B`, ou trabalhe com índice relativo, tomando o menor valor como base 100 |
| Dado de cliente identificado: pedido, endereço, volume, reclamação com o nome junto | Use o modo derivado: só a linha de cabeçalho e as linhas em questão, com o identificador substituído |
| Projeto sob sigilo, desenho, especificação de produto não lançado, contrato | Rode pelo script local, que não envia conteúdo. Quando não houver script, descreva o formato (quantos dígitos, que pontuação, que tipo de campo) em vez do conteúdo |

A pergunta que as skills fazem antes de abrir arquivo cobre as cinco classes da tabela. A segunda linha tem tratamento próprio: folha de pagamento, salário e remuneração individual não entram em nenhum modo, e a skill pede o arquivo sem a coluna de remuneração em vez de abrir. A palavra bônus não aparece nas skills: se o seu arquivo tiver essa coluna, trate como remuneração individual.

A pergunta também depende de o material ainda não ter sido aberto. Documento já colado na conversa não volta atrás: nesse caso a skill diz o que identificou em vez de perguntar, e o modo derivado passa a proteger o arquivo gravado, não a colagem.

**Cada skill traz a sua seção de modo de dado sensível, e quase todas têm modo em que o conteúdo não sai da sua máquina.** Na conferência, você roda o script e cola só a nota de normalização, que por construção não traz valor de célula. Na ficha da área, o script imprime só os nomes de campo do export, e recusa a linha que tem cara de dado. No comparativo de cotações, o script roda local e `--anonimizar-fornecedor` substitui o nome do fornecedor por rótulo em todo texto do diretório, inclusive dentro da linha bruta e do nome do arquivo de origem, menos no `perguntas-aos-fornecedores.md`, que é a mensagem que se envia ao fornecedor e não acompanha a rodada compartilhada. Na triagem de e-mail, `--sem-corpo` lê só cabeçalho e assunto.

A exceção é a extração de documento, e ela diz isso na cara: a leitura do documento é feita pelo modelo, então o documento sobe. O script dela mede e confere depois da leitura. Documento sob sigilo não entra nessa skill.

Quando você não souber se pode, trate como se não pudesse e use o modo derivado. A decisão sobre o que pode sair da empresa é da sua empresa.

---

Claude é marca da Anthropic, que não tem vínculo com este kit.

Nenhuma skill deste kit substitui responsabilidade técnica, decisão de auditoria ou aprovação de documento no sistema de gestão da sua empresa. Todo arquivo que sai daqui é rascunho até alguém competente ler, corrigir e assinar. Os arquivos trazem esse aviso no rodapé, e ele existe por um motivo: o kit acelera a escrita, não transfere a responsabilidade.
