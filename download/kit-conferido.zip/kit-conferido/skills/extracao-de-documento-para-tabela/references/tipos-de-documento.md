# Tipos de documento: o que esperar de cada um

Cada item traz o que esperar, onde falha, a taxa de acerto a exigir antes de confiar, e o
que fazer antes de rodar. A taxa é a parte que costuma faltar, e é a que decide se o
documento entra ou não na primeira leva.

**Os números desta página não são medição de ferramenta nenhuma.** São a barra que você
exige da sua própria medição, no seu documento, contra o seu gabarito. Nenhum número aqui
substitui a rodada de gabarito, e a única taxa que vale é a que saiu do seu
`medicao-contra-gabarito.md`.

Ordem de trabalho: primeiro o grupo 4 (o documento tem campo nomeado e posição fixa?),
depois o grupo 1 (ele nasceu digital?), depois o grupo 2 (o que o escâner fez com ele?), e
por último o grupo 3, que é onde se perde a rodada.

---

## Quantos campos medir para a taxa significar alguma coisa

Taxa de acerto sobre 10 campos não diz nada. Uma leitura certa a mais ou a menos move o
número em 10 pontos.

**Regra de bolso: pelo menos 60 campos comparáveis, ou 3 documentos, o que for maior.** Com
60 campos e 1 erro, a taxa é 98,3%, e a taxa real do processo está em algum lugar entre 91%
e 100%. Isso é ordem de grandeza da incerteza, não inferência estatística, e serve para uma
coisa só: impedir que 100% em 8 campos seja lido como processo confiável.

A contagem é por campo comparado, não por documento. Uma ficha de apontamento com 6 linhas
e 5 campos por linha dá 30 campos comparáveis. Duas fichas dão 60, e aí a medição começa a
valer.

**Contagem que importa mais que a taxa: erros acima do limiar.** Erro abaixo do limiar sai
na lista de conferência e a pessoa acha. Erro acima do limiar entra na planilha com cara de
certo. Uma rodada com 97% de acerto e 2 erros acima do limiar é pior que uma rodada com 92%
e nenhum, porque a primeira mente e a segunda avisa.

---

## Grupo 1: o documento nasceu digital

### 1.1 PDF nativo, com texto selecionável

*Esperar:* leitura fiel do texto. Aqui não existe erro de leitura de caractere, existe erro
de recorte: o campo certo lido do lugar errado.

*Falha:* coluna que se parte entre duas páginas, cabeçalho repetido no meio da tabela lido
como registro, nota de rodapé colada no último valor, texto em duas colunas lido em uma
coluna só, e a linha de total lida como se fosse item.

*Exigir:* 100% nos campos de cabeçalho e 99% ou mais nos campos do corpo. Taxa menor que
isso em PDF nativo quase nunca é problema de leitura: é esquema de campos errado, ou
granularidade errada (uma linha por item quando o documento tem uma linha por item e lote).
Corrija o esquema e meça de novo, em vez de aceitar a taxa.

*Antes de rodar:* confirme se o texto é mesmo selecionável. Abra o PDF e tente selecionar
uma palavra. Se não selecionar, o arquivo é imagem dentro de PDF, e o caso é o 2.1.

### 1.2 Tabela que atravessa várias páginas

*Esperar:* que o número de linhas da saída bata com o número de linhas do documento, e isso
tem que ser conferido, não presumido.

*Falha:* a última linha de uma página e a primeira da seguinte viram uma só; o cabeçalho
repetido em cada página entra como registro; a numeração de item reinicia por página e a
chave duplica.

*Exigir:* contagem de linhas idêntica, página por página, antes de olhar qualquer valor.
Conte as linhas da página 1 no documento e na saída. Se não bater na página 1, pare.

*Antes de rodar:* diga quantas páginas o documento tem e quantas linhas tem cada uma. Sem
isso não existe fechamento.

### 1.3 Planilha impressa em PDF

*Esperar:* o pior dos dois mundos. O dado era tabular, virou imagem de tabela, e o original
ainda existe em algum lugar.

*Falha:* zero à esquerda que já tinha sido perdido na planilha, valor cortado pela largura
da coluna (`#####` ou texto truncado com reticências), casa decimal escondida pela
formatação de exibição.

*Exigir:* nada. Este documento não se extrai, se pede. Peça o arquivo original.

*Antes de rodar:* pergunte quem imprimiu. Em quase todo caso a planilha ainda existe, e
extrair dela é trabalho perdido.

---

## Grupo 2: o documento foi impresso e escaneado

### 2.1 Escaneado de original impresso, boa qualidade

*Esperar:* leitura boa em texto, e cuidado em número.

*Falha:* os pares clássicos, `0` e `O`, `1` e `l` e `I`, `5` e `S`, `8` e `B`, `6` e `G`.
Em texto o contexto corrige. Em código e em número não existe contexto que corrija, e o
erro passa.

*Exigir:* 98% ou mais em campo de texto. Em campo numérico e em código, a taxa não libera
nada: todo número lido de imagem vai para conferência, sempre, por lei de ferro.

*Antes de rodar:* confira a resolução. Escaneado abaixo de 200 dpi transforma dígito em
mancha, e nenhuma medição conserta isso depois.

### 2.2 Escaneado torto, com sombra, ou cópia de cópia

*Esperar:* leitura parcial, com regiões inteiras ilegíveis.

*Falha:* a sombra da lombada come a primeira coluna; a inclinação faz a leitura pular de
linha no meio da tabela e casar o valor de uma linha com a chave de outra. Este é o pior
modo de falha do grupo, porque a saída sai completa e errada, sem nenhum campo vazio para
denunciar.

*Exigir:* antes da taxa, o teste de deslocamento: escolha três linhas em pontos distantes
do documento (primeira, meio, última) e confira a linha inteira contra o papel. Uma linha
deslocada invalida a rodada inteira, não só aquela linha.

*Antes de rodar:* escaneie de novo. Custa menos que a conferência que o escaneado ruim
exige, e é a única correção que funciona.

### 2.3 Formulário impresso preenchido a máquina

*Esperar:* o melhor caso do grupo 2. Posição fixa, campo nomeado, preenchimento legível.

*Falha:* campo em branco no formulário que a leitura preenche com o rótulo do campo, ou com
o valor do campo de cima. Campo marcado com X em caixa de seleção lido como texto.

*Exigir:* 99% em campo de texto, e a conferência de que todo campo em branco no papel saiu
em branco na tabela. Este segundo teste é mais importante que a taxa.

*Antes de rodar:* liste quais campos estão em branco no papel, antes de ler a saída. É a
única forma de pegar campo preenchido por inferência.

---

## Grupo 3: manuscrito

**Este grupo é onde a extração falha, e nenhuma preparação elimina o problema.** Letra de
pessoa não tem fonte, não tem alinhamento e não tem espaçamento constante. Duas pessoas
escrevem o mesmo dígito de formas diferentes, e a mesma pessoa escreve diferente na sexta à
tarde.

Regra do grupo: **não se declara taxa de manuscrito antes de medir.** Quem promete número
antes da rodada de gabarito está chutando. A rodada de gabarito não é recomendação aqui, é
condição de uso.

Quando a leitura falhar, o caminho é declarado e não é desistir da skill: transcreva à mão
os campos que falharam, e use a skill para o resto. Uma ficha com 5 campos por linha em que
só a hora de início falha continua economizando 4 campos por linha.

Caminho registrado em campo para quando a leitura não fecha: passar a mesma imagem por um
segundo modelo de visão e comparar as duas leituras. Onde as duas concordam, a confiança
sobe. Onde divergem é exatamente onde está o erro, e é o que vai para conferência. Isso
dobra o trabalho de leitura e não dobra o de conferência, que é onde está o tempo.

### 3.1 Foto de folha preenchida à mão

*Esperar:* campo estruturado (data, hora, número de ordem) melhor que texto corrido. Texto
corrido manuscrito é o pior caso do kit inteiro.

*Falha:* dígito antes de tudo. `1` e `7` com corte europeu, `4` aberto lido como `9`, `0`
cortado lido como `8`. Depois, a linha em branco que não é ausência: a pessoa escreveu
"idem" ou fez uma seta para cima, e isso não é valor, é referência à linha anterior.
Repetir o valor de cima é inventar dado.

*Exigir:* medição campo a campo, com taxa separada por campo. A taxa média esconde o caso
real, que é 99% em data e 70% em número de ordem. O que decide o uso é a taxa do pior
campo, não a média.

*Antes de rodar:* fotografe reto, com a folha inteira no quadro, sem sombra da própria mão,
e de perto o bastante para o dígito ocupar espaço. Foto de folha inteira tirada de pé, a um
metro, não tem pixel suficiente no dígito.

### 3.2 Foto de quadro branco

*Esperar:* captura do que está escrito, sem estrutura. Quadro não é tabela: é texto,
seta, círculo e rabisco, com ordem de leitura ambígua.

*Falha:* a ordem. O que está à direita pode ser a continuação do que está à esquerda, ou
outro assunto. Seta e círculo carregam significado que não vira campo.

*Exigir:* não exija taxa de campo. Trate a saída como transcrição a conferir por inteiro, e
não como tabela. Quadro branco vira lista de itens, e a estruturação em campos é decisão da
pessoa, na hora, com ela olhando a foto.

*Antes de rodar:* fotografe sem reflexo. Reflexo de luminária apaga trecho inteiro, e o
trecho apagado não aparece como falta: some.

### 3.3 Assinatura, rubrica e carimbo

*Esperar:* a informação de que existe, não o conteúdo.

*Falha:* tentar ler nome de assinatura. Não se lê.

*Exigir:* nada além de presente ou ausente. O campo sai como `assinado` ou vazio, e o nome
vem de outro lugar, tipicamente do campo digitado ao lado ou do próprio carimbo, quando o
carimbo é legível.

*Antes de rodar:* decida se nome de pessoa pode sair da empresa. Quase sempre não pode, e
aí o campo nem entra no esquema.

---

## Grupo 4: layout fixo com campo nomeado

### 4.1 Certificado de calibração, de qualidade ou de material

*Esperar:* o melhor caso do kit. Campo nomeado, posição estável dentro de um mesmo emissor,
valor numérico com unidade explícita.

*Falha:* a unidade. O mesmo campo sai em `mm` num emissor e em `pol` em outro, e a tabela
junta os dois sem avisar. Segunda falha: a validade, que às vezes é data e às vezes é prazo
em meses contado da emissão.

*Exigir:* 99% nos campos de identificação (número do certificado, emissor, data) e 100% na
presença de unidade. Campo de medida sem unidade na tabela é campo inutilizável, mesmo com
o número certo.

*Antes de rodar:* separe os certificados por emissor. Um esquema por emissor lê melhor que
um esquema que tenta servir a todos, e a comparação entre emissores é trabalho da tabela
pronta, não da leitura.

### 4.2 Conhecimento de transporte e documento fiscal

*Esperar:* campo nomeado, layout regulado, e um número de identificação longo que é a chave
de tudo.

*Falha:* a chave longa. Quarenta e quatro dígitos lidos de imagem erram em um dígito e a
chave inteira deixa de existir no sistema. Peso bruto contra peso líquido trocados. Valor
total da nota contra valor dos produtos.

*Exigir:* conferência de 100% das chaves longas, sem exceção e sem amostragem. Chave longa
lida de imagem não tem taxa aceitável: tem conferência. Nos demais campos, 98%.

*Antes de rodar:* pergunte se o arquivo XML existe. Em documento fiscal eletrônico, quase
sempre existe, e ler o XML é leitura de dado estruturado, não extração de imagem. Extrair
do PDF quando o XML existe é criar risco de graça.

### 4.3 Ficha de apontamento de produção

*Esperar:* cabeçalho impresso ou manuscrito, e corpo manuscrito em grade. O caso mais comum
de todos, e um caso do grupo 3 com moldura de grade, o que ajuda.

*Falha:* hora. Formato livre é a regra: `8h`, `08:00`, `8 as 10`, `8-10`. A hora de fim em
branco na última linha do turno, porque a pessoa saiu. Intervalo que atravessa a meia-noite
no turno da noite. E o número da ordem de produção, que é dígito manuscrito, e por isso é o
campo que decide se a ficha serve.

*Exigir:* taxa por campo, com o número da ordem medido à parte. Ordem de produção com taxa
abaixo de 90% derruba o uso: a linha inteira vai para a ordem errada, e o relatório fica
convincente e falso.

*Antes de rodar:* decida o que fazer com hora vazia e com intervalo que atravessa turno,
antes de ler. Decidido depois, vira ajuste caso a caso, e caso a caso é como a tabela ganha
duas regras diferentes dentro da mesma coluna.

### 4.4 Desenho técnico com carimbo

*Esperar:* leitura boa do carimbo, e nada do corpo do desenho.

*Falha:* achar que o corpo do desenho vira campo. Cota, tolerância geométrica e vista não
são tabela. A lista de material, quando existe no próprio desenho, é tabela e se lê.

*Exigir:* 99% no carimbo (código, revisão, data, responsável). A revisão é o campo crítico:
desenho lido na revisão errada contamina tudo o que vier depois.

*Antes de rodar:* confirme que o que se quer é o carimbo e a lista de material. Se o pedido
é ler cota, a resposta é não, e o caminho é o arquivo nativo do desenho.

---

Gerado com apoio de IA a partir de casos de extração registrados em campo. Revisar antes de
assinar. Não substitui responsabilidade técnica.
