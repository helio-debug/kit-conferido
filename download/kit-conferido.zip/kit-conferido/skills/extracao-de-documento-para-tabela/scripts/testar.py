#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do medir.py.

Python 3.8 ou superior, biblioteca padrao apenas. Gera cada caso em diretorio
temporario, roda o medir.py e compara codigo de saida, conteudo dos arquivos, saida
do terminal e mensagem de erro. Sai com codigo 1 se algum caso falhar.

Um caso por defeito conhecido, e um grupo inteiro para a mesma doenca: qualquer
caminho em que o script termine em sucesso tendo perdido, ignorado ou nao medido um
campo. Sao os casos marcados SILENCIO no nome.

Livro-caixa: cada caso roda com --livro-caixa livro.csv dentro do diretorio
temporario, nunca no livro-caixa de verdade da maquina. O livro comeca liberado
(tres documentos distintos, 72 campos, sem erro acima do limiar), a menos que o
proprio caso escreva outro conteudo em livro.csv.

    python3 ~/.claude/skills/extracao-de-documento-para-tabela/scripts/testar.py
"""

import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
MEDIR = AQUI / "medir.py"

LIVRO_CAB = ("data;tabela;gabarito;diretorio;campos_comparados;acertos;"
             "erros_acima_do_limiar;pior_campo;pior_taxa\n")
LIVRO_LIBERADO = LIVRO_CAB + (
    "2026-09-10;doc1.csv;g1.csv;gabarito-1;24;24;0;op;100,0%\n"
    "2026-09-11;doc2.csv;g2.csv;gabarito-2;24;24;0;op;100,0%\n"
    "2026-09-12;doc3.csv;g3.csv;gabarito-3;24;24;0;op;100,0%\n")
LIVRO_VAZIO = LIVRO_CAB
LIVRO_POUCOS_CAMPOS = LIVRO_CAB + (
    "2026-09-10;doc1.csv;g1.csv;gabarito-1;8;8;0;op;100,0%\n"
    "2026-09-11;doc2.csv;g2.csv;gabarito-2;8;8;0;op;100,0%\n"
    "2026-09-12;doc3.csv;g3.csv;gabarito-3;8;8;0;op;100,0%\n")
LIVRO_QUEBRADO = LIVRO_CAB + "2026-09-10;doc1.csv;g1.csv\n"


def tabela(linhas):
    cab = ("registro,op,op__confianca,op__origem,"
           "quantidade,quantidade__confianca,quantidade__origem,"
           "operacao,operacao__confianca,operacao__origem")
    return cab + "\n" + "\n".join(linhas) + "\n"


# A origem sai no formato '<pagina>, <localizacao>' da SKILL.md, com virgula dentro
# e entre aspas, que e como ela chega de verdade.
LINHA_OK_1 = ('1,4182,0.96,"p1, grade linha 3",120,0.93,"p1, grade linha 3",'
              'corte,0.95,"p1, grade linha 3"')
LINHA_OK_2 = ('2,4183,0.97,"p1, grade linha 4",80,0.91,"p1, grade linha 4",'
              'solda,0.94,"p1, grade linha 4"')

CASOS = []


def caso(nome, arquivos, args, esperado, contem=None, nao_contem=None,
         erro_contem=None, saida_contem=None, saida_nao_contem=None):
    CASOS.append({"nome": nome, "arquivos": arquivos, "args": args,
                  "esperado": esperado, "contem": contem or [],
                  "nao_contem": nao_contem or [], "erro_contem": erro_contem or [],
                  "saida_contem": saida_contem or [],
                  "saida_nao_contem": saida_nao_contem or []})


# ---------------------------------------------------------------- contrato

caso("tabela limpa, nada pendente, codigo 0",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2])},
     ["--tabela", "t.csv", "--saida", "out"], 0,
     contem=[("out/a-conferir.csv", "registro;campo;valor_lido")])

caso("campo abaixo do limiar vai para a-conferir, codigo 2",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0.60,"p1, grade linha 4",80,0.91,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 2,
     contem=[("out/a-conferir.csv", "abaixo_do_limiar")])

caso("numero de imagem acima do limiar vai para a-conferir, codigo 2",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2])},
     ["--tabela", "t.csv", "--saida", "out", "--campos-numericos", "quantidade"], 2,
     contem=[("out/a-conferir.csv", "numero_lido_de_imagem")])

caso("campo ausente sai com confianca zero e entra na lista, codigo 2",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0.97,"p1, grade linha 4",,0,ausente na folha,'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 2,
     contem=[("out/a-conferir.csv", "ausente_no_documento")])

caso("valor sem origem derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0.97,,80,0.91,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     contem=[("out/violacoes-do-contrato.csv", "campo_sem_origem")],
     nao_contem=[("out/a-conferir.csv", None)])

caso("coluna de valor sem confianca e sem origem derruba a rodada, codigo 3",
     {"t.csv": ('registro,op,op__confianca,op__origem,turno\n'
                '1,4182,0.96,"p1, grade linha 3",A\n')},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     contem=[("out/violacoes-do-contrato.csv", "campo_sem_confianca_ou_origem")])

caso("campo vazio com confianca alta derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0.97,"p1, grade linha 4",,0.90,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     contem=[("out/violacoes-do-contrato.csv",
              "ausente_com_confianca_diferente_de_zero")])

caso("campo vazio sem marca de ausencia na origem derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0.97,"p1, grade linha 4",,0,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     contem=[("out/violacoes-do-contrato.csv", "ausente_sem_marca_de_ausencia")])

caso("valor preenchido com confianca zero derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0,"p1, grade linha 4",80,0.91,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     contem=[("out/violacoes-do-contrato.csv", "confianca_zero_com_valor")])

caso("registro repetido derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_1])},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     contem=[("out/violacoes-do-contrato.csv", "registro_duplicado")])

caso("campo numerico inexistente derruba a rodada em vez de ser ignorado, codigo 3",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2])},
     ["--tabela", "t.csv", "--saida", "out", "--campos-numericos", "qtde"], 3)

caso("diretorio que ja existe sem --forcar e erro de entrada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1]), "out/marcador.txt": "ja existia"},
     ["--tabela", "t.csv", "--saida", "out"], 3)

caso("confianca com virgula decimal e aceita, codigo 2",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,"0,70","p1, grade linha 4",80,0.91,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 2,
     contem=[("out/a-conferir.csv", "abaixo_do_limiar")])

caso("campo fora por decisao nao entra na lista de conferencia, codigo 0",
     {"t.csv": tabela([
         '1,4182,0.96,"p1, grade linha 3",120,0.93,"p1, grade linha 3",,0,'
         'ausente: tapado na origem',
         '2,4183,0.97,"p1, grade linha 4",80,0.91,"p1, grade linha 4",,0,'
         'ausente: tapado na origem'])},
     ["--tabela", "t.csv", "--saida", "out", "--campos-fora", "operacao"], 0,
     nao_contem=[("out/nao-existe.csv", None)])

caso("campo fora por decisao que saiu preenchido derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2])},
     ["--tabela", "t.csv", "--saida", "out", "--campos-fora", "operacao"], 3,
     contem=[("out/violacoes-do-contrato.csv", "campo_fora_com_valor")])

caso("campo em --campos-fora e em --campos-numericos ao mesmo tempo, codigo 3",
     {"t.csv": tabela([LINHA_OK_1])},
     ["--tabela", "t.csv", "--saida", "out", "--campos-fora", "quantidade",
      "--campos-numericos", "quantidade"], 3)

# ---------------------------------------------------------------- gabarito

caso("gabarito identico e nada pendente, codigo 0",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "registro,op,quantidade,operacao\n1,4182,120,corte\n2,4183,80,solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 0,
     contem=[("out/medicao-contra-gabarito.md", "100.0%")])

caso("gabarito com divergencia acima do limiar, codigo 1",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "registro,op,quantidade,operacao\n1,4182,12,corte\n2,4183,80,solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 1,
     contem=[("out/divergencias-do-gabarito.csv", "12"),
             ("out/medicao-contra-gabarito.md", "Erros acima do limiar: 1")])

caso("registro que existe so no gabarito e divergencia, codigo 1",
     {"t.csv": tabela([LINHA_OK_1]),
      "g.csv": "registro,op,quantidade,operacao\n1,4182,120,corte\n2,4183,80,solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 1,
     contem=[("out/divergencias-do-gabarito.csv", "registro_so_no_gabarito")])

caso("campo fora por decisao nao e comparado contra o gabarito, codigo 0",
     {"t.csv": tabela([
         '1,4182,0.96,"p1, grade linha 3",120,0.93,"p1, grade linha 3",,0,'
         'ausente: tapado na origem']),
      "g.csv": "registro,op,quantidade,operacao\n1,4182,120,corte\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out",
      "--campos-fora", "operacao"], 0,
     contem=[("out/medicao-contra-gabarito.md",
              "Colunas do gabarito nao comparadas por decisao declarada | 1")])

# ------------------------------------------ SILENCIO: campo que some da medicao

caso("SILENCIO: coluna do gabarito que o esquema nao tem derruba a rodada, codigo 3",
     {"t.csv": ('registro,op,op__confianca,op__origem\n'
                '1,4182,0.96,"p1, grade linha 3"\n'),
      "g.csv": "registro,op,hora_fim,quantidade\n1,4182,15:30,120\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 3,
     erro_contem=["esquecido o campo inteiro", "hora_fim", "quantidade"],
     nao_contem=[("out/medicao-contra-gabarito.md", None)],
     saida_nao_contem=["FECHAMENTO"])

caso("SILENCIO: campo do esquema sem coluna no gabarito derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "registro,OP,Qtde,Operacao\n1,4182,120,corte\n2,4183,80,solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 3,
     erro_contem=["nao tem coluna para os campos do esquema",
                  "que o esquema da extracao nao tem"],
     nao_contem=[("out/medicao-contra-gabarito.md", None)])

caso("gabarito com outro nome de coluna, mapeado, acha o erro real, codigo 1",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "registro,OP,Qtde,Operacao\n1,4182,120,corte\n2,4183,88,solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out",
      "--gabarito-colunas", "op:OP,quantidade:Qtde,operacao:Operacao"], 1,
     contem=[("out/divergencias-do-gabarito.csv", "88"),
             ("out/medicao-contra-gabarito.md", "quantidade | Qtde")])

caso("SILENCIO: coluna do gabarito declarada em --nao-comparar aparece no relatorio, "
     "codigo 0",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": ("registro,op,quantidade,operacao,observacao\n"
                "1,4182,120,corte,x\n2,4183,80,solda,y\n")},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out",
      "--nao-comparar", "observacao"], 0,
     contem=[("out/medicao-contra-gabarito.md",
              "Colunas do gabarito nao comparadas por decisao declarada | 1 | "
              "observacao")])

caso("SILENCIO: linha com mais colunas que o cabecalho derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1,
                       "2,4183,0.97,p1, grade linha 4,80,0.91,p1 linha 4,"
                       "solda,0.94,p1 linha 4"])},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     erro_contem=["colunas e o cabecalho tem", "virgula dentro de uma celula sem aspas"])

caso("SILENCIO: coluna repetida no cabecalho da tabela derruba a rodada, codigo 3",
     {"t.csv": ('registro,op,op__confianca,op__origem,op\n'
                '1,4182,0.96,"p1, grade linha 3",4182\n')},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     erro_contem=["coluna repetida", "sobrescreve"])

caso("SILENCIO: registro repetido no gabarito derruba a rodada, codigo 3",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": ("registro,op,quantidade,operacao\n"
                "1,4182,120,corte\n1,4183,80,solda\n")},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 3,
     erro_contem=["registro repetido", "some da"])

caso("SILENCIO: coluna sem nome no cabecalho derruba a rodada, codigo 3",
     {"t.csv": ('registro,op,op__confianca,op__origem,\n'
                '1,4182,0.96,"p1, grade linha 3",\n')},
     ["--tabela", "t.csv", "--saida", "out"], 3,
     erro_contem=["coluna sem nome"])

caso("gabarito sem a coluna registro para sozinho, antes do fechamento, codigo 3",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "OP;Qtde;Operacao\n4182;120;corte\n4183;80;solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 3,
     erro_contem=["precisa de uma coluna chamada 'registro'",
                  "--gabarito-registro-por-ordem"],
     nao_contem=[("out/a-conferir.csv", None)],
     saida_nao_contem=["FECHAMENTO"])

caso("gabarito pareado pela ordem das linhas, codigo 0",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "op,quantidade,operacao\n4182,120,corte\n4183,80,solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out",
      "--gabarito-registro-por-ordem"], 0,
     contem=[("out/medicao-contra-gabarito.md", "pela ordem das linhas")])

caso("menos de 60 campos comparados nao decide nada, e o relatorio diz, codigo 0",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "registro,op,quantidade,operacao\n1,4182,120,corte\n2,4183,80,solda\n"},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 0,
     contem=[("out/medicao-contra-gabarito.md", "Esta taxa nao decide nada")])

# ------------------------------------------ lei de ferro 4 e lista de trabalho

caso("numero de imagem abaixo do limiar sai com os dois motivos, codigo 2",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0.97,"p1, grade linha 4",80,0.60,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out", "--campos-numericos", "quantidade"], 2,
     contem=[("out/a-conferir.csv", "abaixo_do_limiar+numero_lido_de_imagem")])

caso("para-lancar.csv sai pronto para colar, com a linha pendente marcada, codigo 2",
     {"t.csv": tabela([LINHA_OK_1,
                       '2,4183,0.60,"p1, grade linha 4",80,0.91,"p1, grade linha 4",'
                       'solda,0.94,"p1, grade linha 4"'])},
     ["--tabela", "t.csv", "--saida", "out"], 2,
     contem=[("out/para-lancar.csv",
              "registro;op;quantidade;operacao;linha_pendente;campos_pendentes"),
             ("out/para-lancar.csv", "1;4182;120;corte;nao;"),
             ("out/para-lancar.csv", "2;4183;80;solda;sim;op")])

caso("--forcar apaga o resultado da rodada anterior antes de gravar, codigo 3",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "ruim.csv": tabela([LINHA_OK_1,
                          '2,4183,0.97,,80,0.91,"p1, grade linha 4",'
                          'solda,0.94,"p1, grade linha 4"'])},
     [["--tabela", "t.csv", "--saida", "out"],
      ["--tabela", "ruim.csv", "--saida", "out", "--forcar"]], 3,
     contem=[("out/violacoes-do-contrato.csv", "campo_sem_origem")],
     nao_contem=[("out/a-conferir.csv", None), ("out/para-lancar.csv", None)])

# ------------------------------------------ livro-caixa, a porta da lei de ferro 2

caso("sem rodada de gabarito registrada, a rodada real nao e liberada, codigo 4",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]), "livro.csv": LIVRO_VAZIO},
     ["--tabela", "t.csv", "--saida", "out"], 4,
     saida_contem=["NAO LIBERADO", "nenhuma rodada de gabarito registrada"],
     contem=[("out/para-lancar.csv", "Nao lance esta planilha")])

caso("tres rodadas limpas com menos de 60 campos nao liberam, codigo 4",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]), "livro.csv": LIVRO_POUCOS_CAMPOS},
     ["--tabela", "t.csv", "--saida", "out"], 4,
     saida_contem=["NAO LIBERADO", "faltam 36 campo(s) comparado(s)"])

caso("livro-caixa ilegivel nao vira livro vazio e nao libera, codigo 4",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]), "livro.csv": LIVRO_QUEBRADO},
     ["--tabela", "t.csv", "--saida", "out"], 4,
     saida_contem=["INDETERMINADO", "problema no livro-caixa"])

caso("a rodada de gabarito grava a propria linha no livro-caixa, codigo 0",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]),
      "g.csv": "registro,op,quantidade,operacao\n1,4182,120,corte\n2,4183,80,solda\n",
      "livro.csv": LIVRO_VAZIO},
     ["--tabela", "t.csv", "--gabarito", "g.csv", "--saida", "out"], 0,
     contem=[("livro.csv", "t.csv;g.csv;out;6;6;0")])

caso("livro-caixa liberado deixa a rodada real passar, codigo 0",
     {"t.csv": tabela([LINHA_OK_1, LINHA_OK_2]), "livro.csv": LIVRO_LIBERADO},
     ["--tabela", "t.csv", "--saida", "out"], 0,
     saida_contem=["LIBERADO para o trabalho real"])


def rodar():
    falhas = []
    for c in CASOS:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            arquivos = dict(c["arquivos"])
            arquivos.setdefault("livro.csv", LIVRO_LIBERADO)
            for rel, conteudo in arquivos.items():
                p = base / rel
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(conteudo, encoding="utf-8")
            sequencia = c["args"] if isinstance(c["args"][0], list) else [c["args"]]
            r = None
            for args in sequencia:
                r = subprocess.run(
                    [sys.executable, str(MEDIR)] + args
                    + ["--livro-caixa", "livro.csv"],
                    cwd=str(base), capture_output=True, text=True)
            if r.returncode != c["esperado"]:
                falhas.append("%s: esperava codigo %d, veio %d\n%s%s"
                              % (c["nome"], c["esperado"], r.returncode, r.stdout,
                                 r.stderr))
                continue
            problema = None
            for rel, trecho in c["contem"]:
                p = base / rel
                if not p.is_file():
                    problema = "faltou o arquivo %s" % rel
                    break
                if trecho is not None and trecho not in p.read_text(encoding="utf-8"):
                    problema = "%s nao contem %r" % (rel, trecho)
                    break
            if not problema:
                for rel, _ in c["nao_contem"]:
                    if (base / rel).is_file():
                        problema = "o arquivo %s nao devia ter sido escrito" % rel
                        break
            if not problema:
                for trecho in c["erro_contem"]:
                    if trecho not in r.stderr:
                        problema = "a mensagem de erro nao contem %r: %s" % (trecho,
                                                                             r.stderr)
                        break
            if not problema:
                for trecho in c["saida_contem"]:
                    if trecho not in r.stdout:
                        problema = "o terminal nao mostrou %r" % trecho
                        break
            if not problema:
                for trecho in c["saida_nao_contem"]:
                    if trecho in r.stdout:
                        problema = "o terminal mostrou %r e nao devia" % trecho
                        break
            if problema:
                falhas.append("%s: %s" % (c["nome"], problema))
    print("%d casos, %d falha(s)" % (len(CASOS), len(falhas)))
    for f in falhas:
        print("FALHOU: %s" % f)
    return 1 if falhas else 0


if __name__ == "__main__":
    sys.exit(rodar())
