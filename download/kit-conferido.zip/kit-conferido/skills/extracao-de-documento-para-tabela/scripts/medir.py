#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
medir.py, da skill extracao-de-documento-para-tabela, do Kit Conferido.

Python 3.8 ou superior, biblioteca padrao apenas (argparse, csv, datetime, re, sys,
pathlib). Sem rede. Nao escreve nos arquivos de entrada.

O que ele NAO faz: nao le documento, nao faz OCR, nao extrai nada. A extracao e
feita pelo modelo, que escreve a tabela. Este script recebe a tabela pronta.

Quatro trabalhos, todos deterministicos e repetiveis:

  1. Contrato. Confere que todo campo carrega valor, confianca e origem, e escreve
     a-conferir.csv com o que precisa de olho humano, ordenado por confianca.

  2. Trabalho pronto. Escreve para-lancar.csv, a linha que se cola na planilha, com
     a marca de quais linhas ainda dependem de conferencia.

  3. Gabarito. Compara a tabela contra o resultado que a pessoa ja tinha feito a
     mao, campo a campo, mede a taxa de acerto por campo e a calibracao da
     confianca (quantos erros passaram acima do limiar).

  4. Livro-caixa. Registra cada rodada de gabarito em ~/.kit-industrial/
     gabaritos-extracao.csv e responde, em toda rodada, se a skill ja esta liberada
     para o trabalho real. A lei de ferro 2 deixa de depender da memoria da conversa.

REGRA ACIMA DE TODAS: nada sai da medicao em silencio. Campo que existe de um lado e
nao existe do outro derruba a rodada com codigo 3 ate ser declarado na linha de
comando. Descartar dado sem dizer e o unico defeito que este script trata como fatal,
porque a rodada de gabarito existe exatamente para pegar o campo que a extracao
esqueceu inteiro.

Formato de entrada, tabela.csv:
    registro, e depois, para cada campo X, as colunas X, X__confianca, X__origem.
Formato de entrada, gabarito.csv:
    registro, e uma coluna por campo, com o valor que a pessoa entregou na epoca.
    Nome de coluna diferente se mapeia com --gabarito-colunas. Gabarito sem a coluna
    registro se pareia pela ordem das linhas com --gabarito-registro-por-ordem.

Codigos de saida:
  0  contrato valido e nada pendente (no modo gabarito, tambem nenhuma divergencia)
  1  modo gabarito: ha divergencia contra o gabarito
  2  contrato valido, ha campo pendente de conferencia humana
  3  erro de entrada ou violacao do contrato de saida
  4  contrato valido, e a skill ainda nao esta liberada pelo gabarito (lei de ferro 2)
"""

import argparse
import csv
import datetime
import re
import sys
from pathlib import Path

SUF_CONF = "__confianca"
SUF_ORIG = "__origem"
COL_REG = "registro"
RODAPE = ("Gerado com apoio de IA a partir de {fonte}. Revisar antes de assinar. "
          "Nao substitui responsabilidade tecnica.")

LIVRO_PADRAO = str(Path.home() / ".kit-industrial" / "gabaritos-extracao.csv")
LIVRO_CAB = ["data", "tabela", "gabarito", "diretorio", "campos_comparados",
             "acertos", "erros_acima_do_limiar", "pior_campo", "pior_taxa"]
PISO_DOCUMENTOS = 3
PISO_CAMPOS = 60

SAIDAS = ("a-conferir.csv", "para-lancar.csv", "violacoes-do-contrato.csv",
          "medicao-contra-gabarito.md", "divergencias-do-gabarito.csv")


def erro(msg):
    sys.stderr.write("ERRO: %s\n" % msg)
    sys.exit(3)


def _sem_vazias_no_fim(l):
    fim = len(l)
    while fim > 0 and (l[fim - 1] or "").strip() == "":
        fim -= 1
    return l[:fim]


def _eh_comentario(l):
    enxuta = _sem_vazias_no_fim(l)
    return len(enxuta) == 1 and enxuta[0].strip().startswith("#")


def ler_csv(caminho):
    p = Path(caminho)
    if not p.is_file():
        erro("arquivo nao encontrado: %s" % caminho)
    dados = p.read_bytes()
    texto = None
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            texto = dados.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if texto is None:
        erro("nao foi possivel decodificar %s" % caminho)
    linhas_txt = texto.splitlines()
    if not linhas_txt:
        erro("arquivo vazio: %s" % caminho)
    primeira = linhas_txt[0]
    delim = ";" if primeira.count(";") > primeira.count(",") else ","
    bruto = list(csv.reader(linhas_txt, delimiter=delim))

    idx_cab = None
    for i, l in enumerate(bruto):
        if _eh_comentario(l) or not _sem_vazias_no_fim(l):
            continue
        idx_cab = i
        break
    if idx_cab is None:
        erro("arquivo sem cabecalho: %s" % caminho)

    cab = [c.strip() for c in bruto[idx_cab]]
    vazias = [str(i + 1) for i, c in enumerate(cab) if c == ""]
    if vazias:
        erro("o cabecalho de %s tem coluna sem nome na posicao %s. Apague a coluna vazia "
             "(costuma ser um separador sobrando no fim da linha) ou de um nome a ela. "
             "Coluna sem nome engole dado sem aviso" % (caminho, ", ".join(vazias)))
    repetidas = sorted({c for c in cab if cab.count(c) > 1})
    if repetidas:
        erro("o cabecalho de %s tem coluna repetida: %s. Com nome repetido a segunda "
             "coluna sobrescreve a primeira e o dado da primeira some sem aviso. "
             "Renomeie" % (caminho, ", ".join(repetidas)))

    linhas = []
    for i, l in enumerate(bruto):
        if i <= idx_cab or _eh_comentario(l):
            continue
        if not _sem_vazias_no_fim(l):
            continue
        if len(l) != len(cab):
            erro("a linha %d de %s tem %d colunas e o cabecalho tem %d. Causa comum: "
                 "virgula dentro de uma celula sem aspas, tipicamente na coluna de origem, "
                 "que sai no formato '<pagina>, <localizacao>'. Ponha a celula inteira "
                 "entre aspas duplas" % (i + 1, caminho, len(l), len(cab)))
        d = {}
        for j, nome in enumerate(cab):
            d[nome] = l[j].strip()
        linhas.append(d)
    return cab, linhas, enc, delim


def parse_conf(txt):
    t = (txt or "").strip().replace(",", ".")
    if t == "":
        return None
    try:
        return float(t)
    except ValueError:
        return None


def fmt_conf(v):
    return ("%.2f" % v).replace(".", ",")


def descobrir_campos(cab):
    base = [c for c in cab
            if c != COL_REG and not c.endswith(SUF_CONF) and not c.endswith(SUF_ORIG)]
    campos, soltas = [], []
    for c in base:
        if (c + SUF_CONF) in cab and (c + SUF_ORIG) in cab:
            campos.append(c)
        else:
            soltas.append(c)
    orfas = [c for c in cab
             if (c.endswith(SUF_CONF) or c.endswith(SUF_ORIG))
             and c.rsplit("__", 1)[0] not in campos]
    return campos, soltas, orfas


def norm(v, ignorar_caixa):
    t = re.sub(r"\s+", " ", (v or "").strip())
    if ignorar_caixa:
        t = t.casefold()
    return t


def escrever_csv(caminho, cabecalho, linhas, fonte, delim, extras=None):
    with open(caminho, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter=delim)
        w.writerow(cabecalho)
        for l in linhas:
            w.writerow(l)
        f.write("# " + RODAPE.format(fonte=fonte) + "\n")
        for linha in (extras or []):
            f.write("# " + linha + "\n")


# ---------------------------------------------------------------- livro-caixa

def ler_livro(caminho):
    """Devolve (rodadas, problemas). Livro ilegivel nunca vira livro vazio: os
    problemas sobem para o relatorio e a liberacao fica indeterminada."""
    p = Path(caminho)
    if not p.is_file():
        return [], []
    rodadas, problemas = [], []
    try:
        texto = p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        return [], ["o livro-caixa %s nao pode ser lido: %s" % (caminho, e)]
    linhas = [l for l in texto.splitlines() if l.strip() != ""]
    bruto = [l for l in csv.reader(linhas, delimiter=";") if not _eh_comentario(l)]
    if not bruto:
        return [], ["o livro-caixa %s existe e esta sem cabecalho" % caminho]
    cab = [c.strip() for c in bruto[0]]
    if cab != LIVRO_CAB:
        return [], ["o cabecalho do livro-caixa %s nao e o esperado. Esperado: %s"
                    % (caminho, ";".join(LIVRO_CAB))]
    for i, l in enumerate(bruto[1:], start=2):
        if len(l) != len(LIVRO_CAB):
            problemas.append("linha %d do livro-caixa tem %d colunas e o cabecalho tem %d"
                             % (i, len(l), len(LIVRO_CAB)))
            continue
        d = dict(zip(LIVRO_CAB, [c.strip() for c in l]))
        try:
            rodadas.append({
                "data": d["data"],
                "tabela": d["tabela"],
                "gabarito": d["gabarito"],
                "campos": int(d["campos_comparados"]),
                "erros": int(d["erros_acima_do_limiar"]),
            })
        except ValueError:
            problemas.append("linha %d do livro-caixa tem numero ilegivel em "
                             "campos_comparados ou erros_acima_do_limiar" % i)
    return rodadas, problemas


def gravar_no_livro(caminho, linha):
    p = Path(caminho)
    p.parent.mkdir(parents=True, exist_ok=True)
    novo = not p.is_file()
    with open(p, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter=";")
        if novo:
            w.writerow(LIVRO_CAB)
        w.writerow(linha)


def avaliar_livro(rodadas, problemas):
    info = {"registradas": len(rodadas), "documentos": 0, "campos": 0, "repetidos": [],
            "liberado": False, "situacao": ""}
    if problemas:
        info["situacao"] = ("INDETERMINADO: o livro-caixa nao pode ser lido. "
                            "Livro ilegivel nao libera nada")
        return info
    limpas = {}
    for r in rodadas:
        if r["erros"] != 0:
            continue
        chave = (r["tabela"], r["gabarito"])
        if chave in limpas:
            info["repetidos"].append("%s contra %s" % chave)
        limpas[chave] = r
    info["documentos"] = len(limpas)
    info["campos"] = sum(r["campos"] for r in limpas.values())
    faltas = []
    if not rodadas:
        faltas.append("nenhuma rodada de gabarito registrada")
    else:
        if info["documentos"] < PISO_DOCUMENTOS:
            faltas.append("faltam %d documento(s) distinto(s) sem erro acima do limiar"
                          % (PISO_DOCUMENTOS - info["documentos"]))
        if info["campos"] < PISO_CAMPOS:
            faltas.append("faltam %d campo(s) comparado(s) para o piso de %d"
                          % (PISO_CAMPOS - info["campos"], PISO_CAMPOS))
        if rodadas[-1]["erros"] != 0:
            faltas.append("a ultima rodada registrada teve erro acima do limiar")
    if faltas:
        info["situacao"] = "NAO LIBERADO: " + "; ".join(faltas)
    else:
        info["liberado"] = True
        info["situacao"] = "LIBERADO para o trabalho real"
    return info


def imprimir_livro(caminho, rodadas, problemas, info):
    print("")
    print("LIBERACAO PELO GABARITO (lei de ferro 2)")
    print("  livro-caixa ................................ %s" % caminho)
    print("  rodadas de gabarito registradas ............ %d" % info["registradas"])
    print("  documentos distintos sem erro acima do limiar %d (piso %d)"
          % (info["documentos"], PISO_DOCUMENTOS))
    print("  campos comparados nesses documentos ........ %d (piso %d)"
          % (info["campos"], PISO_CAMPOS))
    print("  situacao ................................... %s" % info["situacao"])
    for r in info["repetidos"]:
        print("  atencao: o mesmo par tabela/gabarito aparece mais de uma vez no livro "
              "e conta como um documento so: %s" % r)
    for p in problemas:
        print("  problema no livro-caixa: %s" % p)


# ---------------------------------------------------------------- gabarito

def preparar_gabarito(args, campos, fora):
    """Le e concilia o gabarito ANTES de qualquer medicao e antes do bloco de
    fechamento. Campo sem par, dos dois lados, derruba a rodada aqui."""
    cab_g, linhas_g, enc_g, delim_g = ler_csv(args.gabarito)
    por_ordem = args.gabarito_registro_por_ordem

    if not por_ordem and COL_REG not in cab_g:
        erro("o gabarito precisa de uma coluna chamada '%s', numerada na mesma ordem das "
             "linhas do documento. A planilha que a pessoa preencheu nao serve como esta: "
             "monte o CSV do gabarito com a coluna registro e uma coluna por campo do "
             "esquema. Sem a coluna registro, use --gabarito-registro-por-ordem para "
             "parear pela posicao da linha. Colunas encontradas: %s"
             % (COL_REG, ", ".join(cab_g)))

    colunas_g = [c for c in cab_g if c != COL_REG]
    if not colunas_g:
        erro("o gabarito nao tem nenhuma coluna de campo, so '%s'" % COL_REG)

    mapa = {}
    for par in [s.strip() for s in args.gabarito_colunas.split(",") if s.strip()]:
        if ":" not in par:
            erro("--gabarito-colunas espera pares campo:Coluna separados por virgula. "
                 "Recebido: %r" % par)
        c, col = [x.strip() for x in par.split(":", 1)]
        if c not in campos:
            erro("--gabarito-colunas cita campo que nao existe no esquema da tabela: %s. "
                 "Campos do esquema: %s" % (c, ", ".join(campos)))
        if col not in colunas_g:
            erro("--gabarito-colunas cita coluna que nao existe no gabarito: %s. "
                 "Colunas do gabarito: %s" % (col, ", ".join(colunas_g)))
        mapa[c] = col

    nao_comp = [s.strip() for s in args.nao_comparar.split(",") if s.strip()]
    desconhecidos = [n for n in nao_comp if n not in campos and n not in colunas_g]
    if desconhecidos:
        erro("--nao-comparar cita nome que nao existe nem no esquema da tabela nem no "
             "gabarito: %s. Campos do esquema: %s. Colunas do gabarito: %s"
             % (", ".join(desconhecidos), ", ".join(campos), ", ".join(colunas_g)))

    comparaveis = [c for c in campos if c not in fora and c not in nao_comp]
    par_campo, sem_par = {}, []
    for c in comparaveis:
        col = mapa.get(c) or (c if c in colunas_g else None)
        if col is None:
            sem_par.append(c)
        else:
            par_campo[c] = col
    usadas = set(par_campo.values()) | set(mapa.values())
    fora_do_esquema = [col for col in colunas_g
                       if col not in usadas and col not in nao_comp and col not in fora]

    partes = []
    if sem_par:
        partes.append("o gabarito nao tem coluna para os campos do esquema: %s. Renomeie a "
                      "coluna no gabarito, mapeie com --gabarito-colunas \"campo:Coluna\", "
                      "ou declare o campo em --nao-comparar" % ", ".join(sem_par))
    if fora_do_esquema:
        partes.append("o gabarito tem coluna que o esquema da extracao nao tem: %s. E o "
                      "caso que a rodada de gabarito existe para pegar: a extracao pode ter "
                      "esquecido o campo inteiro. Acrescente o campo ao esquema e extraia de "
                      "novo, ou declare a coluna em --nao-comparar"
                      % ", ".join(fora_do_esquema))
    if partes:
        erro(" | ".join(partes) + ". Campos do esquema: %s. Colunas do gabarito: %s"
             % (", ".join(campos), ", ".join(colunas_g)))

    if not par_campo:
        erro("nenhum campo restou para comparar contra o gabarito. Tabela: %s. "
             "Gabarito: %s" % (", ".join(campos), ", ".join(colunas_g)))

    if not por_ordem:
        vazios = sum(1 for l in linhas_g if l.get(COL_REG, "") == "")
        if vazios:
            erro("%d linha(s) do gabarito estao sem valor na coluna '%s'. Sem identificador "
                 "a linha some da comparacao" % (vazios, COL_REG))
        regs = [l.get(COL_REG, "") for l in linhas_g]
        dups = sorted({r for r in regs if regs.count(r) > 1})
        if dups:
            erro("o gabarito tem registro repetido: %s. Com registro repetido a segunda "
                 "linha sobrescreve a primeira e o que a pessoa transcreveu some da "
                 "medicao sem aviso" % ", ".join(dups))

    return {
        "linhas_g": linhas_g,
        "colunas_g": colunas_g,
        "par_campo": par_campo,
        "comparaveis": [c for c in comparaveis if c in par_campo],
        "por_ordem": por_ordem,
        "nao_comparados_esquema": [c for c in campos if c in nao_comp or c in fora],
        "nao_comparados_gabarito": [c for c in colunas_g if c in nao_comp or c in fora],
        "renomeados": [(c, col) for c, col in sorted(par_campo.items()) if c != col],
    }


def medir_gabarito(args, saida, campos, linhas, limiar, numericos, fonte, fora, gab):
    linhas_g = gab["linhas_g"]
    comuns = gab["comparaveis"]
    par_campo = gab["par_campo"]

    idx_e = {}
    for l in linhas:
        idx_e[l.get(COL_REG, "")] = l

    idx_g = {}
    extras_g = []
    if gab["por_ordem"]:
        regs_e = [l.get(COL_REG, "") for l in linhas]
        for i, lg in enumerate(linhas_g):
            if i < len(regs_e):
                idx_g[regs_e[i]] = lg
            else:
                extras_g.append("(linha %d do gabarito)" % (i + 2))
    else:
        for l in linhas_g:
            idx_g[l.get(COL_REG, "")] = l

    so_extracao = [r for r in idx_e if r not in idx_g]
    so_gabarito = [r for r in idx_g if r not in idx_e] + extras_g
    pareados = [r for r in idx_e if r in idx_g]

    div = []
    por_campo = {}
    cal = {"acima_certo": 0, "acima_errado": 0, "abaixo_certo": 0, "abaixo_errado": 0}

    for reg in sorted(pareados):
        le, lg = idx_e[reg], idx_g[reg]
        for campo in comuns:
            ve, vg = le.get(campo, ""), lg.get(par_campo[campo], "")
            conf = parse_conf(le.get(campo + SUF_CONF, "")) or 0.0
            ne, ng = norm(ve, args.ignorar_caixa), norm(vg, args.ignorar_caixa)
            c = por_campo.setdefault(campo, {"comparados": 0, "acertos": 0,
                                             "erros_acima": 0, "nao_lidos": 0,
                                             "vazios": 0})
            if ng == "" and ne == "":
                c["vazios"] += 1
                continue
            c["comparados"] += 1
            if ne == ng:
                c["acertos"] += 1
                classe = "igual"
            elif ne == "":
                classe = "nao_lido_pela_extracao"
                c["nao_lidos"] += 1
            elif ng == "":
                classe = "so_na_extracao"
            else:
                classe = "divergente"
            certo = (classe == "igual")
            if conf >= limiar:
                cal["acima_certo" if certo else "acima_errado"] += 1
                if not certo:
                    c["erros_acima"] += 1
            else:
                cal["abaixo_certo" if certo else "abaixo_errado"] += 1
            if not certo:
                div.append([reg, campo, ve, vg, fmt_conf(conf),
                            le.get(campo + SUF_ORIG, ""),
                            "sim" if conf >= limiar else "nao", classe])

    for reg in sorted(so_gabarito):
        div.append([reg, "(registro inteiro)", "", "", "0,00", "",
                    "nao", "registro_so_no_gabarito"])
    for reg in sorted(so_extracao):
        div.append([reg, "(registro inteiro)", "", "", "0,00", "",
                    "nao", "registro_so_na_extracao"])

    escrever_csv(saida / "divergencias-do-gabarito.csv",
                 ["registro", "campo", "valor_da_extracao", "valor_do_gabarito",
                  "confianca", "origem", "estava_acima_do_limiar", "classe"],
                 div, fonte, args.delimitador_saida)

    tot_comp = sum(c["comparados"] for c in por_campo.values())
    tot_ac = sum(c["acertos"] for c in por_campo.values())
    tot_vazios = sum(c["vazios"] for c in por_campo.values())
    tot_erros_acima = sum(c["erros_acima"] for c in por_campo.values())
    taxa = (100.0 * tot_ac / tot_comp) if tot_comp else 0.0
    ac_acima = cal["acima_certo"] + cal["acima_errado"]
    ac_abaixo = cal["abaixo_certo"] + cal["abaixo_errado"]
    tx_acima = (100.0 * cal["acima_certo"] / ac_acima) if ac_acima else 0.0
    tx_abaixo = (100.0 * cal["abaixo_certo"] / ac_abaixo) if ac_abaixo else 0.0

    pior_campo, pior_taxa = "-", ""
    for campo in comuns:
        c = por_campo.get(campo)
        if not c or c["comparados"] == 0:
            continue
        t = 100.0 * c["acertos"] / c["comparados"]
        if pior_taxa == "" or t < pior_taxa:
            pior_campo, pior_taxa = campo, t
    pior_txt = ("%.1f%%" % pior_taxa) if pior_taxa != "" else "sem comparacao"

    aviso_piso = None
    if tot_comp < PISO_CAMPOS:
        aviso_piso = ("Menos de %d campos comparados (%d). Esta taxa nao decide nada. A "
                      "regra esta em tipos-de-documento.md: pelo menos %d campos "
                      "comparaveis, ou 3 documentos, o que for maior."
                      % (PISO_CAMPOS, tot_comp, PISO_CAMPOS))

    lin = []
    lin.append("# Medicao contra gabarito")
    lin.append("")
    lin.append("Tabela medida: `%s`. Gabarito: `%s`." % (Path(args.tabela).name,
                                                         Path(args.gabarito).name))
    lin.append("Limiar de confianca: %s. Comparacao: espacos colapsados%s."
               % (fmt_conf(limiar),
                  ", caixa ignorada" if args.ignorar_caixa else ", caixa respeitada"))
    lin.append("Pareamento dos registros: %s."
               % ("pela ordem das linhas (--gabarito-registro-por-ordem)"
                  if gab["por_ordem"] else "pela coluna registro"))
    lin.append("Campos numericos declarados: %s."
               % (", ".join(numericos) if numericos else "nenhum"))
    lin.append("")
    lin.append("## Conciliacao do esquema com o gabarito")
    lin.append("")
    lin.append("Nenhum campo e descartado em silencio. Campo do esquema sem coluna no "
               "gabarito, e coluna do gabarito sem campo no esquema, derrubam a rodada "
               "com codigo 3 antes de qualquer medicao.")
    lin.append("")
    lin.append("| Item | Quantidade | Quais |")
    lin.append("|---|---|---|")
    lin.append("| Campos do esquema comparados | %d | %s |"
               % (len(comuns), ", ".join(comuns) if comuns else "nenhum"))
    lin.append("| Colunas do gabarito lidas com outro nome | %d | %s |"
               % (len(gab["renomeados"]),
                  ", ".join("%s = %s" % p for p in gab["renomeados"])
                  if gab["renomeados"] else "nenhuma"))
    lin.append("| Campos do esquema nao comparados por decisao declarada | %d | %s |"
               % (len(gab["nao_comparados_esquema"]),
                  ", ".join(gab["nao_comparados_esquema"])
                  if gab["nao_comparados_esquema"] else "nenhum"))
    lin.append("| Colunas do gabarito nao comparadas por decisao declarada | %d | %s |"
               % (len(gab["nao_comparados_gabarito"]),
                  ", ".join(gab["nao_comparados_gabarito"])
                  if gab["nao_comparados_gabarito"] else "nenhuma"))
    lin.append("| Campos do esquema sem par no gabarito | 0 | a rodada nao chega aqui com "
               "campo sem par |")
    lin.append("| Colunas do gabarito fora do esquema | 0 | a rodada nao chega aqui com "
               "coluna fora do esquema |")
    lin.append("")
    lin.append("## Cobertura")
    lin.append("")
    lin.append("| Item | Quantidade |")
    lin.append("|---|---|")
    lin.append("| Registros pareados | %d |" % len(pareados))
    lin.append("| Registros so no gabarito | %d |" % len(so_gabarito))
    lin.append("| Registros so na extracao | %d |" % len(so_extracao))
    lin.append("| Campos comparados | %d |" % tot_comp)
    lin.append("| Campos vazios nos dois lados, sem o que comparar | %d |" % tot_vazios)
    lin.append("")
    if aviso_piso:
        lin.append("**%s**" % aviso_piso)
        lin.append("")
    lin.append("## Taxa de acerto por campo")
    lin.append("")
    lin.append("| Campo | Coluna no gabarito | Comparados | Acertos | Taxa | Nao lidos | "
               "Vazios nos dois | Erros acima do limiar |")
    lin.append("|---|---|---|---|---|---|---|---|")
    for campo in comuns:
        c = por_campo.get(campo, {"comparados": 0, "acertos": 0, "erros_acima": 0,
                                  "nao_lidos": 0, "vazios": 0})
        col = par_campo[campo]
        if c["comparados"] == 0:
            lin.append("| %s | %s | 0 | 0 | sem comparacao | 0 | %d | 0 |"
                       % (campo, col, c["vazios"]))
            continue
        t = 100.0 * c["acertos"] / c["comparados"]
        lin.append("| %s | %s | %d | %d | %.1f%% | %d | %d | %d |"
                   % (campo, col, c["comparados"], c["acertos"], t, c["nao_lidos"],
                      c["vazios"], c["erros_acima"]))
    lin.append("| **Total** | | **%d** | **%d** | **%.1f%%** | | **%d** | **%d** |"
               % (tot_comp, tot_ac, taxa, tot_vazios, tot_erros_acima))
    lin.append("")
    lin.append("## Calibracao da confianca")
    lin.append("")
    lin.append("A confianca so vale alguma coisa se o campo que ela deu por certo estiver "
               "certo. Esta tabela e a resposta.")
    lin.append("")
    lin.append("| Faixa | Campos | Acertos | Taxa |")
    lin.append("|---|---|---|---|")
    lin.append("| Acima do limiar | %d | %d | %.1f%% |" % (ac_acima, cal["acima_certo"],
                                                           tx_acima))
    lin.append("| Abaixo do limiar | %d | %d | %.1f%% |" % (ac_abaixo, cal["abaixo_certo"],
                                                            tx_abaixo))
    lin.append("")
    lin.append("**Erros acima do limiar: %d.** Este e o numero que decide. Erro abaixo do "
               "limiar sai na lista de conferencia e a pessoa acha. Erro acima do limiar "
               "entra na planilha como se fosse certo." % tot_erros_acima)
    if tot_erros_acima > 0:
        lin.append("")
        lin.append("Com erro acima do limiar, a confianca desta rodada nao esta calibrada. "
                   "Suba o limiar ate que a faixa de cima fique limpa, ou trate o campo "
                   "que falhou como sempre conferido, e meca de novo.")
    lin.append("")
    lin.append("## Veredito")
    lin.append("")
    if tot_erros_acima == 0 and not div:
        lin.append("Rodada sem divergencia. Uma rodada limpa nao libera o uso real: sao "
                   "tres documentos distintos ja feitos a mao, sem erro que importe, e "
                   "pelo menos %d campos comparados somados. Quem conta e o livro-caixa "
                   "`%s`." % (PISO_CAMPOS, args.livro_caixa))
    else:
        lin.append("Ha divergencia. Antes de usar no trabalho real, decida item por item "
                   "em `divergencias-do-gabarito.csv` se o erro foi da extracao, se foi do "
                   "resultado manual, ou se e so diferenca de formato. Diferenca de formato "
                   "vira regra declarada na nota, nao vira acerto por decreto.")
    lin.append("")
    lin.append(RODAPE.format(fonte=Path(args.tabela).name))
    lin.append("")
    (saida / "medicao-contra-gabarito.md").write_text("\n".join(lin), encoding="utf-8")

    print("")
    print("GABARITO")
    print("  campos do esquema comparados ............... %d de %d" % (len(comuns),
                                                                        len(campos)))
    print("  campos nao comparados por decisao .......... %s"
          % (", ".join(gab["nao_comparados_esquema"])
             if gab["nao_comparados_esquema"] else "nenhum"))
    print("  colunas do gabarito lidas com outro nome ... %s"
          % (", ".join("%s = %s" % p for p in gab["renomeados"])
             if gab["renomeados"] else "nenhuma"))
    print("  campos comparados .......................... %d" % tot_comp)
    print("  campos vazios nos dois lados ............... %d" % tot_vazios)
    print("  acertos .................................... %d (%.1f%%)" % (tot_ac, taxa))
    print("  pior campo ................................. %s %s" % (pior_campo, pior_txt))
    print("  erros acima do limiar ...................... %d" % tot_erros_acima)
    print("  registros so no gabarito ................... %d" % len(so_gabarito))
    print("  registros so na extracao ................... %d" % len(so_extracao))
    if aviso_piso:
        print("  %s" % aviso_piso)

    gravar_no_livro(args.livro_caixa,
                    [datetime.date.today().isoformat(), Path(args.tabela).name,
                     Path(args.gabarito).name, str(saida), tot_comp, tot_ac,
                     tot_erros_acima, pior_campo, pior_txt])

    return 1 if div else 0


# ---------------------------------------------------------------- principal

def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Confere o contrato de saida da extracao e mede contra gabarito.")
    ap.add_argument("--tabela", required=True,
                    help="CSV da extracao, com registro e as triplas campo/confianca/origem")
    ap.add_argument("--gabarito", default=None,
                    help="CSV com o resultado que a pessoa fez a mao (rodada de gabarito)")
    ap.add_argument("--saida", required=True, help="diretorio de saida")
    ap.add_argument("--limiar", default="0,85",
                    help="confianca minima para o campo nao ir para conferencia (padrao 0,85)")
    ap.add_argument("--campos-numericos", default="",
                    help="campos numericos lidos de imagem, separados por virgula. "
                         "Vao para conferencia mesmo acima do limiar (lei de ferro 4)")
    ap.add_argument("--campos-fora", default="",
                    help="campos deixados de fora da leitura por decisao (tapados na "
                         "origem, dado sensivel). Contam no fechamento e nao entram na "
                         "lista de conferencia: a decisao ja foi tomada")
    ap.add_argument("--gabarito-colunas", default="",
                    help="mapeia campo do esquema para coluna do gabarito com outro nome: "
                         "\"hora_inicio:Inicio,hora_fim:Fim\"")
    ap.add_argument("--nao-comparar", default="",
                    help="nomes que ficam fora da comparacao por decisao declarada, "
                         "separados por virgula. Aceita campo do esquema e coluna do "
                         "gabarito. Cada nome precisa existir de um dos dois lados")
    ap.add_argument("--gabarito-registro-por-ordem", action="store_true",
                    help="pareia gabarito e extracao pela posicao da linha, quando o "
                         "gabarito nao tem a coluna registro")
    ap.add_argument("--ignorar-caixa", action="store_true",
                    help="na comparacao com o gabarito, ignora maiuscula e minuscula")
    ap.add_argument("--delimitador-saida", default=";",
                    help="separador de coluna dos CSV escritos (padrao ';', que e o que o "
                         "Excel em portugues abre)")
    ap.add_argument("--livro-caixa", default=LIVRO_PADRAO,
                    help="arquivo que registra as rodadas de gabarito e responde se a "
                         "skill ja esta liberada (padrao %s)" % LIVRO_PADRAO)
    ap.add_argument("--forcar", action="store_true",
                    help="grava em diretorio que ja existe, apagando antes os arquivos de "
                         "resultado da rodada anterior")
    args = ap.parse_args(argv)

    limiar = parse_conf(args.limiar)
    if limiar is None or not (0.0 <= limiar <= 1.0):
        erro("--limiar precisa ser um numero entre 0 e 1, recebido: %s" % args.limiar)
    if len(args.delimitador_saida) != 1:
        erro("--delimitador-saida precisa ser um unico caractere, recebido: %r"
             % args.delimitador_saida)

    saida = Path(args.saida)
    if saida.exists() and not args.forcar:
        erro("o diretorio %s ja existe. Use --forcar para gravar por cima" % saida)

    cab, linhas, enc, delim = ler_csv(args.tabela)
    if COL_REG not in cab:
        erro("a tabela precisa de uma coluna chamada '%s'" % COL_REG)
    campos, soltas, orfas = descobrir_campos(cab)
    if not campos:
        erro("nenhum campo completo na tabela. Cada campo X precisa de X, X%s e X%s"
             % (SUF_CONF, SUF_ORIG))

    numericos = [s.strip() for s in args.campos_numericos.split(",") if s.strip()]
    desconhecidos = [c for c in numericos if c not in campos]
    if desconhecidos:
        erro("--campos-numericos cita campo que nao existe na tabela: %s. "
             "Campos disponiveis: %s" % (", ".join(desconhecidos), ", ".join(campos)))

    fora = [s.strip() for s in args.campos_fora.split(",") if s.strip()]
    desconhecidos = [c for c in fora if c not in campos]
    if desconhecidos:
        erro("--campos-fora cita campo que nao existe na tabela: %s. "
             "Campos disponiveis: %s" % (", ".join(desconhecidos), ", ".join(campos)))
    ambos = [c for c in fora if c in numericos]
    if ambos:
        erro("campo nao pode estar em --campos-fora e em --campos-numericos ao mesmo "
             "tempo: %s" % ", ".join(ambos))

    # O gabarito e conciliado antes de qualquer medicao e antes do bloco de fechamento:
    # erro de entrada do gabarito nao pode sair depois de uma tela que parece rodada boa.
    gab = preparar_gabarito(args, campos, fora) if args.gabarito else None

    rodadas, problemas_livro = ler_livro(args.livro_caixa)
    info_livro = avaliar_livro(rodadas, problemas_livro)

    saida.mkdir(parents=True, exist_ok=True)
    for nome in SAIDAS:
        p = saida / nome
        if p.exists():
            p.unlink()

    violacoes = []
    for c in soltas:
        violacoes.append(["", c, "campo_sem_confianca_ou_origem",
                          "coluna presente sem %s e sem %s. Lei de ferro 1: campo sem "
                          "origem nao entra na tabela" % (SUF_CONF, SUF_ORIG)])
    for c in orfas:
        violacoes.append(["", c, "coluna_orfa",
                          "coluna de confianca ou origem sem a coluna de valor correspondente"])

    vistos = set()
    com_valor = ausentes = acima = abaixo = com_origem = fora_decisao = 0
    a_conferir = []

    for i, linha in enumerate(linhas, start=2):
        reg = linha.get(COL_REG, "")
        if reg == "":
            violacoes.append([str(i), COL_REG, "registro_vazio",
                              "linha %d do arquivo sem identificador de registro" % i])
        elif reg in vistos:
            violacoes.append([reg, COL_REG, "registro_duplicado",
                              "o registro %s aparece mais de uma vez" % reg])
        vistos.add(reg)

        for campo in campos:
            valor = linha.get(campo, "")
            conf = parse_conf(linha.get(campo + SUF_CONF, ""))
            orig = linha.get(campo + SUF_ORIG, "")

            if campo in fora:
                if valor != "":
                    violacoes.append([reg, campo, "campo_fora_com_valor",
                                      "campo declarado em --campos-fora saiu preenchido"])
                elif conf is None or conf != 0.0:
                    violacoes.append([reg, campo, "ausente_com_confianca_diferente_de_zero",
                                      "campo vazio precisa sair com confianca 0. "
                                      "Lei de ferro 5"])
                elif not orig.startswith("ausente"):
                    violacoes.append([reg, campo, "ausente_sem_marca_de_ausencia",
                                      "campo vazio precisa sair com origem comecando por "
                                      "'ausente'. Recebido: %r" % orig])
                else:
                    fora_decisao += 1
                continue

            if valor != "":
                com_valor += 1
                if orig != "":
                    com_origem += 1
                else:
                    violacoes.append([reg, campo, "campo_sem_origem",
                                      "valor preenchido sem origem. Lei de ferro 1"])
                if conf is None:
                    violacoes.append([reg, campo, "confianca_ilegivel",
                                      "confianca vazia ou nao numerica: %r"
                                      % linha.get(campo + SUF_CONF, "")])
                elif not (0.0 <= conf <= 1.0):
                    violacoes.append([reg, campo, "confianca_fora_da_escala",
                                      "confianca %s fora do intervalo de 0 a 1" % conf])
                elif conf == 0.0:
                    violacoes.append([reg, campo, "confianca_zero_com_valor",
                                      "confianca zero e reservada a campo ausente. "
                                      "Lei de ferro 5"])
                else:
                    motivos = []
                    if conf < limiar:
                        abaixo += 1
                        motivos.append("abaixo_do_limiar")
                    else:
                        acima += 1
                    # Lei de ferro 4 nao depende da confianca: numero lido de imagem e
                    # marcado tambem quando ja caiu na lista por estar abaixo do limiar.
                    if campo in numericos:
                        motivos.append("numero_lido_de_imagem")
                    if motivos:
                        a_conferir.append([conf, reg, campo, valor, fmt_conf(conf),
                                           orig, "+".join(motivos)])
            else:
                ausentes += 1
                if conf is None or conf != 0.0:
                    violacoes.append([reg, campo, "ausente_com_confianca_diferente_de_zero",
                                      "campo vazio precisa sair com confianca 0. "
                                      "Lei de ferro 5"])
                if not orig.startswith("ausente"):
                    violacoes.append([reg, campo, "ausente_sem_marca_de_ausencia",
                                      "campo vazio precisa sair com origem comecando por "
                                      "'ausente'. Recebido: %r" % orig])
                a_conferir.append([0.0, reg, campo, "", "0,00",
                                   orig or "ausente", "ausente_no_documento"])

    fonte = Path(args.tabela).name

    if violacoes:
        escrever_csv(saida / "violacoes-do-contrato.csv",
                     ["registro", "campo", "tipo", "detalhe"], violacoes, fonte,
                     args.delimitador_saida)
        print("CONTRATO VIOLADO: %d ocorrencia(s). Ver %s"
              % (len(violacoes), saida / "violacoes-do-contrato.csv"))
        for v in violacoes[:20]:
            print("  registro %s, campo %s: %s" % (v[0] or "-", v[1] or "-", v[2]))
        if len(violacoes) > 20:
            print("  ... e mais %d" % (len(violacoes) - 20))
        print("Nenhuma medicao foi feita. A tabela nao esta no contrato de saida.")
        return 3

    a_conferir.sort(key=lambda r: (r[0], r[1], r[2]))
    escrever_csv(saida / "a-conferir.csv",
                 ["registro", "campo", "valor_lido", "confianca", "origem", "motivo"],
                 [r[1:] for r in a_conferir], fonte, args.delimitador_saida)

    ordem = {c: i for i, c in enumerate(campos)}
    pendentes = {}
    for r in a_conferir:
        pendentes.setdefault(r[1], []).append(r[2])
    for p in pendentes.values():
        p.sort(key=lambda c: ordem.get(c, len(ordem)))
    lancar = []
    for linha in linhas:
        reg = linha.get(COL_REG, "")
        p = pendentes.get(reg, [])
        lancar.append([reg] + [linha.get(c, "") for c in campos]
                      + ["sim" if p else "nao", " ".join(p)])

    registros = len(linhas)
    esperados = registros * len(campos)
    num_acima = sum(1 for r in a_conferir if r[6] == "numero_lido_de_imagem")

    print("EXTRACAO: %s (encoding %s, delimitador %r)" % (fonte, enc, delim))
    print("Campos do esquema: %s" % ", ".join(campos))
    print("Limiar de confianca: %s" % fmt_conf(limiar))
    print("Campos numericos lidos de imagem: %s"
          % (", ".join(numericos) if numericos else "nenhum declarado"))
    print("Campos fora da leitura por decisao: %s"
          % (", ".join(fora) if fora else "nenhum"))
    print("")
    print("FECHAMENTO")
    ident = [
        ("campos_esperados = registros x campos_do_esquema",
         esperados, registros * len(campos)),
        ("campos_esperados = com_valor + ausentes_no_documento + fora_por_decisao",
         esperados, com_valor + ausentes + fora_decisao),
        ("com_valor = acima_do_limiar + abaixo_do_limiar", com_valor, acima + abaixo),
        ("com_origem = com_valor", com_origem, com_valor),
        ("linhas em a-conferir.csv = ausentes_no_documento + abaixo_do_limiar + "
         "numeros_de_imagem_acima", len(a_conferir), ausentes + abaixo + num_acima),
        ("linhas em para-lancar.csv = registros", len(lancar), registros),
    ]
    todas_fecham = True
    for nome, a, b in ident:
        ok = (a == b)
        todas_fecham = todas_fecham and ok
        print("  %-82s %6d = %-6d %s" % (nome, a, b, "fecha" if ok else "NAO FECHA"))
    print("")
    print("VERIFICACOES")
    print("  registros na tabela ........................ %d" % registros)
    print("  campos por registro ........................ %d" % len(campos))
    print("  campos com valor ........................... %d" % com_valor)
    print("  campos ausentes no documento ............... %d" % ausentes)
    print("  campos fora da leitura por decisao ......... %d" % fora_decisao)
    print("  campos acima do limiar ..................... %d" % acima)
    print("  campos abaixo do limiar .................... %d" % abaixo)
    print("  numeros de imagem acima do limiar .......... %d" % num_acima)
    print("  linhas em a-conferir.csv ................... %d" % len(a_conferir))
    print("  linhas pendentes em para-lancar.csv ........ %d" % len(pendentes))
    if not todas_fecham:
        print("")
        print("Uma identidade nao fechou. A rodada e invalida e nao se entrega.")
        return 3

    codigo = 2 if a_conferir else 0

    if args.gabarito:
        codigo_gab = medir_gabarito(args, saida, campos, linhas, limiar, numericos, fonte,
                                    fora, gab)
        if codigo_gab == 1:
            codigo = 1
        rodadas, problemas_livro = ler_livro(args.livro_caixa)
        info_livro = avaliar_livro(rodadas, problemas_livro)

    imprimir_livro(args.livro_caixa, rodadas, problemas_livro, info_livro)

    # para-lancar.csv sai depois da medicao para carregar o estado de liberacao desta
    # rodada, e nao o estado de antes dela.
    extras = []
    if not info_livro["liberado"]:
        extras.append("Gabarito: %s. Nao lance esta planilha antes de a skill estar "
                      "liberada pelo livro-caixa." % info_livro["situacao"])
    escrever_csv(saida / "para-lancar.csv",
                 [COL_REG] + campos + ["linha_pendente", "campos_pendentes"],
                 lancar, fonte, args.delimitador_saida, extras)

    if not args.gabarito and not info_livro["liberado"]:
        print("")
        print("Rodada valida, e a skill ainda nao esta liberada para o trabalho real. "
              "Os arquivos ficam no diretorio para conferencia, e para-lancar.csv sai "
              "com o aviso no rodape.")
        codigo = 4

    print("")
    print("Arquivos gravados em: %s" % saida)
    return codigo


if __name__ == "__main__":
    sys.exit(main())
