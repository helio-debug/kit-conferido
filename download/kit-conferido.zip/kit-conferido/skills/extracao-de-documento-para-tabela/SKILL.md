---
name: extracao-de-documento-para-tabela
description: >
  Recebe um documento que a pessoa já tem (PDF nativo, PDF escaneado, foto de folha
  preenchida à mão, foto de quadro branco, certificado, conhecimento de transporte, ficha
  de apontamento) e devolve CSV com uma linha por registro e, para cada campo, o valor, a
  confiança da leitura e a origem (página e posição no documento). Campo abaixo do limiar,
  campo ausente e todo número lido de imagem saem numa lista separada, ordenada por
  confiança, para conferência humana. Sai também o arquivo pronto para colar na planilha,
  com as linhas que ainda dependem de conferência marcadas. Campo que não está no documento
  sai vazio, nunca inferido. A primeira rodada é obrigatoriamente sobre um documento que a
  pessoa já transcreveu à mão: a skill compara campo a campo e mede a taxa de acerto antes
  do uso real. Use SEMPRE que aparecer: "aí eu pego e passo para a planilha", "transforma
  essa folha em planilha", "tirei foto da folha de apontamento", "extrai os dados desse
  PDF", "tenho 40 fichas para lançar", "o apontamento aqui é no papel", "digitar isso na
  mão leva a manhã inteira". NÃO use para comparar dois arquivos que já são tabela
  (conferencia-entre-duas-fontes), para triar caixa de e-mail (triagem-de-caixa-de-email),
  nem para comparar cotações (comparativo-de-cotacoes). NÃO use para áudio: o Claude Code
  recebe texto e imagem.
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que esta skill
ocupe o lugar das outras.

| Caso | Skill | Relação com esta |
|---|---|---|
| Dois arquivos que já são tabela e deveriam dizer a mesma coisa | `conferencia-entre-duas-fontes`, nesta versão | Esta skill produz o CSV que aquela consome. Extração primeiro, conferência depois, nunca as duas na mesma rodada |
| Caixa de e-mail inteira para separar o que exige ação | `triagem-de-caixa-de-email`, nesta versão | Ela tria e aponta o anexo. A extração do que está dentro do anexo é aqui |
| Várias cotações do mesmo item, para comparar | `comparativo-de-cotacoes`, nesta versão | Esta extrai os campos de cada cotação. A normalização de unidade e a ordenação são lá. Nenhuma das duas escolhe fornecedor |
| O mesmo relatório, todo mês, a partir da mesma fonte | `relatorio-recorrente`, nesta versão | Rode esta skill a cada mês e guarde a nota de cada rodada |
| Registrar o desvio que a extração revelou | `registro-de-anomalia`, nesta versão | A tabela é insumo do registro, não o registro |
| Descrever a área uma vez para as outras skills lerem | `ficha-da-area`, nesta versão | Rode-a antes: ela escreve `~/.kit-industrial/ficha-da-area.md`, que o passo 1 desta lê |
| Medir quanto tempo a transcrição manual leva hoje | `linha-de-base-antes-de-automatizar`, nesta versão | Anote o tempo da sua transcrição manual na rodada de gabarito. É a única chance de medir o antes |
| Conferir um padrão interno contra a norma | `padrao-conferido-contra-norma`, nesta versão | Fora do alcance desta skill |
| Achar o documento que ninguém sabe onde está | `indice-do-acervo-da-area`, nesta versão | Encadeie: o índice acha o documento e diz onde ele está, esta skill o abre e tira os campos de dentro dele |

---

# Extração de documento para tabela

O sinal é sempre a mesma frase: "aí eu pego e passo para a planilha". O dado já existe, em
papel ou em PDF, e alguém digita. Digitar leva a manhã inteira, o erro de digitação não
aparece, e ninguém sabe quantos erros passaram.

Esta skill termina em arquivo. A saída é um conjunto de arquivos gravados em disco. Resposta
em prosa com a tabela dentro é falha de execução.

**Esta skill não acessa ERP, não acessa servidor de arquivos e não substitui o documento.**
O papel continua sendo o documento de origem, e a tabela cita onde ele está arquivado. Ela
lê o arquivo que recebeu, e diz isso na cara antes de começar.

---

## Leis de ferro

1. **Contrato de saída único: todo campo carrega valor, confiança e origem.** Campo sem
   origem não entra na tabela. Origem é página e posição, e o teste é de dez segundos: se
   uma pessoa com o documento na mão não acha aquele valor a partir da origem escrita, a
   origem não vale e o campo não entra.
2. **Gabarito antes do uso real.** A primeira rodada é sobre um documento que a pessoa já
   transcreveu à mão, com o resultado que ela entregou na época. A skill compara campo a
   campo e reporta a divergência. São três documentos sem erro que importe antes de usar no
   trabalho de verdade. Tarefa sem gabarito não é primeira tarefa, por maior que seja o
   ganho prometido.
3. **Manuscrito é o caso que mais falha, e a skill não promete manuscrito sem ressalva.** O
   limite é declarado antes de ler: letra de pessoa não tem fonte nem espaçamento constante,
   e dígito manuscrito é o pior caso. Aqui a rodada de gabarito não é recomendação, é
   condição de uso, com taxa medida por campo, nunca média. Quando a leitura falhar, o
   caminho é transcrever à mão os campos que falharam e usar a skill para o resto.
4. **Número lido de imagem nunca sai sem conferência.** Não importa a confiança: campo
   numérico lido de imagem vai para a lista de conferência, sempre. O erro que criou esta
   lei é real e não parece erro: um valor de 48 lido como 48.000, porque o separador escrito
   na própria folha entrou no número. Número errado não tem cara de errado.
5. **A skill não inventa campo que não está no documento.** Campo ausente sai vazio, com
   confiança zero e origem `ausente`, e vai para a lista de conferência. Nunca preenchido
   por inferência do contexto, nunca repetido da linha de cima. Folha em que a pessoa
   escreveu "idem" ou desenhou uma seta para cima é campo ausente com uma observação, não é
   o valor da linha anterior.

---

## O que a confiança quer dizer, e o que ela não quer dizer

A confiança escrita na tabela é a confiança **declarada** na leitura: o quanto o traço no
documento é inequívoco. Ela não é probabilidade medida, e no começo não vale nada.

O que a torna útil é a rodada de gabarito, que responde à única pergunta que importa:
**quantos erros passaram acima do limiar?** Erro abaixo do limiar sai na lista de
conferência e a pessoa acha. Erro acima do limiar entra na planilha com cara de certo.

Enquanto essa medição não existir, trate a coluna de confiança como ordem de conferência, e
não como garantia. Depois dela, a tabela `medicao-contra-gabarito.md` diz se a confiança
desta rodada está calibrada, e o limiar sobe até a faixa de cima ficar limpa.

Limiar padrão: **0,85**. Ele não é um número mágico, é o ponto de partida que a medição
move.

---

## Passo 1: carregar a ficha da área e o livro-caixa do gabarito

Leia `~/.kit-industrial/ficha-da-area.md`. Se existir, use o vocabulário da área para nomear
os campos, e os sistemas em uso para saber se o dado já existe em formato digital em algum
lugar. Se não existir, declare em voz alta "rodando sem ficha da área" e siga normalmente.

Leia também `~/.kit-industrial/gabaritos-extracao.csv`, o livro-caixa das rodadas de
gabarito. Ele é escrito pelo `medir.py`, uma linha por rodada, e é o que faz a lei de ferro
2 sobreviver ao fim da conversa. **A primeira linha da resposta diz `liberado pelo gabarito`
ou `não liberado`, com o que falta.** Quem calcula é o script, e ele imprime o bloco
`LIBERAÇÃO PELO GABARITO` em toda rodada: a resposta deste passo é a leitura desse bloco,
não uma contagem feita de memória.

A skill que escreve essa ficha é a `ficha-da-area`, nesta versão do kit. Rodar sem ficha não
degrada a extração: só obriga a confirmar o nome de cada campo com a pessoa, que é o passo 3.

**Critério de conclusão:** carregada a ficha, a resposta repete o status gravado nela. A
primeira linha da resposta diz se a ficha foi carregada ou se a
extração está rodando sem ficha, e se a skill está liberada pelo gabarito.

---

## Passo 2: perguntar o que tem dentro antes de abrir o documento

Quatro perguntas, nesta ordem:

1. **O dado é sensível?** As cinco classes: nome de pessoa; folha de pagamento, salário e
   remuneração individual; preço de fornecedor identificado; dado de cliente identificado;
   projeto sob sigilo. Folha, salário e remuneração individual não entram em nenhum modo:
   peça o documento sem essa parte, ou não rode. Se a resposta for sim, ou se a pessoa não
   souber, vá para o **modo de dado sensível** e não abra o documento. Ofereça sempre o modo
   derivado, que aqui é literal: tapar a coluna com uma folha antes de escanear, recortar a
   imagem, ou enviar só as páginas em questão.
2. **Existe o mesmo dado já digital?** Documento fiscal tem XML. Planilha impressa em PDF
   tem a planilha. Relatório de sistema impresso tem o export. Se existe, o caminho é pedir
   o arquivo, e esta skill não roda. Extrair de imagem quando o dado estruturado existe é
   criar risco de graça.
3. **Isso se repete?** Quantos documentos por semana ou por mês, e quanto tempo leva hoje.
   Anote o tempo agora: depois da automação, ninguém lembra quanto levava.
4. **Existe um documento já transcrito à mão, com o resultado da época?** É o gabarito.
   Se não existir, a primeira rodada é a rodada de gabarito: a pessoa transcreve um
   documento à mão agora, cronometrando, e só então a skill roda sobre ele.

**Critério de conclusão:** as quatro respostas estão registradas, e o documento de gabarito
está nomeado, antes de qualquer arquivo ser aberto.

---

## Passo 3: declarar o esquema de campos antes de ler valor

Antes de ler qualquer valor, declare a lista de campos, e confirme com a pessoa. O esquema
sai de um destes três, nesta ordem de preferência: um exemplar em branco do formulário, o
cabeçalho impresso do documento, ou a descrição que a pessoa faz dos campos.

Antes da lista de campos, declare **o que é uma linha**: uma linha por item, por lote, por
hora apontada? É a granularidade do documento, não atributo de campo, e ela se declara uma
vez, antes de tudo.

Para cada campo, quatro coisas:

| Item | Por quê |
|---|---|
| Nome do campo | Vira o nome da coluna. Use o vocabulário da área, não o do documento, quando os dois brigam |
| É número lido de imagem? | Decide se o campo entra em `--campos-numericos`, e por lei de ferro 4 vai para conferência sempre |
| Unidade | Unidade colada no valor (`12 kg` contra `12`) vira campo próprio, `<campo> (unidade)`. Descartar a unidade é como se perde a diferença entre 12 kg e 12 g |
| Fica fora da leitura? | Campo tapado na origem ou que não pode sair da empresa continua no esquema, e entra em `--campos-fora`. Ele conta no fechamento e não entra na lista de conferência, porque a decisão já foi tomada |

**Campo de cabeçalho se repete em toda linha.** Se o documento tem cabeçalho (número da
ordem, data, turno) e corpo em grade, cada linha do CSV carrega o cabeçalho repetido, com a
mesma origem nas duas. Isso é o que torna a tabela utilizável na planilha, e a origem
repetida diz que veio de um lugar só.

**Mais de um documento na mesma rodada:** o `registro` vira `<arquivo>:<n>`, para que a
origem continue localizável.

**O valor sai como está escrito no documento.** Converter separador decimal, uniformizar
data ou remover zero à esquerda é normalização, e normalização é trabalho da conferência,
não da extração. A extração transcreve e marca; ela não decide se `48.000` é quarenta e
oito mil ou quarenta e oito. Quando a escrita for ambígua, o campo sai como está, com
confiança abaixo do limiar, e as duas leituras possíveis entram na nota.

**O esquema é conferido contra o gabarito, e não o contrário.** Na rodada do passo 4, coluna
do gabarito que não tem campo correspondente no esquema derruba a rodada com código 3. É de
propósito: campo que a extração esqueceu inteiro é exatamente o que a rodada de gabarito
existe para pegar, e ele não pode sumir da medição por não estar no esquema.

**Critério de conclusão:** existe uma lista de campos escrita, com nome, natureza numérica,
unidade e granularidade, e a pessoa concordou com ela antes de o documento ser aberto.

---

## Passo 4: a rodada de gabarito, que vem antes do trabalho real

A primeira rodada não é trabalho, é medição. Ela roda os passos 5, 6 e 7 sobre um documento
que a pessoa já transcreveu à mão, e compara.

1. Peça o resultado manual da época. **A planilha que ela preencheu não serve como está.**
   Monte o CSV do gabarito com uma coluna `registro`, numerada na mesma ordem das linhas do
   documento, e uma coluna por campo com o nome exato do esquema do passo 3. Quando o nome
   da coluna dela for outro (`Início` no lugar de `hora_inicio`), mapeie na linha de comando
   com `--gabarito-colunas "hora_inicio:Início"`, em vez de renomear a planilha dela. Quando
   não houver coluna `registro`, use `--gabarito-registro-por-ordem`, que pareia pela
   posição da linha.
2. Rode a extração sobre o mesmo documento, sem olhar o resultado manual antes. Olhar antes
   contamina a leitura e a medição deixa de valer.
3. Rode `medir.py` com `--gabarito` e leia `medicao-contra-gabarito.md`, começando pela
   tabela **Conciliação do esquema com o gabarito**. Campo que existe de um lado e não do
   outro não é comparado, e por isso derruba a rodada com código 3 antes de qualquer
   medição: ou ele entra no esquema e a extração roda de novo, ou ele é declarado em
   `--nao-comparar`, item por item, e sai nomeado no relatório.
4. Percorra `divergencias-do-gabarito.csv` item por item e classifique cada um em três:
   **erro da extração**, **erro do resultado manual** (acontece, e é achado de valor), ou
   **só diferença de formato**. Diferença de formato vira regra declarada na nota, não vira
   acerto por decreto.
5. Confira que a linha da rodada entrou em `~/.kit-industrial/gabaritos-extracao.csv`. O
   script grava sozinho, ao fim de toda rodada com `--gabarito`, e é dessa contagem que sai
   a liberação. Rodada repetida sobre o mesmo par de arquivos conta como um documento só.
6. Repita com o segundo e o terceiro documento.

**O script não distingue diferença de formato de erro de leitura**, e nem tem como: para
ele, `1.200` e `1200` são dois textos diferentes. Por isso a classificação do item 4 é
humana. Quando a decisão for "é formato", a regra entra na nota, o resultado manual é
padronizado conforme essa regra, e a medição roda de novo. Aceitar o item como acerto sem
declarar a regra é como a taxa de acerto vira número de enfeite.

**A liberação para o trabalho real tem três condições, as três obrigatórias:** três
documentos distintos comparados sem erro que importe, zero erro acima do limiar na última
rodada, e pelo menos 60 campos comparados somados nesses três documentos. Erro que importa é
o que mudaria o número lançado ou a decisão tomada. O piso de 60 está em
`references/tipos-de-documento.md`: abaixo dele a taxa não significa nada, e três
certificados de 8 campos liberariam o uso real com uma medição sem valor.

Quem confere as três condições é o `medir.py`, lendo o livro-caixa. Rodada sem `--gabarito`
com a skill não liberada termina com **código 4**, grava os arquivos para conferência e
escreve o aviso no rodapé do `para-lancar.csv`. A porta não abre sozinha e não abre de
memória.

Nas primeiras semanas depois da liberação, continue conferindo por amostra: um documento
inteiro a cada tantos, com o intervalo escolhido pelo volume declarado no passo 2.

**Critério de conclusão:** o bloco `LIBERAÇÃO PELO GABARITO` diz `LIBERADO para o trabalho
real`, e a taxa por campo do pior campo está dita em voz alta. Enquanto isso não existir, a
skill não é usada no trabalho real, e ela diz isso em vez de entregar tabela.

---

## Passo 5: extrair e escrever a tabela

Uma linha por registro. Para cada campo, três colunas: `<campo>`, `<campo>__confianca` e
`<campo>__origem`.

Leia `references/tipos-de-documento.md` e localize o tipo do documento em questão antes de
ler valor. Cada tipo traz onde ele falha, a taxa a exigir e o que fazer antes de rodar.

Regras de escrita da tabela:

| Situação | O que sai |
|---|---|
| Campo lido sem dúvida | Valor, confiança acima do limiar, origem |
| Campo lido com dúvida entre duas leituras | O valor mais provável, confiança abaixo do limiar, origem, e as duas leituras na nota |
| Campo ilegível | Vazio, confiança 0, origem `ausente: ilegivel` |
| Campo que não existe no documento | Vazio, confiança 0, origem `ausente: nao consta` |
| Campo em branco no papel | Vazio, confiança 0, origem `ausente: em branco na folha` |
| Campo escrito como "idem" ou seta para cima | Vazio, confiança 0, origem `ausente: idem na folha`. Nunca o valor de cima |
| Número lido de imagem | Valor como escrito, e o campo declarado em `--campos-numericos` |
| Campo tapado na origem, por decisão | Vazio, confiança 0, origem `ausente: tapado na origem`, e o campo declarado em `--campos-fora` |

Formato da origem: `<página ou arquivo>, <localização>`. Exemplos: `p3, linha 12 da tabela
de itens`; `foto 2, grade linha 7, coluna Hora fim`; `p1, campo Emitente no cabeçalho`. O
teste é o de dez segundos da lei de ferro 1.

**A origem tem vírgula dentro. Escreva a célula inteira entre aspas duplas no CSV**, senão a
linha ganha colunas, o conteúdo desliza e a origem é truncada. O script confere a contagem
de colunas de cada linha contra o cabeçalho e derruba a rodada com código 3 quando não bate,
mas a aspa é o que evita o problema.

**Critério de conclusão:** o CSV está gravado, tem `registro` e as três colunas de cada
campo do esquema do passo 3, e nenhuma coluna a mais.

---

## Passo 6: conferir o contrato e montar a lista do que precisa de olho humano

**Por que aqui cabe script.** A leitura do documento é do modelo, e disso não escapa: não
existe OCR de biblioteca padrão. Mas três coisas depois da leitura não são do modelo, e
foram para o script: conferir campo a campo que todo valor tem confiança e origem, ordenar a
lista de conferência, e medir contra o gabarito. As três são aritmética sobre muitos campos,
repetida toda semana, e é exatamente onde a leitura em contexto pula uma linha sem gerar
erro. Uma taxa de acerto conferida a olho não é taxa de acerto, é impressão. O script também
roda sem rede, o que importa no modo de dado sensível.

Dependência declarada: Python 3.8 ou superior, biblioteca padrão apenas (`argparse`, `csv`,
`datetime`, `re`, `sys`, `pathlib`). Sem instalação, sem rede, sem escrita nos arquivos de
entrada. A única escrita fora do diretório de saída é a linha da rodada de gabarito no
livro-caixa `~/.kit-industrial/gabaritos-extracao.csv`.

**Onde o script está depois de instalado.** A instalação copia a pasta da skill para
`~/.claude/skills/extracao-de-documento-para-tabela/`, e o script fica em
`~/.claude/skills/extracao-de-documento-para-tabela/scripts/medir.py`. A rodada acontece na
pasta dos arquivos de trabalho, não na pasta da skill, e por isso o script é sempre chamado
pelo caminho completo. Caminho relativo como `scripts/medir.py` só funciona de dentro da
pasta da skill: fora dela o Python responde `can't open file`.

**Confira a instalação antes do primeiro comando.** Sem a pasta copiada, o Python responde
`can't open file` e sai com código 2, que é o código da rodada boa. Uma rodada que não
processou nada devolveria o código da rodada bem sucedida.

```
test -f ~/.claude/skills/extracao-de-documento-para-tabela/scripts/medir.py \
    && echo instalada || echo "skill não instalada, veja o 00-LEIA-ME.md"
```

No macOS e no Linux:

```
python3 ~/.claude/skills/extracao-de-documento-para-tabela/scripts/medir.py \
    --tabela tabela.csv --saida extracao-apontamento-2026-09-20 \
    --campos-numericos "ordem_de_producao,quantidade,hora_inicio,hora_fim" \
    --campos-fora "operador"
```

Na rodada de gabarito, o mesmo comando com o resultado manual:

```
python3 ~/.claude/skills/extracao-de-documento-para-tabela/scripts/medir.py \
    --tabela tabela.csv --gabarito resultado-manual.csv \
    --saida gabarito-1-2026-09-20 \
    --campos-numericos "ordem_de_producao,quantidade,hora_inicio,hora_fim" \
    --campos-fora "operador"
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho vai entre
aspas com `$env:USERPROFILE` no lugar do `~`, e a linha continua com acento grave no lugar
da barra invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\extracao-de-documento-para-tabela\scripts\medir.py" `
    --tabela tabela.csv --saida extracao-apontamento-2026-09-20 `
    --campos-numericos "ordem_de_producao,quantidade,hora_inicio,hora_fim" `
    --campos-fora "operador"
```

Rodada que caiu deixa o diretório criado. Repita o comando com `--forcar`, que grava por
cima depois de apagar os arquivos de resultado da rodada anterior. Sem essa limpeza, um
`a-conferir.csv` velho sobreviveria ao lado das violações da rodada nova.

Opções que a rodada de gabarito usa, todas declaradas item por item:

| Opção | Para quê |
|---|---|
| `--gabarito-colunas "hora_inicio:Início"` | A coluna do resultado manual tem outro nome. Sem o mapa, o campo ficaria sem par e a rodada cai |
| `--gabarito-registro-por-ordem` | O resultado manual não tem coluna `registro`. Pareia pela posição da linha |
| `--nao-comparar "operador,Observação"` | Tira da comparação um campo do esquema ou uma coluna do gabarito, por decisão. Aceita nome dos dois lados, cada nome precisa existir, e todos saem nomeados no relatório |
| `--delimitador-saida ,` | Troca o `;` padrão dos CSV escritos pelo separador americano |
| `--livro-caixa <arquivo>` | Usa outro livro-caixa no lugar de `~/.kit-industrial/gabaritos-extracao.csv` |

Campo numérico que não estiver em `--campos-numericos` não vai para a lista por lei de ferro
4, e por isso o script derruba a rodada com código 3 quando o nome citado ali não existe na
tabela: erro de digitação no nome do campo desligaria a lei em silêncio. A mesma guarda vale
para `--campos-fora`, para `--nao-comparar` e para `--gabarito-colunas`, e um campo não pode
estar nas duas primeiras listas ao mesmo tempo.

**Por que `--campos-fora` existe.** Sem ele, o campo tapado na origem entra na lista de
conferência uma vez por linha. Em quarenta fichas isso são quarenta linhas sobre uma decisão
que já foi tomada, e uma lista de conferência com ruído dentro é uma lista que ninguém lê
até o fim.

| Código de saída | Significado |
|---|---|
| 0 | Contrato válido e nada pendente. No modo gabarito, também nenhuma divergência |
| 1 | Modo gabarito: há divergência contra o resultado manual |
| 2 | Contrato válido, e há campo pendente de conferência humana |
| 3 | Erro de entrada, violação do contrato de saída, ou identidade que não fecha |
| 4 | Contrato válido, e a skill ainda não está liberada pelo gabarito (lei de ferro 2) |

O código 2 é o caso normal de uma rodada boa: quase toda extração deixa algum campo para
conferir. O código 0 é raro de propósito, porque numa rodada agendada 0 é lido como "não
precisa olhar", e isso só pode sair quando de fato não há nada para olhar.

**Qualquer outro código, e o 2 acompanhado de `can't open file`, quer dizer que o script não
chegou a rodar.** Confira o caminho antes de ler o 2 como rodada boa: nenhum arquivo gravado
e nenhuma linha conferida também terminam em 2 quando o Python não acha o arquivo.

**Critério de conclusão:** o diretório tem `a-conferir.csv` e `para-lancar.csv`, o bloco de
fechamento impresso no terminal tem `fecha` em todas as linhas, e o código de saída é 0, 2
ou 4. Código 3 não é resultado parcial, é resultado inválido, e a tabela não é entregue
enquanto a violação listada em `violacoes-do-contrato.csv` não for corrigida. Código 4 é
rodada válida que não se lança: falta gabarito.

---

## Passo 7: fechamento

Confira as identidades. Todas devem fechar, e os números vão na nota:

```
campos_esperados = registros x campos_do_esquema
campos_esperados = com_valor + ausentes_no_documento + fora_por_decisao
com_valor        = acima_do_limiar + abaixo_do_limiar
com_origem       = com_valor
linhas em a-conferir.csv = ausentes_no_documento + abaixo_do_limiar
                           + numeros_de_imagem_acima_do_limiar
linhas em para-lancar.csv = registros
```

A quarta identidade é a lei de ferro 1 em forma de conta: todo valor tem origem, e por isso
os dois números são o mesmo. A quinta não tem contagem dupla: número de imagem acima do
limiar é disjunto de abaixo do limiar e de ausente. Campo fora por decisão aparece na
segunda identidade e não na quinta: ele é contado, e não é conferido. A sexta diz que
nenhuma linha da tabela ficou de fora do arquivo que a pessoa vai lançar.

As identidades saem dos mesmos contadores e fecham por construção: provam que a contabilidade
da rodada é consistente, não que a leitura prestou. O que pode falhar de fato vem no bloco
seguinte, impresso no terminal e repetido na nota: registros na tabela contra registros no
documento, campos ausentes, campos abaixo do limiar, números de imagem, e, na rodada de
gabarito, a taxa por campo e os erros acima do limiar.

**A contagem de registros é conferida contra o documento, não contra a tabela.** O script
conta o que está na tabela e não sabe quantas linhas o papel tinha. Conte as linhas do
documento à mão e compare. Em documento de várias páginas, conte página por página. É a
única verificação desta skill que nenhum script faz.

**Critério de conclusão:** as seis identidades foram impressas com os números e todas
fecham, a contagem de registros bate com a contagem feita no documento, e cada linha do
bloco de verificações foi lida e respondida.

---

## Contrato de saída

Os arquivos ficam num diretório com a data da rodada. Ordem de escrita: a nota sai antes da
tabela, a tabela antes do script, e a nota é reescrita por último, com o fechamento.

### 1. `nota-de-extracao.md`, primeiro, sempre

Abre com `status: incompleto` e só vira `status: completo` na última gravação, depois do
fechamento. Os quatro valores possíveis são `incompleto` (a rodada caiu no meio e a saída
não vale), `gabarito, sem uso real` (rodada de medição), `completo` (o fechamento fecha) e
`invalido, nao fecha`.

Seções obrigatórias:

- **Documento.** Nome do arquivo, tipo pela referência, número de páginas, e onde o original
  está arquivado. O arquivo físico continua sendo o documento.
- **Esquema declarado.** A lista de campos do passo 3, com natureza numérica, unidade e
  granularidade, e de onde o esquema saiu.
- **Leitura.** Limiar usado, campos declarados como numéricos, e o que a referência de tipos
  diz que falha neste tipo de documento.
- **Ambiguidades de leitura.** Uma linha por campo em que a escrita permite duas leituras,
  com as duas leituras e a que foi escrita na tabela. Sem o valor real quando o dado é
  sensível.
- **Campos ausentes.** Contagem por motivo: ilegível, não consta, em branco na folha, idem.
- **O que não foi normalizado, por decisão.** A lista do que sai como está escrito e por
  quê, com a remissão à conferência.
- **Estado do gabarito.** O bloco `LIBERAÇÃO PELO GABARITO` copiado do terminal: quantos
  documentos distintos já foram medidos sem erro acima do limiar, quantos campos comparados
  somados, e a situação. Mais a taxa do pior campo da última rodada. Enquanto a situação não
  for `LIBERADO`, esta seção diz em letras que a skill ainda não está liberada para o
  trabalho real.
- **Fechamento.** As identidades com os números e o bloco de verificações.
- **Limite declarado.** A frase de que a skill não acessa ERP nem servidor de arquivos, e
  de que o documento original continua sendo o documento.

### 2. `tabela.csv`

Uma linha por registro.

| Coluna | Conteúdo |
|---|---|
| `registro` | Identificador da linha. Único. Com mais de um documento, `<arquivo>:<n>` |
| `<campo>` | Valor como está escrito no documento |
| `<campo>__confianca` | De 0 a 1, com duas casas. Ponto ou vírgula decimal. Zero é reservado a campo ausente |
| `<campo>__origem` | Página e posição. Em campo ausente, começa por `ausente` |

Nenhuma outra coluna. Coluna solta derruba a rodada com código 3, e é de propósito:
observação em coluna extra é por onde entra o dado sem origem.

### 3. `a-conferir.csv`

Escrita pelo script. Colunas: `registro`, `campo`, `valor_lido`, `confianca`, `origem`,
`motivo`. Ordenada por confiança crescente, o que põe os campos ausentes em primeiro. A
saída usa ponto e vírgula, que é o que o Excel em português abre, e a confiança sai com
vírgula decimal. Use `--delimitador-saida ,` para o padrão americano.

| `motivo` | Significado |
|---|---|
| `ausente_no_documento` | Campo vazio, confiança zero. Precisa de decisão humana sobre o que fazer com a falta |
| `abaixo_do_limiar` | Lido, mas a escrita não era inequívoca |
| `numero_lido_de_imagem` | Acima do limiar, e ainda assim na lista, por lei de ferro 4 |
| `abaixo_do_limiar+numero_lido_de_imagem` | Os dois |

Campo declarado em `--campos-fora` não entra nesta lista, e continua contado no fechamento.

**Esta é a lista de trabalho da pessoa.** Ela confere de cima para baixo, com o documento ao
lado, e para quando a confiança ficar alta o bastante para o uso que ela vai dar ao dado.

### 4. `para-lancar.csv`

Escrito pelo script. **É o arquivo que se cola na planilha.** Colunas: `registro`, uma por
campo do esquema com o valor como está escrito, `linha_pendente` e `campos_pendentes`.
Linha com `linha_pendente` igual a `sim` só entra depois de conferida, e `campos_pendentes`
diz quais células olhar, sem ir procurar no `a-conferir.csv`.

Sem ele, a pessoa apagaria as colunas `__confianca` e `__origem` à mão toda rodada: um
esquema de 6 campos dá 19 colunas na `tabela.csv`, que não se cola em planilha nenhuma. As
duas últimas colunas se apagam de uma vez depois da conferência.

Enquanto a skill não estiver liberada pelo gabarito, o rodapé do arquivo diz isso em letras.

### 5 e 6. `medicao-contra-gabarito.md` e `divergencias-do-gabarito.csv`

Saem só na rodada de gabarito. A medição abre pela conciliação do esquema com o gabarito,
que nomeia campo por campo o que foi comparado, o que foi lido com outro nome de coluna e o
que ficou fora por decisão declarada, e segue com cobertura, taxa de acerto por campo,
calibração da confiança e a contagem de erros acima do limiar. As divergências trazem, por
campo, o valor da extração, o valor do resultado manual, a confiança, a origem, se estava
acima do limiar, e a classe.

### 7. `violacoes-do-contrato.csv`

Sai só quando a tabela viola o contrato, e nesse caso nenhum outro arquivo de resultado é
escrito. Colunas: `registro`, `campo`, `tipo`, `detalhe`.

### 8. `~/.kit-industrial/gabaritos-extracao.csv`, fora do diretório da rodada

O livro-caixa das rodadas de gabarito, escrito pelo script ao fim de toda rodada com
`--gabarito`. Uma linha por rodada, separada por ponto e vírgula: `data`, `tabela`,
`gabarito`, `diretorio`, `campos_comparados`, `acertos`, `erros_acima_do_limiar`,
`pior_campo`, `pior_taxa`. É o único arquivo que atravessa as sessões, e é dele que sai a
resposta de o passo 1. Livro ilegível não vira livro vazio: a situação fica indeterminada e
nada é liberado.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de <fonte>. Revisar antes de assinar. Não substitui
responsabilidade técnica.
```

---

## Modo de dado sensível

Aqui o modo tem um limite que a conferência entre duas fontes não tem, e ele é dito antes de
tudo: **a leitura do documento não roda local.** Não existe OCR de biblioteca padrão, e o
documento precisa ser lido pelo modelo. O script mede, não lê. Então o que se protege é o
que entra, não o que é processado.

Três níveis. O padrão, quando a pessoa não decide, é o nível 2.

**Nível 1, só o esquema.** A pessoa envia um exemplar em branco do formulário, ou descreve
os campos. Com isso se define o esquema, a granularidade, os campos numéricos e a linha de
comando. Nenhum valor real é lido, e a transcrição fica com ela.

**Nível 2, documento derivado (padrão).** O documento vai com a parte sensível fora: a
coluna de nome tapada com uma folha antes de escanear, a imagem recortada, ou só as páginas
em questão. O campo tapado entra no esquema como `ausente: tapado na origem`, é declarado em
`--campos-fora`, e continua contando no fechamento sem poluir a lista de conferência. Nesta
skill o campo tapado não vira pseudônimo: ele sai vazio. Campo declarado em `--campos-fora`
que sair preenchido, inclusive com `[pessoa 1]`, derruba a rodada com código 3.

**Nível 3, nada sai.** O modelo entrega o esquema, o cabeçalho do CSV, a lista de
conferência a preencher e a linha de comando do `medir.py`. A pessoa transcreve, roda o
script na máquina dela e responde apenas se fechou, e qual identidade quebrou se não fechou.

Regra que não se quebra: folha de pagamento, salário e remuneração individual não entram em
nenhum dos três níveis. Projeto sob sigilo e contrato: nível 3, ou não roda.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**O dado já existe estruturado.** Documento fiscal com XML, planilha impressa em PDF,
relatório de sistema que tem export. Pare e peça o arquivo. Extrair de imagem o que já
existe em tabela é criar erro onde não havia.

**Áudio.** O Claude Code recebe texto e imagem, não áudio. A transcrição é feita fora do kit,
pelo ditado do próprio celular ou por aplicativo de transcrição, e o que entra aqui é o
texto. Isso é dependência declarada, não descoberta no meio do uso.

**Manuscrito sem gabarito.** Sem um documento já transcrito à mão para comparar, não existe
taxa, e sem taxa a saída é um palpite bem formatado. A skill diz isso e para, em vez de
entregar tabela. É a lei de ferro 2, e no manuscrito ela não tem exceção.

**Escaneado torto ou cópia de cópia.** O modo de falha é leitura deslocada, em que o valor
de uma linha casa com a chave de outra. A saída sai completa e errada, sem nenhum campo
vazio para denunciar. Escaneie de novo. Enquanto não escanear, a skill roda apenas com o
teste de deslocamento da referência, em três linhas distantes, e declara que a rodada
depende dele.

**Cota, tolerância e vista de desenho técnico.** Não é tabela. Do desenho se lê o carimbo e
a lista de material. O resto pede o arquivo nativo.

**Assinatura manuscrita.** Sai como presente ou ausente. Nome de assinatura não se lê, e
tentar é inventar.

**Documento com granularidade indefinida.** Se não dá para dizer o que é uma linha, a
tabela não existe. Pergunte qual agregação a área usa, em vez de agregar por conta própria.

---

## Referência

A pasta da skill fica em `~/.claude/skills/extracao-de-documento-para-tabela/` depois de
instalada. Os arquivos de referência são lidos por esse caminho, e os scripts são chamados
pelo caminho completo.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/extracao-de-documento-para-tabela/references/tipos-de-documento.md` | Os tipos de documento em quatro grupos, cada um com o que esperar, onde falha, a taxa a exigir e o que fazer antes de rodar. Traz também quantos campos medir para a taxa significar alguma coisa. Leia antes de ler valor. |
| `~/.claude/skills/extracao-de-documento-para-tabela/scripts/medir.py` | Confere o contrato de saída, escreve `a-conferir.csv` ordenada por confiança e `para-lancar.csv` pronto para colar, mede contra o gabarito e mantém o livro-caixa que responde se a skill está liberada. Não lê documento e não faz OCR. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/extracao-de-documento-para-tabela/scripts/testar.py` | Teste de regressão do `medir.py`, biblioteca padrão apenas. Gera os casos em diretório temporário e compara código de saída, conteúdo dos arquivos, saída do terminal e mensagem de erro. Trinta e nove casos, em quatro grupos: a tabela limpa; um caso por defeito conhecido do contrato (valor sem origem, campo vazio com confiança alta, registro repetido, campo declarado nas duas listas, e os demais); os casos da rodada de gabarito (idêntico, divergente, registro só no gabarito, coluna com outro nome mapeada, pareamento pela ordem da linha, piso de 60 campos, livro-caixa); e o grupo marcado `SILÊNCIO`, que persegue uma doença só, qualquer caminho em que o script termine em sucesso tendo perdido, ignorado ou não medido um campo: coluna do gabarito fora do esquema, campo do esquema sem coluna no gabarito, linha com mais colunas que o cabeçalho, coluna repetida, coluna sem nome, registro repetido no gabarito e coluna tirada da comparação por decisão. Cada caso roda com o livro-caixa dentro do diretório temporário, nunca no livro-caixa da máquina. Rode `python3 ~/.claude/skills/extracao-de-documento-para-tabela/scripts/testar.py` depois de qualquer mudança no script, ou `py -3 "$env:USERPROFILE\.claude\skills\extracao-de-documento-para-tabela\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
