# Catálogo das mudanças de estrutura entre um mês e outro

Quatro grupos. Cada item traz a manifestação, como o script detecta, o efeito de
ninguém olhar e o que fazer. Leia antes de aceitar o resultado do modo estrutura.

O ponto do catálogo é este: quem monta o relatório à mão percebe quase todas
essas mudanças sem pensar, porque esbarra nelas. Quem repete a montagem sem
olhar não percebe nenhuma, e o relatório sai completo, ordenado e errado.

---

## Grupo 1. O cabeçalho mudou

| Item | Manifestação | Detecção | Efeito se ninguém olhar |
|---|---|---|---|
| Coluna sumiu | O nome não está mais no cabeçalho do export | `coluna_sumiu` | A conta que dependia dela sai vazia, ou sai com o valor do mês passado copiado |
| Coluna nova | Nome que não existia | `coluna_nova` | Dado novo sem lugar no relatório. Às vezes é a coluna que a área passou a usar no lugar da antiga |
| Coluna renomeada | A antiga sumiu e uma nova apareceu, na mesma posição e com o mesmo tipo | Sai como o par `coluna_sumiu` mais `coluna_nova`, e o par na mesma posição e mesmo tipo é o sinal | Quem lê por nome perde a coluna. Quem lê por posição continua certo, e é o único caso em que isso acontece |
| Coluna mudou de posição | Mesmo nome, outra ordem | `coluna_mudou_de_posicao` | Quem lê por posição passa a ler a coluna errada em silêncio. É a falha mais cara do grupo |
| Unidade no nome mudou | `Peso (kg)` virou `Peso (t)` | `unidade_no_nome_mudou` | O número muda de ordem de grandeza e o quadro não parece errado |
| Nome de coluna repetido | Duas colunas `Qtde`, duas `Data`, duas `Valor` no mesmo cabeçalho | `nome_de_coluna_repetido_no_cabecalho`. A segunda é lida como `Qtde#2` | Quem lê por nome pega sempre a primeira, e o conteúdo da segunda não entra em conta nenhuma. Um script que rejeitasse esse cabeçalho adotaria a primeira linha de dado como cabeçalho e perderia essa linha |
| Coluna sem nome | Cabeçalho vazio na posição, quase sempre a última, por ponto e vírgula sobrando | `coluna_sem_nome_no_cabecalho`. É lida como `(sem nome 7)` | A coluna sai do relatório sem ninguém decidir que ela sai |

A troca de par de leitura é a decisão que fecha este grupo: ler por nome protege
contra mudança de posição e quebra em renomeação; ler por posição faz o inverso.
Declare qual dos dois a receita usa e por quê.

---

## Grupo 2. O conteúdo da coluna mudou

| Item | Manifestação | Detecção | Efeito se ninguém olhar |
|---|---|---|---|
| Formato de número | `1.234,56` virou `1234.56` | `coluna_mudou_de_formato`, de `numero_br` para `numero_en` | Some o separador de milhar e o valor lido fica mil vezes menor, ou o número vira texto e não soma |
| Formato de data | `01/02/2026` virou `2026-02-01` | `coluna_mudou_de_formato`, de `data_dmy` para `data_iso` | A ordenação por data embaralha, e o filtro do mês pega o mês errado |
| Milhar ambíguo | `1.234` sozinho na célula | tipo `ambiguo_milhar` | Mil duzentos e trinta e quatro ou um vírgula duzentos e trinta e quatro. O script declara a ambiguidade e não resolve. Quem resolve é quem conhece a grandeza |
| Coluna ficou vazia | O cabeçalho continua, o conteúdo sumiu inteiro | `coluna_ficou_vazia` | O relatório sai completo com uma coluna em branco. Nenhum erro aparece em lugar nenhum |
| Coluna perdeu preenchimento | O cabeçalho continua, o conteúdo sumiu em parte das linhas. É a forma frequente do apontamento que parou no meio do mês | `coluna_perdeu_preenchimento`, a partir de 20 pontos percentuais de queda | A conta que depende da coluna sai menor e o relatório sai completo. Ficar vazia de uma vez é o caso raro, e era o único que o script pegava |
| Tipo misto | A mesma coluna com número e texto | marca `MISTO` no perfil | Parte das linhas soma e parte não, e o total fica menor sem acusar |
| Zero à esquerda | `00123` virou `123` | Aparece como diferença de formato no gabarito | Deixa de parear com o cadastro, e o item vira item faltante que não falta |
| Notação científica | `1,23E+14` no lugar do código | tipo `numero_en` numa coluna de código | Os dígitos se perderam na origem, e nenhuma regra reconstrói |

---

## Grupo 3. A forma do arquivo mudou

| Item | Manifestação | Detecção | Efeito se ninguém olhar |
|---|---|---|---|
| Delimitador | Ponto e vírgula virou vírgula | `delimitador_mudou` | O arquivo inteiro cai numa coluna só, e duas tabelas diferentes passam a ter a mesma estrutura por vacuidade. O script para aqui em vez de comparar |
| Encoding | UTF-8 virou cp1252 | `encoding_mudou` | Acento vira caractere estranho dentro do relatório assinado |
| Linha do cabeçalho | O export ganhou uma linha de título ou de filtro | `linha_do_cabecalho_mudou` | Quem pula um número fixo de linhas passa a engolir a primeira linha de dado, ou a ler o cabeçalho como dado |
| Rodapé de identificação | `Emitido em`, `Página 1 de 1`, `Usuário:` | Vai para `linhas-nao-lidas.csv` com classe `reconhecida` | Lida como dado, entra no total. Descartada em silêncio, some do fechamento. Por isso sai reportada, nunca apagada. Sendo reconhecida pelo padrão, ela não derruba o código 0, porque não é dado da tabela |
| Título ou filtro acima do cabeçalho | `Relatório de produção`, `Período: 01/08 a 31/08` antes da linha de nomes | Classe `reconhecida`, causa `titulo_ou_filtro_acima_do_cabecalho` | Quem pula um número fixo de linhas engole dado quando o export ganha ou perde uma linha de título |
| Linha de dado acima do cabeçalho | Uma linha com a largura da tabela antes da linha de nomes | Classe `perdida`, causa `acima_do_cabecalho_com_a_largura_da_tabela` | É a forma mais silenciosa de perder dado: a linha não aparece em lugar nenhum e as contagens dos dois lados fecham do mesmo jeito. Por isso ela derruba o código 0 |
| Célula mesclada | Valor na primeira célula do bloco e vazio nas seguintes | `bloco_com_valor_so_na_primeira_linha` | Preencher para baixo inventa dado. Não preencher perde o agrupamento. Decida e declare |

---

## Grupo 4. A lógica do relatório mudou

É o grupo que o script existe para achar, e o único que não aparece no cabeçalho.

| Item | Manifestação | Detecção | Efeito se ninguém olhar |
|---|---|---|---|
| Critério de agrupamento | Agrupava por setor, passou a agrupar por centro de custo | `criterio_de_agrupamento_mudou` | Os dois meses deixam de ser comparáveis, e a série histórica tem uma quebra que ninguém registrou |
| Total mudou de lugar | Total só no rodapé virou total por bloco, ou o contrário | `total_mudou_de_lugar` | Linha de total lida como item infla o relatório. Item lido como total esvazia |
| Bloco a mais ou a menos | Um setor novo, ou um setor que parou de aparecer | `quantidade_de_linhas_de_total_mudou` | O relatório fecha e falta um bloco inteiro |
| Rótulo do bloco | `Utilidades` virou `UTIL`, ou ganhou código na frente | `rotulos_de_total_mudaram` | Quem procura pelo rótulo antigo não acha, e a linha vira zero |
| Granularidade | Uma linha por item virou uma linha por item e lote | Chave repetida de um lado só, no modo gabarito | Soma duplicada, e o total fica maior sem nenhum valor estar errado |
| Filtro do export | Quem extraiu marcou outra data, outra planta, outro status | Nenhum sinal no arquivo | É o único item sem detecção automática. Por isso a receita registra o filtro exato usado no export |

---

## O que não é mudança de estrutura

Número de linhas. Ele muda todo mês por motivo legítimo, e tratar como mudança
encheria a lista de ruído até ninguém mais ler a lista. Ele sai no perfil como
informação.

Rodapé do próprio kit. Todo artefato do kit termina com a assinatura de que foi
gerado com apoio de IA, e o refeito de um mês é a entrada do mês seguinte. Essa
linha é reconhecida pela assinatura, sai contada como `rodape_do_kit` e não é
tratada como dado perdido. Sem esse reconhecimento, o próprio artefato que a
skill grava envenenaria a rodada seguinte.

Valor diferente também não é mudança de estrutura. O relatório do mês atual tem
valores diferentes do mês passado por definição. O modo estrutura compara a
forma, e o modo gabarito é o único que compara valor, contra o mês fechado.

---

Gerado com apoio de IA a partir do catálogo de armadilhas do kit. Revisar antes
de assinar. Não substitui responsabilidade técnica.
