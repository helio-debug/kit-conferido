# A receita do relatório, campo a campo

A receita é o que faz o mês seguinte sair igual ao mês aprovado. Ela é derivada
do relatório aprovado e dos dados brutos daquele mesmo mês, nunca perguntada de
memória: o que a pessoa lembra é o que ela acha que faz, e o que o relatório
mostra é o que ela fez.

**A receita tem duas formas, e as duas são obrigatórias.** O `receita.json` é o
arquivo que o `montar.py` executa, e é ele que faz a montagem sair igual. O
`receita-do-relatorio.md` é a mesma receita em palavras, para quem vai ler,
auditar ou herdar o relatório. Receita só em prosa não monta nada. Receita só em
JSON ninguém confere.

O modelo completo está em `references/receita-exemplo.json`, com uma coluna de
cada regra. A sua receita tem só as colunas do seu relatório.

Campo sem resposta fica escrito como lacuna, com essa palavra, nos dois arquivos.
Coluna com `"regra": "lacuna"` para a montagem de propósito: coluna que ninguém
consegue explicar não é montada por inferência.

---

## 1. Origem

Campo `origem` no JSON. Nada aqui muda a montagem, e é o campo que mais explica
diferença sem causa aparente.

- Qual sistema gerou os dados brutos, e qual relatório ou tela dentro dele.
- O filtro exato usado no export: período, planta, status, centro de custo.
  Este campo não tem detecção automática.
- Quem extrai, em que dia do mês, e se o export é feito antes ou depois do
  fechamento do sistema.

## 2. Leitura do bruto

Campo `leitura`: `delimitador`, `encoding`, `ignorar_linha`.

- Delimitador e encoding em branco significam detecção automática, e a detecção
  sai escrita na nota da montagem, com a evidência.
- `ignorar_linha` é uma expressão regular de linha excluída por decisão
  declarada. Ela sai contada e nomeada no rastro, nunca apagada.
- Rodapé de identificação do sistema e linha de título acima do cabeçalho são
  reconhecidos sozinhos, e também saem contados. Não precisam entrar aqui.
- Se a leitura é por nome de coluna ou por posição, e por quê. O script lê por
  nome.

## 3. De-para de coluna

Campo `colunas`, uma entrada por coluna do relatório final, na ordem em que elas
aparecem. Quatro campos: `nome` no relatório, `regra`, `vem_de` no bruto e
`formato` de saída.

| Regra | O que faz | Exige `vem_de` |
|---|---|---|
| `agrupamento` | Valor da coluna pela qual o relatório agrupa | Sim |
| `copia` | Valor copiado do bruto, sem agregar | Sim |
| `unico` | Valor que deve ser o mesmo em todas as linhas do grupo. Diferindo, a montagem para | Sim |
| `soma` | Soma da coluna do bruto no grupo | Sim |
| `contagem` | Quantas linhas do bruto entraram no grupo | Não |
| `razao` | Divisão de duas colunas somadas, no formato `Boas/Produzidas` | Sim |
| `diferenca` | Subtração de duas colunas somadas, no formato `Previsto-Realizado` | Sim |
| `fixo` | Texto constante, escrito em `vem_de` | Sim |
| `lacuna` | Coluna que ninguém explicou. Para a montagem | Não |

Formatos aceitos: `texto`, `inteiro`, `numero_br:N`, `numero_en:N`,
`moeda_br:N`, `percentual:N`, `data_dmy`, `data_iso`. O `N` é o número de casas
decimais. `percentual` recebe a fração e escreve o percentual: `0,969` sai
`96,9%`.

## 4. Agrupamento e ordem

Campos `agrupar_por` e `ordem`.

- `agrupar_por` é a lista de colunas do bruto que definem o grupo. Lista vazia
  significa uma linha do relatório por linha do bruto.
- `ordem` é uma lista de `{"coluna", "sentido"}`, aplicada na ordem declarada,
  com `crescente` ou `decrescente`. A coluna é a do relatório, não a do bruto.
- Havendo total por bloco, a primeira coluna de `ordem` tem que ser a coluna do
  bloco. Não sendo, o bloco sai partido em dois pedaços e a montagem para, em vez
  de gravar dois totais com o mesmo rótulo.

## 5. Totais

Campo `totais`, com `por_bloco` e `geral`.

- `posicao`: `depois_do_bloco` ou `antes_do_bloco` para o bloco, `rodape` ou
  `topo` para o geral.
- `rotulo` do bloco aceita `{bloco}`, que é substituído pelo valor do bloco. O
  rótulo tem que ser o mesmo, letra por letra, do relatório aprovado.
- `coluna_do_rotulo` é a coluna que recebe o rótulo. Nas outras colunas de texto
  a linha de total sai vazia, que é a forma real: a linha de total não tem código
  de item.
- O total do bloco é recalculado da soma do bloco. Coluna de razão também: média
  de percentual não é o percentual do bloco.

## 6. Formato de saída

Campos `arredondamento` e `saida`.

- `arredondamento`: `depois_de_somar`, que é o padrão, ou `antes_de_somar`.
  Arredondar antes ou depois de somar muda o total, e é a causa mais comum de o
  refazer errar por poucos centavos.
- `saida.encoding` é o encoding do relatório gravado. Declare o mesmo que o
  relatório aprovado usa, que sai escrito no `perfil-atual.txt` do passo 4.
  Declarando outro, o passo 8 acusa `encoding_mudou`, com razão.
- `saida.delimitador` e `saida.assinatura_de_ia`.

## 7. O que a receita não cobre

Campo `nao_coberto`, uma lista. O comentário do mês, o destaque que a pessoa
escreve olhando o número, a decisão sobre o que virou exceção. Isso não é falha
da receita. É a parte que a skill não faz, e escrever isso evita que alguém
confie que faz.

Coluna do bruto que a receita não lê entra aqui também, com o nome exato da
coluna dentro do item. O `montar.py` lista toda coluna do bruto que nenhuma
coluna do relatório consome, no terminal e na nota. Estando escrita aqui, ela é
decisão declarada e não derruba o código 0. Não estando, ela sai como aviso e a
montagem devolve 5, porque coluna que o export ganhou e ninguém leu é a forma
silenciosa de o relatório continuar saindo completo sem o dado novo.

---

## Consolidar um arquivo por área num relatório só

Campo `empilhar`, e só ele. Existindo mais de um arquivo de bruto, ele é
obrigatório.

```
"empilhar": {
  "coluna_de_origem": "Area",
  "origem_por_arquivo": {
    "previsao-utilidades.csv": "Utilidades",
    "previsao-processo.csv": "Processo"
  }
}
```

Duas regras que o script aplica sozinho. Os arquivos empilhados precisam ter o
mesmo cabeçalho, no mesmo nome e na mesma ordem: divergindo, a montagem para e
manda rodar o modo estrutura entre os dois, porque empilhar tabela com coluna em
outra ordem mistura coluna e a soma sai certa com o dado no lugar errado. E cada
arquivo precisa de origem declarada: deduzir a área pelo nome do arquivo
inventaria o nome da área.

A coluna de origem entra em `colunas` como qualquer outra, com
`"regra": "agrupamento"` e `"vem_de"` igual ao nome declarado em
`coluna_de_origem`, e entra em `agrupar_por` na primeira posição.

---

Gerado com apoio de IA a partir do relatório aprovado e dos dados brutos do mês
fechado. Revisar antes de assinar. Não substitui responsabilidade técnica.
