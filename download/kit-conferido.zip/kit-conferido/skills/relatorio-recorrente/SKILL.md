---
name: relatorio-recorrente
description: >
  Recebe o relatório do mês passado, já pronto e aprovado, mais os dados brutos do mês
  atual, e devolve o relatório do mês atual no mesmo formato, montado por script a partir
  de uma receita gravada, mais a lista do que mudou de estrutura entre um mês e outro:
  coluna que sumiu, coluna nova, coluna que trocou de posição ou de formato, coluna que
  passou a vir vazia, critério de agrupamento diferente, linha de total que mudou de lugar.
  Quem monta à mão percebe essas mudanças sem pensar. Quem repete a montagem sem olhar não
  percebe nenhuma. A primeira rodada é obrigatoriamente um refazer: a skill remonta um mês
  já fechado e compara célula a célula, por script, com o relatório entregue na época.
  Entrada e saída em CSV. Use SEMPRE que aparecer: "monta o relatório desse mês", "todo mês
  eu faço esse relatório igual", "refaz esse relatório com os dados novos", "atualiza o
  relatório mensal", "esse painel eu monto à mão todo mês", "os números do painel saem de
  três telas diferentes", "junta as previsões de cada área num relatório só", "o fechamento
  do mês é sempre a mesma planilha", "por que o relatório desse mês ficou diferente do
  passado". NÃO use para conferir duas fontes da mesma verdade
  (conferencia-entre-duas-fontes), para tirar dado de PDF ou de foto
  (extracao-de-documento-para-tabela), nem para decidir o que o relatório deveria medir
  (linha-de-base-antes-de-automatizar).
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que esta skill
ocupe o lugar das outras.

| Caso | Skill | Como se encadeia |
|---|---|---|
| Os dados brutos vêm em PDF, em foto de folha ou em documento escaneado | `extracao-de-documento-para-tabela` | Extraia primeiro, com a taxa medida contra gabarito, e traga o CSV para cá |
| Duas fontes que deveriam dizer a mesma coisa e não dizem | `conferencia-entre-duas-fontes` | O critério é o propósito: lá se procura divergência entre fontes da mesma verdade, aqui se remonta um relatório |
| O relatório é um comparativo de propostas de fornecedor | `comparativo-de-cotacoes` | Lá o que se normaliza é unidade |
| Separar o que responder na caixa cheia | `triagem-de-caixa-de-email` | Independente desta |
| Descrever a área uma vez para as outras skills lerem | `ficha-da-area` | Rode antes. Ela escreve `~/.kit-industrial/ficha-da-area.md`, que o passo 1 lê |
| Registrar o desvio que o relatório deste mês revelou | `registro-de-anomalia` | O achado sai daqui, o registro sai de lá |
| Conferir um procedimento contra a norma | `padrao-conferido-contra-norma` | Independente desta |
| Medir quanto a montagem manual custa hoje, antes de mudar o processo | `linha-de-base-antes-de-automatizar` | Rode antes, se a conversa for sobre automatizar |
| Achar o relatório antigo, a especificação e o anexo que ninguém sabe onde está | `indice-do-acervo-da-area` | Ele acha o relatório aprovado que vira gabarito aqui |

---

# Relatório recorrente

Todo mês a pessoa abre o mesmo export do sistema, abre o relatório do mês passado ao lado,
e refaz: mesma ordem, mesmas colunas, mesmos blocos, mesmos totais. Leva o dia. E a parte
que ela faz sem perceber que está fazendo é a que importa: ela esbarra na coluna que mudou
de lugar, no bloco que ganhou nome novo, na coluna que veio vazia. Corrige na hora e nem
registra.

Quem repete essa montagem sem olhar não esbarra em nada. O relatório sai completo,
ordenado, com cara de certo, e é assinado.

Esta skill entrega três coisas. A receita executável, que é o `receita.json`. O relatório do
mês montado por script a partir dela, com os blocos, os totais e os formatos no lugar. E a
lista do que mudou de estrutura. O que tira o dia da mesa é a primeira: enquanto a regra
está na cabeça de alguém, o mês seguinte é feito de novo à mão.

**Ela termina em arquivo.** O relatório gravado em disco, com o caminho informado.
Resposta em prosa com a tabela dentro é falha de execução.

**Ela não acessa ERP, não acessa rede e não acessa servidor de arquivos.** O export
continua manual, e ela diz isso na cara antes de começar.

---

## Leis de ferro

1. **Nenhuma linha sai da comparação por causa do rótulo.** Item cujo nome contém TOTAL ou
   GERAL é dado. Linha de total é classificada e contada, nunca descartada, e é pareada pelo
   rótulo quando não tem código de item. Descartar por rótulo é como um relatório perde um
   item e fecha do mesmo jeito.
2. **Enquanto o refazer não bater célula a célula, não se usa no mês corrente.** O gabarito
   não é etapa de qualidade no fim. É a condição de uso, e vem antes.
3. **No gabarito, diferença de formato conta.** O produto desta skill é o relatório no
   mesmo formato do que foi aprovado. `1.234,50` contra `1234.5` é achado, não ruído.
4. **A lista de mudanças de estrutura sai antes do relatório do mês.** Relatório montado
   sobre uma estrutura que mudou sai completo e errado, e é o pior resultado possível.
5. **A montagem e a comparação são do script, não da leitura.** Ler duas tabelas lado a
   lado e dizer que batem é amostragem. Montar por leitura entrega este mês e não entrega o
   mês seguinte.
6. **Contagem que não fecha invalida a rodada.** As identidades do passo 9 são
   obrigatórias. Não fechando, o relatório não é entregue.
7. **Dado perdido e decisão declarada não são a mesma coisa, e nenhuma das duas é
   silenciada.** Linha que deveria ter sido comparada e não foi derruba a rodada. Rodapé
   reconhecido pelo padrão, linha excluída em `--ignorar-linha`, célula igualada pela
   tolerância e linha tirada por filtro da receita saem contadas, nomeadas no arquivo de
   rastro e escritas no status. Misturar as duas coisas põe o portão fora de alcance, e
   portão fora de alcance é portão que a pessoa aprende a pular.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Existindo, use o vocabulário da área, os
sistemas em uso e a lista de relatórios que a área já extrai para nomear as colunas e
reconhecer o relatório em questão. Não existindo, declare em voz alta a frase
"rodando sem ficha da área" e siga normalmente.

Rodar sem ficha não degrada o resultado: só obriga a confirmar com a pessoa o nome do
relatório, o sistema de origem e a coluna-chave, que é o passo 3.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi carregada ou se
a rodada está sem ficha e, carregada, repete o status gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir o arquivo

Relatório mensal de indústria carrega dado sensível com frequência alta. Pergunte antes de
pedir o arquivo, nesta ordem:

1. **O que tem dentro?** Cinco classes: nome de pessoa; folha de pagamento, salário e
   remuneração individual; preço de fornecedor identificado; dado de cliente identificado;
   projeto sob sigilo. Folha, salário e remuneração individual não entram em nenhum modo:
   peça o arquivo sem essas colunas, ou rode os dois scripts na máquina, que montam e
   conferem sem enviar conteúdo. Para as outras quatro, ofereça sempre o modo derivado,
   descrito no fim desta página: trabalhar só com o cabeçalho e o perfil das colunas, nunca
   com os valores.
2. **Esse relatório se repete?** Sendo mensal, o script é obrigatório mesmo que a tabela
   caiba na leitura. O valor está em repetir igual, e leitura não repete igual.
3. **Quantas linhas tem o bruto e quantas tem o relatório?** Acima de 150 linhas no
   relatório, ou 400 no bruto, a montagem por script é obrigatória sem exceção, e a receita
   tem que estar no `receita.json` antes de montar.

**Critério de conclusão:** as três respostas estão registradas, e a escolha entre modo
completo e modo derivado está feita antes de qualquer arquivo ser aberto.

---

## Passo 3: reunir as entradas e declarar a chave

Três arquivos são obrigatórios, e a ausência de qualquer um deles para a rodada:

| Entrada | Para quê |
|---|---|
| O relatório aprovado de um mês já fechado | É o gabarito. Tem que ser um que a pessoa entregou e que foi aceito |
| Os dados brutos daquele mesmo mês fechado | É o insumo do refazer. Sem ele não existe gabarito |
| Os dados brutos do mês atual | É o que vira o relatório novo |

Opcional, e recomendado: o relatório aprovado do mês anterior ao fechado, que permite
comparar a estrutura do próprio relatório ao longo do tempo.

Tudo em CSV. Planilha binária precisa ser salva como CSV antes, com a coluna-chave
formatada como Texto, e a conversão é o próprio perigo: está descrito em Falha honesta.

Declare a coluna que identifica a linha nos dois lados. Não havendo coluna que identifique
a linha, o pareamento é por posição, com `--por-posicao`, e aí as duas tabelas precisam ter
o mesmo número de linhas. Chave composta entra como `--chave "Setor,Item"`, confirmada pela
pessoa.

A linha de total não precisa de chave. Ela quase nunca tem código de item, e o script pareia
a linha de chave vazia pelo rótulo, montado com as colunas de texto, e conta isso na nota
como linha de total pareada pelo rótulo.

**Critério de conclusão:** os três arquivos estão na mesa, a coluna-chave está nomeada, e a
pessoa confirmou que o relatório escolhido como gabarito foi mesmo entregue e aceito.

---

## Códigos de saída dos dois scripts

Esta tabela vale para os passos 4, 6, 7 e 8, e cada modo lê o mesmo número de um jeito
diferente. Leia a linha do modo que você está rodando.

| Código | `conferir.py --modo estrutura` | `conferir.py --modo gabarito` | `montar.py` |
|---|---|---|---|
| 0 | Nenhuma mudança de estrutura e nenhuma linha perdida na leitura | O refazer bateu célula a célula e nada ficou fora da comparação | Montou, e cada linha lida virou linha do relatório ou saiu por filtro declarado |
| 1 | Há mudança de estrutura. No passo 4 é o resultado esperado, no passo 8 é defeito | Há célula que não bate, ou diferença de formato | Não sai. Montar não compara |
| 3 | Erro de entrada, fechamento que não fecha, arquivo sem registro, delimitador não detectado, diretório de saída já existente sem `--forcar` | O mesmo, mais nenhuma coluna pareada e nenhuma linha pareada | O mesmo, mais receita inválida, coluna da receita ausente no bruto, lacuna na receita, valor diferente dentro do grupo em coluna declarada única, célula vazia ou não numérica em coluna de soma |
| 5 | Nada mudou, mas sobrou linha com conteúdo perdida na leitura | Nada divergiu, mas sobrou dado fora da comparação | Montou, mas sobrou linha perdida na leitura, coluna do bruto que a receita não lê e ninguém declarou em `nao_coberto`, ou saiu aviso |

O código 5 é o mais importante da tabela, porque 0 é lido como "bateu". Ele sai quando a
rodada aconteceu, nada divergiu, e ainda assim ficou dado que nunca entrou nela. As causas,
no gabarito: linha que existe só de um lado, coluna excluída por `--campos`, coluna
comparada que está vazia dos dois lados, chave repetida com conteúdo diferente, linha de
chave vazia cujo rótulo não achou par, e linha com conteúdo que a leitura não classificou.

**O que não derruba o 0**, porque não é dado da tabela perdido: rodapé de identificação do
sistema reconhecido pelo padrão, rodapé que este kit grava no fim dos próprios artefatos,
linha de título ou de filtro acima do cabeçalho, linha excluída em `--ignorar-linha`, célula
igualada pela tolerância declarada, linha tirada por filtro declarado na receita, e coluna
do bruto que a receita não lê e está escrita em `nao_coberto`. Cada uma dessas sai contada
no bloco de decisões declaradas e nomeada em `linhas-nao-lidas.csv`, na coluna `classe`.

**Célula vazia em coluna de soma não é zero.** Ela conta num balde próprio, sai nomeada no
rastro da montagem, aparece na nota e derruba a rodada com código 3. Somar vazio como zero
grava no relatório um número que o bruto não diz, e o pior é que fecha: a soma lida e a soma
escrita aplicam a mesma suposição e batem. Por isso a identidade da soma declara no lado
esquerdo quantas células ficaram sem valor, e o censo de células obriga cada célula de
coluna de soma a cair em somada, vazia ou não numérica.

Todos os comandos das próximas seções aceitam `--forcar`, e a segunda tentativa do mesmo mês
precisa dele: sem `--forcar` o script recusa sobrescrever a saída da tentativa anterior e
sai com 3. Corrigir a receita e rodar de novo é o caminho normal, não a exceção.

---

## Passo 4: rodar o modo estrutura nos dados brutos

Antes de qualquer conta, compare a estrutura do bruto do mês anterior com a do mês atual.
Leia `references/mudancas-de-estrutura.md` e percorra os quatro grupos.

```
python3 ~/.claude/skills/relatorio-recorrente/scripts/conferir.py --modo estrutura \
    --anterior bruto-2026-07.csv --atual bruto-2026-08.csv \
    --saida estrutura-2026-08 --forcar
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho vai entre
aspas com `$env:USERPROFILE` no lugar do `~`, e a linha continua com acento grave no lugar
da barra invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\relatorio-recorrente\scripts\conferir.py" --modo estrutura `
    --anterior bruto-2026-07.csv --atual bruto-2026-08.csv `
    --saida estrutura-2026-08 --forcar
```

Cada mudança sai com o efeito de ninguém olhar, escrito na linha. Mudança que a pessoa
aceita vira decisão registrada na receita. Mudança que a pessoa não esperava para a rodada:
o relatório não se monta sobre estrutura que mudou sem alguém saber.

**Critério de conclusão:** `mudancas-de-estrutura.md` está gravado, todas as linhas do
fechamento dizem `fecha`, e cada mudança listada recebeu uma resposta, aceita ou corrigida.
Código de saída 1 aqui não é falha: é a skill fazendo o que promete. Código 5 aqui é linha
com conteúdo perdida na leitura, e ela é lida antes de seguir: linha de dado acima do
cabeçalho eleito é a forma mais silenciosa de perder um item.

---

## Passo 5: derivar a receita e gravar o `receita.json`

Com o relatório aprovado do mês fechado e os dados brutos do mesmo mês lado a lado, derive
a regra que transforma um no outro. Os campos estão em `references/receita-do-relatorio.md`
e são sete: origem e filtro do export, leitura do bruto, de-para de coluna, agrupamento e
ordem, totais, formato de saída, e o que a receita não cobre. O modelo completo, com uma
coluna de cada regra, está em `references/receita-exemplo.json`.

A receita sai em dois arquivos, e os dois são obrigatórios. O `receita.json` é o que o
script executa. O `receita-do-relatorio.md` é a mesma receita em palavras, para quem vai
ler, auditar ou herdar o relatório. Receita só em prosa não monta nada, e é por isso que o
mês seguinte volta para a mão.

Derive, não pergunte de memória. O que a pessoa lembra é o que ela acha que faz. O que o
relatório mostra é o que ela fez. Campo sem resposta fica escrito como lacuna, com essa
palavra, nos dois arquivos, e nunca preenchido por inferência: coluna com
`"regra": "lacuna"` para a montagem de propósito.

Declare em `saida.encoding` o encoding do relatório aprovado, que o passo 4 imprimiu em
`perfil-atual.txt`. Quem sai do Excel em `cp1252` e é montado em `utf-8` acusa
`encoding_mudou` no passo 8, com razão.

**Critério de conclusão:** `receita.json` e `receita-do-relatorio.md` estão gravados, cada
coluna do relatório tem regra, origem e formato declarados, e as lacunas estão marcadas como
lacuna.

---

## Passo 6: a lei do gabarito

Esta é a rodada que libera o uso, e são dois comandos. Primeiro monte o relatório do mês
**já fechado** a partir dos dados brutos daquele mês, pela receita do passo 5. Depois compare
o que saiu com o relatório que a pessoa entregou na época.

```
python3 ~/.claude/skills/relatorio-recorrente/scripts/montar.py \
    --receita receita.json --bruto bruto-2026-07.csv \
    --saida refeito-2026-07.csv --forcar
```

```
python3 ~/.claude/skills/relatorio-recorrente/scripts/conferir.py --modo gabarito \
    --entregue relatorio-2026-07.csv --refeito refeito-2026-07.csv \
    --chave Codigo --saida gabarito-2026-07 --forcar
```

A montagem é do script, e a comparação é do script. Montar por leitura entrega este mês e
deixa o mês seguinte na mesa. Ler as duas tabelas e dizer que batem é amostragem.

Opções do gabarito que resolvem os casos comuns:

- `--campos "Qtde:Quantidade,Dt:Data"` quando o nome da coluna difere entre os dois. Sem
  `--campos`, coluna sem par derruba a rodada com código 3, porque no gabarito coluna sem
  par é o próprio defeito: o refazer não produziu as mesmas colunas. Com `--campos`, a
  exclusão passa a ser decisão declarada, a rodada anda, e as colunas fora da comparação
  saem nomeadas. Elas continuam derrubando o 0.
- `--chave-sem-zeros` quando o zero à esquerda se perdeu de um lado.
- `--por-posicao` quando o relatório não tem coluna que identifique a linha.
- `--tolerancia 0.01` quando a diferença de centavo por arredondamento é aceita. Vem
  desligada: por padrão a igualdade é exata. Cada célula dada como igual pela tolerância sai
  contada, e o status passa a dizer `bateu celula a celula, dentro das decisoes declaradas`.
  A tolerância declarada tem que estar escrita na receita, no campo `arredondamento`.
- `--ignorar-linha "Emitido em"` para excluir uma linha por decisão declarada, com a
  contagem na nota. O rodapé de identificação do sistema já é reconhecido sem esta opção.

Coluna vazia dos dois lados merece um parágrafo. Ela dá acerto de cem por cento e não prova
nada, e é o caminho mais silencioso para um gabarito falso. Por isso ela derruba o 0.

**Enquanto o código não for 0, o refazer não vai para o mês corrente.** Cada célula que não
bate é corrigida na receita, não no resultado. Corrigir o resultado faz este mês fechar e o
próximo errar igual.

**Critério de conclusão:** a montagem saiu com 0, o gabarito saiu com 0, todas as linhas do
fechamento dizem `fecha`, e a `nota-do-refazer.md` está com `status: bateu celula a celula`,
ou com `status: bateu celula a celula, dentro das decisoes declaradas` e cada decisão
declarada escrita na receita.

---

## Passo 7: montar o relatório do mês atual

Só depois do código 0 no passo 6. O comando é o mesmo, com o bruto do mês atual:

```
python3 ~/.claude/skills/relatorio-recorrente/scripts/montar.py \
    --receita receita.json --bruto bruto-2026-08.csv \
    --saida relatorio-2026-08.csv --forcar
```

A receita já traz as colunas, a ordem, o agrupamento, os totais no mesmo lugar e o formato
de número e de data. O que ela não cobre continua manual e sai listado na nota da montagem:
o comentário do mês, o destaque escrito olhando o número, a decisão sobre o que virou
exceção.

Junto com esses, a nota lista **toda coluna do bruto que nenhuma coluna do relatório lê**, e
o terminal repete a lista. É aqui que a coluna nova do export aparece para quem pulou o
passo 4. Coluna que fica de fora de propósito entra em `nao_coberto`, com o nome exato da
coluna, e passa a ser decisão declarada. Sem isso ela sai como aviso e a montagem devolve 5.

Este é o passo exposto: se o bruto do mês corrente trouxer célula vazia em coluna de soma, o
gabarito do passo 6 já passou e não pega mais nada. Por isso a célula vazia para a montagem
aqui, com código 3, em vez de virar `0,00` num relatório que vai assinado.

**Um arquivo por área, um relatório só.** Sendo o caso de consolidação, repita `--bruto` uma
vez por arquivo e declare `empilhar` na receita, com a coluna de origem e a origem de cada
arquivo. O script recusa empilhar arquivos de cabeçalho diferente e manda rodar o passo 4
entre eles, porque empilhar tabela com a coluna em outra ordem mistura coluna e a soma sai
certa com o dado no lugar errado. E recusa deduzir a área pelo nome do arquivo.

```
python3 ~/.claude/skills/relatorio-recorrente/scripts/montar.py \
    --receita receita.json \
    --bruto previsao-utilidades.csv --bruto previsao-processo.csv \
    --saida relatorio-2026-08.csv --forcar
```

**Critério de conclusão:** o código de saída é 0, o arquivo está gravado, o caminho absoluto
foi informado, a identidade da soma fecha, e a lista do que continua manual foi dita junto.
Código 5 aqui é linha perdida na leitura ou aviso: leia
`relatorio-2026-08.linhas-fora-da-montagem.csv` antes de entregar.

---

## Passo 8: conferir a estrutura do que foi montado

Rode o modo estrutura de novo, agora entre o relatório aprovado e o que acabou de ser
montado.

```
python3 ~/.claude/skills/relatorio-recorrente/scripts/conferir.py --modo estrutura \
    --anterior relatorio-2026-07.csv --atual relatorio-2026-08.csv \
    --saida estrutura-relatorio-2026-08 --forcar
```

Aqui a expectativa é o contrário do passo 4: código 0. Qualquer diferença de estrutura
entre o aprovado e o montado é defeito do montado, a menos que seja uma mudança que a
pessoa pediu neste mês. Nesse caso ela sai registrada no arquivo, e não some.

Duas mudanças aqui quase sempre são erro de receita, não do mês. `encoding_mudou` significa
que `saida.encoding` não é o encoding do aprovado. `rotulos_de_total_mudaram` significa que o
rótulo declarado em `totais` não é o do aprovado, letra por letra.

**Critério de conclusão:** o código é 0, ou cada mudança listada tem uma decisão da pessoa
escrita ao lado. Código 5 aqui é linha perdida na leitura de um dos dois arquivos, e ela é
lida antes de entregar.

---

## Passo 9: fechamento

Confira as identidades impressas pelos scripts. Todas devem fechar, e os números vão na
nota.

No `montar.py`:

```
registros_lidos = agregados + filtrados_por_regra_declarada
linhas_do_relatorio = linhas_de_grupo + linhas_de_total
linhas gravadas no relatorio = linhas_do_relatorio
celulas de cada coluna de soma lidas = somadas + vazias + nao numericas
soma de cada coluna lida no bruto = soma da coluna escrita no relatorio
```

As duas últimas andam juntas. O censo obriga cada célula de coluna de soma a cair num dos
três baldes, e a conta dos três tem que dar o número de linhas agregadas: célula que não
aparece em balde nenhum é célula que sumiu antes de qualquer conta. A da soma lê de volta o
número gravado no arquivo, com o formato declarado, e compara com a soma acumulada na
leitura do bruto, declarando no lado esquerdo quantas células ficaram sem valor. Ela só pode
fechar quando não houve nenhuma, e é isso que impede que ela feche aplicando `vazio é zero`
dos dois lados. Fechando as duas, a montagem não perdeu linha, não contou a mesma linha duas
vezes e não inventou número.

No modo gabarito:

```
celulas_do_entregue = comparadas + so_no_entregue
celulas_do_refeito  = comparadas + so_no_refeito
comparadas          = iguais + tolerancia + formato + diferentes
registros_do_entregue = pareadas + fora_do_pareamento
registros_do_refeito  = pareadas + fora_do_pareamento
linhas gravadas em cada CSV de saída = o contador correspondente
```

No modo estrutura:

```
colunas_no_anterior  = pareadas + sumiram
colunas_no_atual     = pareadas + novas
colunas_da_uniao     = colunas_conferidas
atributos_conferidos = iguais + mudancas
linhas gravadas em mudancas-de-estrutura.csv = mudancas
```

O lado esquerdo de cada identidade vem da forma da tabela, em células e em registros. O
lado direito vem de contadores incrementados dentro do laço. Isso é de propósito:
identidade cujas partes são derivadas por subtração fecha sozinha mesmo com dado faltando,
e provaria só que a aritmética está certa.

As identidades provam que a contabilidade é consistente, não que a rodada prestou. O que
pode falhar de fato vem no bloco de verificações, impresso no terminal e repetido na nota:
células comparadas, linhas pareadas, linhas de total pareadas por rótulo, colunas pareadas,
células que não batem, diferença de formato, linhas perdidas na leitura, e cada item que
ficou fora da comparação. Zero em células comparadas ou em linhas pareadas invalida a
rodada, cada item fora da comparação exige uma decisão registrada, e cada decisão declarada
exige uma linha na receita.

**Critério de conclusão:** todas as identidades foram impressas com os números e fecham, e
cada linha do bloco de verificações foi lida e respondida. Quebrando uma identidade, a
entrega para e o motivo é dito.

---

## Contrato de saída

Cinco conjuntos de arquivo, com o caminho absoluto informado no fim.

### 1. `receita.json` e `receita-do-relatorio.md`

Do passo 5. São os arquivos que fazem o mês seguinte sair igual, e os únicos que sobrevivem
à rodada. O primeiro é executado pelo `montar.py`. O segundo tem as sete seções em palavras,
conforme a referência.

### 2. Diretório do modo estrutura

| Arquivo | Conteúdo |
|---|---|
| `mudancas-de-estrutura.md` | A lista do que mudou, com o efeito de ninguém olhar, mais as decisões declaradas e o fechamento |
| `mudancas-de-estrutura.csv` | Uma linha por mudança: tipo, alvo, antes, depois, efeito |
| `perfil-anterior.txt`, `perfil-atual.txt` | O perfil estrutural de cada mês, em texto simples, para diferença com qualquer ferramenta |
| `linhas-nao-lidas.csv` | Toda linha que não virou registro, com lado, linha, classe, causa e conteúdo. A classe diz se foi perdida, reconhecida ou declarada. É o arquivo que impede o descarte silencioso |

### 3. Diretório do gabarito

| Arquivo | Conteúdo |
|---|---|
| `nota-do-refazer.md` | Escrita antes de qualquer comparação, com `status: incompleto`, e reescrita no fim com o status final. Traz arquivos, pareamento, resultado, o que ficou fora, as decisões declaradas e o fechamento |
| `celulas-que-nao-batem.csv` | Linha no entregue, linha no refeito, coluna dos dois lados, valor dos dois lados |
| `diferencas-de-formato.csv` | Mesmo valor escrito de outro jeito. No gabarito isso conta |
| `so-no-entregue.csv`, `so-no-refeito.csv` | Linha que não pareou, com a causa e a linha inteira |
| `linhas-nao-lidas.csv` | Igual ao do modo estrutura |

Os seis valores de `status` da nota, na string exata que o script grava:

| Status | O que obriga |
|---|---|
| `incompleto` | A rodada caiu no meio. A saída inteira não vale |
| `invalido, nao fecha` | Uma identidade de fechamento não fecha. A saída inteira não vale, e o número das duas pontas vai na resposta |
| `nao bateu, o refazer ainda nao pode ser usado no mes corrente` | Corrigir a receita, nunca o resultado, e rodar de novo |
| `bateu no que comparou, e sobrou dado fora da comparacao` | Ler o que ficou fora e decidir item por item. Não libera o passo 7 |
| `bateu celula a celula` | Libera o passo 7 |
| `bateu celula a celula, dentro das decisoes declaradas` | Libera o passo 7, com cada decisão declarada escrita na receita |

### 4. Saída da montagem

| Arquivo | Conteúdo |
|---|---|
| `relatorio-<aaaa-mm>.csv` | O entregável. Mesma estrutura do aprovado |
| `relatorio-<aaaa-mm>.nota-da-montagem.md` | Receita usada, arquivos lidos, contagens, células vazias e não numéricas em coluna de soma, decisões declaradas, fechamento, o que a receita não cobre e as colunas do bruto que nenhuma coluna do relatório lê |
| `relatorio-<aaaa-mm>.linhas-fora-da-montagem.csv` | Toda linha do bruto que não virou linha do relatório, com arquivo, linha, classe, causa e detalhe |

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de <fonte>. Revisar antes de assinar. Não substitui
responsabilidade técnica.
```

Nos CSV ele sai na última linha, iniciada por `#`, e não é um dado. Os dois scripts
reconhecem essa assinatura na leitura e a contam como rodapé do kit, porque o refeito de um
mês é a entrada do mês seguinte.

---

## Modo derivado, para dado sensível

Três níveis. O padrão, quando a pessoa não decide, é o nível do meio.

**Só o cabeçalho.** A pessoa cola apenas a linha de cabeçalho dos arquivos e, querendo,
duas ou três linhas com os valores trocados por exemplos inventados que preservem o formato:
mesmo número de dígitos, mesma pontuação, mesmo separador. Com isso dá para derivar o
de-para de coluna, escrever o `receita.json` e devolver as linhas de comando prontas.
Nenhum valor real é lido.

**Script local, o padrão.** A pessoa roda os dois scripts na máquina dela. O conteúdo nunca
chega ao modelo, e o relatório é montado do mesmo jeito, porque quem monta é o
`montar.py` com o `receita.json`. Depois ela cola só a `nota-do-refazer.md`, a
`nota-da-montagem.md` e o `mudancas-de-estrutura.md`, que por construção não contêm valor de
célula: só nome de arquivo, tamanho, nome de coluna, nome de regra e contagem. Nome de
arquivo em indústria costuma identificar a planta, o cliente ou o projeto: sendo o caso,
renomeie os arquivos antes de rodar, ou apague a seção de arquivos da nota antes de colar.

**Nada sai.** O modelo entrega as linhas de comando e a explicação de como ler cada arquivo
de saída. A pessoa responde apenas se fechou, e não tendo fechado, qual identidade quebrou.

Regra que não se quebra: com dado sensível, a leitura, a montagem e a filtragem são locais.
Nunca peça o `celulas-que-nao-batem.csv` colado para resumir.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**Não existem os dados brutos do mês fechado.** Sem eles não há refazer, sem refazer não há
gabarito, e sem gabarito a skill não roda no mês corrente. Não é rigor: é que um relatório
mensal montado por regra derivada de memória sai completo e ninguém consegue dizer se está
certo. Peça o export do mês fechado ao mesmo sistema. Não existindo, diga o que faltaria e
pare.

**O relatório escolhido como gabarito nunca foi aceito.** Rascunho não serve. Gabarito é o
que foi entregue e aceito, porque o que se está provando é a capacidade de reproduzir o
resultado aprovado.

**Ela entrega tabela, não desenha painel.** A saída é CSV, e a montagem do gráfico, da cor e
do layout continua na ferramenta de painel da empresa. O trabalho que ela tira da mesa é o
de juntar, somar e formatar os números que alimentam o painel.

**Alguma coluna do relatório ninguém consegue explicar.** Ela fica como lacuna na receita, e
a montagem para dizendo qual é. Preencher por inferência entrega uma coluna que ninguém
sabe conferir. O caminho é derivar a regra do relatório aprovado, ou tirar a coluna da
receita e declarar que ela continua manual.

**Planilha binária.** Os scripts são de biblioteca padrão e não leem `.xlsx`. A instrução é
converter para CSV, e a conversão é o próprio perigo: salvar com a coluna de código
formatada como número apaga zero à esquerda e converte código longo em notação científica,
de forma irreversível. Antes de salvar, formate a coluna-chave como Texto. Depois de
converter, abra o CSV num editor de texto e confirme que os zeros continuam lá. O script
detecta o estrago e reporta, e não desfaz. A saída também é CSV: quem cola no arquivo final
formatado é a pessoa, e a skill diz isso em vez de fingir que entrega a planilha pronta.

**A granularidade do bruto mudou.** Uma linha por item virou uma linha por item e lote. A
soma duplica sem nenhum valor estar errado. A skill para e pergunta qual agregação a área
usa, em vez de agregar por conta própria. Na montagem, coluna declarada única com valor
diferente dentro do grupo tem o mesmo tratamento: para e mostra os valores, em vez de
escolher um.

**O relatório depende de julgamento a cada mês.** Relatório cujo conteúdo é a análise
escrita olhando o número não é recorrente no sentido desta skill. Ela monta a tabela e diz
o que continua manual. Não escreve o comentário.

**Dados brutos em PDF ou em foto.** É extração, não montagem. Encadeie com
`extracao-de-documento-para-tabela`, que devolve valor, confiança e origem por campo e só
libera o uso depois da taxa medida contra gabarito.

---

## Referência

A pasta da skill fica em `~/.claude/skills/relatorio-recorrente/` depois de instalada. Os
arquivos de referência são lidos por esse caminho, e os scripts são chamados pelo caminho
completo. Caminho relativo só funciona de dentro da pasta da skill, e a rodada acontece na
pasta dos arquivos de trabalho.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/relatorio-recorrente/references/mudancas-de-estrutura.md` | Catálogo das mudanças de estrutura em quatro grupos: cabeçalho, conteúdo da coluna, forma do arquivo e lógica do relatório. Cada item com manifestação, detecção, efeito de ninguém olhar e o que fazer. Traz também o que não é mudança de estrutura, e por quê |
| `~/.claude/skills/relatorio-recorrente/references/receita-do-relatorio.md` | Os sete campos da receita, a tabela de regras por coluna, os formatos aceitos e a consolidação de um arquivo por área |
| `~/.claude/skills/relatorio-recorrente/references/receita-exemplo.json` | O `receita.json` completo, com uma coluna de cada regra. Ponto de partida para escrever o do relatório em questão |
| `~/.claude/skills/relatorio-recorrente/scripts/montar.py` | A montagem: lê o `receita.json` e os brutos, agrupa, soma, ordena, formata, posiciona os totais, empilha um arquivo por área e grava o relatório mais o rastro de toda linha que não entrou. Python 3.8 de biblioteca padrão |
| `~/.claude/skills/relatorio-recorrente/scripts/conferir.py` | A conferência, nos dois modos, em Python 3.8 de biblioteca padrão (`argparse`, `csv`, `datetime`, `decimal`, `re`, `sys`, `unicodedata`, `pathlib`). Sem instalação, sem rede, sem escrita nos arquivos de entrada. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções |
| `~/.claude/skills/relatorio-recorrente/scripts/testar.py` | Teste de regressão dos dois scripts, biblioteca padrão apenas. Cada caso é gerado em diretório temporário, mais o ciclo inteiro (montar o mês fechado e conferir contra o aprovado) e a conferência de coerência entre esta página e os scripts. Os casos não foram escritos a partir das funcionalidades: foram escritos a partir de uma pergunta só, existe caminho em que a rodada sai com sucesso tendo perdido dado. Item cujo nome contém TOTAL e GERAL tratado como descarte, linha de total não comparada, linha de total com a chave vazia, nome de coluna repetido no cabeçalho, linha de dado acima do cabeçalho eleito, nenhuma coluna emparelhada, nenhuma linha emparelhada, coluna excluída por `--campos`, coluna comparada vazia dos dois lados, coluna que passou a vir vazia em parte das linhas, linha com conteúdo não lida, rodapé do próprio kit na entrada, diferença só de formato contada como igualdade, duplicata divergente, parte do fechamento derivada por subtração, delimitador não detectado, arquivo sem registro, lacuna na receita, célula não numérica em coluna de soma, célula vazia em coluna de soma virando zero no relatório, identidade da soma fechando com a mesma suposição dos dois lados, censo de células de coluna de soma, coluna do bruto que a receita não lê, valor diferente dentro do grupo, ordem que parte o bloco, e consolidação sem coluna de origem. Rode `python3 ~/.claude/skills/relatorio-recorrente/scripts/testar.py` depois de qualquer mudança nos scripts, ou `py -3 "$env:USERPROFILE\.claude\skills\relatorio-recorrente\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
