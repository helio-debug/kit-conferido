#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
conferir.py, da skill relatorio-recorrente.

Biblioteca padrao apenas. Nao le .xlsx, nao acessa ERP, nao acessa rede e nao
escreve nos arquivos de entrada.

Dois modos.

  --modo estrutura
      Compara a estrutura de dois arquivos do mesmo tipo em dois meses e lista
      o que mudou: coluna que sumiu, coluna nova, coluna que trocou de posicao,
      coluna que trocou de formato, coluna que ficou vazia, criterio de
      agrupamento diferente, linha de total que mudou de lugar. Rode nos dados
      brutos (mes anterior contra mes atual) e depois no relatorio.

  --modo gabarito
      Compara celula a celula o relatorio refeito contra o relatorio que foi
      entregue na epoca. E a rodada que libera o uso no mes corrente.

Codigos de saida:

  0  rodou inteiro, nada divergiu e nada ficou fora da comparacao
  1  rodou, ha diferenca (celula que nao bate, ou mudanca de estrutura)
  3  erro de entrada, fechamento que nao fecha, ou rodada que nao comparou nada
  5  rodou, nada divergiu, mas sobrou dado fora da comparacao

O codigo 5 existe porque 0 e lido como "bateu". Chave que existe so de um lado,
coluna excluida por decisao declarada, coluna comparada vazia dos dois lados,
duplicata divergente e linha que nao foi lida sao dado que nunca entrou na
comparacao, e a rodada nao pode devolver o codigo que dispensa a leitura dos
arquivos de saida.

Regra que atravessa o arquivo inteiro: nenhuma linha sai da comparacao por causa
do rotulo. Linha com marcador de total e classificada e contada, nunca
descartada. Item cujo nome contem TOTAL ou GERAL e dado.
"""

import argparse
import csv
import re
import sys
import unicodedata
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

OK = 0
DIFERENCA = 1
ERRO = 3
SOBROU = 5

ENCODINGS_TENTADOS = ("utf-8", "cp1252", "latin-1")
DELIMITADORES = (";", ",", "\t", "|")
NOME_DELIM = {";": "ponto e virgula", ",": "virgula", "\t": "tabulacao",
              "|": "barra vertical"}

CATEGORICAS = ("texto", "vazio", "misto")

MARCADOR_TOTAL = re.compile(
    r"\b(total|totais|subtotal|sub total|soma|somatorio|acumulado|geral)\b")
RODAPE_RELATORIO = re.compile(
    r"\b(emitido em|impresso em|pagina \d|pag \d|relatorio gerado|"
    r"gerado em|usuario:|sistema:)\b")

RODAPE = ("Gerado com apoio de IA a partir de %s. Revisar antes de assinar. "
          "Nao substitui responsabilidade tecnica.")

# A assinatura que este kit grava no fim de todo artefato. O refeito de um mes e
# a entrada do mes seguinte, entao a assinatura precisa ser reconhecida na
# leitura em vez de virar dado perdido e derrubar a rodada seguinte.
ASSINATURA_DO_KIT = re.compile(r"^#\s*gerado com apoio de ia")

# Queda de preenchimento, em pontos percentuais, a partir da qual a coluna que
# passou a vir vazia em parte das linhas entra como mudanca de estrutura. Coluna
# que fica vazia de uma vez e o caso raro. O caso frequente e o apontamento que
# parou no meio do mes.
LIMITE_QUEDA_PREENCHIMENTO = 20

# Nome da causa por classe. Linha perdida derruba o codigo 0. Linha reconhecida
# pelo padrao e linha excluida por decisao declarada saem contadas e nomeadas,
# sem derrubar, porque nenhuma das duas e dado da tabela.
CLASSE_DA_CAUSA = {
    "linha_vazia": "linha_sem_conteudo",
    "contagem_de_colunas_diferente_do_cabecalho": "perdida",
    "acima_do_cabecalho_com_a_largura_da_tabela": "perdida",
    "rodape_do_kit": "reconhecida",
    "rodape_de_sistema": "reconhecida",
    "titulo_ou_filtro_acima_do_cabecalho": "reconhecida",
    "ignorada_por_ignorar_linha": "declarada",
}


# ---------------------------------------------------------------- utilidades

def sem_acento(texto):
    decomposto = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in decomposto if not unicodedata.combining(c))


def normal(texto):
    return re.sub(r"\s+", " ", sem_acento(texto or "").strip().lower())


def tipo_celula(valor):
    """Perfil de uma celula. Ambiguidade e declarada, nao resolvida."""
    v = (valor or "").strip()
    if v == "":
        return "vazio"
    if re.fullmatch(r"-?\d{1,3}(\.\d{3})+,\d+", v):
        return "numero_br"
    if re.fullmatch(r"-?\d+,\d+", v):
        return "numero_br"
    if re.fullmatch(r"-?\d{1,3}(,\d{3})+\.\d+", v):
        return "numero_en"
    if re.fullmatch(r"-?\d{1,3}\.\d{3}", v):
        return "ambiguo_milhar"
    if re.fullmatch(r"-?\d{1,3},\d{3}", v):
        return "ambiguo_milhar"
    if re.fullmatch(r"-?\d+\.\d+", v):
        return "numero_en"
    if re.fullmatch(r"\d{2}/\d{2}/\d{4}", v):
        return "data_dmy"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        return "data_iso"
    if re.fullmatch(r"-?[\d.,]+\s*%", v):
        return "percentual"
    if re.fullmatch(r"(R\$|US\$|\$)\s*-?[\d.,]+", v):
        return "moeda"
    if re.fullmatch(r"-?\d+", v):
        return "inteiro"
    return "texto"


def valor_numerico(valor, tipo):
    """Decimal do valor, ou None quando nao for numero sem chute."""
    v = (valor or "").strip()
    if v == "":
        return None
    if tipo in ("numero_br",):
        v = v.replace(".", "").replace(",", ".")
    elif tipo in ("numero_en",):
        v = v.replace(",", "")
    elif tipo in ("percentual",):
        v = v.rstrip("%").strip()
        v = v.replace(".", "").replace(",", ".") if "," in v else v
    elif tipo in ("moeda",):
        v = re.sub(r"^(R\$|US\$|\$)\s*", "", v)
        v = v.replace(".", "").replace(",", ".") if "," in v else v
    elif tipo in ("inteiro",):
        pass
    else:
        return None
    try:
        return Decimal(v)
    except InvalidOperation:
        return None


def valor_canonico(valor):
    """Forma canonica para saber se a diferenca e so de formato."""
    v = (valor or "").strip()
    if v == "":
        return ""
    tipo = tipo_celula(v)
    if tipo in ("numero_br", "numero_en", "inteiro", "percentual", "moeda"):
        num = valor_numerico(v, tipo)
        if num is not None:
            return "num:" + str(num.normalize())
    if tipo == "data_dmy":
        try:
            return "data:" + datetime.strptime(v, "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            return v
    if tipo == "data_iso":
        return "data:" + v
    return normal(v)


def unidade_no_nome(nome):
    achado = re.search(r"[\(\[]\s*([^\)\]]{1,12})\s*[\)\]]", nome or "")
    return normal(achado.group(1)) if achado else ""


# -------------------------------------------------------------------- leitura

class ErroDeEntrada(Exception):
    pass


class ContadorDeLinhas(object):
    """Alimenta o csv.reader guardando a linha fisica que abriu cada registro.

    Uma celula com quebra de linha dentro ocupa mais de uma linha no arquivo e
    continua sendo um registro so.
    """

    def __init__(self, linhas):
        self.linhas = linhas
        self.i = 0
        self.inicio = 1
        self.novo = True

    def __iter__(self):
        return self

    def __next__(self):
        if self.i >= len(self.linhas):
            raise StopIteration
        if self.novo:
            self.inicio = self.i + 1
            self.novo = False
        linha = self.linhas[self.i]
        self.i += 1
        return linha


class Registro(object):
    __slots__ = ("linha", "celulas")

    def __init__(self, linha, celulas):
        self.linha = linha
        self.celulas = celulas


class Tabela(object):
    def __init__(self, caminho):
        self.caminho = Path(caminho)
        self.encoding = ""
        self.evidencia_encoding = ""
        self.delimitador = ""
        self.evidencia_delimitador = ""
        self.linha_cabecalho = 0
        self.colunas = []
        self.registros = []
        self.nao_lidas = []            # (linha, causa, conteudo), dado perdido
        self.reconhecidas = []         # (linha, causa, conteudo), nao e dado
        self.ignoradas_declaradas = []  # (linha, conteudo)
        self.colunas_repetidas = []    # (nome, nome desambiguado)
        self.colunas_sem_nome = []     # nome dado a cabecalho vazio
        self.criterio_do_cabecalho = ""
        self.antes_do_cabecalho = 0
        self.linhas_no_arquivo = 0


def detectar_encoding(caminho, forcado):
    dados = Path(caminho).read_bytes()
    if forcado:
        return forcado, "declarado em --encoding"
    if dados.startswith(b"\xef\xbb\xbf"):
        return "utf-8-sig", "BOM de UTF-8 no inicio do arquivo"
    for enc in ENCODINGS_TENTADOS:
        try:
            dados.decode(enc)
        except UnicodeDecodeError:
            continue
        if enc == "utf-8":
            return enc, "decodifica inteiro em UTF-8"
        return enc, "nao decodifica em UTF-8, decodifica em %s" % enc
    return "latin-1", "ultimo recurso, nenhum encoding decodificou limpo"


def detectar_delimitador(linhas, forcado):
    if forcado:
        return forcado, "declarado em --delimitador"
    amostra = [l for l in linhas[:40] if l.strip()]
    if not amostra:
        raise ErroDeEntrada("arquivo sem nenhuma linha com conteudo")
    placar = []
    for d in DELIMITADORES:
        contagens = [l.count(d) for l in amostra]
        if max(contagens) == 0:
            continue
        frequente = max(set(contagens), key=contagens.count)
        if frequente == 0:
            continue
        acerto = contagens.count(frequente) / float(len(contagens))
        placar.append((acerto, frequente, d))
    if not placar:
        return None, "nenhum de ; , tabulacao | aparece nas primeiras linhas"
    placar.sort(key=lambda t: (t[0], t[1]), reverse=True)
    acerto, frequente, d = placar[0]
    evid = "%s, %d ocorrencias em %d%% das primeiras linhas" % (
        NOME_DELIM[d], frequente, int(round(acerto * 100)))
    return d, evid


def achar_cabecalho(brutos):
    """Primeira linha que serve de cabecalho. brutos: [(linha, celulas)].

    Duas passadas, e a ordem importa. A primeira exige que nenhuma celula
    preenchida seja numero, data, percentual ou moeda, porque nome de coluna
    quase nunca e numero. So nao havendo linha assim vale a maioria de dois
    tercos, que e a regra frouxa: uma linha de dado com duas celulas de texto e
    duas de numero passa por ela e vira cabecalho, e ai a linha de cabecalho de
    verdade vira registro e as colunas do arquivo inteiro saem com nome de
    valor. Devolve (indice, criterio).
    """
    if not brutos:
        return None, ""
    larguras = [len(c) for _, c in brutos]
    largura = max(set(larguras), key=larguras.count)
    for exigencia in ("todas", "maioria"):
        indice = achar_cabecalho_com(brutos, largura, exigencia)
        if indice is not None:
            return indice, exigencia
    return None, ""


def achar_cabecalho_com(brutos, largura, exigencia):
    for i, (_, cel) in enumerate(brutos):
        if len(cel) != largura:
            continue
        preenchidas = [c for c in cel if c.strip()]
        if len(preenchidas) < 2:
            continue
        textuais = sum(1 for c in preenchidas if tipo_celula(c) == "texto")
        if exigencia == "todas":
            if textuais != len(preenchidas):
                continue
        elif textuais < max(2, int(len(preenchidas) * 0.6)):
            continue
        # Nome de coluna repetido nao desqualifica a linha de cabecalho. Export
        # de ERP traz duas colunas Qtde, duas Data ou duas Valor com frequencia,
        # e trocar de cabecalho por causa disso adota a primeira linha de dado
        # como cabecalho e perde essa linha em silencio. A repeticao e
        # desambiguada na leitura e sai como achado.
        return i
    return None


def nomear_colunas(tab, celulas):
    """Nomeia o cabecalho sem descartar coluna.

    Nome repetido e desambiguado com #2, #3. Cabecalho vazio recebe nome de
    posicao: coluna sem nome que o script deixasse cair levaria o dado dela
    junto.
    """
    nomes = []
    vistos = {}
    for j, bruta in enumerate(celulas):
        nome = bruta.strip()
        if nome == "":
            nome = "(sem nome %d)" % (j + 1)
            tab.colunas_sem_nome.append(nome)
        chave = normal(nome)
        if chave in vistos:
            vistos[chave] += 1
            novo = "%s#%d" % (nome, vistos[chave])
            tab.colunas_repetidas.append((nome, novo))
            nome = novo
        else:
            vistos[chave] = 1
        nomes.append(nome)
    return nomes


def ler(caminho, enc_forcado=None, delim_forcado=None, ignorar=None):
    tab = Tabela(caminho)
    if not tab.caminho.exists():
        raise ErroDeEntrada("arquivo nao encontrado: %s" % caminho)
    if tab.caminho.suffix.lower() in (".xlsx", ".xls", ".xlsm"):
        raise ErroDeEntrada(
            "%s e planilha binaria. Este script e de biblioteca padrao e nao le "
            "xlsx. Salve como CSV com a coluna-chave formatada como Texto e "
            "rode de novo." % tab.caminho.name)
    tab.encoding, tab.evidencia_encoding = detectar_encoding(caminho, enc_forcado)
    texto = tab.caminho.read_text(encoding=tab.encoding, errors="replace")
    linhas = texto.splitlines()
    tab.linhas_no_arquivo = len(linhas)
    tab.delimitador, tab.evidencia_delimitador = detectar_delimitador(
        linhas, delim_forcado)
    if tab.delimitador is None:
        raise ErroDeEntrada(
            "%s: nenhum delimitador conhecido foi encontrado. Com uma coluna so "
            "de cada lado duas estruturas diferentes pareceriam iguais, entao a "
            "rodada para aqui. Declare o separador em --delimitador."
            % tab.caminho.name)

    gerador = ContadorDeLinhas(linhas)
    leitor = csv.reader(gerador, delimiter=tab.delimitador)
    brutos = []
    for celulas in leitor:
        brutos.append((gerador.inicio, celulas))
        gerador.novo = True

    idx, criterio = achar_cabecalho(brutos)
    tab.criterio_do_cabecalho = criterio
    if idx is None:
        raise ErroDeEntrada(
            "%s: nenhuma linha serve de cabecalho. Uma linha de cabecalho tem "
            "pelo menos dois nomes nao numericos." % tab.caminho.name)
    tab.linha_cabecalho = brutos[idx][0]
    tab.antes_do_cabecalho = idx
    tab.colunas = nomear_colunas(tab, brutos[idx][1])
    if len(tab.colunas) < 2:
        raise ErroDeEntrada(
            "%s: o cabecalho tem uma coluna so depois de separar por %s. Ou o "
            "delimitador esta errado, ou o arquivo nao e tabela."
            % (tab.caminho.name, NOME_DELIM.get(tab.delimitador, "?")))

    padrao_ignorar = re.compile(ignorar, re.IGNORECASE) if ignorar else None

    def fora_da_tabela(linha, celulas, acima):
        """Toda linha que nao virou registro passa por aqui e sai nomeada."""
        conteudo = tab.delimitador.join(celulas)
        if ASSINATURA_DO_KIT.search(normal(conteudo)):
            tab.reconhecidas.append((linha, "rodape_do_kit", conteudo))
            return
        if padrao_ignorar is not None and padrao_ignorar.search(conteudo):
            tab.ignoradas_declaradas.append((linha, conteudo))
            return
        if not any(c.strip() for c in celulas):
            tab.nao_lidas.append((linha, "linha_vazia", conteudo))
            return
        if RODAPE_RELATORIO.search(normal(conteudo)):
            tab.reconhecidas.append((linha, "rodape_de_sistema", conteudo))
            return
        if acima:
            # Linha acima do cabecalho com a largura da tabela e linha de dado
            # que ficou fora, e e a forma mais silenciosa de perder dado: sem
            # este registro ela nao apareceria em lugar nenhum. Titulo e linha
            # de filtro de export tem largura diferente da tabela.
            if len(celulas) == len(tab.colunas):
                tab.nao_lidas.append(
                    (linha, "acima_do_cabecalho_com_a_largura_da_tabela",
                     conteudo))
            else:
                tab.reconhecidas.append(
                    (linha, "titulo_ou_filtro_acima_do_cabecalho", conteudo))
            return
        tab.nao_lidas.append(
            (linha, "contagem_de_colunas_diferente_do_cabecalho", conteudo))

    for linha, celulas in brutos[:idx]:
        fora_da_tabela(linha, celulas, True)
    for linha, celulas in brutos[idx + 1:]:
        conteudo = tab.delimitador.join(celulas)
        e_registro = (
            any(c.strip() for c in celulas)
            and len(celulas) == len(tab.colunas)
            and not ASSINATURA_DO_KIT.search(normal(conteudo))
            and not (padrao_ignorar is not None
                     and padrao_ignorar.search(conteudo)))
        if e_registro:
            tab.registros.append(Registro(linha, [c.strip() for c in celulas]))
        else:
            fora_da_tabela(linha, celulas, False)
    return tab


def nao_lidas_com_conteudo(tab):
    """Dado perdido: linha com conteudo que nao virou registro e nao foi
    reconhecida por nenhum padrao. So esta lista derruba o codigo 0."""
    return [n for n in tab.nao_lidas if n[1] != "linha_vazia"]


def reconhecidas_por_causa(tab, causa):
    return [r for r in tab.reconhecidas if r[1] == causa]


def linhas_fora_da_tabela(tab):
    """Toda linha do arquivo que nao virou registro, nomeada e classificada.

    E o que alimenta linhas-nao-lidas.csv. Uma linha que nao aparece nem aqui
    nem nos registros seria descarte silencioso.
    """
    itens = list(tab.nao_lidas) + list(tab.reconhecidas)
    itens += [(l, "ignorada_por_ignorar_linha", c)
              for l, c in tab.ignoradas_declaradas]
    return [(linha, CLASSE_DA_CAUSA.get(causa, "perdida"), causa, conteudo)
            for linha, causa, conteudo in sorted(itens, key=lambda t: t[0])]


def declaracoes_da_leitura(tabelas):
    """Linhas fora da tabela que sairam reconhecidas ou declaradas.

    Cada item vira uma linha do bloco de decisoes declaradas. Elas nao entram em
    "fora da comparacao": rodapé nao e dado da tabela, e linha excluida por
    --ignorar-linha e decisao de quem rodou, com o padrao escrito na linha de
    comando e a contagem na nota.
    """
    itens = []
    causas = (("rodape_do_kit",
               "linha(s) de rodape deste kit, reconhecida(s) pela assinatura"),
              ("rodape_de_sistema",
               "linha(s) de rodape de identificacao do sistema, reconhecida(s) "
               "pelo padrao"),
              ("titulo_ou_filtro_acima_do_cabecalho",
               "linha(s) de titulo ou filtro acima do cabecalho"))
    for causa, frase in causas:
        n = sum(len(reconhecidas_por_causa(t, causa)) for t in tabelas)
        if n:
            itens.append("%d %s" % (n, frase))
    n = sum(len(t.ignoradas_declaradas) for t in tabelas)
    if n:
        itens.append("%d linha(s) ignorada(s) por decisao declarada em "
                     "--ignorar-linha" % n)
    return itens


# -------------------------------------------------------------------- perfil

def perfil_de_coluna(tab, j):
    valores = [r.celulas[j] for r in tab.registros]
    tipos = {}
    vazias = 0
    for v in valores:
        t = tipo_celula(v)
        if t == "vazio":
            vazias += 1
        tipos[t] = tipos.get(t, 0) + 1
    naovazios = [t for t in tipos if t != "vazio"]
    if not naovazios:
        dominante = "vazio"
    else:
        dominante = max(naovazios, key=lambda t: tipos[t])
    misto = len(naovazios) > 1
    return {
        "dominante": dominante,
        "misto": misto,
        "tipos": tipos,
        "vazias": vazias,
        "preenchidas": len(valores) - vazias,
        "unidade": unidade_no_nome(tab.colunas[j]),
    }


def padrao_de_agrupamento(tab, j, excluir=()):
    """Diz se a coluna se comporta como criterio de agrupamento.

    Dois padroes: valor so na primeira linha do bloco (celula mesclada) e valor
    repetido em blocos consecutivos. As linhas de total entram em excluir: elas
    deixam celula vazia por natureza e fariam qualquer coluna parecer agrupada.
    """
    valores = [r.celulas[j] for pos, r in enumerate(tab.registros)
               if pos not in excluir]
    if len(valores) < 4:
        return ""
    vazias = sum(1 for v in valores if not v)
    preenchidas = len(valores) - vazias
    if valores[0] and preenchidas >= 2 and vazias / float(len(valores)) >= 0.3:
        return "bloco_com_valor_so_na_primeira_linha"
    corridas = 1
    for a, b in zip(valores, valores[1:]):
        if normal(a) != normal(b):
            corridas += 1
    distintos = len(set(normal(v) for v in valores if v))
    if distintos >= 2 and corridas == distintos and len(valores) > distintos * 1.5:
        return "valor_repetido_em_blocos_consecutivos"
    return ""


def classificar_linhas_de_total(tab, colunas_perfil):
    """Classifica sem descartar. Nenhuma linha sai da comparacao por rotulo."""
    numericas = [j for j in range(len(tab.colunas))
                 if colunas_perfil[j]["dominante"]
                 in ("numero_br", "numero_en", "inteiro", "moeda")]
    # O rotulo do bloco sai so das colunas cujo tipo dominante e de texto.
    # Percentual, data e moeda nao somam, mas tambem nao nomeiam bloco: com eles
    # dentro, o rotulo carrega o valor da coluna de aproveitamento e muda todo
    # mes, o que fazia rotulos_de_total_mudaram disparar sempre.
    identificadoras = [j for j in range(len(tab.colunas))
                       if colunas_perfil[j]["dominante"] in CATEGORICAS]
    if not identificadoras:
        identificadoras = [j for j in range(len(tab.colunas))
                           if j not in numericas]
    marcadas = []
    acumulado = {j: Decimal(0) for j in numericas}
    contados = {j: 0 for j in numericas}
    for pos, reg in enumerate(tab.registros):
        texto = " ".join(reg.celulas[j] for j in identificadoras)
        tem_marcador = bool(MARCADOR_TOTAL.search(normal(texto)))
        # Soma que confere so vira sinal quando as colunas de identificacao
        # estao majoritariamente vazias. Sem essa condicao, o item cujo valor
        # por acaso iguala a soma do bloco anterior seria lido como total, e o
        # total de verdade logo abaixo perderia o acumulado.
        identificacao_vazia = bool(identificadoras) and (
            sum(1 for j in identificadoras if not reg.celulas[j].strip()) * 2
            >= len(identificadoras))
        soma_confere = False
        if numericas and identificacao_vazia:
            j = numericas[0]
            atual = valor_numerico(reg.celulas[j], tipo_celula(reg.celulas[j]))
            if (atual is not None and contados[j] >= 2 and acumulado[j] != 0
                    and atual == acumulado[j]):
                soma_confere = True
        if tem_marcador or soma_confere:
            if tem_marcador and soma_confere:
                classe = "total"
            elif tem_marcador:
                classe = "marcador_sem_soma"
            else:
                classe = "soma_sem_marcador"
            marcadas.append({
                "posicao": pos,
                "linha": reg.linha,
                "rotulo": texto.strip()[:60],
                "classe": classe,
            })
            for j in numericas:
                acumulado[j] = Decimal(0)
                contados[j] = 0
            continue
        for j in numericas:
            v = valor_numerico(reg.celulas[j], tipo_celula(reg.celulas[j]))
            if v is not None:
                acumulado[j] += v
                contados[j] += 1
    return marcadas


def posicao_dos_totais(marcadas, total_registros):
    if not marcadas:
        return "nenhum"
    ultimas = [m for m in marcadas if m["posicao"] >= total_registros - 1]
    primeiras = [m for m in marcadas if m["posicao"] == 0]
    meio = [m for m in marcadas
            if 0 < m["posicao"] < total_registros - 1]
    partes = []
    if primeiras:
        partes.append("topo")
    if meio:
        partes.append("por_bloco")
    if ultimas:
        partes.append("rodape")
    return "+".join(partes) if partes else "nenhum"


def montar_perfil(tab):
    lista = [perfil_de_coluna(tab, j) for j in range(len(tab.colunas))]
    marcadas = classificar_linhas_de_total(tab, lista)
    fora = set(m["posicao"] for m in marcadas)
    colunas = {}
    for j, nome in enumerate(tab.colunas):
        p = lista[j]
        p["posicao"] = j + 1
        # Agrupamento e criterio categorico. Coluna de numero ou de data com
        # valor repetido nao e bloco, e contar como bloco encheria a lista de
        # mudancas de ruido.
        p["agrupamento"] = (padrao_de_agrupamento(tab, j, fora)
                            if p["dominante"] in CATEGORICAS else "")
        colunas[normal(nome)] = p
        p["nome"] = nome
    return {
        "arquivo": tab.caminho.name,
        "encoding": tab.encoding,
        "delimitador": NOME_DELIM.get(tab.delimitador, tab.delimitador),
        "linha_do_cabecalho": tab.linha_cabecalho,
        "colunas_na_ordem": list(tab.colunas),
        "colunas": colunas,
        "registros": len(tab.registros),
        "marcadas": marcadas,
        "posicao_dos_totais": posicao_dos_totais(marcadas, len(tab.registros)),
        "colunas_repetidas": sorted(novo for _, novo in tab.colunas_repetidas),
        "colunas_sem_nome": sorted(tab.colunas_sem_nome),
        "criterio_do_cabecalho": tab.criterio_do_cabecalho,
        "rotulos_de_total": sorted(normal(m["rotulo"]) for m in marcadas),
        "agrupamento": sorted(
            "%s: %s" % (p["nome"], p["agrupamento"])
            for p in colunas.values() if p["agrupamento"]),
    }


def taxa_de_preenchimento(p):
    """Percentual de celulas preenchidas na coluna, arredondado."""
    total = p["vazias"] + p["preenchidas"]
    if total == 0:
        return 0
    return int(round(100.0 * p["preenchidas"] / total))


def texto_do_perfil(perf):
    linhas = []
    linhas.append("arquivo: %s" % perf["arquivo"])
    linhas.append("encoding: %s" % perf["encoding"])
    linhas.append("delimitador: %s" % perf["delimitador"])
    linhas.append("linha do cabecalho: %d, eleita com %s"
                  % (perf["linha_do_cabecalho"],
                     "nenhuma celula numerica"
                     if perf["criterio_do_cabecalho"] == "todas"
                     else "maioria de celulas nao numericas, regra frouxa"))
    linhas.append("registros (informacao, nao e mudanca de estrutura): %d"
                  % perf["registros"])
    linhas.append("posicao das linhas de total: %s" % perf["posicao_dos_totais"])
    linhas.append("criterio de agrupamento: %s"
                  % (", ".join(perf["agrupamento"]) or "nenhum detectado"))
    linhas.append("nome de coluna repetido no cabecalho: %s"
                  % (", ".join(perf["colunas_repetidas"]) or "nenhum"))
    linhas.append("coluna sem nome no cabecalho: %s"
                  % (", ".join(perf["colunas_sem_nome"]) or "nenhuma"))
    linhas.append("")
    linhas.append("colunas, na ordem:")
    for nome in perf["colunas_na_ordem"]:
        p = perf["colunas"][normal(nome)]
        linhas.append(
            "  %2d  %-28s tipo=%-14s preenchidas=%d/%d (%d%%) unidade=%s%s"
            % (p["posicao"], nome, p["dominante"], p["preenchidas"],
               p["vazias"] + p["preenchidas"], taxa_de_preenchimento(p),
               p["unidade"] or "-", "  MISTO" if p["misto"] else ""))
    linhas.append("")
    linhas.append("linhas com marcador de total ou soma que confere:")
    if not perf["marcadas"]:
        linhas.append("  nenhuma")
    for m in perf["marcadas"]:
        linhas.append("  linha %d, posicao %d, classe %s, rotulo %s"
                      % (m["linha"], m["posicao"] + 1, m["classe"], m["rotulo"]))
    return "\n".join(linhas) + "\n"


# ------------------------------------------------------------------- escrita

def preparar_saida(caminho, forcar):
    saida = Path(caminho)
    if saida.exists() and not forcar:
        raise ErroDeEntrada(
            "o diretorio %s ja existe. Use --forcar para sobrescrever." % saida)
    saida.mkdir(parents=True, exist_ok=True)
    return saida


def escrever_csv(caminho, cabecalho, linhas, fonte):
    """Escreve e devolve quantas linhas de dado foram gravadas de fato.

    O retorno entra no fechamento: contar o que se pretendia gravar em vez do
    que se gravou deixaria a identidade fechar sozinha.
    """
    escritas = 0
    with Path(caminho).open("w", encoding="utf-8-sig", newline="") as fh:
        escritor = csv.writer(fh, delimiter=";", quoting=csv.QUOTE_MINIMAL,
                              lineterminator="\n")
        escritor.writerow(cabecalho)
        for linha in linhas:
            escritor.writerow(linha)
            escritas += 1
        fh.write("# " + RODAPE % fonte + "\n")
    return escritas


def escrever_texto(caminho, texto, fonte):
    conteudo = texto.rstrip("\n") + "\n\n" + RODAPE % fonte + "\n"
    Path(caminho).write_text(conteudo, encoding="utf-8")


# ------------------------------------------------------------ modo estrutura

def rodar_estrutura(args):
    anterior = ler(args.anterior, args.encoding, args.delimitador,
                   args.ignorar_linha)
    atual = ler(args.atual, args.encoding, args.delimitador, args.ignorar_linha)
    for rotulo, tab in (("anterior", anterior), ("atual", atual)):
        if not tab.registros:
            raise ErroDeEntrada(
                "%s (%s) tem cabecalho e nenhum registro lido. Duas tabelas "
                "sem linha nenhuma teriam a mesma estrutura por vacuidade, e "
                "sair com 0 aqui seria dizer que nada mudou sem ter olhado "
                "dado nenhum." % (rotulo, tab.caminho.name))
    saida = preparar_saida(args.saida, args.forcar)
    fonte = "%s e %s" % (anterior.caminho.name, atual.caminho.name)

    pa = montar_perfil(anterior)
    pb = montar_perfil(atual)
    escrever_texto(saida / "perfil-anterior.txt", texto_do_perfil(pa), fonte)
    escrever_texto(saida / "perfil-atual.txt", texto_do_perfil(pb), fonte)

    fora_da_tabela = []
    for lado, tab in (("anterior", anterior), ("atual", atual)):
        for linha, classe, causa, conteudo in linhas_fora_da_tabela(tab):
            fora_da_tabela.append([lado, linha, classe, causa, conteudo])
    escrever_csv(saida / "linhas-nao-lidas.csv",
                 ["lado", "linha", "classe", "causa", "conteudo_da_linha"],
                 fora_da_tabela, fonte)
    declaradas = declaracoes_da_leitura((anterior, atual))

    mudancas = []
    conferidos = {"n": 0}
    iguais = {"n": 0}
    colunas_conferidas = {"n": 0}

    def registrar_atributo(tipo, alvo, antes, depois, efeito, mudou):
        """Confere um atributo. Quem decide se mudou e quem chama.

        Atributo com faixa de tolerancia, como a taxa de preenchimento, precisa
        de um criterio que nao e a igualdade das strings.
        """
        conferidos["n"] += 1
        if not mudou:
            iguais["n"] += 1
            return
        mudancas.append({"tipo": tipo, "alvo": alvo, "antes": str(antes),
                         "depois": str(depois), "efeito": efeito})

    def conferir(tipo, alvo, antes, depois, efeito):
        registrar_atributo(tipo, alvo, antes, depois, efeito, antes != depois)

    conferir("delimitador_mudou", "arquivo", pa["delimitador"], pb["delimitador"],
             "o script que le o arquivo quebra ou le tudo numa coluna so")
    conferir("encoding_mudou", "arquivo", pa["encoding"], pb["encoding"],
             "acento vira caractere estranho no relatorio montado")
    conferir("nome_de_coluna_repetido_no_cabecalho", "arquivo",
             ", ".join(pa["colunas_repetidas"]) or "nenhum",
             ", ".join(pb["colunas_repetidas"]) or "nenhum",
             "duas colunas com o mesmo nome no cabecalho: quem le por nome pega "
             "sempre a primeira, e o conteudo da segunda nao entra em conta "
             "nenhuma")
    conferir("coluna_sem_nome_no_cabecalho", "arquivo",
             ", ".join(pa["colunas_sem_nome"]) or "nenhuma",
             ", ".join(pb["colunas_sem_nome"]) or "nenhuma",
             "coluna sem cabecalho sai do relatorio sem ninguem decidir que ela "
             "sai")
    conferir("linha_do_cabecalho_mudou", "arquivo", pa["linha_do_cabecalho"],
             pb["linha_do_cabecalho"],
             "quem le pulando um numero fixo de linhas passa a perder ou a "
             "engolir linha")

    nomes_a = [normal(c) for c in pa["colunas_na_ordem"]]
    nomes_b = [normal(c) for c in pb["colunas_na_ordem"]]
    uniao = list(nomes_a) + [n for n in nomes_b if n not in nomes_a]
    pareadas = 0
    sumiram = 0
    novas = 0
    for nome in uniao:
        colunas_conferidas["n"] += 1
        em_a = nome in pa["colunas"]
        em_b = nome in pb["colunas"]
        if em_a and em_b:
            pareadas += 1
        elif em_a:
            sumiram += 1
            conferir("coluna_sumiu", pa["colunas"][nome]["nome"], "presente",
                     "ausente",
                     "a conta que dependia dessa coluna sai vazia ou errada")
            continue
        else:
            novas += 1
            conferir("coluna_nova", pb["colunas"][nome]["nome"], "ausente",
                     "presente",
                     "dado novo que o relatorio do mes passado nao tinha onde por")
            continue
        ca = pa["colunas"][nome]
        cb = pb["colunas"][nome]
        conferir("coluna_mudou_de_posicao", cb["nome"], ca["posicao"],
                 cb["posicao"],
                 "quem le por posicao e nao por nome passa a ler a coluna errada")
        conferir("coluna_mudou_de_formato", cb["nome"], ca["dominante"],
                 cb["dominante"],
                 "numero lido como texto, ou data em outro formato, nao soma e "
                 "nao ordena")
        conferir("unidade_no_nome_mudou", cb["nome"], ca["unidade"] or "-",
                 cb["unidade"] or "-",
                 "mesmo numero em outra unidade: o valor muda de ordem de "
                 "grandeza sem o quadro parecer errado")
        conferir("coluna_mudou_de_agrupamento", cb["nome"],
                 ca["agrupamento"] or "-", cb["agrupamento"] or "-",
                 "o criterio de agrupamento do relatorio mudou")
        vazia_antes = ca["preenchidas"] == 0
        vazia_agora = cb["preenchidas"] == 0
        conferir("coluna_ficou_vazia" if vazia_agora else "coluna_voltou_a_ter_dado",
                 cb["nome"], vazia_antes, vazia_agora,
                 "a coluna existe, o relatorio sai completo, e o conteudo dela "
                 "sumiu sem erro nenhum")
        # Coluna que fica 100% vazia e o caso raro. O caso frequente e o
        # apontamento que parou no meio do mes: a coluna continua no cabecalho,
        # continua com dado em parte das linhas, e a conta sai menor sem nenhum
        # erro aparecer. So a queda declarada entra como mudanca.
        if not vazia_agora:
            queda = taxa_de_preenchimento(ca) - taxa_de_preenchimento(cb)
            registrar_atributo(
                "coluna_perdeu_preenchimento", cb["nome"],
                "%d/%d preenchidas" % (ca["preenchidas"],
                                       ca["preenchidas"] + ca["vazias"]),
                "%d/%d preenchidas" % (cb["preenchidas"],
                                       cb["preenchidas"] + cb["vazias"]),
                "parte das linhas passou a vir vazia nessa coluna. O relatorio "
                "sai completo e a conta que depende dela sai menor, sem erro "
                "nenhum aparecer",
                queda >= LIMITE_QUEDA_PREENCHIMENTO)

    conferir("criterio_de_agrupamento_mudou", "arquivo",
             ", ".join(pa["agrupamento"]) or "nenhum",
             ", ".join(pb["agrupamento"]) or "nenhum",
             "o mesmo dado agrupado por outro criterio nao compara com o mes "
             "passado")
    conferir("total_mudou_de_lugar", "arquivo", pa["posicao_dos_totais"],
             pb["posicao_dos_totais"],
             "linha de total lida como item, ou item lido como total")
    conferir("quantidade_de_linhas_de_total_mudou", "arquivo",
             len(pa["marcadas"]), len(pb["marcadas"]),
             "bloco a mais ou a menos no relatorio")
    conferir("rotulos_de_total_mudaram", "arquivo",
             " | ".join(pa["rotulos_de_total"]) or "-",
             " | ".join(pb["rotulos_de_total"]) or "-",
             "o nome do bloco mudou, e quem procura pelo rotulo antigo nao acha")

    gravadas = escrever_csv(
        saida / "mudancas-de-estrutura.csv",
        ["tipo", "alvo", "antes", "depois", "efeito_se_ninguem_olhar"],
        [[m["tipo"], m["alvo"], m["antes"], m["depois"], m["efeito"]]
         for m in mudancas], fonte)

    # fechamento. O lado esquerdo vem da forma das tabelas, o direito vem dos
    # contadores do laco.
    identidades = [
        ("colunas_no_anterior = pareadas + sumiram",
         len(pa["colunas_na_ordem"]), pareadas + sumiram),
        ("colunas_no_atual = pareadas + novas",
         len(pb["colunas_na_ordem"]), pareadas + novas),
        ("colunas_da_uniao = colunas_conferidas",
         len(uniao), colunas_conferidas["n"]),
        ("atributos_conferidos = iguais + mudancas",
         conferidos["n"], iguais["n"] + len(mudancas)),
        ("linhas gravadas em mudancas-de-estrutura.csv = mudancas",
         gravadas, len(mudancas)),
    ]

    md = []
    md.append("# Mudancas de estrutura entre os dois meses")
    md.append("")
    md.append("Anterior: %s. Atual: %s." % (pa["arquivo"], pb["arquivo"]))
    md.append("")
    if mudancas:
        md.append("status: %d mudancas de estrutura" % len(mudancas))
        md.append("")
        md.append("| Tipo | Alvo | Antes | Depois | Efeito se ninguem olhar |")
        md.append("|---|---|---|---|---|")
        for m in mudancas:
            md.append("| %s | %s | %s | %s | %s |"
                      % (m["tipo"], m["alvo"], m["antes"], m["depois"],
                         m["efeito"]))
    else:
        md.append("status: nenhuma mudanca de estrutura entre os dois arquivos")
    md.append("")
    md.append("## Fechamento")
    md.append("")
    for nome, esq, dir_ in identidades:
        md.append("- %s: %d contra %d, %s"
                  % (nome, esq, dir_, "fecha" if esq == dir_ else "NAO FECHA"))
    md.append("")
    md.append("## Verificacoes que podem falhar de fato")
    md.append("")
    md.append("- colunas lidas no anterior: %d" % len(pa["colunas_na_ordem"]))
    md.append("- colunas lidas no atual: %d" % len(pb["colunas_na_ordem"]))
    md.append("- registros lidos no anterior: %d" % pa["registros"])
    md.append("- registros lidos no atual: %d" % pb["registros"])
    md.append("- atributos conferidos: %d" % conferidos["n"])
    md.append("- linhas perdidas, com conteudo e sem causa reconhecida: %d"
              % (len(nao_lidas_com_conteudo(anterior))
                 + len(nao_lidas_com_conteudo(atual))))
    md.append("")
    md.append("## Decisoes declaradas e linhas reconhecidas")
    md.append("")
    md.append("Rodape do proprio kit, rodape de identificacao do sistema, linha "
              "de titulo acima do cabecalho e linha excluida em --ignorar-linha "
              "saem contadas aqui. Nenhuma delas e dado da tabela, e por isso "
              "nenhuma derruba o codigo 0. Todas estao em linhas-nao-lidas.csv, "
              "com a linha e o conteudo.")
    md.append("")
    if declaradas:
        for item in declaradas:
            md.append("- %s" % item)
    else:
        md.append("- nenhuma")
    md.append("")
    md.append("Registro nao e estrutura: o numero de linhas muda todo mes por "
              "motivo legitimo e nao entra como mudanca.")

    escrever_texto(saida / "mudancas-de-estrutura.md", "\n".join(md), fonte)

    print("MODO ESTRUTURA")
    print("  anterior: %s, %d colunas, %d registros"
          % (pa["arquivo"], len(pa["colunas_na_ordem"]), pa["registros"]))
    print("  atual:    %s, %d colunas, %d registros"
          % (pb["arquivo"], len(pb["colunas_na_ordem"]), pb["registros"]))
    print("")
    print("FECHAMENTO")
    quebrou = False
    for nome, esq, dir_ in identidades:
        marca = "fecha" if esq == dir_ else "NAO FECHA"
        if esq != dir_:
            quebrou = True
        print("  %-52s %6d %6d  %s" % (nome, esq, dir_, marca))
    print("")
    print("VERIFICACOES")
    print("  atributos conferidos:            %d" % conferidos["n"])
    print("  colunas conferidas:              %d" % colunas_conferidas["n"])
    print("  mudancas de estrutura:           %d" % len(mudancas))
    print("  linhas perdidas, sem causa reconhecida: %d"
          % (len(nao_lidas_com_conteudo(anterior))
             + len(nao_lidas_com_conteudo(atual))))
    for item in declaradas:
        print("  DECISAO DECLARADA: %s" % item)
    print("")
    print("Saida em %s" % saida)

    if quebrou:
        print("ERRO: uma identidade de fechamento nao fecha. A saida nao vale.",
              file=sys.stderr)
        return ERRO
    if conferidos["n"] == 0 or colunas_conferidas["n"] == 0:
        print("ERRO: nenhum atributo foi conferido. Sair com 0 aqui seria dizer "
              "que as estruturas batem sem ter comparado nada.", file=sys.stderr)
        return ERRO
    if mudancas:
        return DIFERENCA
    if nao_lidas_com_conteudo(anterior) or nao_lidas_com_conteudo(atual):
        print("Nenhuma mudanca de estrutura, mas ficou linha com conteudo fora "
              "da leitura sem causa reconhecida. Leia linhas-nao-lidas.csv, "
              "coluna classe igual a perdida.")
        return SOBROU
    return OK


# ------------------------------------------------------------- modo gabarito

def pares_de_coluna(cols_a, cols_b, campos):
    """Devolve (pares, so_em_a, so_em_b, declarado)."""
    if campos:
        pares = []
        usados_a, usados_b = set(), set()
        mapa_a = {normal(c): i for i, c in enumerate(cols_a)}
        mapa_b = {normal(c): i for i, c in enumerate(cols_b)}
        for item in campos.split(","):
            if ":" not in item:
                raise ErroDeEntrada(
                    "--campos espera pares no formato 'coluna no entregue:"
                    "coluna no refeito', separados por virgula. Recebi %r" % item)
            a, b = item.split(":", 1)
            ia = mapa_a.get(normal(a))
            ib = mapa_b.get(normal(b))
            if ia is None:
                raise ErroDeEntrada("coluna %r nao existe no entregue" % a.strip())
            if ib is None:
                raise ErroDeEntrada("coluna %r nao existe no refeito" % b.strip())
            if ia in usados_a or ib in usados_b:
                raise ErroDeEntrada(
                    "a mesma coluna aparece em mais de um par de --campos (%r). "
                    "Com a coluna contada duas vezes o fechamento deixa de "
                    "valer." % item)
            pares.append((ia, ib))
            usados_a.add(ia)
            usados_b.add(ib)
        so_a = [i for i in range(len(cols_a)) if i not in usados_a]
        so_b = [i for i in range(len(cols_b)) if i not in usados_b]
        return pares, so_a, so_b, True
    pares = []
    usados_b = set()
    mapa_b = {}
    for j, c in enumerate(cols_b):
        mapa_b.setdefault(normal(c), j)
    so_a = []
    for i, c in enumerate(cols_a):
        j = mapa_b.get(normal(c))
        if j is None or j in usados_b:
            so_a.append(i)
            continue
        pares.append((i, j))
        usados_b.add(j)
    so_b = [j for j in range(len(cols_b)) if j not in usados_b]
    return pares, so_a, so_b, False


def indices_da_chave(tab, nomes):
    idx = []
    mapa = {normal(c): i for i, c in enumerate(tab.colunas)}
    for nome in nomes:
        i = mapa.get(normal(nome))
        if i is None:
            raise ErroDeEntrada(
                "a coluna-chave %r nao existe em %s. Colunas: %s"
                % (nome, tab.caminho.name, ", ".join(tab.colunas)))
        idx.append(i)
    return idx


def chave_do_registro(reg, idx, sem_zeros):
    partes = []
    for i in idx:
        v = normal(reg.celulas[i])
        if sem_zeros:
            v = v.lstrip("0") or "0"
        partes.append(v)
    return "|".join(partes)


def rotulo_da_linha(reg, indices):
    """Texto que nomeia a linha, so com as colunas de texto.

    E o que permite parear a linha de total, que nao tem codigo de item e por
    isso tem a coluna-chave vazia nos dois lados.
    """
    return normal(" ".join(reg.celulas[i] for i in indices))


def agrupar_por_chave(tab, idx, sem_zeros):
    grupos = {}
    vazias = []
    for reg in tab.registros:
        ch = chave_do_registro(reg, idx, sem_zeros)
        if ch.replace("|", "").strip() == "":
            vazias.append(reg)
            continue
        grupos.setdefault(ch, []).append(reg)
    return grupos, vazias


def rodar_gabarito(args):
    entregue = ler(args.entregue, args.encoding, args.delimitador,
                   args.ignorar_linha)
    refeito = ler(args.refeito, args.encoding, args.delimitador,
                  args.ignorar_linha)
    saida = preparar_saida(args.saida, args.forcar)
    fonte = "%s e %s" % (entregue.caminho.name, refeito.caminho.name)

    # a nota sai antes de qualquer comparacao, com status incompleto
    escrever_texto(saida / "nota-do-refazer.md",
                   "status: incompleto\n\nA rodada caiu antes de fechar. "
                   "A saida nao vale.", fonte)
    fora_da_tabela = []
    for lado, tab in (("entregue", entregue), ("refeito", refeito)):
        for linha, classe, causa, conteudo in linhas_fora_da_tabela(tab):
            fora_da_tabela.append([lado, linha, classe, causa, conteudo])
    escrever_csv(saida / "linhas-nao-lidas.csv",
                 ["lado", "linha", "classe", "causa", "conteudo_da_linha"],
                 fora_da_tabela, fonte)

    pares, so_col_e, so_col_r, declarado = pares_de_coluna(
        entregue.colunas, refeito.colunas, args.campos)
    if not pares:
        print("ERRO: nenhuma coluna emparelhou entre os dois arquivos. Sair com "
              "0 aqui seria dizer que o refazer bateu sem ter comparado nada.\n"
              "  entregue: %s\n  refeito:  %s"
              % (", ".join(entregue.colunas), ", ".join(refeito.colunas)),
              file=sys.stderr)
        return ERRO
    if not declarado and (so_col_e or so_col_r):
        print("ERRO: coluna sem par no emparelhamento automatico. No gabarito "
              "isso e o proprio defeito: o refazer nao produziu as mesmas "
              "colunas.\n  so no entregue: %s\n  so no refeito:  %s\n"
              "Declare os pares em --campos para seguir mesmo assim."
              % (", ".join(entregue.colunas[i] for i in so_col_e) or "nenhuma",
                 ", ".join(refeito.colunas[j] for j in so_col_r) or "nenhuma"),
              file=sys.stderr)
        return ERRO

    # pareamento de linha
    if args.por_posicao:
        if len(entregue.registros) != len(refeito.registros):
            print("ERRO: --por-posicao com %d registros no entregue e %d no "
                  "refeito. Comparar linha a linha com contagens diferentes "
                  "desalinha tudo a partir da primeira sobra."
                  % (len(entregue.registros), len(refeito.registros)),
                  file=sys.stderr)
            return ERRO
        pares_linha = list(zip(entregue.registros, refeito.registros))
        so_linha_e, so_linha_r = [], []
        dup_e = dup_r = 0
        vazias_e, vazias_r = [], []
        pareadas_por_rotulo = 0
    else:
        nomes_chave_e = args.chave_entregue or args.chave
        nomes_chave_r = args.chave_refeito or args.chave
        if not nomes_chave_e or not nomes_chave_r:
            raise ErroDeEntrada(
                "informe --chave, ou --chave-entregue e --chave-refeito, ou "
                "--por-posicao")
        idx_e = indices_da_chave(entregue, [c.strip() for c in nomes_chave_e.split(",")])
        idx_r = indices_da_chave(refeito, [c.strip() for c in nomes_chave_r.split(",")])
        grupos_e, vazias_e = agrupar_por_chave(entregue, idx_e, args.chave_sem_zeros)
        grupos_r, vazias_r = agrupar_por_chave(refeito, idx_r, args.chave_sem_zeros)
        pares_linha = []
        so_linha_e, so_linha_r = [], []
        dup_e = dup_r = 0
        divergentes_e, divergentes_r = [], []
        for ch, regs_e in grupos_e.items():
            regs_r = grupos_r.get(ch)
            if regs_r is None:
                so_linha_e.extend((r, "so_no_entregue") for r in regs_e)
                continue
            iguais_e = len(set(tuple(r.celulas) for r in regs_e)) == 1
            iguais_r = len(set(tuple(r.celulas) for r in regs_r)) == 1
            if not iguais_e or not iguais_r:
                if not iguais_e:
                    divergentes_e.extend(
                        (r, "duplicata_divergente") for r in regs_e)
                else:
                    so_linha_e.extend(
                        (r, "duplicata_divergente_no_outro_lado") for r in regs_e)
                if not iguais_r:
                    divergentes_r.extend(
                        (r, "duplicata_divergente") for r in regs_r)
                else:
                    so_linha_r.extend(
                        (r, "duplicata_divergente_no_outro_lado") for r in regs_r)
                continue
            pares_linha.append((regs_e[0], regs_r[0]))
            dup_e += len(regs_e) - 1
            dup_r += len(regs_r) - 1
        for ch, regs_r in grupos_r.items():
            if ch not in grupos_e:
                so_linha_r.extend((r, "so_no_refeito") for r in regs_r)
        so_linha_e.extend(divergentes_e)
        so_linha_r.extend(divergentes_r)

        # Chave vazia dos dois lados e a forma real da linha de total: ela nao
        # tem codigo de item. Chave vazia nunca pareia com chave vazia, e sem
        # este trecho a camada de blocos e totais, que e o miolo do relatorio,
        # ficava fora da comparacao celula a celula e a rodada saia 5 para
        # sempre. O par sai pelo rotulo, e o rotulo sai das colunas de texto.
        perf_e = [perfil_de_coluna(entregue, j)
                  for j in range(len(entregue.colunas))]
        perf_r = [perfil_de_coluna(refeito, j)
                  for j in range(len(refeito.colunas))]
        de_texto = [(ie, ir) for ie, ir in pares
                    if perf_e[ie]["dominante"] in CATEGORICAS
                    or perf_r[ir]["dominante"] in CATEGORICAS]
        idx_rot_e = [ie for ie, _ in de_texto]
        idx_rot_r = [ir for _, ir in de_texto]
        rot_e, rot_r = {}, {}
        for reg in vazias_e:
            rot_e.setdefault(rotulo_da_linha(reg, idx_rot_e), []).append(reg)
        for reg in vazias_r:
            rot_r.setdefault(rotulo_da_linha(reg, idx_rot_r), []).append(reg)
        pareadas_por_rotulo = 0
        for rot, regs_e in rot_e.items():
            regs_r = rot_r.get(rot)
            if not rot:
                so_linha_e.extend(
                    (r, "chave_vazia_e_sem_rotulo") for r in regs_e)
                continue
            if regs_r is None:
                so_linha_e.extend(
                    (r, "chave_vazia_sem_rotulo_par_no_refeito") for r in regs_e)
                continue
            if len(regs_e) > 1 or len(regs_r) > 1:
                so_linha_e.extend(
                    (r, "chave_vazia_com_rotulo_repetido") for r in regs_e)
                so_linha_r.extend(
                    (r, "chave_vazia_com_rotulo_repetido") for r in regs_r)
                continue
            pares_linha.append((regs_e[0], regs_r[0]))
            pareadas_por_rotulo += 1
        for rot, regs_r in rot_r.items():
            if not rot:
                so_linha_r.extend(
                    (r, "chave_vazia_e_sem_rotulo") for r in regs_r)
            elif rot not in rot_e:
                so_linha_r.extend(
                    (r, "chave_vazia_sem_rotulo_par_no_entregue")
                    for r in regs_r)

    if not pares_linha:
        print("ERRO: nenhuma linha emparelhou entre os dois arquivos. Confira a "
              "coluna-chave, ou rode com --chave-sem-zeros se o zero a esquerda "
              "se perdeu num dos lados.", file=sys.stderr)
        return ERRO

    # comparacao celula a celula, tudo contado no laco
    comparadas = 0
    iguais = 0
    por_tolerancia = 0
    so_formato = 0
    diferentes = 0
    cel_so_e = 0
    cel_so_r = 0
    linhas_que_nao_batem = []
    linhas_de_formato = []
    vazias_nos_dois = {j: 0 for j, _ in pares}
    try:
        tolerancia = Decimal(args.tolerancia) if args.tolerancia else Decimal(0)
    except InvalidOperation:
        raise ErroDeEntrada("--tolerancia espera um numero, recebi %r"
                            % args.tolerancia)

    for reg_e, reg_r in pares_linha:
        for ie, ir in pares:
            comparadas += 1
            va = reg_e.celulas[ie]
            vb = reg_r.celulas[ir]
            if va.strip() == "" and vb.strip() == "":
                vazias_nos_dois[ie] += 1
            if va == vb:
                iguais += 1
                continue
            ca = valor_canonico(va)
            cb = valor_canonico(vb)
            if ca == cb:
                so_formato += 1
                linhas_de_formato.append(
                    [reg_e.linha, reg_r.linha, entregue.colunas[ie],
                     refeito.colunas[ir], va, vb, ca])
                continue
            na = valor_numerico(va, tipo_celula(va))
            nb = valor_numerico(vb, tipo_celula(vb))
            if (tolerancia > 0 and na is not None and nb is not None
                    and abs(na - nb) <= tolerancia):
                por_tolerancia += 1
                continue
            diferentes += 1
            linhas_que_nao_batem.append(
                [reg_e.linha, reg_r.linha, entregue.colunas[ie],
                 refeito.colunas[ir], va, vb])
        for ie in so_col_e:
            cel_so_e += 1
        for ir in so_col_r:
            cel_so_r += 1

    linhas_so_e = []
    for reg, causa in so_linha_e:
        linhas_so_e.append([reg.linha, causa] + reg.celulas)
        cel_so_e += len(entregue.colunas)
    linhas_so_r = []
    for reg, causa in so_linha_r:
        linhas_so_r.append([reg.linha, causa] + reg.celulas)
        cel_so_r += len(refeito.colunas)

    colunas_vazias_nos_dois = [entregue.colunas[j]
                               for j, n in vazias_nos_dois.items()
                               if n == len(pares_linha) and n > 0]

    grav_nao_batem = escrever_csv(
        saida / "celulas-que-nao-batem.csv",
        ["linha_no_entregue", "linha_no_refeito", "coluna_no_entregue",
         "coluna_no_refeito", "valor_entregue", "valor_refeito"],
        linhas_que_nao_batem, fonte)
    grav_formato = escrever_csv(
        saida / "diferencas-de-formato.csv",
        ["linha_no_entregue", "linha_no_refeito", "coluna_no_entregue",
         "coluna_no_refeito", "valor_entregue", "valor_refeito",
         "valor_canonico"],
        linhas_de_formato, fonte)
    grav_so_e = escrever_csv(saida / "so-no-entregue.csv",
                             ["linha", "causa"] + entregue.colunas,
                             linhas_so_e, fonte)
    grav_so_r = escrever_csv(saida / "so-no-refeito.csv",
                             ["linha", "causa"] + refeito.colunas,
                             linhas_so_r, fonte)

    # fechamento: o lado esquerdo vem da forma da tabela, o direito vem dos
    # contadores do laco. Parte derivada por subtracao fecharia sozinha.
    celulas_entregue = len(entregue.registros) * len(entregue.colunas)
    celulas_refeito = len(refeito.registros) * len(refeito.colunas)
    identidades = [
        ("celulas_do_entregue = comparadas + so_no_entregue",
         celulas_entregue, comparadas + cel_so_e),
        ("celulas_do_refeito = comparadas + so_no_refeito",
         celulas_refeito, comparadas + cel_so_r),
        ("comparadas = iguais + tolerancia + formato + diferentes",
         comparadas, iguais + por_tolerancia + so_formato + diferentes),
        ("registros_do_entregue = pareadas + fora_do_pareamento",
         len(entregue.registros), len(pares_linha) + len(so_linha_e) + dup_e),
        ("registros_do_refeito = pareadas + fora_do_pareamento",
         len(refeito.registros), len(pares_linha) + len(so_linha_r) + dup_r),
        ("linhas gravadas em celulas-que-nao-batem.csv = diferentes",
         grav_nao_batem, diferentes),
        ("linhas gravadas em diferencas-de-formato.csv = formato",
         grav_formato, so_formato),
        ("linhas gravadas em so-no-entregue.csv = fora do pareamento",
         grav_so_e, len(so_linha_e)),
        ("linhas gravadas em so-no-refeito.csv = fora do pareamento",
         grav_so_r, len(so_linha_r)),
    ]
    quebrou = any(esq != dir_ for _, esq, dir_ in identidades)

    fora = []
    if so_linha_e:
        fora.append("%d linha(s) so no entregue" % len(so_linha_e))
    if so_linha_r:
        fora.append("%d linha(s) so no refeito" % len(so_linha_r))
    if so_col_e:
        fora.append("coluna do entregue fora da comparacao por decisao "
                    "declarada em --campos: %s"
                    % ", ".join(entregue.colunas[i] for i in so_col_e))
    if so_col_r:
        fora.append("coluna do refeito fora da comparacao por decisao "
                    "declarada em --campos: %s"
                    % ", ".join(refeito.colunas[j] for j in so_col_r))
    if colunas_vazias_nos_dois:
        fora.append("coluna comparada vazia dos dois lados, o acerto nao prova "
                    "nada: %s" % ", ".join(colunas_vazias_nos_dois))
    if dup_e or dup_r:
        fora.append("%d linha(s) repetida(s) com conteudo identico, pareadas "
                    "uma vez so" % (dup_e + dup_r))
    if nao_lidas_com_conteudo(entregue) or nao_lidas_com_conteudo(refeito):
        fora.append("%d linha(s) com conteudo perdida(s) na leitura, sem causa "
                    "reconhecida"
                    % (len(nao_lidas_com_conteudo(entregue))
                       + len(nao_lidas_com_conteudo(refeito))))

    # Decisao declarada e coisa diferente de dado perdido, e misturar as duas
    # tornava o codigo 0 inalcancavel em qualquer export com rodape, ou seja,
    # quase sempre. Rodape reconhecido pelo padrao, linha excluida em
    # --ignorar-linha e celula igualada pela tolerancia saem contadas e nomeadas
    # aqui, e o status diz que a rodada passou dentro de decisao declarada. Dado
    # que deveria ter sido comparado e nao foi continua em fora, e continua
    # derrubando o 0.
    declaradas = declaracoes_da_leitura((entregue, refeito))
    if por_tolerancia:
        declaradas.append(
            "%d celula(s) dadas como iguais pela tolerancia declarada de %s"
            % (por_tolerancia, args.tolerancia))

    if quebrou:
        status = "invalido, nao fecha"
    elif diferentes or so_formato:
        status = "nao bateu, o refazer ainda nao pode ser usado no mes corrente"
    elif fora:
        status = "bateu no que comparou, e sobrou dado fora da comparacao"
    elif declaradas:
        status = "bateu celula a celula, dentro das decisoes declaradas"
    else:
        status = "bateu celula a celula"

    nota = []
    nota.append("# Nota do refazer")
    nota.append("")
    nota.append("status: %s" % status)
    nota.append("")
    nota.append("## Arquivos")
    nota.append("")
    for rotulo, tab in (("entregue na epoca", entregue), ("refeito", refeito)):
        nota.append("- %s: %s, %d bytes, %d linhas no arquivo, cabecalho na "
                    "linha %d, %d registros lidos, encoding %s (%s), "
                    "delimitador %s (%s)"
                    % (rotulo, tab.caminho.name,
                       tab.caminho.stat().st_size, tab.linhas_no_arquivo,
                       tab.linha_cabecalho, len(tab.registros), tab.encoding,
                       tab.evidencia_encoding,
                       NOME_DELIM.get(tab.delimitador, tab.delimitador),
                       tab.evidencia_delimitador))
    nota.append("")
    nota.append("## Pareamento")
    nota.append("")
    nota.append("- linhas pareadas: %d" % len(pares_linha))
    nota.append("- linhas de total pareadas pelo rotulo, com a coluna-chave "
                "vazia dos dois lados: %d" % pareadas_por_rotulo)
    nota.append("- colunas pareadas: %d" % len(pares))
    nota.append("- pares de coluna declarados em --campos: %s"
                % ("sim" if declarado else "nao, emparelhados por nome"))
    nota.append("")
    nota.append("## Resultado da comparacao")
    nota.append("")
    nota.append("- celulas comparadas: %d" % comparadas)
    nota.append("- iguais: %d" % iguais)
    nota.append("- iguais pela tolerancia declarada: %d" % por_tolerancia)
    nota.append("- diferenca so de formato: %d" % so_formato)
    nota.append("- celulas que nao batem: %d" % diferentes)
    nota.append("")
    nota.append("No gabarito, diferenca de formato conta. O produto desta skill "
                "e o relatorio no mesmo formato do que foi aprovado, entao "
                "1.234,50 contra 1234.5 e achado, nao ruido.")
    nota.append("")
    nota.append("## O que ficou fora da comparacao")
    nota.append("")
    if fora:
        for item in fora:
            nota.append("- %s" % item)
    else:
        nota.append("- nada")
    nota.append("")
    nota.append("## Decisoes declaradas e linhas reconhecidas")
    nota.append("")
    nota.append("Rodape do proprio kit, rodape de identificacao do sistema, "
                "linha de titulo acima do cabecalho, linha excluida em "
                "--ignorar-linha e celula igualada pela tolerancia declarada. "
                "Nenhuma delas e dado da tabela perdido, e por isso nenhuma "
                "derruba o codigo 0. Havendo item nesta lista, o status diz "
                "dentro das decisoes declaradas, e cada item precisa estar "
                "escrito na receita.")
    nota.append("")
    if declaradas:
        for item in declaradas:
            nota.append("- %s" % item)
    else:
        nota.append("- nenhuma")
    nota.append("")
    nota.append("## Fechamento")
    nota.append("")
    for nome, esq, dir_ in identidades:
        nota.append("- %s: %d contra %d, %s"
                    % (nome, esq, dir_, "fecha" if esq == dir_ else "NAO FECHA"))
    nota.append("")
    nota.append("O lado esquerdo de cada identidade vem da forma da tabela e o "
                "direito vem dos contadores do laco. Parte derivada por "
                "subtracao fecharia sozinha mesmo com dado faltando.")
    nota.append("")
    nota.append("## Limite declarado")
    nota.append("")
    nota.append("O script nao acessa ERP, nao acessa rede e nao acessa servidor "
                "de arquivos. Ele compara os dois arquivos que recebeu.")
    escrever_texto(saida / "nota-do-refazer.md", "\n".join(nota), fonte)

    print("MODO GABARITO")
    print("  entregue: %s, %d registros, %d colunas"
          % (entregue.caminho.name, len(entregue.registros),
             len(entregue.colunas)))
    print("  refeito:  %s, %d registros, %d colunas"
          % (refeito.caminho.name, len(refeito.registros),
             len(refeito.colunas)))
    print("")
    print("FECHAMENTO")
    for nome, esq, dir_ in identidades:
        print("  %-56s %6d %6d  %s"
              % (nome, esq, dir_, "fecha" if esq == dir_ else "NAO FECHA"))
    print("")
    print("VERIFICACOES")
    print("  celulas comparadas:              %d" % comparadas)
    print("  linhas pareadas:                 %d" % len(pares_linha))
    print("  linhas de total pareadas por rotulo: %d" % pareadas_por_rotulo)
    print("  colunas pareadas:                %d" % len(pares))
    print("  celulas que nao batem:           %d" % diferentes)
    print("  diferenca so de formato:         %d" % so_formato)
    for item in fora:
        print("  FORA DA COMPARACAO: %s" % item)
    for item in declaradas:
        print("  DECISAO DECLARADA: %s" % item)
    print("")
    print("Saida em %s" % saida)

    if quebrou:
        print("ERRO: uma identidade de fechamento nao fecha. A saida nao vale.",
              file=sys.stderr)
        return ERRO
    if comparadas == 0:
        print("ERRO: nenhuma celula foi comparada.", file=sys.stderr)
        return ERRO
    if diferentes or so_formato:
        return DIFERENCA
    if fora:
        return SOBROU
    return OK


# ----------------------------------------------------------------------- cli

def montar_parser():
    p = argparse.ArgumentParser(
        description="Compara a estrutura de dois meses, ou mede o refazer de um "
                    "mes fechado contra o relatorio entregue na epoca.")
    p.add_argument("--modo", required=True, choices=("estrutura", "gabarito"))
    p.add_argument("--anterior", help="modo estrutura: arquivo do mes anterior")
    p.add_argument("--atual", help="modo estrutura: arquivo do mes atual")
    p.add_argument("--entregue", help="modo gabarito: o relatorio entregue na epoca")
    p.add_argument("--refeito", help="modo gabarito: o relatorio refeito agora")
    p.add_argument("--chave", help="coluna que identifica a linha nos dois lados")
    p.add_argument("--chave-entregue")
    p.add_argument("--chave-refeito")
    p.add_argument("--chave-sem-zeros", action="store_true",
                   help="remove zeros a esquerda da chave nos dois lados")
    p.add_argument("--por-posicao", action="store_true",
                   help="pareia linha a linha na ordem, sem chave")
    p.add_argument("--campos",
                   help="pares de coluna quando os nomes diferem, no formato "
                        "'Qtde:Quantidade,Dt:Data'")
    p.add_argument("--tolerancia", default="",
                   help="diferenca numerica aceita como igual. Vazio ou 0 exige "
                        "igualdade exata")
    p.add_argument("--ignorar-linha",
                   help="regex de linha excluida por decisao declarada")
    p.add_argument("--delimitador")
    p.add_argument("--encoding")
    p.add_argument("--saida", required=True, help="diretorio de saida")
    p.add_argument("--forcar", action="store_true")
    return p


def main(argv=None):
    args = montar_parser().parse_args(argv)
    try:
        if args.modo == "estrutura":
            if not args.anterior or not args.atual:
                raise ErroDeEntrada(
                    "modo estrutura exige --anterior e --atual")
            return rodar_estrutura(args)
        if not args.entregue or not args.refeito:
            raise ErroDeEntrada("modo gabarito exige --entregue e --refeito")
        return rodar_gabarito(args)
    except ErroDeEntrada as erro:
        print("ERRO: %s" % erro, file=sys.stderr)
        return ERRO


if __name__ == "__main__":
    sys.exit(main())
