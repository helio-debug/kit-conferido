#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
montar.py, da skill relatorio-recorrente.

Monta o relatorio a partir dos dados brutos e da receita gravada em
receita.json. E a parte que consome o dia: agrupar, somar, ordenar, formatar e
posicionar os totais. Feita por script, ela sai igual todo mes, que e a unica
razao de automatizar um relatorio mensal.

Biblioteca padrao apenas. Nao le .xlsx, nao acessa ERP, nao acessa rede e nao
escreve nos arquivos de entrada. A leitura, a deteccao de encoding e de
delimitador e o perfil de coluna vem do conferir.py, importados dele, para que a
montagem e a conferencia nunca discordem sobre o que o arquivo diz.

Uso:

    python3 montar.py --receita receita.json \\
        --bruto bruto-2026-08.csv --saida relatorio-2026-08.csv

Consolidacao de um arquivo por area num relatorio so, com a coluna de origem
declarada na receita em "empilhar":

    python3 montar.py --receita receita.json \\
        --bruto previsao-utilidades.csv --bruto previsao-processo.csv \\
        --saida relatorio-2026-08.csv

Grava tres arquivos:

    relatorio-2026-08.csv                            o entregavel
    relatorio-2026-08.nota-da-montagem.md            o que virou o que
    relatorio-2026-08.linhas-fora-da-montagem.csv    toda linha que nao entrou

Codigos de saida:

  0  montou, e cada linha lida entrou numa linha do relatorio ou num filtro
     declarado na receita
  3  erro de entrada, receita invalida, coluna da receita ausente no bruto,
     valor diferente dentro do grupo em coluna declarada unica, celula vazia ou
     nao numerica em coluna de soma, lacuna na receita, ou identidade que nao
     fecha
  5  montou, e sobrou linha fora da montagem sem causa declarada, coluna do
     bruto que a receita nao le e ninguem declarou em 'nao_coberto', ou saiu
     aviso que exige leitura

Nao existe codigo 1 aqui: montar nao compara. Quem compara e o conferir.py no
modo gabarito, e e ele que libera o uso no mes corrente.

Regra que atravessa o arquivo inteiro: nenhuma linha do bruto desaparece. Ela
vira linha do relatorio, ou sai nomeada em linhas-fora-da-montagem.csv com a
causa. Coluna que a receita nao explica nao e inventada: a montagem para e diz
qual campo esta como lacuna.

A mesma regra vale celula a celula nas colunas de soma. Vazio nao e zero: a
celula vazia cai num balde proprio, sai nomeada no rastro, aparece na nota e
para a montagem, em vez de somar como zero e escrever no relatorio um numero que
o bruto nao diz. E vale coluna a coluna no bruto: coluna que existe no arquivo e
que nenhuma coluna do relatorio le sai nomeada, e so nao derruba o codigo 0
quando a receita a declara em 'nao_coberto'.
"""

import argparse
import csv
import json
import re
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from conferir import (  # noqa: E402
    ErroDeEntrada, NOME_DELIM, RODAPE, escrever_csv, escrever_texto,
    linhas_fora_da_tabela, ler, normal, tipo_celula, valor_numerico)

OK = 0
ERRO = 3
SOBROU = 5

REGRAS = ("agrupamento", "copia", "unico", "soma", "contagem", "razao",
          "diferenca", "fixo", "lacuna")
REGRAS_COM_FONTE = ("agrupamento", "copia", "unico", "soma", "razao",
                    "diferenca", "fixo")
REGRAS_DE_COPIA = ("agrupamento", "copia", "unico")
FORMATOS = ("texto", "inteiro", "numero_br", "numero_en", "moeda_br",
            "percentual", "data_dmy", "data_iso")
CHAVES_DA_RECEITA = ("relatorio", "origem", "leitura", "empilhar",
                     "filtro_de_linha", "agrupar_por", "colunas", "ordem",
                     "totais", "arredondamento", "saida", "nao_coberto")
CHAVES_DA_COLUNA = ("nome", "regra", "vem_de", "formato", "observacao")
# Formato cuja soma volta a Decimal sem ambiguidade. Percentual e data nao
# somam, e a identidade da soma nao e conferida neles.
FORMATOS_SOMAVEIS = ("inteiro", "numero_br", "numero_en", "moeda_br")


def exigir(condicao, mensagem):
    if not condicao:
        raise ErroDeEntrada(mensagem)


# ------------------------------------------------------------------- receita

def carregar_receita(caminho):
    """Le e critica a receita. Campo desconhecido para a montagem.

    Receita com campo escrito errado e pior do que receita faltando: ela roda,
    ignora o campo em silencio, e o relatorio sai diferente sem ninguem saber
    por que.
    """
    arquivo = Path(caminho)
    exigir(arquivo.exists(), "receita nao encontrada: %s" % caminho)
    try:
        receita = json.loads(arquivo.read_text(encoding="utf-8"))
    except ValueError as erro:
        raise ErroDeEntrada("a receita %s nao e JSON valido: %s"
                            % (arquivo.name, erro))
    exigir(isinstance(receita, dict), "a receita precisa ser um objeto JSON")
    for chave in receita:
        exigir(chave in CHAVES_DA_RECEITA,
               "campo desconhecido na receita: %r. Campos aceitos: %s"
               % (chave, ", ".join(CHAVES_DA_RECEITA)))
    colunas = receita.get("colunas") or []
    exigir(colunas, "a receita nao declara nenhuma coluna em 'colunas'")
    nomes = []
    lacunas = []
    for col in colunas:
        exigir(isinstance(col, dict), "cada item de 'colunas' e um objeto JSON")
        for chave in col:
            exigir(chave in CHAVES_DA_COLUNA,
                   "campo desconhecido na coluna %r: %r"
                   % (col.get("nome"), chave))
        nome = col.get("nome")
        exigir(nome, "coluna sem 'nome' na receita")
        exigir(nome not in nomes,
               "a coluna %r aparece duas vezes na receita" % nome)
        nomes.append(nome)
        regra = col.get("regra")
        exigir(regra in REGRAS,
               "a coluna %r tem regra %r. Regras aceitas: %s"
               % (nome, regra, ", ".join(REGRAS)))
        exigir(nome_do_formato(col.get("formato") or "texto") in FORMATOS,
               "a coluna %r tem formato %r. Formatos aceitos: texto, inteiro, "
               "numero_br:N, numero_en:N, moeda_br:N, percentual:N, data_dmy, "
               "data_iso" % (nome, col.get("formato")))
        if regra == "lacuna":
            lacunas.append(nome)
        if regra in REGRAS_COM_FONTE:
            exigir(col.get("vem_de"),
                   "a coluna %r com regra %s precisa de 'vem_de'"
                   % (nome, regra))
        if regra in ("razao", "diferenca"):
            sinal = "/" if regra == "razao" else "-"
            exigir(sinal in (col.get("vem_de") or ""),
                   "a coluna %r com regra %s espera 'vem_de' no formato "
                   "'ColunaA%sColunaB'" % (nome, regra, sinal))
    exigir(not lacunas,
           "a receita tem lacuna declarada em %s. Coluna que ninguem consegue "
           "explicar nao e montada por inferencia: derive a regra do relatorio "
           "aprovado, ou tire a coluna da receita e declare que ela continua "
           "manual em 'nao_coberto'." % ", ".join(lacunas))
    agrupar = receita.get("agrupar_por") or []
    for nome in agrupar:
        exigir(any(normal(c.get("vem_de") or "") == normal(nome)
                   and c["regra"] in REGRAS_DE_COPIA for c in colunas),
               "a receita agrupa por %r e nenhuma coluna do relatorio copia "
               "essa coluna do bruto. Agrupamento que nao aparece no relatorio "
               "junta linha sem dizer por que." % nome)
    arred = receita.get("arredondamento", "depois_de_somar")
    exigir(arred in ("depois_de_somar", "antes_de_somar"),
           "arredondamento aceita depois_de_somar ou antes_de_somar, recebi %r"
           % arred)
    saida = receita.get("saida") or {}
    for chave in saida:
        exigir(chave in ("delimitador", "encoding", "assinatura_de_ia"),
               "campo desconhecido em 'saida': %r" % chave)
    return receita


# -------------------------------------------------------------------- formato

def nome_do_formato(formato):
    return (formato or "texto").split(":")[0]


def casas_do_formato(formato):
    partes = (formato or "texto").split(":")
    if len(partes) == 2 and partes[1].isdigit():
        return partes[0], int(partes[1])
    return partes[0], None


def casas_padrao(formato):
    nome, casas = casas_do_formato(formato)
    if nome == "inteiro":
        return 0
    if casas is not None:
        return casas
    return 1 if nome == "percentual" else 2


def numero_en(valor, casas):
    passo = Decimal(1).scaleb(-casas)
    return ("{:,.%df}" % casas).format(valor.quantize(passo,
                                                      rounding=ROUND_HALF_UP))


def numero_br(valor, casas):
    texto = numero_en(valor, casas)
    return texto.replace(",", "\x00").replace(".", ",").replace("\x00", ".")


def arredondar(valor, formato):
    passo = Decimal(1).scaleb(-casas_padrao(formato))
    return valor.quantize(passo, rounding=ROUND_HALF_UP)


def formatar(valor, formato):
    """Escreve o numero no formato declarado na receita.

    O produto desta skill e o relatorio no mesmo formato do que foi aprovado,
    entao o formato e parte do resultado, nao acabamento.
    """
    if valor is None:
        return ""
    nome = nome_do_formato(formato)
    casas = casas_padrao(formato)
    if nome == "inteiro":
        return str(int(valor.quantize(Decimal(1), rounding=ROUND_HALF_UP)))
    if nome == "percentual":
        return numero_br(valor * 100, casas) + "%"
    if nome == "moeda_br":
        return "R$ " + numero_br(valor, casas)
    if nome == "numero_en":
        return numero_en(valor, casas)
    if nome == "numero_br":
        return numero_br(valor, casas)
    return str(valor)


def ler_no_formato(texto, formato):
    """Volta de texto para Decimal usando o formato declarado, nao adivinhado.

    Adivinhar aqui erraria em 1.234, que e mil duzentos e trinta e quatro no
    formato brasileiro sem casas e um virgula dois no outro. A identidade da
    soma existe para conferir o que foi gravado no arquivo, entao ela le o que
    esta escrito.
    """
    t = (texto or "").strip()
    if t == "":
        return None
    nome = nome_do_formato(formato)
    if nome == "moeda_br":
        t = re.sub(r"^(R\$|US\$|\$)\s*", "", t)
        nome = "numero_br"
    if nome == "percentual":
        t = t.rstrip("%").strip()
        nome = "numero_br"
    if nome == "numero_br":
        t = t.replace(".", "").replace(",", ".")
    elif nome == "numero_en":
        t = t.replace(",", "")
    try:
        return Decimal(t)
    except Exception:
        return None


def data_formatada(bruto, formato):
    """Converte data entre dmy e iso. Texto que nao e data sai como esta."""
    tipo = tipo_celula(bruto)
    if formato == "data_dmy" and tipo == "data_iso":
        a, m, d = bruto.split("-")
        return "%s/%s/%s" % (d, m, a)
    if formato == "data_iso" and tipo == "data_dmy":
        d, m, a = bruto.split("/")
        return "%s-%s-%s" % (a, m, d)
    return bruto


# -------------------------------------------------------------------- leitura

class LinhaFora(object):
    __slots__ = ("arquivo", "linha", "classe", "causa", "detalhe", "conteudo")

    def __init__(self, arquivo, linha, classe, causa, detalhe, conteudo=""):
        self.arquivo = arquivo
        self.linha = linha
        self.classe = classe
        self.causa = causa
        self.detalhe = detalhe
        self.conteudo = conteudo

    def como_linha(self):
        return [self.arquivo, self.linha, self.classe, self.causa,
                self.detalhe, self.conteudo]


def indice_da_coluna(tab, nome, arquivo):
    mapa = {normal(c): i for i, c in enumerate(tab.colunas)}
    i = mapa.get(normal(nome))
    if i is None:
        raise ErroDeEntrada(
            "a receita usa a coluna %r e ela nao existe em %s. Colunas do "
            "arquivo: %s. Rode o modo estrutura do conferir.py antes de montar: "
            "coluna que a receita espera e o bruto nao tem e mudanca de "
            "estrutura, e relatorio montado sobre estrutura que mudou sai "
            "completo e errado." % (nome, arquivo, ", ".join(tab.colunas)))
    return i


def fontes_do_bruto(receita):
    """Colunas do bruto que a receita usa, por finalidade.

    A de soma e indexada pelo nome normalizado: coluna do bruto usada por duas
    colunas do relatorio, como Produzidas no total e no aproveitamento, e somada
    uma vez. Sem isso a soma lida sairia dobrada e a identidade acusaria erro
    onde nao ha.
    """
    de_copia = []
    de_soma = {}
    for col in receita["colunas"]:
        if col["regra"] in REGRAS_DE_COPIA:
            de_copia.append((col["vem_de"], col))
            continue
        nomes = []
        if col["regra"] == "soma":
            nomes = [col["vem_de"]]
        elif col["regra"] in ("razao", "diferenca"):
            sinal = "/" if col["regra"] == "razao" else "-"
            nomes = [p.strip() for p in col["vem_de"].split(sinal, 1)]
        for nome in nomes:
            chave = normal(nome)
            if chave not in de_soma or col["regra"] == "soma":
                de_soma[chave] = (nome, col)
    return de_copia, de_soma


def colunas_lidas_da_receita(receita, coluna_origem):
    """Nomes normalizados das colunas do bruto que a receita de fato le.

    Serve para nomear a coluna que o bruto tem e nenhuma coluna do relatorio
    consome. A regra 'fixo' fica de fora de proposito: o 'vem_de' dela e o texto
    gravado na celula, nao o nome de uma coluna do arquivo.
    """
    de_copia, de_soma = fontes_do_bruto(receita)
    usadas = set(de_soma)
    usadas |= set(normal(nome) for nome, _ in de_copia)
    usadas |= set(normal(n) for n in (receita.get("agrupar_por") or []))
    usadas |= set(normal(f.get("coluna") or "")
                  for f in (receita.get("filtro_de_linha") or []))
    if coluna_origem:
        usadas.add(normal(coluna_origem))
    return usadas


def declarada_em_nao_coberto(nome, receita):
    """Item de 'nao_coberto' que declara essa coluna, ou string vazia.

    Coluna do bruto que a receita deixa de fora de proposito e decisao
    declarada, e decisao declarada nao derruba o codigo 0. Nao estando escrita
    em lugar nenhum, ela e dado do arquivo que nunca entrou na rodada, e ai
    derruba. As duas saem nomeadas: e a lei de ferro 7.
    """
    alvo = re.compile(r"\b%s\b" % re.escape(normal(nome)))
    for item in (receita.get("nao_coberto") or []):
        if alvo.search(normal(item)):
            return item
    return ""


def colunas_nao_cobertas(receita, tabelas, coluna_origem):
    """Colunas do bruto que a receita nao le, com o item que as declara.

    Devolve [(nome da coluna, item de 'nao_coberto' ou string vazia)]. O
    cabecalho dos arquivos empilhados e obrigatoriamente o mesmo, conferido em
    ler_brutos, entao a lista sai do primeiro.
    """
    usadas = colunas_lidas_da_receita(receita, coluna_origem)
    _, tab, _ = tabelas[0]
    return [(nome, declarada_em_nao_coberto(nome, receita))
            for nome in tab.colunas if normal(nome) not in usadas]


def ler_brutos(caminhos, receita):
    """Le cada bruto e confere que os arquivos empilhaveis tem o mesmo cabecalho.

    Duas tabelas com colunas em ordem diferente empilhadas na marra misturam
    coluna, e a soma sai certa com o dado no lugar errado.
    """
    leitura = receita.get("leitura") or {}
    empilhar = receita.get("empilhar") or {}
    coluna_origem = empilhar.get("coluna_de_origem") or ""
    origem_por_arquivo = empilhar.get("origem_por_arquivo") or {}
    if len(caminhos) > 1:
        exigir(coluna_origem,
               "%d arquivos de bruto e nenhuma coluna de origem declarada em "
               "'empilhar'. Sem ela, depois de empilhar ninguem sabe de que "
               "area veio cada linha." % len(caminhos))
    tabelas = []
    referencia = None
    for caminho in caminhos:
        tab = ler(caminho, leitura.get("encoding") or None,
                  leitura.get("delimitador") or None,
                  leitura.get("ignorar_linha") or None)
        exigir(tab.registros,
               "%s tem cabecalho e nenhum registro lido. Montar sobre arquivo "
               "sem linha nenhuma entrega um relatorio vazio com cara de "
               "pronto." % Path(caminho).name)
        assinatura = [normal(c) for c in tab.colunas]
        if referencia is None:
            referencia = (assinatura, Path(caminho).name)
        else:
            exigir(assinatura == referencia[0],
                   "o cabecalho de %s nao e o mesmo de %s, nem no nome nem na "
                   "ordem. Rode o modo estrutura do conferir.py entre os dois e "
                   "resolva a diferenca antes de empilhar."
                   % (Path(caminho).name, referencia[1]))
        nome = Path(caminho).name
        origem = origem_por_arquivo.get(nome)
        if coluna_origem:
            exigir(origem is not None,
                   "o arquivo %s nao tem origem declarada em "
                   "'empilhar.origem_por_arquivo'. Deduzir a area pelo nome do "
                   "arquivo inventaria o nome da area." % nome)
        tabelas.append((nome, tab, origem))
    return tabelas, coluna_origem


# ------------------------------------------------------------------ montagem

def montar(receita, tabelas, coluna_origem):
    """Agrega o bruto conforme a receita.

    Cada linha lida termina em um grupo ou em linhas-fora-da-montagem.csv. As
    contagens saem do laco, nunca de subtracao.

    Cada celula de coluna de soma tambem: ela cai em somada, vazia ou nao
    numerica, e a conta dos tres baldes tem que dar o numero de linhas
    agregadas. Celula que nao aparece em balde nenhum e celula que some sem
    ninguem contar, e era por ai que o vazio virava zero no relatorio.
    """
    colunas = receita["colunas"]
    agrupar = receita.get("agrupar_por") or []
    filtros = receita.get("filtro_de_linha") or []
    arred_antes = (receita.get("arredondamento", "depois_de_somar")
                   == "antes_de_somar")
    de_copia, de_soma = fontes_do_bruto(receita)

    fora, problemas, avisos = [], [], []
    lidos = filtradas = agregadas = 0
    grupos = {}
    ordem_dos_grupos = []
    somas_lidas = {}
    somadas, vazias, nao_numericas, nomes_de_fonte = {}, {}, {}, {}
    for fonte, (nome, _) in de_soma.items():
        if coluna_origem and normal(nome) == normal(coluna_origem):
            continue
        somadas[fonte] = 0
        vazias[fonte] = 0
        nao_numericas[fonte] = 0
        somas_lidas[fonte] = Decimal(0)
        nomes_de_fonte[fonte] = nome

    nao_cobertas = colunas_nao_cobertas(receita, tabelas, coluna_origem)
    nome_do_primeiro, primeira, _ = tabelas[0]
    for nome_col, declarada in nao_cobertas:
        if declarada:
            fora.append(LinhaFora(
                nome_do_primeiro, primeira.linha_cabecalho, "declarada",
                "coluna_do_bruto_declarada_em_nao_coberto",
                "a coluna %r existe no bruto, nenhuma coluna do relatorio a "
                "le, e a receita declara isso em 'nao_coberto': %s"
                % (nome_col, declarada)))
        else:
            avisos.append(LinhaFora(
                nome_do_primeiro, primeira.linha_cabecalho, "aviso",
                "coluna_do_bruto_que_a_receita_nao_cobre",
                "a coluna %r existe no bruto e nenhuma coluna do relatorio a "
                "le. Sendo coluna nova, o modo estrutura do conferir.py diz "
                "desde quando; ficando de fora de proposito, escreva o nome "
                "dela em 'nao_coberto'" % nome_col))

    for nome_arquivo, tab, origem in tabelas:
        for linha, classe, causa, conteudo in linhas_fora_da_tabela(tab):
            if classe == "linha_sem_conteudo":
                continue
            fora.append(LinhaFora(nome_arquivo, linha, classe, causa, "",
                                  conteudo))
        idx = {}
        for nome, _ in de_copia + list(de_soma.values()):
            if coluna_origem and normal(nome) == normal(coluna_origem):
                continue
            idx[normal(nome)] = indice_da_coluna(tab, nome, nome_arquivo)
        for nome in agrupar:
            if coluna_origem and normal(nome) == normal(coluna_origem):
                continue
            idx[normal(nome)] = indice_da_coluna(tab, nome, nome_arquivo)
        filtros_idx = [(f.get("coluna"),
                        indice_da_coluna(tab, f.get("coluna"), nome_arquivo),
                        [normal(v) for v in (f.get("manter") or [])],
                        f.get("manter") or [])
                       for f in filtros]

        for reg in tab.registros:
            lidos += 1
            excluida = False
            for coluna, i, manter_n, manter in filtros_idx:
                if normal(reg.celulas[i]) not in manter_n:
                    fora.append(LinhaFora(
                        nome_arquivo, reg.linha,
                        "filtrada_por_regra_declarada",
                        "fora_do_filtro_declarado_na_receita",
                        "%s=%r, a receita mantem %s"
                        % (coluna, reg.celulas[i], ", ".join(manter)),
                        tab.delimitador.join(reg.celulas)))
                    filtradas += 1
                    excluida = True
                    break
            if excluida:
                continue
            agregadas += 1
            if agrupar:
                chave = tuple(
                    normal(origem or "") if (coluna_origem
                                             and normal(n) == normal(coluna_origem))
                    else normal(reg.celulas[idx[normal(n)]])
                    for n in agrupar)
            else:
                chave = (nome_arquivo, reg.linha)
            if chave not in grupos:
                grupos[chave] = {"linhas": [], "idx": idx, "origem": origem,
                                 "arquivo": nome_arquivo}
                ordem_dos_grupos.append(chave)
            grupos[chave]["linhas"].append(reg)
            for fonte, (nome, col) in de_soma.items():
                if coluna_origem and normal(nome) == normal(coluna_origem):
                    continue
                bruto = reg.celulas[idx[fonte]]
                num = valor_numerico(bruto, tipo_celula(bruto))
                if num is None:
                    if bruto.strip():
                        nao_numericas[fonte] += 1
                        problemas.append(LinhaFora(
                            nome_arquivo, reg.linha, "problema",
                            "celula_nao_numerica_em_coluna_de_soma",
                            "a coluna %r do bruto alimenta %r e traz %r"
                            % (nome, col["nome"], bruto),
                            tab.delimitador.join(reg.celulas)))
                    else:
                        vazias[fonte] += 1
                        problemas.append(LinhaFora(
                            nome_arquivo, reg.linha, "problema",
                            "celula_vazia_em_coluna_de_soma",
                            "a coluna %r do bruto alimenta %r e veio vazia. "
                            "Vazio nao e zero: somar como zero escreveria no "
                            "relatorio um numero que o bruto nao diz"
                            % (nome, col["nome"]),
                            tab.delimitador.join(reg.celulas)))
                    continue
                somadas[fonte] += 1
                if arred_antes:
                    num = arredondar(num, col.get("formato") or "texto")
                somas_lidas[fonte] = somas_lidas.get(fonte, Decimal(0)) + num

    exigir(grupos,
           "nenhuma linha do bruto sobreviveu ao filtro declarado na receita. "
           "Relatorio vazio com cara de pronto e pior do que relatorio nenhum: "
           "confira o filtro de linha.")

    linhas_de_grupo = []
    for chave in ordem_dos_grupos:
        grupo = grupos[chave]
        somas = {}
        celulas = [valor_da_coluna(col, grupo, somas, arred_antes,
                                   coluna_origem, problemas, avisos)
                   for col in colunas]
        linhas_de_grupo.append({"celulas": celulas, "grupo": grupo,
                                "somas": somas})

    linhas_de_grupo = ordenar(linhas_de_grupo, receita)
    linhas, gravadas_de_grupo, de_total = posicionar_totais(
        linhas_de_grupo, receita, avisos)
    return {
        "linhas": linhas,
        "de_grupo_celulas": gravadas_de_grupo,
        "de_grupo": len(linhas_de_grupo),
        "de_total": de_total,
        "lidos": lidos,
        "filtradas": filtradas,
        "agregadas": agregadas,
        "fora": fora,
        "problemas": problemas,
        "avisos": avisos,
        "somas_lidas": somas_lidas,
        "somadas": somadas,
        "vazias": vazias,
        "nao_numericas": nao_numericas,
        "nomes_de_fonte": nomes_de_fonte,
        "nao_cobertas": nao_cobertas,
        "grupos": len(grupos),
    }


def somar_fonte(grupo, nome, arred_antes, formato, coluna_origem):
    """Soma a coluna do bruto dentro do grupo.

    Devolve (total, celulas sem valor). Celula vazia ou nao numerica nao entra
    na soma e nao vira zero: ela sai contada, e quem chama decide o que
    escrever. Somar como zero aqui gravaria no relatorio um total que o bruto
    nao sustenta, e a diferenca nao apareceria em lugar nenhum.
    """
    if coluna_origem and normal(nome) == normal(coluna_origem):
        return Decimal(0), 0
    total = Decimal(0)
    faltando = 0
    i = grupo["idx"][normal(nome)]
    for reg in grupo["linhas"]:
        bruto = reg.celulas[i]
        num = valor_numerico(bruto, tipo_celula(bruto))
        if num is None:
            faltando += 1
            continue
        total += arredondar(num, formato) if arred_antes else num
    return total, faltando


def valor_da_coluna(col, grupo, somas, arred_antes, coluna_origem, problemas,
                    avisos):
    regra = col["regra"]
    formato = col.get("formato") or "texto"
    if regra == "fixo":
        return col["vem_de"]
    if regra == "contagem":
        return formatar(Decimal(len(grupo["linhas"])), formato)
    if regra in REGRAS_DE_COPIA:
        if coluna_origem and normal(col["vem_de"]) == normal(coluna_origem):
            return grupo["origem"] or ""
        i = grupo["idx"][normal(col["vem_de"])]
        valores = [reg.celulas[i] for reg in grupo["linhas"]]
        distintos = sorted(set(valores))
        if regra in ("agrupamento", "unico") and len(distintos) > 1:
            problemas.append(LinhaFora(
                grupo["arquivo"], grupo["linhas"][0].linha, "problema",
                "valor_diferente_dentro_do_grupo",
                "a coluna %r foi declarada %s e o grupo traz %s. Escolher um "
                "por conta propria esconderia o outro"
                % (col["nome"], regra, "; ".join(distintos))))
            return ""
        bruto = valores[0]
        if nome_do_formato(formato) in ("data_dmy", "data_iso"):
            return data_formatada(bruto, formato)
        if nome_do_formato(formato) == "texto":
            return bruto
        num = valor_numerico(bruto, tipo_celula(bruto))
        return formatar(num, formato) if num is not None else bruto
    if regra == "soma":
        total, faltando = somar_fonte(grupo, col["vem_de"], arred_antes,
                                      formato, coluna_origem)
        if faltando:
            # A celula sai vazia, como no denominador zero: o total do grupo
            # nao e conhecido, e escrever a soma do que sobrou apresentaria um
            # numero parcial com cara de total fechado.
            somas[col["nome"]] = None
            return ""
        somas[col["nome"]] = total
        return formatar(total, formato)
    sinal = "/" if regra == "razao" else "-"
    a, b = [p.strip() for p in col["vem_de"].split(sinal, 1)]
    va, fa = somar_fonte(grupo, a, arred_antes, formato, coluna_origem)
    vb, fb = somar_fonte(grupo, b, arred_antes, formato, coluna_origem)
    if fa or fb:
        somas[col["nome"]] = None
        return ""
    somas[col["nome"]] = (va, vb)
    if regra == "diferenca":
        return formatar(va - vb, formato)
    if vb == 0:
        avisos.append(LinhaFora(
            grupo["arquivo"], grupo["linhas"][0].linha, "aviso",
            "denominador_zero_na_coluna_derivada",
            "a coluna %r divide por %s, que somou zero neste grupo. A celula "
            "sai vazia, porque zero seria um resultado inventado"
            % (col["nome"], b)))
        return ""
    return formatar(va / vb, formato)


def ordenar(linhas, receita):
    """Ordena pelas colunas declaradas, com o tipo da coluna respeitado."""
    ordem = receita.get("ordem") or []
    if not ordem:
        return linhas
    nomes = [c["nome"] for c in receita["colunas"]]
    formatos = {c["nome"]: c.get("formato") or "texto"
                for c in receita["colunas"]}
    for item in reversed(ordem):
        coluna = item.get("coluna")
        exigir(coluna in nomes,
               "a receita ordena por %r, que nao e coluna do relatorio" % coluna)
        sentido = item.get("sentido") or "crescente"
        exigir(sentido in ("crescente", "decrescente"),
               "sentido de ordem aceita crescente ou decrescente, recebi %r"
               % sentido)
        j = nomes.index(coluna)
        fmt = formatos[coluna]

        def peso(linha, j=j, fmt=fmt):
            bruto = linha["celulas"][j]
            num = ler_no_formato(bruto, fmt)
            if num is None:
                num = valor_numerico(bruto, tipo_celula(bruto))
            if num is None:
                return (1, normal(bruto), Decimal(0))
            return (0, "", num)

        linhas.sort(key=peso, reverse=(sentido == "decrescente"))
    return linhas


def posicionar_totais(linhas_de_grupo, receita, avisos):
    """Insere as linhas de total no lugar declarado na receita.

    O total do bloco e recalculado da soma do bloco, nunca da media das linhas
    ja formatadas: media de percentual nao e o percentual do bloco.
    """
    totais = receita.get("totais") or {}
    colunas = receita["colunas"]
    nomes = [c["nome"] for c in colunas]
    por_bloco = totais.get("por_bloco") or {}
    geral = totais.get("geral") or {}
    saida = []
    gravadas_de_grupo = []
    de_total = 0

    def linha_de_total(subconjunto, rotulo, coluna_do_rotulo):
        celulas = []
        for col in colunas:
            if col["nome"] == coluna_do_rotulo:
                celulas.append(rotulo)
                continue
            formato = col.get("formato") or "texto"
            if col["regra"] == "soma":
                parcelas = [l["somas"][col["nome"]] for l in subconjunto]
                # Grupo com celula sem valor nao tem total conhecido, e o bloco
                # que o contem tambem nao. O vazio sobe.
                if any(p is None for p in parcelas):
                    celulas.append("")
                    continue
                total = sum(parcelas, Decimal(0))
                celulas.append(formatar(total, formato))
                continue
            if col["regra"] == "contagem":
                total = sum(len(l["grupo"]["linhas"]) for l in subconjunto)
                celulas.append(formatar(Decimal(total), formato))
                continue
            if col["regra"] in ("razao", "diferenca"):
                parcelas = [l["somas"][col["nome"]] for l in subconjunto]
                if any(p is None for p in parcelas):
                    celulas.append("")
                    continue
                va = sum((p[0] for p in parcelas), Decimal(0))
                vb = sum((p[1] for p in parcelas), Decimal(0))
                if col["regra"] == "diferenca":
                    celulas.append(formatar(va - vb, formato))
                elif vb == 0:
                    avisos.append(LinhaFora(
                        "", 0, "aviso", "denominador_zero_na_linha_de_total",
                        "a coluna %r divide por zero na linha %r"
                        % (col["nome"], rotulo)))
                    celulas.append("")
                else:
                    celulas.append(formatar(va / vb, formato))
                continue
            celulas.append("")
        return celulas

    rotulo_geral = geral.get("rotulo") or "TOTAL GERAL"
    coluna_geral = geral.get("coluna_do_rotulo") or nomes[0]
    exigir(coluna_geral in nomes,
           "o total geral poe o rotulo na coluna %r, que nao e coluna do "
           "relatorio" % coluna_geral)

    if geral and (geral.get("posicao") or "rodape") == "topo":
        saida.append(linha_de_total(linhas_de_grupo, rotulo_geral, coluna_geral))
        de_total += 1

    if por_bloco:
        coluna = por_bloco.get("coluna")
        exigir(coluna in nomes,
               "a receita poe total por bloco na coluna %r, que nao e coluna do "
               "relatorio" % coluna)
        j = nomes.index(coluna)
        posicao = por_bloco.get("posicao") or "depois_do_bloco"
        exigir(posicao in ("depois_do_bloco", "antes_do_bloco"),
               "posicao do total por bloco aceita depois_do_bloco ou "
               "antes_do_bloco, recebi %r" % posicao)
        coluna_rot = por_bloco.get("coluna_do_rotulo") or nomes[0]
        exigir(coluna_rot in nomes,
               "o total por bloco poe o rotulo na coluna %r, que nao e coluna "
               "do relatorio" % coluna_rot)
        modelo = por_bloco.get("rotulo") or "TOTAL {bloco}"
        vistos = []
        bloco_atual = None
        acumulado = []
        for linha in linhas_de_grupo:
            valor = linha["celulas"][j]
            if valor != bloco_atual:
                exigir(valor not in vistos,
                       "o bloco %r aparece em dois pedacos separados depois da "
                       "ordenacao declarada. Total por bloco exige que a ordem "
                       "mantenha o bloco junto: ponha %r como primeira coluna "
                       "de 'ordem'." % (valor, coluna))
                if acumulado and posicao == "depois_do_bloco":
                    saida.append(linha_de_total(
                        acumulado, modelo.format(bloco=bloco_atual), coluna_rot))
                    de_total += 1
                vistos.append(valor)
                bloco_atual = valor
                acumulado = []
                if posicao == "antes_do_bloco":
                    do_bloco = [l for l in linhas_de_grupo
                                if l["celulas"][j] == valor]
                    saida.append(linha_de_total(
                        do_bloco, modelo.format(bloco=valor), coluna_rot))
                    de_total += 1
            acumulado.append(linha)
            saida.append(linha["celulas"])
            gravadas_de_grupo.append(linha["celulas"])
        if acumulado and posicao == "depois_do_bloco":
            saida.append(linha_de_total(
                acumulado, modelo.format(bloco=bloco_atual), coluna_rot))
            de_total += 1
    else:
        for linha in linhas_de_grupo:
            saida.append(linha["celulas"])
            gravadas_de_grupo.append(linha["celulas"])

    if geral and (geral.get("posicao") or "rodape") == "rodape":
        saida.append(linha_de_total(linhas_de_grupo, rotulo_geral, coluna_geral))
        de_total += 1
    return saida, gravadas_de_grupo, de_total


# -------------------------------------------------------------------- escrita

def escrever_relatorio(caminho, cabecalho, linhas, receita, fonte):
    cfg = receita.get("saida") or {}
    delim = cfg.get("delimitador") or ";"
    enc = cfg.get("encoding") or "utf-8-sig"
    assina = cfg.get("assinatura_de_ia", True)
    escritas = 0
    try:
        fh = Path(caminho).open("w", encoding=enc, newline="")
    except LookupError:
        raise ErroDeEntrada("encoding desconhecido na receita: %r" % enc)
    try:
        escritor = csv.writer(fh, delimiter=delim, quoting=csv.QUOTE_MINIMAL,
                              lineterminator="\n")
        escritor.writerow(cabecalho)
        for linha in linhas:
            escritor.writerow(linha)
            escritas += 1
        if assina:
            fh.write("# " + RODAPE % fonte + "\n")
    except UnicodeEncodeError as erro:
        fh.close()
        raise ErroDeEntrada(
            "o relatorio tem caractere que nao existe no encoding %s declarado "
            "na receita: %s. Declare utf-8-sig, ou tire o caractere na origem."
            % (enc, erro))
    fh.close()
    return escritas, enc, delim, assina


def identidades_da_montagem(receita, resultado, escritas, gravadas_fora,
                            todas_fora, cabecalho):
    agregadas = resultado["agregadas"]
    lista = [
        ("registros_lidos = agregados + filtrados_por_regra_declarada",
         resultado["lidos"], agregadas + resultado["filtradas"]),
        ("linhas_do_relatorio = linhas_de_grupo + linhas_de_total",
         len(resultado["linhas"]),
         resultado["de_grupo"] + resultado["de_total"]),
        ("linhas gravadas no relatorio = linhas_do_relatorio",
         escritas, len(resultado["linhas"])),
        ("linhas gravadas em linhas-fora-da-montagem.csv = fora + problemas "
         "+ avisos", gravadas_fora, len(todas_fora)),
    ]
    # Censo de celulas, uma identidade por coluna do bruto que alimenta soma,
    # razao ou diferenca. O lado esquerdo vem da forma do bruto, o direito vem
    # dos tres baldes do laco. Celula que a leitura descartasse sem contar nao
    # apareceria em balde nenhum, e a identidade nao fecharia. E a que impede
    # que o vazio suma antes de qualquer conta.
    for fonte in sorted(resultado["somadas"]):
        lista.append(
            ("celulas de %s lidas = somadas + vazias + nao numericas"
             % resultado["nomes_de_fonte"][fonte],
             agregadas,
             resultado["somadas"][fonte] + resultado["vazias"][fonte]
             + resultado["nao_numericas"][fonte]))
    # A identidade que importa: o total escrito no relatorio e o total lido no
    # bruto. Ela le de volta o texto gravado, com o formato declarado, em vez de
    # comparar o mesmo Decimal com ele mesmo. E o lado esquerdo declara quantas
    # celulas ficaram sem valor, em vez de trata-las como zero: assim ela so
    # pode fechar quando nao houve nenhuma. Enquanto os dois lados aplicavam
    # "vazio e zero", ela fechava sem provar nada.
    for col in receita["colunas"]:
        if col["regra"] != "soma":
            continue
        formato = col.get("formato") or "texto"
        if nome_do_formato(formato) not in FORMATOS_SOMAVEIS:
            continue
        fonte = normal(col["vem_de"])
        lida = resultado["somas_lidas"].get(fonte, Decimal(0))
        sem_valor = (resultado["vazias"].get(fonte, 0)
                     + resultado["nao_numericas"].get(fonte, 0))
        j = cabecalho.index(col["nome"])
        montada = Decimal(0)
        for celulas in resultado["de_grupo_celulas"]:
            num = ler_no_formato(celulas[j], formato)
            if num is not None:
                montada += num
        esquerda = str(arredondar(lida, formato))
        if sem_valor:
            esquerda += " + %d celula(s) sem valor" % sem_valor
        lista.append(
            ("soma de %s lida no bruto = soma de %s escrita no relatorio"
             % (col["vem_de"], col["nome"]),
             esquerda, str(arredondar(montada, formato))))
    return lista


def montar_nota(receita, tabelas, resultado, identidades, alvo, escritas, enc,
                delim, assina, perdidas, reconhecidas, caminho_receita):
    l = []
    l.append("# Nota da montagem")
    l.append("")
    l.append("status: %s"
             % ("invalido, a receita nao descreve o dado"
                if resultado["problemas"] else
                "montou, e cada linha lida terminou em linha do relatorio ou "
                "em filtro declarado"))
    l.append("")
    l.append("## Receita")
    l.append("")
    l.append("- relatorio: %s" % (receita.get("relatorio") or "sem nome"))
    l.append("- arquivo da receita: %s" % Path(caminho_receita).name)
    l.append("- agrupamento: %s"
             % (", ".join(receita.get("agrupar_por") or [])
                or "nenhum, uma linha do relatorio por linha do bruto"))
    l.append("- arredondamento: %s"
             % receita.get("arredondamento", "depois_de_somar"))
    l.append("- colunas do relatorio, na ordem:")
    for col in receita["colunas"]:
        l.append("  - %s: regra %s, vem de %s, formato %s"
                 % (col["nome"], col["regra"], col.get("vem_de") or "-",
                    col.get("formato") or "texto"))
    l.append("")
    l.append("## Arquivos")
    l.append("")
    for nome, tab, origem in tabelas:
        l.append("- bruto: %s, %d bytes, %d linhas no arquivo, cabecalho na "
                 "linha %d, %d registros lidos, encoding %s, delimitador %s%s"
                 % (nome, tab.caminho.stat().st_size, tab.linhas_no_arquivo,
                    tab.linha_cabecalho, len(tab.registros), tab.encoding,
                    NOME_DELIM.get(tab.delimitador, tab.delimitador),
                    ", origem declarada %s" % origem if origem else ""))
    l.append("- relatorio: %s, %d linhas de dado, encoding %s, delimitador %s, "
             "assinatura de IA no fim: %s"
             % (alvo.name, escritas, enc, NOME_DELIM.get(delim, delim),
                "sim" if assina else "nao"))
    l.append("")
    l.append("## Resultado")
    l.append("")
    l.append("- registros lidos no bruto: %d" % resultado["lidos"])
    l.append("- filtrados por regra declarada na receita: %d"
             % resultado["filtradas"])
    l.append("- grupos: %d" % resultado["grupos"])
    l.append("- linhas de grupo no relatorio: %d" % resultado["de_grupo"])
    l.append("- linhas de total no relatorio: %d" % resultado["de_total"])
    l.append("- linhas perdidas na leitura, sem causa reconhecida: %d"
             % len(perdidas))
    l.append("- celulas vazias em coluna de soma: %d"
             % sum(resultado["vazias"].values()))
    l.append("- celulas nao numericas em coluna de soma: %d"
             % sum(resultado["nao_numericas"].values()))
    l.append("- colunas do bruto que a receita nao le: %d, das quais %d "
             "declaradas em 'nao_coberto'"
             % (len(resultado["nao_cobertas"]),
                sum(1 for _, d in resultado["nao_cobertas"] if d)))
    l.append("- problemas que invalidam a montagem: %d"
             % len(resultado["problemas"]))
    l.append("- avisos: %d" % len(resultado["avisos"]))
    l.append("")
    l.append("## Decisoes declaradas e linhas reconhecidas")
    l.append("")
    if reconhecidas:
        for f in reconhecidas:
            l.append("- %s, %s, linha %s, em %s"
                     % (f.classe, f.causa, f.linha, f.arquivo))
    else:
        l.append("- nenhuma")
    l.append("")
    l.append("## Fechamento")
    l.append("")
    for nome, esq, dir_ in identidades:
        l.append("- %s: %s contra %s, %s"
                 % (nome, esq, dir_, "fecha" if esq == dir_ else "NAO FECHA"))
    l.append("")
    l.append("O lado esquerdo vem da forma do bruto, o direito vem dos "
             "contadores do laco. O censo de celulas poe cada celula de coluna "
             "de soma em somada, vazia ou nao numerica, e prova que nenhuma "
             "sumiu antes da conta. A identidade da soma le de volta o numero "
             "escrito no relatorio e declara no lado esquerdo quantas celulas "
             "ficaram sem valor, entao ela nao fecha tratando vazio como zero "
             "dos dois lados: ela e a que prova que a montagem nao perdeu "
             "linha, nao contou duas vezes e nao inventou numero.")
    l.append("")
    l.append("## O que a receita nao cobre")
    l.append("")
    nao_coberto = receita.get("nao_coberto") or []
    if nao_coberto:
        for item in nao_coberto:
            l.append("- %s" % item)
    else:
        l.append("- a receita nao declara nada como manual. Confira: comentario "
                 "do mes, destaque escrito olhando o numero e decisao de "
                 "excecao costumam continuar manuais.")
    l.append("")
    l.append("Colunas do bruto que nenhuma coluna do relatorio le:")
    l.append("")
    if resultado["nao_cobertas"]:
        for nome_col, declarada in resultado["nao_cobertas"]:
            l.append("- %s: %s"
                     % (nome_col,
                        "declarada em 'nao_coberto' (%s)" % declarada
                        if declarada else
                        "nao esta declarada em 'nao_coberto'. Saiu como aviso. "
                        "Sendo coluna nova do export, o modo estrutura do "
                        "conferir.py diz desde quando"))
    else:
        l.append("- nenhuma. Toda coluna do bruto entra numa coluna do "
                 "relatorio, no agrupamento ou num filtro declarado.")
    l.append("")
    l.append("## Limite declarado")
    l.append("")
    l.append("Este script monta a tabela. Ele nao escreve o comentario do mes, "
             "nao desenha painel, nao formata planilha e nao decide excecao. "
             "Quem confere se a montagem reproduz o relatorio aprovado e o "
             "conferir.py, no modo gabarito.")
    return "\n".join(l)


def rodar(args):
    receita = carregar_receita(args.receita)
    alvo = Path(args.saida)
    if alvo.exists() and not args.forcar:
        raise ErroDeEntrada(
            "%s ja existe. Use --forcar para sobrescrever a tentativa anterior "
            "deste mes." % alvo)
    tabelas, coluna_origem = ler_brutos(args.bruto, receita)
    resultado = montar(receita, tabelas, coluna_origem)

    fonte = ", ".join(nome for nome, _, _ in tabelas)
    cabecalho = [c["nome"] for c in receita["colunas"]]
    escritas, enc, delim, assina = escrever_relatorio(
        alvo, cabecalho, resultado["linhas"], receita, fonte)

    base = str(alvo.parent / alvo.stem)
    caminho_fora = Path(base + ".linhas-fora-da-montagem.csv")
    todas_fora = (resultado["fora"] + resultado["problemas"]
                  + resultado["avisos"])
    gravadas_fora = escrever_csv(
        caminho_fora,
        ["arquivo", "linha", "classe", "causa", "detalhe", "conteudo_da_linha"],
        [f.como_linha() for f in todas_fora], fonte)

    perdidas = [f for f in resultado["fora"] if f.classe == "perdida"]
    reconhecidas = [f for f in resultado["fora"]
                    if f.classe in ("reconhecida", "declarada",
                                    "filtrada_por_regra_declarada")]
    identidades = identidades_da_montagem(
        receita, resultado, escritas, gravadas_fora, todas_fora, cabecalho)
    quebrou = any(esq != dir_ for _, esq, dir_ in identidades)

    escrever_texto(Path(base + ".nota-da-montagem.md"),
                   montar_nota(receita, tabelas, resultado, identidades, alvo,
                               escritas, enc, delim, assina, perdidas,
                               reconhecidas, args.receita),
                   fonte)

    print("MONTAGEM")
    for nome, tab, origem in tabelas:
        print("  bruto: %s, %d colunas, %d registros lidos%s"
              % (nome, len(tab.colunas), len(tab.registros),
                 ", origem %s" % origem if origem else ""))
    print("  relatorio: %s, %d colunas, %d linhas (%d de grupo, %d de total)"
          % (alvo.name, len(cabecalho), escritas, resultado["de_grupo"],
             resultado["de_total"]))
    print("")
    print("FECHAMENTO")
    for nome, esq, dir_ in identidades:
        print("  %-64s %12s %12s  %s"
              % (nome, esq, dir_, "fecha" if esq == dir_ else "NAO FECHA"))
    print("")
    print("VERIFICACOES")
    print("  registros lidos no bruto:         %d" % resultado["lidos"])
    print("  linhas agregadas:                 %d" % resultado["agregadas"])
    print("  grupos no relatorio:              %d" % resultado["grupos"])
    print("  filtradas por regra da receita:   %d" % resultado["filtradas"])
    print("  linhas perdidas na leitura:       %d" % len(perdidas))
    print("  celulas vazias em coluna de soma: %d"
          % sum(resultado["vazias"].values()))
    print("  celulas nao numericas em coluna de soma: %d"
          % sum(resultado["nao_numericas"].values()))
    print("  colunas do bruto que a receita nao le:   %d"
          % len(resultado["nao_cobertas"]))
    print("  problemas que invalidam:          %d" % len(resultado["problemas"]))
    print("  avisos:                           %d" % len(resultado["avisos"]))
    for nome_col, declarada in resultado["nao_cobertas"]:
        print("  COLUNA DO BRUTO QUE A RECEITA NAO LE: %s, %s"
              % (nome_col,
                 "declarada em nao_coberto" if declarada
                 else "nao declarada em nao_coberto"))
    for f in resultado["problemas"]:
        print("  PROBLEMA: %s, linha %s, %s" % (f.causa, f.linha, f.detalhe))
    for f in resultado["avisos"]:
        print("  AVISO: %s, %s" % (f.causa, f.detalhe))
    for f in perdidas:
        print("  LINHA PERDIDA: %s, linha %s" % (f.causa, f.linha))
    for f in reconhecidas:
        print("  DECISAO DECLARADA: %s, linha %s" % (f.causa, f.linha))
    print("")
    print("Relatorio em %s" % alvo)
    print("Rastro em %s" % caminho_fora)

    codigo = OK
    if resultado["problemas"]:
        print("ERRO: a montagem encontrou dado que a receita nao descreve. O "
              "relatorio gravado nao pode ser usado: corrija a receita ou o "
              "bruto e monte de novo. Celula vazia em coluna de soma entra "
              "aqui: vazio nao e zero, e a montagem nao escolhe por conta "
              "propria qual dos dois o bruto queria dizer.", file=sys.stderr)
        codigo = ERRO
    if quebrou:
        print("ERRO: uma identidade de fechamento nao fecha. A saida nao vale.",
              file=sys.stderr)
        codigo = ERRO
    if codigo != OK:
        return codigo
    if perdidas or resultado["avisos"]:
        print("Montou, e sobrou linha perdida na leitura ou aviso que exige "
              "leitura. Leia %s." % caminho_fora.name)
        return SOBROU
    return OK


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Monta o relatorio do mes a partir dos dados brutos e da "
                    "receita gravada em JSON.")
    p.add_argument("--receita", required=True,
                   help="receita.json derivada no passo 5")
    p.add_argument("--bruto", action="append", required=True,
                   help="dados brutos do mes. Repita a opcao para consolidar um "
                        "arquivo por area num relatorio so")
    p.add_argument("--saida", required=True,
                   help="caminho do CSV do relatorio. Os dois arquivos de "
                        "rastro saem ao lado, com o mesmo prefixo")
    p.add_argument("--forcar", action="store_true",
                   help="sobrescreve a saida de uma tentativa anterior do "
                        "mesmo mes")
    args = p.parse_args(argv)
    try:
        return rodar(args)
    except ErroDeEntrada as erro:
        print("ERRO: %s" % erro, file=sys.stderr)
        return ERRO


if __name__ == "__main__":
    sys.exit(main())
