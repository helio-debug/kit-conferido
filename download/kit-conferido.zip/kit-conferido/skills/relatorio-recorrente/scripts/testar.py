#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do conferir.py e do montar.py.

Biblioteca padrao apenas. Gera cada caso num diretorio temporario, roda o script
nele e compara o codigo de saida e trechos dos arquivos gerados com o esperado.

Os casos nao foram escritos a partir das funcionalidades do script. Foram
escritos a partir de uma pergunta so: existe caminho em que a rodada sai com
sucesso tendo perdido dado? Cada caso e uma resposta afirmativa a essa pergunta
que precisou ser fechada.

Rode depois de qualquer mudanca em qualquer um dos dois:

    python3 ~/.claude/skills/relatorio-recorrente/scripts/testar.py

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\relatorio-recorrente\\scripts\\testar.py"

Sai com 1 se algum caso falhar.
"""

import re
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
CONFERIR = AQUI / "conferir.py"
MONTAR = AQUI / "montar.py"
SKILL = AQUI.parent / "SKILL.md"
RECEITA_EXEMPLO = AQUI.parent / "references" / "receita-exemplo.json"

falhas = []


def registrar(nome, erros):
    if erros:
        falhas.append((nome, erros))
        print("FALHOU  %s" % nome)
        for e in erros:
            print("        %s" % e)
    else:
        print("ok      %s" % nome)


def conferir_texto(conteudo, alvo, deve):
    if alvo.startswith("re:"):
        achou = re.search(alvo[3:], conteudo) is not None
    else:
        achou = alvo in conteudo
    return achou == deve


def rodar(nome, modo, arquivos, esperado, checagens, extra=None):
    """checagens: lista de (arquivo, texto, deve_aparecer).

    arquivo aceita 'stdout', 'stderr' ou um nome dentro do diretorio de saida.
    texto com o prefixo 're:' e tratado como expressao regular.
    """
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        for n, c in arquivos.items():
            (base / n).write_text(c, encoding="utf-8")
        cmd = [sys.executable, str(CONFERIR), "--modo", modo,
               "--saida", str(base / "saida")]
        if modo == "estrutura":
            cmd += ["--anterior", str(base / "anterior.csv"),
                    "--atual", str(base / "atual.csv")]
        else:
            cmd += ["--entregue", str(base / "entregue.csv"),
                    "--refeito", str(base / "refeito.csv")]
        if extra:
            cmd += extra
        proc = subprocess.run(cmd, capture_output=True, text=True)
        erros = []
        if proc.returncode != esperado:
            erros.append("codigo de saida %d, esperado %d. stderr: %s"
                         % (proc.returncode, esperado, proc.stderr.strip()[:300]))
        for arquivo, texto, deve in checagens:
            if arquivo == "stdout":
                conteudo = proc.stdout
            elif arquivo == "stderr":
                conteudo = proc.stderr
            else:
                caminho = base / "saida" / arquivo
                if not caminho.exists():
                    erros.append("arquivo %s nao foi gravado" % arquivo)
                    continue
                conteudo = caminho.read_text(encoding="utf-8-sig")
            if not conferir_texto(conteudo, texto, deve):
                erros.append("%s: %s %r"
                             % (arquivo,
                                "esperava encontrar" if deve
                                else "nao deveria conter", texto))
        registrar(nome, erros)


def rodar_montar(nome, arquivos, receita, esperado, checagens, extra=None,
                 brutos=("bruto.csv",)):
    """Roda o montar.py. checagens: (arquivo, texto, deve_aparecer).

    arquivo aceita 'stdout', 'stderr', 'relatorio' e os dois arquivos de rastro
    pelo sufixo: 'nota' e 'fora'.
    """
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        for n, c in arquivos.items():
            (base / n).write_text(c, encoding="utf-8")
        (base / "receita.json").write_text(receita, encoding="utf-8")
        alvo = base / "relatorio-2026-08.csv"
        cmd = [sys.executable, str(MONTAR), "--receita",
               str(base / "receita.json"), "--saida", str(alvo)]
        for b in brutos:
            cmd += ["--bruto", str(base / b)]
        if extra:
            cmd += extra
        proc = subprocess.run(cmd, capture_output=True, text=True)
        erros = []
        if proc.returncode != esperado:
            erros.append("codigo de saida %d, esperado %d. stderr: %s"
                         % (proc.returncode, esperado, proc.stderr.strip()[:300]))
        mapa = {
            "relatorio": alvo,
            "nota": base / "relatorio-2026-08.nota-da-montagem.md",
            "fora": base / "relatorio-2026-08.linhas-fora-da-montagem.csv",
        }
        for arquivo, alvo_texto, deve in checagens:
            if arquivo == "stdout":
                conteudo = proc.stdout
            elif arquivo == "stderr":
                conteudo = proc.stderr
            else:
                caminho = mapa[arquivo]
                if not caminho.exists():
                    if deve:
                        erros.append("nao existe o arquivo %s" % arquivo)
                    continue
                conteudo = caminho.read_text(encoding="utf-8-sig")
            if not conferir_texto(conteudo, alvo_texto, deve):
                erros.append("%s: %s %r"
                             % (arquivo,
                                "esperava encontrar" if deve
                                else "nao deveria conter", alvo_texto))
        registrar(nome, erros)


# ------------------------------------------------------------------- massas

RELATORIO = (
    "Codigo;Descricao;Setor;Quantidade;Valor\n"
    "001;Valvula 3/4;Utilidades;10;1.200,00\n"
    "002;Manometro;Utilidades;4;300,50\n"
    "003;Bomba;Processo;2;5.000,00\n"
)

BLOCOS = (
    "Setor;Item;Valor\n"
    "Utilidades;Valvula;100\n"
    "Utilidades;Manometro;200\n"
    "Processo;Bomba;300\n"
    "Processo;Motor;400\n"
)

# A forma real de um relatorio com blocos: a linha de total nao tem codigo de
# item, entao a coluna-chave dela fica vazia dos dois lados.
COM_TOTAL = (
    "Codigo;Descricao;Setor;Valor;Aproveitamento\n"
    "001;Valvula esfera;Utilidades;2.000,00;98,5%\n"
    "002;Manometro;Utilidades;300,50;95,0%\n"
    ";TOTAL UTILIDADES;;2.300,50;97,9%\n"
    "003;Bomba;Processo;6.000,00;91,7%\n"
    ";TOTAL PROCESSO;;6.000,00;91,7%\n"
    ";TOTAL GERAL;;8.300,50;97,6%\n"
)

COM_TOTAL_OUTRO_MES = (
    "Codigo;Descricao;Setor;Valor;Aproveitamento\n"
    "001;Valvula esfera;Utilidades;2.500,00;99,1%\n"
    "002;Manometro;Utilidades;280,00;94,0%\n"
    ";TOTAL UTILIDADES;;2.780,00;98,4%\n"
    "003;Bomba;Processo;7.100,00;92,5%\n"
    ";TOTAL PROCESSO;;7.100,00;92,5%\n"
    ";TOTAL GERAL;;9.880,00;96,9%\n"
)

# Export de ERP com duas colunas de mesmo nome, que e comum.
DUPLICADO = (
    "Setor;Item;Qtde;Qtde\n"
    "Utilidades;Valvula esfera;120;117\n"
    "Utilidades;Manometro;40;38\n"
    "Processo;Bomba;10;9\n"
    "Processo;Motor;5;5\n"
)

BRUTO_DE_MONTAGEM = (
    "Relatorio de producao por setor\n"
    "Periodo: 01/08/2026 a 31/08/2026\n"
    "Setor;Item;Produzidas;Boas;Valor;Status\n"
    "Utilidades;Valvula esfera;120;117;1.200,00;Fechado\n"
    "Utilidades;Valvula esfera;80;80;800,00;Fechado\n"
    "Utilidades;Manometro;40;38;300,50;Fechado\n"
    "Processo;Bomba;10;9;5.000,00;Fechado\n"
    "Processo;Motor;5;5;2.500,00;Aberto\n"
    "Processo;Bomba;2;2;1.000,00;Fechado\n"
    "Emitido em 01/09/2026 pelo usuario PCP\n"
)

RECEITA = """{
  "relatorio": "Producao por setor",
  "leitura": {"delimitador": ";"},
  "filtro_de_linha": [{"coluna": "Status", "manter": ["Fechado"]}],
  "agrupar_por": ["Setor", "Item"],
  "colunas": [
    {"nome": "Setor", "regra": "agrupamento", "vem_de": "Setor",
     "formato": "texto"},
    {"nome": "Item", "regra": "agrupamento", "vem_de": "Item",
     "formato": "texto"},
    {"nome": "Apontamentos", "regra": "contagem", "formato": "inteiro"},
    {"nome": "Produzidas", "regra": "soma", "vem_de": "Produzidas",
     "formato": "inteiro"},
    {"nome": "Valor", "regra": "soma", "vem_de": "Valor",
     "formato": "numero_br:2"},
    {"nome": "Aproveitamento", "regra": "razao", "vem_de": "Boas/Produzidas",
     "formato": "percentual:1"}
  ],
  "ordem": [{"coluna": "Setor", "sentido": "crescente"},
            {"coluna": "Valor", "sentido": "decrescente"}],
  "totais": {
    "por_bloco": {"coluna": "Setor", "rotulo": "TOTAL {bloco}",
                  "posicao": "depois_do_bloco", "coluna_do_rotulo": "Item"},
    "geral": {"rotulo": "TOTAL GERAL", "posicao": "rodape",
              "coluna_do_rotulo": "Item"}
  },
  "arredondamento": "depois_de_somar",
  "saida": {"delimitador": ";", "encoding": "utf-8-sig"},
  "nao_coberto": ["comentario do mes"]
}"""


# ---------------------------------------------------- gabarito, casos de base

rodar("gabarito: refazer identico bate e sai com 0",
      "gabarito",
      {"entregue.csv": RELATORIO, "refeito.csv": RELATORIO},
      0,
      [("stdout", "re:celulas comparadas:\\s+15", True),
       ("nota-do-refazer.md", "status: bateu celula a celula", True)],
      ["--chave", "Codigo"])

rodar("gabarito: item cujo nome contem TOTAL e GERAL e dado, nao e descarte",
      "gabarito",
      {"entregue.csv": (
          "Codigo;Descricao;Setor;Quantidade;Valor\n"
          "001;Valvula 3/4;Utilidades;10;1.200,00\n"
          "002;Totalizador GERAL de vapor;Utilidades;4;300,50\n"
          "003;Bomba;Processo;2;5.000,00\n"),
       "refeito.csv": (
          "Codigo;Descricao;Setor;Quantidade;Valor\n"
          "001;Valvula 3/4;Utilidades;10;1.200,00\n"
          "002;Totalizador GERAL de vapor;Utilidades;4;300,60\n"
          "003;Bomba;Processo;2;5.000,00\n")},
      1,
      [("stdout", "re:celulas comparadas:\\s+15", True),
       ("celulas-que-nao-batem.csv", "300,60", True)],
      ["--chave", "Codigo"])

rodar("gabarito: a linha de total tambem e comparada celula a celula",
      "gabarito",
      {"entregue.csv": ("Setor;Item;Valor\n"
                        "Utilidades;Valvula;100\n"
                        "Processo;Bomba;300\n"
                        "TOTAL GERAL;;400\n"),
       "refeito.csv": ("Setor;Item;Valor\n"
                       "Utilidades;Valvula;100\n"
                       "Processo;Bomba;300\n"
                       "TOTAL GERAL;;410\n")},
      1,
      [("stdout", "re:celulas comparadas:\\s+9", True),
       ("celulas-que-nao-batem.csv", "410", True)],
      ["--chave", "Setor"])


# ------------------------------- gabarito, sair com sucesso tendo perdido dado

rodar("gabarito: nenhuma coluna emparelhada nao pode sair 0",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": ("Item;Nome;Area;Qtd;Preco\n"
                       "001;Valvula 3/4;Utilidades;10;1.200,00\n"
                       "002;Manometro;Utilidades;4;300,50\n"
                       "003;Bomba;Processo;2;5.000,00\n")},
      3,
      [("stderr", "nenhuma coluna emparelhou", True)],
      ["--chave", "Codigo"])

rodar("gabarito: nenhuma linha emparelhada nao pode sair 0",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": ("Codigo;Descricao;Setor;Quantidade;Valor\n"
                       "1;Valvula 3/4;Utilidades;10;1.200,00\n"
                       "2;Manometro;Utilidades;4;300,50\n"
                       "3;Bomba;Processo;2;5.000,00\n")},
      3,
      [("stderr", "nenhuma linha emparelhou", True)],
      ["--chave", "Codigo"])

rodar("gabarito: zero a esquerda perdido volta a parear com --chave-sem-zeros",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": ("Codigo;Descricao;Setor;Quantidade;Valor\n"
                       "1;Valvula 3/4;Utilidades;10;1.200,00\n"
                       "2;Manometro;Utilidades;4;300,50\n"
                       "3;Bomba;Processo;2;5.000,00\n")},
      1,
      [("stdout", "re:linhas pareadas:\\s+3", True),
       ("stdout", "re:celulas que nao batem:\\s+0", True),
       ("diferencas-de-formato.csv", "001", True)],
      ["--chave", "Codigo", "--chave-sem-zeros"])

rodar("gabarito: linha que sumiu no refeito derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": ("Codigo;Descricao;Setor;Quantidade;Valor\n"
                       "001;Valvula 3/4;Utilidades;10;1.200,00\n"
                       "002;Manometro;Utilidades;4;300,50\n")},
      5,
      [("so-no-entregue.csv", "so_no_entregue", True),
       ("so-no-entregue.csv", "Bomba", True),
       ("stdout", "FORA DA COMPARACAO", True)],
      ["--chave", "Codigo"])

rodar("gabarito: coluna fora da comparacao por --campos derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO, "refeito.csv": RELATORIO},
      5,
      [("stdout", "decisao declarada em --campos", True),
       ("stdout", "Setor", True),
       ("nota-do-refazer.md", "sobrou dado fora da comparacao", True)],
      ["--chave", "Codigo",
       "--campos", "Codigo:Codigo,Descricao:Descricao,"
                   "Quantidade:Quantidade,Valor:Valor"])

rodar("gabarito: coluna comparada vazia dos dois lados derruba o 0",
      "gabarito",
      {"entregue.csv": ("Codigo;Descricao;Observacao;Valor\n"
                        "001;Valvula 3/4;;1.200,00\n"
                        "002;Manometro;;300,50\n"
                        "003;Bomba;;5.000,00\n"),
       "refeito.csv": ("Codigo;Descricao;Observacao;Valor\n"
                       "001;Valvula 3/4;;1.200,00\n"
                       "002;Manometro;;300,50\n"
                       "003;Bomba;;5.000,00\n")},
      5,
      [("stdout", "vazia dos dois lados", True),
       ("stdout", "Observacao", True)],
      ["--chave", "Codigo"])

rodar("gabarito: linha com conteudo perdida na leitura derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO + "004;Motor;Processo\n",
       "refeito.csv": RELATORIO},
      5,
      [("linhas-nao-lidas.csv", "perdida", True),
       ("linhas-nao-lidas.csv",
        "contagem_de_colunas_diferente_do_cabecalho", True),
       ("stdout", "perdida", True)],
      ["--chave", "Codigo"])

rodar("gabarito: rodape de identificacao do sistema nao derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO + "Emitido em 01/10/2026 pelo usuario\n",
       "refeito.csv": RELATORIO},
      0,
      [("linhas-nao-lidas.csv", "reconhecida", True),
       ("linhas-nao-lidas.csv", "Emitido em", True),
       ("stdout", "DECISAO DECLARADA", True),
       ("nota-do-refazer.md",
        "status: bateu celula a celula, dentro das decisoes declaradas", True)],
      ["--chave", "Codigo"])

rodar("gabarito: o rodape que este kit grava no refeito nao derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": RELATORIO + "# Gerado com apoio de IA a partir de "
                                  "bruto.csv. Revisar antes de assinar. Nao "
                                  "substitui responsabilidade tecnica.\n"},
      0,
      [("linhas-nao-lidas.csv", "rodape_do_kit", True),
       ("nota-do-refazer.md", "rodape deste kit", True)],
      ["--chave", "Codigo"])

rodar("gabarito: linha ignorada em --ignorar-linha sai contada e nao derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO + "Emitido em 01/10/2026 pelo usuario\n",
       "refeito.csv": RELATORIO},
      0,
      [("stdout", "DECISAO DECLARADA", True),
       ("linhas-nao-lidas.csv", "declarada", True)],
      ["--chave", "Codigo", "--ignorar-linha", "Emitido em"])

rodar("gabarito: celula igualada pela tolerancia declarada nao derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": ("Codigo;Descricao;Setor;Quantidade;Valor\n"
                       "001;Valvula 3/4;Utilidades;10;1.200,01\n"
                       "002;Manometro;Utilidades;4;300,50\n"
                       "003;Bomba;Processo;2;5.000,00\n")},
      0,
      [("stdout", "tolerancia declarada de 0.01", True),
       ("nota-do-refazer.md",
        "status: bateu celula a celula, dentro das decisoes declaradas", True)],
      ["--chave", "Codigo", "--tolerancia", "0.01"])


# ------------------------------- gabarito: a camada de blocos e totais compara

rodar("gabarito: linha de total com a chave vazia pareia pelo rotulo",
      "gabarito",
      {"entregue.csv": COM_TOTAL, "refeito.csv": COM_TOTAL},
      0,
      [("stdout", "re:linhas de total pareadas por rotulo: 3", True),
       ("stdout", "re:celulas comparadas:\\s+30", True),
       ("nota-do-refazer.md", "status: bateu celula a celula", True),
       ("so-no-entregue.csv", "TOTAL", False)],
      ["--chave", "Codigo"])

rodar("gabarito: a linha de total pareada por rotulo compara celula a celula",
      "gabarito",
      {"entregue.csv": COM_TOTAL,
       "refeito.csv": COM_TOTAL.replace(";TOTAL GERAL;;8.300,50",
                                        ";TOTAL GERAL;;8.300,60")},
      1,
      [("celulas-que-nao-batem.csv", "8.300,60", True),
       ("stdout", "re:celulas que nao batem:\\s+1", True)],
      ["--chave", "Codigo"])

rodar("gabarito: rotulo de total sem par nao pareia na marra",
      "gabarito",
      {"entregue.csv": COM_TOTAL,
       "refeito.csv": COM_TOTAL.replace("TOTAL UTILIDADES", "SOMA UTILIDADES")},
      5,
      [("so-no-entregue.csv", "chave_vazia_sem_rotulo_par_no_refeito", True),
       ("so-no-refeito.csv", "chave_vazia_sem_rotulo_par_no_entregue", True)],
      ["--chave", "Codigo"])

rodar("gabarito: cabecalho com nome de coluna repetido nao perde linha de dado",
      "gabarito",
      {"entregue.csv": DUPLICADO, "refeito.csv": DUPLICADO},
      0,
      [("stdout", "re:entregue: .*, 4 registros", True),
       ("stdout", "re:celulas comparadas:\\s+16", True)],
      ["--chave", "Item"])

rodar("gabarito: diferenca so de formato nao e igualdade",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": ("Codigo;Descricao;Setor;Quantidade;Valor\n"
                       "001;Valvula 3/4;Utilidades;10;1200\n"
                       "002;Manometro;Utilidades;4;300,50\n"
                       "003;Bomba;Processo;2;5.000,00\n")},
      1,
      [("diferencas-de-formato.csv", "1200", True),
       ("stdout", "re:diferenca so de formato:\\s+1", True),
       ("stdout", "re:celulas que nao batem:\\s+0", True)],
      ["--chave", "Codigo"])

rodar("gabarito: duplicata divergente fica fora do pareamento e derruba o 0",
      "gabarito",
      {"entregue.csv": RELATORIO + "003;Bomba reserva;Processo;2;7.000,00\n",
       "refeito.csv": RELATORIO},
      5,
      [("so-no-entregue.csv", "duplicata_divergente", True),
       ("so-no-refeito.csv", "duplicata_divergente_no_outro_lado", True)],
      ["--chave", "Codigo"])

rodar("gabarito: as partes do fechamento sao contadas no laco, nao subtraidas",
      "gabarito",
      {"entregue.csv": ("Codigo;Descricao;Setor;Quantidade;Valor;Observacao\n"
                        "001;Valvula 3/4;Utilidades;10;1.200,00;conferido\n"
                        "002;Manometro;Utilidades;4;300,50;conferido\n"
                        "003;Bomba;Processo;2;5.000,00;conferido\n"),
       "refeito.csv": ("Codigo;Descricao;Setor;Quantidade;Valor\n"
                       "001;Valvula 3/4;Utilidades;10;1.200,00\n"
                       "002;Manometro;Utilidades;4;300,50\n")},
      5,
      [("nota-do-refazer.md",
        "celulas_do_entregue = comparadas + so_no_entregue: 18 contra 18, fecha",
        True),
       ("nota-do-refazer.md",
        "celulas_do_refeito = comparadas + so_no_refeito: 10 contra 10, fecha",
        True),
       ("nota-do-refazer.md", "NAO FECHA", False)],
      ["--chave", "Codigo",
       "--campos", "Codigo:Codigo,Descricao:Descricao,Setor:Setor,"
                   "Quantidade:Quantidade,Valor:Valor"])

rodar("gabarito: --por-posicao com contagens diferentes nao pareia na marra",
      "gabarito",
      {"entregue.csv": RELATORIO,
       "refeito.csv": ("Codigo;Descricao;Setor;Quantidade;Valor\n"
                       "001;Valvula 3/4;Utilidades;10;1.200,00\n"
                       "002;Manometro;Utilidades;4;300,50\n")},
      3,
      [("stderr", "desalinha", True)],
      ["--por-posicao"])

rodar("gabarito: a mesma coluna em dois pares de --campos e recusada",
      "gabarito",
      {"entregue.csv": RELATORIO, "refeito.csv": RELATORIO},
      3,
      [("stderr", "mais de um par", True)],
      ["--chave", "Codigo",
       "--campos", "Codigo:Codigo,Descricao:Descricao,Descricao:Setor"])


# ------------------------------------------------------------ modo estrutura

rodar("estrutura: dois arquivos identicos saem com 0",
      "estrutura",
      {"anterior.csv": BLOCOS, "atual.csv": BLOCOS},
      0,
      [("mudancas-de-estrutura.md", "nenhuma mudanca de estrutura", True)])

rodar("estrutura: coluna que sumiu e coluna nova",
      "estrutura",
      {"anterior.csv": ("Codigo;Descricao;Setor;Valor\n"
                        "001;Valvula;Utilidades;100\n"
                        "002;Manometro;Utilidades;200\n"
                        "003;Bomba;Processo;300\n"
                        "004;Motor;Processo;400\n"),
       "atual.csv": ("Codigo;Descricao;Centro de Custo;Valor\n"
                     "001;Valvula;4110;100\n"
                     "002;Manometro;4110;200\n"
                     "003;Bomba;4220;300\n"
                     "004;Motor;4220;400\n")},
      1,
      [("mudancas-de-estrutura.csv", "coluna_sumiu", True),
       ("mudancas-de-estrutura.csv", "coluna_nova", True),
       ("mudancas-de-estrutura.csv", "Centro de Custo", True)])

rodar("estrutura: linha de total que mudou de lugar",
      "estrutura",
      {"anterior.csv": ("Setor;Item;Valor\n"
                        "Utilidades;Valvula;100\n"
                        "Utilidades;Manometro;200\n"
                        "Processo;Bomba;300\n"
                        "TOTAL GERAL;;600\n"),
       "atual.csv": ("Setor;Item;Valor\n"
                     "Utilidades;Valvula;100\n"
                     "Utilidades;Manometro;200\n"
                     "TOTAL Utilidades;;300\n"
                     "Processo;Bomba;300\n"
                     "TOTAL Processo;;300\n")},
      1,
      [("mudancas-de-estrutura.csv", "total_mudou_de_lugar", True)])

rodar("estrutura: criterio de agrupamento diferente com as mesmas colunas",
      "estrutura",
      {"anterior.csv": BLOCOS,
       "atual.csv": ("Setor;Item;Valor\n"
                     "Utilidades;Valvula;100\n"
                     ";Manometro;200\n"
                     "Processo;Bomba;300\n"
                     ";Motor;400\n")},
      1,
      [("mudancas-de-estrutura.csv", "agrupamento", True)])

rodar("estrutura: coluna que ficou vazia com o cabecalho intacto",
      "estrutura",
      {"anterior.csv": ("Codigo;Descricao;Setor;Valor\n"
                        "001;Valvula;Utilidades;100\n"
                        "002;Manometro;Utilidades;200\n"
                        "003;Bomba;Processo;300\n"
                        "004;Motor;Processo;400\n"),
       "atual.csv": ("Codigo;Descricao;Setor;Valor\n"
                     "001;Valvula;;100\n"
                     "002;Manometro;;200\n"
                     "003;Bomba;;300\n"
                     "004;Motor;;400\n")},
      1,
      [("mudancas-de-estrutura.csv", "coluna_ficou_vazia", True)])

rodar("estrutura: coluna que mudou de formato de data",
      "estrutura",
      {"anterior.csv": ("Codigo;Descricao;Data;Valor\n"
                        "001;Valvula;01/02/2026;100\n"
                        "002;Manometro;02/02/2026;200\n"
                        "003;Bomba;03/02/2026;300\n"
                        "004;Motor;04/02/2026;400\n"),
       "atual.csv": ("Codigo;Descricao;Data;Valor\n"
                     "001;Valvula;2026-02-01;100\n"
                     "002;Manometro;2026-02-02;200\n"
                     "003;Bomba;2026-02-03;300\n"
                     "004;Motor;2026-02-04;400\n")},
      1,
      [("mudancas-de-estrutura.csv", "coluna_mudou_de_formato", True),
       ("mudancas-de-estrutura.csv", "data_dmy", True)])

rodar("estrutura: delimitador nao detectado nao pode virar estrutura igual",
      "estrutura",
      {"anterior.csv": ("Relatorio de producao do mes\n"
                        "Linha um sem separador nenhum\n"
                        "Linha dois sem separador nenhum\n"),
       "atual.csv": BLOCOS},
      3,
      [("stderr", "delimitador", True)])

rodar("estrutura: arquivo com cabecalho e nenhum registro nao pode sair 0",
      "estrutura",
      {"anterior.csv": "Setor;Item;Valor\n", "atual.csv": BLOCOS},
      3,
      [("stderr", "nenhum registro lido", True)])

rodar("estrutura: linha com conteudo perdida na leitura derruba o 0",
      "estrutura",
      {"anterior.csv": BLOCOS + "Processo;Motor\n", "atual.csv": BLOCOS},
      5,
      [("linhas-nao-lidas.csv", "perdida", True),
       ("stdout", "re:linhas perdidas, sem causa reconhecida: 1", True)])

rodar("estrutura: rodape de identificacao do sistema nao derruba o 0",
      "estrutura",
      {"anterior.csv": BLOCOS + "Emitido em 01/10/2026 pelo usuario\n",
       "atual.csv": BLOCOS},
      0,
      [("linhas-nao-lidas.csv", "reconhecida", True),
       ("linhas-nao-lidas.csv", "Emitido em", True),
       ("stdout", "DECISAO DECLARADA", True)])

rodar("estrutura: linha excluida por --ignorar-linha sai contada e nao derruba "
      "o 0",
      "estrutura",
      {"anterior.csv": BLOCOS + "Emitido em 01/10/2026 pelo usuario\n",
       "atual.csv": BLOCOS},
      0,
      [("stdout", "ignorada(s) por decisao declarada", True),
       ("linhas-nao-lidas.csv", "declarada", True)],
      ["--ignorar-linha", "Emitido em"])

rodar("estrutura: linha de dado acima do cabecalho eleito e registrada",
      "estrutura",
      {"anterior.csv": ("Utilidades;Valvula esfera;120\n" + BLOCOS),
       "atual.csv": ("Utilidades;Valvula esfera;120\n" + BLOCOS)},
      5,
      [("linhas-nao-lidas.csv",
        "acima_do_cabecalho_com_a_largura_da_tabela", True),
       ("linhas-nao-lidas.csv", "Valvula esfera", True),
       ("perfil-anterior.txt", "linha do cabecalho: 2", True)])

rodar("estrutura: nome de coluna repetido no cabecalho sai como mudanca",
      "estrutura",
      {"anterior.csv": BLOCOS.replace("Setor;Item;Valor", "Setor;Item;Valor"),
       "atual.csv": BLOCOS.replace("Setor;Item;Valor", "Setor;Item;Item")},
      1,
      [("mudancas-de-estrutura.csv",
        "nome_de_coluna_repetido_no_cabecalho", True),
       ("mudancas-de-estrutura.csv", "Item#2", True)])

rodar("estrutura: coluna que passou a vir vazia em parte das linhas e mudanca",
      "estrutura",
      {"anterior.csv": ("Setor;Item;Refugo\n"
                        "Utilidades;Valvula;3\n"
                        "Utilidades;Manometro;1\n"
                        "Utilidades;Bomba;2\n"
                        "Processo;Motor;4\n"
                        "Processo;Redutor;1\n"
                        "Processo;Painel;2\n"),
       "atual.csv": ("Setor;Item;Refugo\n"
                     "Utilidades;Valvula;3\n"
                     "Utilidades;Manometro;\n"
                     "Utilidades;Bomba;\n"
                     "Processo;Motor;4\n"
                     "Processo;Redutor;\n"
                     "Processo;Painel;\n")},
      1,
      [("mudancas-de-estrutura.csv", "coluna_perdeu_preenchimento", True),
       ("mudancas-de-estrutura.csv", "2/6 preenchidas", True)])

rodar("estrutura: queda pequena de preenchimento nao enche a lista de ruido",
      "estrutura",
      {"anterior.csv": ("Setor;Item;Refugo\n"
                        "Utilidades;Valvula;3\n"
                        "Utilidades;Manometro;1\n"
                        "Utilidades;Bomba;2\n"
                        "Processo;Motor;4\n"
                        "Processo;Redutor;1\n"
                        "Processo;Painel;2\n"),
       "atual.csv": ("Setor;Item;Refugo\n"
                     "Utilidades;Valvula;3\n"
                     "Utilidades;Manometro;1\n"
                     "Utilidades;Bomba;2\n"
                     "Processo;Motor;4\n"
                     "Processo;Redutor;1\n"
                     "Processo;Painel;\n")},
      0,
      [("mudancas-de-estrutura.md", "nenhuma mudanca de estrutura", True),
       ("mudancas-de-estrutura.csv", "coluna_perdeu_preenchimento", False)])

rodar("estrutura: percentual na linha de total nao entra no rotulo do bloco",
      "estrutura",
      {"anterior.csv": COM_TOTAL, "atual.csv": COM_TOTAL_OUTRO_MES},
      0,
      [("mudancas-de-estrutura.md", "nenhuma mudanca de estrutura", True),
       ("mudancas-de-estrutura.csv", "rotulos_de_total_mudaram", False)])




# --------------------------------------------------------- montagem, montar.py

ESPERADO = (
    "Setor;Item;Apontamentos;Produzidas;Valor;Aproveitamento\n"
    "Processo;Bomba;2;12;6.000,00;91,7%\n"
    ";TOTAL Processo;2;12;6.000,00;91,7%\n"
    "Utilidades;Valvula esfera;2;200;2.000,00;98,5%\n"
    "Utilidades;Manometro;1;40;300,50;95,0%\n"
    ";TOTAL Utilidades;3;240;2.300,50;97,9%\n"
    ";TOTAL GERAL;5;252;8.300,50;97,6%\n"
)

rodar_montar("montar: agrupa, soma, ordena, formata e posiciona os totais",
             {"bruto.csv": BRUTO_DE_MONTAGEM}, RECEITA, 0,
             [("relatorio", ";TOTAL Utilidades;3;240;2.300,50;97,9%", True),
              ("relatorio", ";TOTAL GERAL;5;252;8.300,50;97,6%", True),
              ("relatorio", "Utilidades;Valvula esfera;2;200;2.000,00;98,5%",
               True),
              ("stdout", "re:linhas \\(3 de grupo, 3 de total\\)", True)])

rodar_montar("montar: a soma escrita no relatorio e a soma lida no bruto",
             {"bruto.csv": BRUTO_DE_MONTAGEM}, RECEITA, 0,
             [("stdout", "re:soma de Valor lida no bruto.*fecha", True),
              ("stdout", "re:soma de Produzidas lida no bruto.*fecha", True),
              ("stdout", "NAO FECHA", False),
              ("nota", "NAO FECHA", False)])

rodar_montar("montar: linha filtrada por regra da receita sai nomeada no rastro",
             {"bruto.csv": BRUTO_DE_MONTAGEM}, RECEITA, 0,
             [("fora", "fora_do_filtro_declarado_na_receita", True),
              ("fora", "Motor", True),
              ("fora", "rodape_de_sistema", True),
              ("fora", "titulo_ou_filtro_acima_do_cabecalho", True),
              ("stdout", "re:filtradas por regra da receita:   1", True)])

rodar_montar("montar: linha perdida na leitura derruba o 0 da montagem",
             {"bruto.csv": BRUTO_DE_MONTAGEM + "Processo;Motor;5\n"},
             RECEITA, 5,
             [("fora", "perdida", True),
              ("stdout", "LINHA PERDIDA", True)])

rodar_montar("montar: lacuna na receita para a montagem",
             {"bruto.csv": BRUTO_DE_MONTAGEM},
             RECEITA.replace(
                 '{"nome": "Apontamentos", "regra": "contagem", '
                 '"formato": "inteiro"}',
                 '{"nome": "Observacao", "regra": "lacuna", '
                 '"formato": "texto"}'),
             3,
             [("stderr", "lacuna declarada", True),
              ("relatorio", "Observacao", False)])

rodar_montar("montar: coluna da receita que nao existe no bruto para a montagem",
             {"bruto.csv": BRUTO_DE_MONTAGEM},
             RECEITA.replace('"vem_de": "Produzidas"', '"vem_de": "Qtde"'),
             3,
             [("stderr", "nao existe em", True),
              ("stderr", "modo estrutura", True)])

rodar_montar("montar: valor diferente dentro do grupo nao escolhe um em silencio",
             {"bruto.csv": BRUTO_DE_MONTAGEM.replace(
                 "Processo;Bomba;2;2;1.000,00;Fechado",
                 "Processo;Bomba;2;2;1.000,00;Aberto")},
             RECEITA.replace(
                 '{"nome": "Apontamentos", "regra": "contagem", '
                 '"formato": "inteiro"}',
                 '{"nome": "Status", "regra": "unico", "vem_de": "Status", '
                 '"formato": "texto"}').replace(
                 '"filtro_de_linha": [{"coluna": "Status", '
                 '"manter": ["Fechado"]}],', ''),
             3,
             [("stderr", "receita nao descreve", True),
              ("fora", "valor_diferente_dentro_do_grupo", True)])

rodar_montar("montar: celula nao numerica em coluna de soma para a montagem",
             {"bruto.csv": BRUTO_DE_MONTAGEM.replace(
                 "Processo;Bomba;10;9;5.000,00;Fechado",
                 "Processo;Bomba;dez;9;5.000,00;Fechado")},
             RECEITA, 3,
             [("fora", "celula_nao_numerica_em_coluna_de_soma", True),
              ("stderr", "receita nao descreve", True)])

# Celula VAZIA em coluna de soma. O caso que saia com codigo 0: o vazio virava
# 0,00 no relatorio entregue, sem linha no rastro e sem mencao na nota, e a
# identidade da soma fechava porque leitura e escrita aplicavam a mesma
# suposicao. A exposicao real esta no mes corrente, quando o gabarito ja passou.
BRUTO_COM_VAZIO = BRUTO_DE_MONTAGEM.replace(
    "Utilidades;Manometro;40;38;300,50;Fechado",
    "Utilidades;Manometro;40;38;;Fechado")

rodar_montar("montar: celula vazia em coluna de soma nao vira zero",
             {"bruto.csv": BRUTO_COM_VAZIO}, RECEITA, 3,
             [("fora", "celula_vazia_em_coluna_de_soma", True),
              ("fora", "Manometro", True),
              ("stdout", "re:celulas vazias em coluna de soma: 1", True),
              ("stdout", "PROBLEMA: celula_vazia_em_coluna_de_soma", True),
              ("nota", "celulas vazias em coluna de soma: 1", True),
              ("stderr", "vazio nao e zero", True),
              ("relatorio", "Utilidades;Manometro;1;40;0,00", False)])

rodar_montar("montar: a identidade da soma nao fecha tratando vazio como zero",
             {"bruto.csv": BRUTO_COM_VAZIO}, RECEITA, 3,
             [("stdout", "celula(s) sem valor", True),
              ("stdout", "NAO FECHA", True),
              ("nota", "NAO FECHA", True),
              ("stderr", "nao fecha", True)])

rodar_montar("montar: o censo poe cada celula de coluna de soma num balde",
             {"bruto.csv": BRUTO_COM_VAZIO}, RECEITA, 3,
             [("stdout",
               "re:celulas de Valor lidas = somadas \\+ vazias \\+ nao "
               "numericas\\s+5\\s+5\\s+fecha", True),
              ("nota", "celulas de Produzidas lidas = somadas + vazias + nao "
                       "numericas: 5 contra 5, fecha", True)])

# Coluna nova no bruto que a receita nao cobre. Saia com codigo 0 sem citar a
# coluna em lugar nenhum, e quem pulasse o modo estrutura perdia a coluna nova
# em silencio.
BRUTO_COM_COLUNA_NOVA = (
    "Relatorio de producao por setor\n"
    "Periodo: 01/08/2026 a 31/08/2026\n"
    "Setor;Item;Produzidas;Boas;Valor;Status;Centro de custo\n"
    "Utilidades;Valvula esfera;120;117;1.200,00;Fechado;4110\n"
    "Utilidades;Valvula esfera;80;80;800,00;Fechado;4110\n"
    "Utilidades;Manometro;40;38;300,50;Fechado;4110\n"
    "Processo;Bomba;10;9;5.000,00;Fechado;4220\n"
    "Processo;Motor;5;5;2.500,00;Aberto;4220\n"
    "Processo;Bomba;2;2;1.000,00;Fechado;4220\n"
    "Emitido em 01/09/2026 pelo usuario PCP\n")

rodar_montar("montar: coluna do bruto que a receita nao cobre sai nomeada",
             {"bruto.csv": BRUTO_COM_COLUNA_NOVA}, RECEITA, 5,
             [("stdout",
               "COLUNA DO BRUTO QUE A RECEITA NAO LE: Centro de custo", True),
              ("fora", "coluna_do_bruto_que_a_receita_nao_cobre", True),
              ("nota", "colunas do bruto que a receita nao le: 1", True),
              ("nota", "re:## O que a receita nao cobre(.|\\n)*Centro de custo",
               True)])

rodar_montar("montar: coluna declarada em nao_coberto nao derruba o 0",
             {"bruto.csv": BRUTO_COM_COLUNA_NOVA},
             RECEITA.replace('"nao_coberto": ["comentario do mes"]',
                             '"nao_coberto": ["comentario do mes",\n'
                             '    "Centro de custo: continua so no ERP"]'),
             0,
             [("stdout",
               "COLUNA DO BRUTO QUE A RECEITA NAO LE: Centro de custo", True),
              ("stdout", "declarada em nao_coberto", True),
              ("fora", "coluna_do_bruto_declarada_em_nao_coberto", True),
              ("nota", "re:## O que a receita nao cobre(.|\\n)*Centro de custo",
               True)])

rodar_montar("montar: campo desconhecido na receita para a montagem",
             {"bruto.csv": BRUTO_DE_MONTAGEM},
             RECEITA.replace('"relatorio": "Producao por setor",',
                             '"relatorio": "Producao por setor",\n'
                             '  "agrupa_por": ["Setor"],'),
             3,
             [("stderr", "campo desconhecido na receita", True)])

rodar_montar("montar: ordem que separa o bloco em dois pedacos para a montagem",
             {"bruto.csv": ("Setor;Item;Produzidas;Boas;Valor;Status\n"
                            "Utilidades;Valvula;100;100;5.000,00;Fechado\n"
                            "Processo;Bomba;100;100;3.000,00;Fechado\n"
                            "Utilidades;Manometro;100;100;1.000,00;Fechado\n")},
             RECEITA.replace(
                 '"ordem": [{"coluna": "Setor", "sentido": "crescente"},\n'
                 '            {"coluna": "Valor", "sentido": "decrescente"}],',
                 '"ordem": [{"coluna": "Valor", "sentido": "decrescente"}],'),
             3,
             [("stderr", "dois pedacos separados", True)])

rodar_montar("montar: consolidar sem coluna de origem declarada para a montagem",
             {"bruto.csv": BRUTO_DE_MONTAGEM,
              "bruto2.csv": BRUTO_DE_MONTAGEM}, RECEITA, 3,
             [("stderr", "nenhuma coluna de origem declarada", True)],
             brutos=("bruto.csv", "bruto2.csv"))

rodar_montar("montar: consolidar um arquivo por area empilha com a origem",
             {"bruto.csv": BRUTO_DE_MONTAGEM,
              "bruto2.csv": BRUTO_DE_MONTAGEM.replace("Utilidades", "Caldeira")},
             RECEITA.replace(
                 '"agrupar_por": ["Setor", "Item"],',
                 '"empilhar": {"coluna_de_origem": "Area",\n'
                 '    "origem_por_arquivo": {"bruto.csv": "Planta 1",\n'
                 '                           "bruto2.csv": "Planta 2"}},\n'
                 '  "agrupar_por": ["Area", "Setor", "Item"],').replace(
                 '{"nome": "Setor", "regra": "agrupamento", "vem_de": "Setor",\n'
                 '     "formato": "texto"},',
                 '{"nome": "Area", "regra": "agrupamento", "vem_de": "Area",\n'
                 '     "formato": "texto"},\n'
                 '    {"nome": "Setor", "regra": "agrupamento", '
                 '"vem_de": "Setor",\n     "formato": "texto"},').replace(
                 '"por_bloco": {"coluna": "Setor"',
                 '"por_bloco": {"coluna": "Area"').replace(
                 '"ordem": [{"coluna": "Setor", "sentido": "crescente"},',
                 '"ordem": [{"coluna": "Area", "sentido": "crescente"},\n'
                 '            {"coluna": "Setor", "sentido": "crescente"},'),
             0,
             [("relatorio", "Planta 1", True),
              ("relatorio", "Planta 2", True),
              ("relatorio", "TOTAL Planta 2", True),
              ("stdout", "re:registros lidos no bruto:         12", True)],
             brutos=("bruto.csv", "bruto2.csv"))

rodar_montar("montar: cabecalho diferente entre os arquivos empilhados para",
             {"bruto.csv": BRUTO_DE_MONTAGEM,
              "bruto2.csv": BRUTO_DE_MONTAGEM.replace(
                  "Setor;Item;Produzidas;Boas;Valor;Status",
                  "Setor;Item;Boas;Produzidas;Valor;Status")},
             RECEITA.replace(
                 '"agrupar_por": ["Setor", "Item"],',
                 '"empilhar": {"coluna_de_origem": "Area",\n'
                 '    "origem_por_arquivo": {"bruto.csv": "Planta 1",\n'
                 '                           "bruto2.csv": "Planta 2"}},\n'
                 '  "agrupar_por": ["Setor", "Item"],'),
             3,
             [("stderr", "nao e o mesmo de", True)],
             brutos=("bruto.csv", "bruto2.csv"))


# ------------------------------------------- o ciclo inteiro, que e o produto

def rodar_ciclo():
    """Monta o mes fechado pela receita e confere contra o aprovado.

    E o unico caso que mede o que a skill promete: a montagem sai do script, e a
    conferencia diz que ela reproduz o relatorio que foi entregue e aceito.
    """
    erros = []
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        (base / "bruto-2026-07.csv").write_text(BRUTO_DE_MONTAGEM,
                                                encoding="utf-8")
        (base / "receita.json").write_text(RECEITA, encoding="utf-8")
        (base / "relatorio-2026-07.csv").write_text(ESPERADO, encoding="utf-8")
        montagem = subprocess.run(
            [sys.executable, str(MONTAR), "--receita", str(base / "receita.json"),
             "--bruto", str(base / "bruto-2026-07.csv"),
             "--saida", str(base / "refeito-2026-07.csv")],
            capture_output=True, text=True)
        if montagem.returncode != 0:
            erros.append("a montagem saiu com %d: %s"
                         % (montagem.returncode, montagem.stderr.strip()[:300]))
        gabarito = subprocess.run(
            [sys.executable, str(CONFERIR), "--modo", "gabarito",
             "--entregue", str(base / "relatorio-2026-07.csv"),
             "--refeito", str(base / "refeito-2026-07.csv"),
             "--chave", "Item", "--saida", str(base / "g")],
            capture_output=True, text=True)
        if gabarito.returncode != 0:
            erros.append("o gabarito saiu com %d, esperado 0: %s\n%s"
                         % (gabarito.returncode, gabarito.stderr.strip()[:300],
                            gabarito.stdout[-800:]))
        nota = base / "g" / "nota-do-refazer.md"
        if nota.exists():
            conteudo = nota.read_text(encoding="utf-8")
            if "status: bateu celula a celula" not in conteudo:
                erros.append("a nota nao diz que bateu celula a celula")
            if "linhas de total pareadas pelo rotulo" not in conteudo:
                erros.append("a nota nao conta a linha de total pareada por "
                             "rotulo")
        else:
            erros.append("a nota do refazer nao foi gravada")
    registrar("ciclo: o que o script monta bate celula a celula com o aprovado",
              erros)


rodar_ciclo()


# -------------------------------------------------- coerencia com o SKILL.md

def conferir_skill():
    erros = []
    if not SKILL.exists():
        registrar("SKILL.md coerente com o script", ["SKILL.md nao encontrado"])
        return
    texto = SKILL.read_text(encoding="utf-8")
    codigo = CONFERIR.read_text(encoding="utf-8")
    codigo_montar = MONTAR.read_text(encoding="utf-8")

    # name do frontmatter igual ao nome da pasta, senao a skill nao carrega
    nome = re.search(r"^name:\s*(\S+)", texto, re.M)
    if not nome:
        erros.append("SKILL.md nao tem name no frontmatter")
    elif nome.group(1) != SKILL.parent.name:
        erros.append("o name do frontmatter e %r e a pasta e %r"
                     % (nome.group(1), SKILL.parent.name))

    # description dentro do limite. Acima de 1.400 caracteres ela e cortada, e o
    # que se perde e sempre o fim, onde ficam os NAO use.
    bloco = re.search(r"^description: >\n((?:  .*\n)+)", texto, re.M)
    if not bloco:
        erros.append("SKILL.md nao tem description em bloco no frontmatter")
    else:
        corrida = " ".join(l.strip() for l in bloco.group(1).splitlines())
        if len(corrida) > 1400:
            erros.append("a description tem %d caracteres, o limite e 1.400"
                         % len(corrida))
        for gatilho in ("painel",):
            if gatilho not in corrida:
                erros.append("a description nao tem gatilho com %r" % gatilho)

    # cada string de status que o script grava aparece literalmente na pagina
    escritos = sorted(set(re.findall(r'status = "([^"]+)"', codigo)))
    if len(escritos) < 4:
        erros.append("o script grava %d status, esperava ao menos 4"
                     % len(escritos))
    for status in escritos + ["incompleto"]:
        if status not in texto:
            erros.append("SKILL.md nao traz o status %r que o script grava"
                         % status)

    for trecho in ("~/.claude/skills/relatorio-recorrente/scripts/conferir.py",
                   "~/.claude/skills/relatorio-recorrente/scripts/montar.py",
                   "~/.claude/skills/relatorio-recorrente/scripts/testar.py",
                   "~/.kit-industrial/ficha-da-area.md",
                   "receita.json",
                   "--forcar",
                   "rodando sem ficha da área",
                   "Revisar antes de assinar",
                   "py -3"):
        if trecho not in texto:
            erros.append("SKILL.md nao menciona %r" % trecho)

    for codigo_saida in ("| 0 |", "| 1 |", "| 3 |", "| 5 |"):
        if codigo_saida not in texto:
            erros.append("SKILL.md nao documenta o codigo de saida %s"
                         % codigo_saida.strip("| "))
    if "| 2 |" in texto or "| 4 |" in texto:
        erros.append("SKILL.md documenta codigo de saida que o script nao emite")

    for vizinha in ("conferencia-entre-duas-fontes",
                    "extracao-de-documento-para-tabela",
                    "triagem-de-caixa-de-email", "comparativo-de-cotacoes",
                    "ficha-da-area", "relatorio-recorrente",
                    "registro-de-anomalia", "padrao-conferido-contra-norma",
                    "linha-de-base-antes-de-automatizar",
                    "indice-do-acervo-da-area"):
        if vizinha not in texto:
            erros.append("SKILL.md nao cita a skill vizinha %s" % vizinha)

    for proibido in ("—", "–"):
        if proibido in texto:
            erros.append("SKILL.md contem travessao ou meia-risca")
        if proibido in codigo:
            erros.append("conferir.py contem travessao ou meia-risca")
        if proibido in codigo_montar:
            erros.append("montar.py contem travessao ou meia-risca")
        for ref in sorted((SKILL.parent / "references").glob("*")):
            if proibido in ref.read_text(encoding="utf-8"):
                erros.append("%s contem travessao ou meia-risca" % ref.name)

    # a receita de exemplo tem que ser a receita que o script aceita
    if not RECEITA_EXEMPLO.exists():
        erros.append("falta references/receita-exemplo.json")
    else:
        import json as _json
        try:
            exemplo = _json.loads(RECEITA_EXEMPLO.read_text(encoding="utf-8"))
        except ValueError as erro_json:
            erros.append("receita-exemplo.json nao e JSON valido: %s"
                         % erro_json)
            exemplo = None
        if exemplo is not None:
            campos = set(re.findall(r'"(\w+)"',
                                    re.search(r"CHAVES_DA_RECEITA = \(([^)]*)\)",
                                              codigo_montar).group(1)))
            for chave in exemplo:
                if chave not in campos:
                    erros.append("receita-exemplo.json usa o campo %r, que o "
                                 "montar.py nao aceita" % chave)

    registrar("SKILL.md coerente com o script", erros)


conferir_skill()


# ----------------------------------------------------------------- resultado

print("")
if falhas:
    print("%d caso(s) falharam." % len(falhas))
    sys.exit(1)
print("Todos os casos passaram.")
sys.exit(0)
