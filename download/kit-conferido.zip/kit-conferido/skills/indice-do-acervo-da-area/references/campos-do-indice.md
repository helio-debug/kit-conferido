# Os cinco campos do índice, e as armadilhas de cada um

Leia antes de preencher a primeira linha. Cada campo tem uma regra de
preenchimento, uma regra de recusa e o erro típico que ele produz quando a
regra de recusa é ignorada.

A regra que vale para os cinco: **campo sem apuração se escreve
`nao apurado`, nunca em branco e nunca por inferência.** Campo em branco é
lido como "não tem", e "não tem" é uma afirmação que ninguém fez.

---

## 1. Caminho

**O que é.** O caminho do arquivo dentro da pasta varrida, relativo à raiz,
com barra normal. É o único campo obrigatório em toda linha, e é o que faz o
índice ser índice.

**Regra de preenchimento.** Copiado do `inventario.csv`, tal como está.
Nunca redigitado.

**Regra de recusa.** Linha sem caminho não é linha de índice. O conferidor
derruba a rodada.

**Erro típico.** O índice sai bonito, a pessoa acha o documento na lista, e
não acha o arquivo. O índice vira um segundo documento a manter, que é
exatamente o contrário do que ele existe para fazer.

**Caminho absoluto.** Fica na coluna `caminho_absoluto` do inventário, e
nunca no lugar do relativo. Com `--raiz-como`, o absoluto sai como rótulo e o
relativo continua inteiro: é assim que o índice circula sem carregar o nome
do servidor, da pasta pessoal e do usuário. O rótulo entra também no texto dos
motivos, inclusive nos que vêm do erro do sistema operacional.

**No gabarito.** A coluna `caminho` do CSV do gabarito leva esse mesmo caminho
relativo, com barra normal, igual ao que está no `inventario.csv`. Caminho
absoluto e caminho com barra invertida não casam, e o conferidor derruba a
conferência dizendo isso.

---

## 2. Data do documento

**O que é.** A data que está escrita dentro do documento: data de emissão,
data de revisão, data da reunião, data de assinatura.

**Formato.** A coluna `data_do_documento` do índice sai em `aaaa-mm-dd`, sempre.
O CSV do gabarito pode vir em `aaaa-mm-dd`, `dd/mm/aaaa` ou `dd-mm-aaaa`: o
conferidor compara data com data, não texto com texto, e não reprova por
formatação.

**Regra de preenchimento.** Junto com a data vai a origem dela, na coluna
`origem_da_data`, com o lugar exato: `cabecalho do documento`,
`carimbo de revisao`, `assinatura na ultima pagina`, `nome do arquivo`,
`corpo do texto, primeira pagina`.

**Data apurada por máquina.** Rodando com `--extrair-texto`, a varredura acha a
primeira data do texto e grava, no `termos-por-documento.csv`, a data e a origem
`extraido por maquina do texto do arquivo`, com o padrão que casou. Essa data e
essa origem são copiadas para o índice tal como estão, inclusive nas linhas que
ninguém leu ainda. Abrindo o documento e achando data melhor, a data do documento
vale mais, e a origem passa a dizer onde ela estava. As outras datas do texto
ficam na coluna `datas_no_texto`, para a divergência aparecer em vez de ser
escolhida em silêncio.

**Regra de recusa.** A data de modificação do arquivo **não é** a data do
documento, e não entra nesta coluna em hipótese nenhuma. Ela fica na coluna
`modificado_em` do inventário, que é outra coisa.

**Erro típico, e ele é o mais frequente do acervo de pasta de rede.** A pasta
foi copiada de um servidor para outro, ou restaurada de backup, e todos os
arquivos ficaram com a data da cópia. O índice datado por essa coluna diz que
trezentos documentos são do mesmo dia. A varredura detecta a concentração e
avisa na cobertura, mas o aviso só serve se a regra for respeitada.

**Documento sem data escrita.** `nao apurado`, com a origem
`o documento nao traz data`. Estimar pelo assunto é inventar.

**Data no nome do arquivo.** Vale, e a origem é `nome do arquivo`. Ela é
fraca: quem renomeia copiando o nome do arquivo anterior propaga a data
errada. Havendo data no corpo e no nome, vale a do corpo, e a divergência
entra no resumo.

---

## 3. Assunto

**O que é.** Do que o documento trata, em três a oito palavras, no
vocabulário da casa. Sai da ficha da área quando ela existe.

**Regra de preenchimento.** É categoria, não título. O título do documento já
está no nome do arquivo, e repetir o nome do arquivo na coluna assunto gasta
uma coluna para não dizer nada.

**Regra de recusa.** Assunto não se deduz do nome da pasta. Documento dentro
de `Qualidade` pode ser um orçamento que alguém salvou no lugar errado, e o
índice existe justamente para revelar isso.

**Erro típico.** O índice reproduz a estrutura de pastas em forma de tabela.
Quem já sabia navegar na pasta não ganha nada, e quem não sabia continua sem
saber.

---

## 4. Entidades citadas

**O que é.** Os nomes próprios que aparecem **no texto**: equipamento, linha,
área, sistema, norma citada por número, código de item, número de ordem,
número de projeto, número de contrato, empresa.

**Regra de preenchimento.** Separadas por vírgula, como estão escritas no
documento. É este campo que faz o índice responder a pergunta real do acervo,
que nunca é "o que tem nessa pasta" e sim "onde está o documento que fala
daquele equipamento".

**Regra de recusa.** Entidade que não está no texto não entra. Nada de
deduzir o fornecedor pelo nome da pasta, o equipamento pelo nome do arquivo
ou o cliente pela subpasta. Documento sem texto apurado tem `nao apurado`, nunca
uma lista derivada do caminho.

**Entidade apurada por máquina.** Rodando com `--extrair-texto`, a varredura
casa o texto do documento com os códigos e as normas que a ficha da área declara,
e reconhece por padrão norma citada por número, código de item e número de ordem.
O resultado está na coluna `entidades_no_texto` do `termos-por-documento.csv` e é
copiado para o índice, inclusive nas linhas que ninguém leu. Isso não fere a regra
de recusa: o casamento é dentro do texto, nunca no nome da pasta nem no do arquivo.

**Pessoa física.** Nome de pessoa é uma das cinco classes de dado sensível.
Ele entra no índice apenas quando a pessoa que conduz a rodada disse que
entra, e na dúvida entra como cargo ou função, com o fato declarado na
cobertura.

**Norma.** Entra o número, e só o número. O índice não reproduz texto de
norma, e não descreve o requisito: ele diz que o documento cita a cláusula.
Quem precisa do requisito confere na edição vigente da sua empresa.

---

## 5. Resumo de uma linha

**O que é.** Uma frase que diz o que o documento decide, registra ou
prescreve. Uma linha, não um parágrafo.

**Regra de preenchimento.** A frase responde "por que alguém abriria este
arquivo". Um procedimento prescreve, uma ata decide, um relatório mede, uma
proposta oferece, um certificado atesta. Comece pelo verbo.

**Regra de recusa, e é a lei de ferro da skill.** Resumo de documento que a
rodada não leu é invenção. Documento não lido leva, no lugar do resumo, a
frase NAO LIDO: <motivo>, com o motivo que a varredura registrou. O
conferidor derruba a rodada quando encontra resumo escrito para documento com
status de falha.

**Os motivos, e o que fazer com cada um:**

| Motivo | O que fazer |
|---|---|
| `formato nao suportado` | Desenho de engenharia, pacote compactado, banco de dados, vídeo. Exporte para PDF, ou descompacte e varra de novo |
| `formato antigo de escritorio` | `.doc`, `.xls`, `.ppt` e `.msg`. Nenhuma ferramenta do kit abre. Salve como PDF ou no formato novo e rode de novo. É limite de ferramenta, não escolha de ninguém |
| `protegido por senha` | Quem tem a senha abre e salva uma cópia liberada numa pasta à parte. Antes disso, confira: PDF que apenas declara `/Encrypt` recebe marca e continua legível, porque senha só de proprietário abre sem senha |
| `vazio, zero bytes` | Arquivo que existe e não tem conteúdo. Quase sempre é sobra de gravação interrompida. Confirme com quem mantém a pasta antes de apagar |
| `ilegivel, erro ao abrir` | Arquivo corrompido, ou atalho para arquivo que não existe mais |
| `sem permissao de leitura` | Peça acesso a quem administra a pasta, e rode de novo |
| `arquivo sem extensao` | Renomeie com a extensão correta. Não adivinhe o formato pelo conteúdo |
| `nao selecionado nesta leva` | Não é falha. É o índice dizendo que o documento existe e ainda não foi lido |

**Documento que o modelo abriu e não entendeu.** Não é `inventariado` com
resumo vago: é NAO LIDO: ilegivel, com o motivo dito em palavras próprias
(manuscrito apagado, digitalização torta, idioma estrangeiro, página em
branco). Resumo vago é pior que nenhum resumo, porque não se distingue de
resumo bom numa lista de duzentas linhas.

Esse caso conta no balde **falha na leitura**, e não no de escolha. Só dois
motivos contam como escolha, e são os dois últimos da tabela acima. O conferidor
decide pelo motivo escrito, grava os demais em `nao-lidos-na-leitura.csv` e conta
os três baldes em linhas separadas da cobertura: falha da varredura é da máquina,
falha na leitura é do modelo, escolha é da pessoa. Misturar as três escondia a
falha atrás de uma decisão que ninguém tomou.

---

## O que o índice não faz

Ele não substitui o documento, não classifica o documento como válido ou
vencido, não diz qual é a revisão vigente e não diz o que está certo. Essas
quatro perguntas exigem abrir o documento e responder por ele, e quem
responde assina. O índice diz onde o documento está.
