---
name: indice-do-acervo-da-area
description: >
  Recebe uma pasta de documentos da área e devolve o índice: uma linha por documento, com
  resumo de uma linha, data, assunto, entidades citadas e o caminho do arquivo de origem em
  toda linha. A varredura é da árvore inteira e é feita por script, que no modo padrão não
  abre arquivo nenhum: a pessoa lê a lista primeiro e só depois escolhe o que o modelo abre.
  Documento que a rodada não conseguiu ler não some do índice. Ele entra com o motivo, e a
  rodada não sai com sucesso fingindo que leu tudo. Trata formato não suportado, arquivo
  protegido por senha, arquivo de zero byte, pasta que não pode ser listada, atalho não
  seguido, cópia repetida do mesmo documento e a data de modificação que virou a data da
  cópia. Use SEMPRE que aparecer: "monta o índice dessa pasta", "ninguém acha documento
  aqui", "o que tem nessa pasta de rede", "cataloga os documentos da área", "indexa esses
  arquivos", "preciso saber o que existe antes de procurar", "essa pasta tem dez anos de
  coisa dentro", "onde está o documento que fala daquele equipamento", "só o fulano sabe
  onde estão as coisas". NÃO use para virar um documento em tabela de dados
  (extracao-de-documento-para-tabela), para triar e-mail salvo em pasta
  (triagem-de-caixa-de-email), nem para conferir duas listas que deveriam bater
  (conferencia-entre-duas-fontes). NÃO use como substituto do documento: o índice diz onde
  ele está.
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que esta skill
ocupe o lugar das outras.

| Caso | Skill | Critério |
|---|---|---|
| Tirar os dados de dentro de um documento e pôr numa tabela | `extracao-de-documento-para-tabela` | O critério é a profundidade: aqui sai uma linha por documento, lá saem os campos de dentro dele. Encadeie: o índice acha o documento, a extração o abre |
| Pasta de e-mails salvos | `triagem-de-caixa-de-email` | Ela ordena por urgência de resposta. Esta aqui ordena por onde está |
| Duas listas que deveriam dizer a mesma coisa | `conferencia-entre-duas-fontes` | Lá se procura divergência, aqui se procura o documento |
| Conferir um procedimento contra a norma à qual ele responde | `padrao-conferido-contra-norma` | Ela precisa do procedimento vigente. O índice diz qual é e onde está |
| Refazer todo mês o mesmo relatório | `relatorio-recorrente` | Ela lê o índice para achar o relatório do mês passado |
| Comparar propostas de fornecedores | `comparativo-de-cotacoes` | O índice acha as propostas antigas do mesmo item |
| Registrar um desvio no formato que a empresa usa | `registro-de-anomalia` | O índice acha o registro anterior semelhante, que é a entrada dela |
| Medir o antes de uma tarefa que se quer automatizar | `linha-de-base-antes-de-automatizar` | O tempo gasto procurando documento é um dos antes que ela mede |
| Descrever a área uma vez para as outras skills lerem | `ficha-da-area` | Ela escreve `~/.kit-industrial/ficha-da-area.md`. Esta skill lê |

---

# Índice do acervo da área

A proposta de dois anos atrás, a especificação que alguém escreveu, a análise crítica do
fornecedor e a revisão que valeu estão numa pasta de rede e na memória de uma pessoa.
Quando ela sai de férias, ninguém acha. Quando ela sai da empresa, ninguém acha nunca mais.

Esta skill termina em arquivo. A saída é um conjunto de arquivos gravados em disco, e o
caminho é informado. Resposta em prosa listando os documentos é falha de execução: o índice
existe para ser consultado depois, por quem não estava na conversa.

**Ela não acessa servidor de arquivos, não acessa ERP e não acessa nuvem.** Ela varre a
pasta que está na máquina, e diz isso antes de começar.

---

## Leis de ferro

1. **O índice diz onde está o documento, nunca substitui o documento.** Toda linha carrega
   o caminho do arquivo de origem. Resumo que não permite achar o arquivo é inútil, e linha
   sem caminho não é linha de índice.
2. **O índice nasce da varredura, não da leitura.** Uma linha por arquivo encontrado, todas
   escritas antes de qualquer documento ser aberto. Depois as linhas são preenchidas. O
   índice montado a partir do que foi lido perde o que não foi lido, e perde em silêncio.
3. **Documento que a rodada não conseguiu ler entra com o motivo.** Formato não suportado,
   protegido por senha, vazio, ilegível, sem permissão. Ele fica no índice, nomeado, e a
   rodada não sai com sucesso fingindo que leu tudo.
4. **Resumo de documento não lido é invenção.** No lugar do resumo vai a frase NAO LIDO:
   mais o motivo, escrita sem crases. O conferidor derruba a rodada quando encontra resumo
   escrito para documento com status de falha.
5. **A varredura é sempre da árvore inteira, e uma linha por documento.** Pasta ignorada por
   pedido, pasta que não pode ser listada, atalho não seguido e atalho que fecha ciclo saem
   nomeados, e a cobertura declara que o que está dentro deles não foi contado. Nenhum
   documento entra duas vezes, e o fechamento confere isso no arquivo gravado.
6. **Na dúvida entre descartar e reportar, reporte.** Nada é filtrado em silêncio. Arquivo
   que parece ruído de sistema entra com a marca, e quando filtrado por pedido sai nomeado
   um a um em arquivo próprio.
7. **A data do documento é a que está escrita dentro dele.** A data de modificação do
   arquivo é outra coisa e fica em coluna própria. Pasta copiada de rede ou restaurada de
   backup tem tudo com a data da cópia.
8. **Entidade citada é entidade que está no texto.** Fornecedor, equipamento e cliente não
   se deduzem do nome da pasta.
9. **Gabarito antes do uso real, e o arquivo diz se houve.** Descrito no passo 7. A rodada
   sem gabarito sai com o status marcado `nao validado` na `cobertura.md`, e não só na
   conversa.
10. **Dado que a rodada apurou não se descarta.** O que a extração de texto apurou por
    máquina entra no índice com a origem declarada, inclusive nas linhas que ninguém leu
    ainda. O conferidor derruba a rodada que deixou esse dado para trás.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Existindo, use o vocabulário da área, os sistemas
em uso e os códigos que a casa emprega para escolher o vocabulário da coluna assunto e para
reconhecer entidade. Não existindo, declare em voz alta "rodando sem ficha da área" e siga.

Rodar sem ficha não degrada a varredura, que é mecânica. Degrada a coluna assunto, que sai
no vocabulário do documento em vez de sair no da casa.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi carregada ou se a
rodada está sem ficha e, carregada, repete o status gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir arquivo

Nesta skill o passo 2 é mais forte do que nas outras, e a razão é simples: a pasta da área
tem de tudo, e ninguém sabe o que tem. Por isso a ordem é invertida em relação ao resto do
kit. **Primeiro o script inventaria sem abrir nada, depois a pessoa olha a lista, e só então
ela escolhe o que o modelo lê.**

Cinco perguntas, nesta ordem:

1. **O que pode haver de sensível nessa pasta?** As cinco classes: nome de pessoa; folha de
   pagamento, salário e remuneração individual; preço de fornecedor identificado; dado de
   cliente identificado; projeto sob sigilo. Folha, salário e remuneração individual não
   entram em nenhum modo: os arquivos ficam no índice, com o motivo, e não são abertos.
   Sendo a resposta sim, ou não sabendo a pessoa, vá para o **modo de dado sensível**.
2. **O índice vai circular?** Sendo sim, rode com `--raiz-como`, que troca o caminho
   absoluto por um rótulo e mantém o relativo. O caminho relativo ainda acha o arquivo para
   quem tem a pasta, e o índice deixa de carregar o nome do servidor e o do usuário.
3. **Quantos arquivos a pasta tem, por alto, e quantos gigabytes?** O número de arquivos
   define quantas levas de leitura, pela tabela do passo 4. O tamanho decide duas opções:
   `--marcar-duplicatas` e `--extrair-texto` leem byte de cada arquivo na máquina local, e
   acima de uns 20 GB a rodada passa de alguns minutos. Nesse caso rode a primeira vez sem
   elas, só para ver a lista, e depois rode de novo com elas na subpasta que interessa.
4. **Existe uma pasta que a pessoa conhece de cor?** Existindo, ela é uma **rodada própria**,
   com o gabarito dela: varredura, índice e conferidor com `--gabarito` na mesma pasta. Ela
   não é gabarito da rodada grande, porque o gabarito é sempre conferido contra o índice da
   rodada em que roda. Não existindo, o passo 7 diz o que fazer.
5. **O índice já existe em versão anterior?** Existindo, a rodada nova é regravada por cima
   com `--forcar`, no mesmo diretório, para a comparação ficar possível.

**Critério de conclusão:** as cinco respostas estão registradas, e nenhum arquivo foi
aberto até aqui.

---

## Passo 3: varrer a árvore inteira

A varredura é sempre pelo script, qualquer que seja o tamanho da pasta, sem exceção. Não é
questão de volume: leitura em contexto não enumera árvore de diretório de forma
reproduzível, não enxerga pasta sem permissão, não deixa rastro e não repete igual na semana
seguinte. O que varia com o volume é quantos documentos o modelo lê depois, e isso é o passo
4.

**Dependência declarada:** Python 3.8 ou superior, biblioteca padrão apenas (`argparse`,
`csv`, `hashlib`, `os`, `re`, `sys`, `unicodedata`, `zipfile`, `zlib`, `datetime`,
`pathlib`). Sem instalação, sem rede, e nada é escrito dentro da pasta varrida.

**Onde o script está depois de instalado.** A instalação copia a pasta da skill para
`~/.claude/skills/indice-do-acervo-da-area/`. A rodada acontece na pasta de trabalho, não na
pasta da skill, e por isso o script é chamado pelo caminho completo.

No macOS e no Linux:

```
python3 ~/.claude/skills/indice-do-acervo-da-area/scripts/inventariar.py \
    --pasta "/Volumes/rede/Engenharia/Acervo" \
    --saida acervo-2026-09-20 \
    --marcar-duplicatas \
    --extrair-texto
```

No PowerShell, com `py -3` no lugar de `python3`, `$env:USERPROFILE` no lugar do `~` e
acento grave no lugar da barra invertida:

```
py -3 "$env:USERPROFILE\.claude\skills\indice-do-acervo-da-area\scripts\inventariar.py" `
    --pasta "Z:\Engenharia\Acervo" `
    --saida acervo-2026-09-20 `
    --marcar-duplicatas `
    --extrair-texto
```

As duas opções do comando acima são o caminho normal, e não extras. `--marcar-duplicatas` é
o que revela as seis cópias da mesma proposta, e `--extrair-texto` é o que faz o índice
responder onde está o documento sem esperar leitura de tudo. Desligue só pelo motivo da
quinta pergunta do passo 2, o tamanho da pasta.

| Opção | Quando usar |
|---|---|
| `--extrair-texto` | Abre **na máquina local** os formatos que a biblioteca padrão lê e apura por máquina a data escrita dentro do documento, as entidades citadas e um trecho de busca, em `termos-por-documento.csv`. Nada sai da máquina. Arquivo marcado como remuneração não é aberto |
| `--marcar-duplicatas` | Calcula sha256 local e agrupa arquivos de conteúdo idêntico |
| `--contar-paginas` | Conta página, aba ou linha, abrindo na máquina local. **Muda status:** arquivo que não abre passa a não lido, e o motivo diz qual foi o erro |
| `--ficha CAMINHO` | Ficha da área de onde saem os códigos e as normas que a extração procura no texto. O padrão é `~/.kit-industrial/ficha-da-area.md` |
| `--raiz-como ROTULO` | Troca o caminho absoluto por um rótulo e mantém o relativo, inclusive dentro do texto de erro do sistema |
| `--sem-ruido` | Tira do inventário os arquivos de sistema de nome conhecido, e nomeia cada um em `ruido-filtrado.csv` |
| `--ignorar-pasta NOME` | Não varre aquela pasta. É o **nome** da pasta, não o caminho. Nome que não casa com nenhuma pasta encontrada derruba a rodada com código 3, antes de gravar |
| `--seguir-atalhos` | Entra em atalho de pasta. Atalho que fecha ciclo é barrado e sai nomeado, e nenhum documento entra duas vezes |
| `--forcar` | Regrava por cima do diretório da rodada. É o caminho normal da segunda rodada |
| `--max-bytes-abertura N` | Acima disso o arquivo não é aberto, e a contagem e a extração saem como não apuradas, nomeadas |

| Código de saída | Significado |
|---|---|
| 0 | Varreu, todo arquivo encontrado foi inventariado, nenhuma pasta ficou fora e nada foi filtrado |
| 1 | Varreu, e há itens fora da leitura: arquivo não lido, pasta não listada, pasta ignorada, atalho não seguido, atalho em ciclo ou ruído filtrado. Todos nomeados em `nao-lidos.csv` |
| 3 | Erro de entrada, nome de `--ignorar-pasta` que não casou com nada, ou fechamento que não fecha |

O código 1 não é falha. É a varredura dizendo quantos documentos ainda não têm resposta.
Código 0 numa pasta de rede de dez anos é raro, e quando aparece merece desconfiança.

**Critério de conclusão,** e ele é conferido na saída, não de memória: o diretório da rodada
tem `cobertura.md`, `inventario.csv` e `nao-lidos.csv`, o bloco de fechamento impresso tem
`fecha` em todas as linhas, a contagem por classe de conteúdo da seção 1 da cobertura foi
lida em voz alta e a pessoa reconheceu a pasta nela, e a seção 2 nomeia item por item tudo o
que ficou fora, com o total batendo com o número impresso no fim da rodada. Não se pede à
pessoa o número de arquivos que ela esperava: numa pasta de dez anos esse número não existe,
e exigir isso era pedir para o critério ser declarado cumprido no olho.

---

## Passo 4: ler a lista e escolher o que abrir

Mostre à pessoa a contagem por classe de conteúdo, a lista do que não foi lido e os nomes
marcados como remuneração. Peça que ela escolha o que pode ser aberto.

A marca de remuneração é por nome de arquivo, e o limite está declarado: folha de pagamento
salva como `Planilha1.xlsx` não é pega por heurística nenhuma. É por isso que a pessoa lê a
lista.

**Antes de escolher, mostre o que a máquina já apurou.** Rodando com `--extrair-texto`, o
`termos-por-documento.csv` já tem a data e as entidades de cada arquivo legível, e ele é
pesquisável: o nome do equipamento, o número da ordem ou o número da norma acham o documento
sem nenhuma leitura. A leitura pelo modelo serve para o que a máquina não faz, que é o assunto
no vocabulário da casa e o resumo de uma linha. Numa pasta de milhares de arquivos, é isso que
separa um índice que responde de um índice que promete responder depois de cem levas.

| Documentos liberados para leitura | Como ler |
|---|---|
| Até 40 | Uma leva só |
| 41 a 200 | Levas de 40. O índice já tem todas as linhas desde o passo 5, e cada leva preenche as suas |
| Acima de 200 | Uma leva por pasta, começando pela que a pessoa apontar como a mais procurada |
| Qualquer tamanho, com dado sensível | Só o que a pessoa liberou. O resto fica no índice com NAO LIDO: nao liberado nesta rodada |

**Critério de conclusão:** existe uma lista escrita dos arquivos liberados, e ela é menor ou
igual ao inventário. O que ficou de fora já tem o motivo escolhido.

---

## Passo 5: o índice nasce do inventário

Antes de abrir qualquer documento, escreva `indice.csv` com **uma linha para cada linha do
inventário**, nesta ordem de colunas:

`id`, `caminho`, `data_do_documento`, `origem_da_data`, `assunto`, `resumo`, `entidades`,
`status_leitura`.

O `id`, o `caminho` e o `status_leitura` são copiados do inventário, tal como estão. O
conferidor derruba a rodada quando o `id` ou o `status_leitura` divergem do inventário: os
três vêm da varredura e não se reescrevem.

Havendo `termos-por-documento.csv`, ou seja rodada com `--extrair-texto`, três campos também
são copiados, em toda linha, lida ou não: `data_do_documento` recebe `data_no_texto`,
`origem_da_data` recebe a origem que o arquivo declara, e `entidades` recebe
`entidades_no_texto`. Isso não é adiantamento de leitura, é dado que a rodada já apurou por
máquina, com a origem escrita. **O conferidor derruba a rodada quando a extração apurou a
data ou as entidades e o índice traz `nao apurado` no lugar.** Dado apurado não se descarta.

Os demais campos nascem preenchidos assim:

- Documento com status de falha: `resumo` recebe NAO LIDO: mais o motivo do inventário, e os
  campos sem apuração recebem `nao apurado`.
- Documento legível e ainda não lido: `resumo` recebe NAO LIDO: nao selecionado nesta leva, e
  os campos sem apuração recebem `nao apurado`.

Escreva a frase sem crases dentro do campo. Crase no começo de um campo do CSV faz o
conferidor ler o valor como outra coisa.

O rodapé do `indice.csv` vai na última linha, na primeira coluna, prefixado, e os outros
campos ficam vazios. Escrito assim, pronto para copiar:

```
# Gerado com apoio de IA a partir da varredura da pasta do acervo. Revisar antes de assinar. Nao substitui responsabilidade tecnica.;;;;;;;
```

Esta é a construção que torna o desaparecimento impossível. O índice não é montado a partir
do que foi lido: ele já existe inteiro, e a leitura só preenche.

**Critério de conclusão:** `indice.csv` tem exatamente o mesmo número de linhas que
`inventario.csv`, nenhum campo está em branco, e os `id` são os do inventário.

---

## Passo 6: preencher as linhas lidas

Leia `references/campos-do-indice.md` antes da primeira linha. Ele traz, para cada um dos
cinco campos, a regra de preenchimento, a regra de recusa e o erro típico.

Abra os documentos da leva, um a um, e substitua a marca de não lido pelos cinco campos.
Documento que abriu e não deu para entender volta a ser NAO LIDO: ilegivel, com o motivo em
palavras próprias. Esse caso é contado no balde **falha na leitura**, não no balde de
escolha, e sai nomeado em `nao-lidos-na-leitura.csv`. Só dois motivos contam como escolha:
nao selecionado nesta leva e nao liberado nesta rodada. Resumo vago não se distingue de
resumo bom numa lista de duzentas linhas.

Escreva também `indice.md`, que é o arquivo que a pessoa consulta, entre as marcas
`<!-- inicio do indice -->` e `<!-- fim do indice -->`. As marcas não são enfeite: é por elas
que o conferidor separa a tabela do índice de qualquer outra tabela do arquivo, e sem elas a
rodada não passa.

O cabeçalho da tabela é este, e a linha separadora abaixo dele é obrigatória:

```
| Id | Caminho | Data | Assunto | Resumo | Entidades |
|---|---|---|---|---|---|
```

A ordem das colunas pode mudar, desde que exista uma coluna chamada `Caminho`: é dela que o
conferidor lê o caminho de cada linha. **O caminho vai entre crases, e só ele.** Crase em
outra célula é lida como caminho citado.

**Critério de conclusão:** todo documento da leva tem os cinco campos preenchidos, e nenhum
documento fora da leva perdeu a linha dele.

---

## Passo 7: a lei do gabarito

A skill não vai para o trabalho real antes de acertar um caso que a pessoa já fez à mão. **O
gabarito descreve documentos da rodada que está sendo conferida**, sempre: o conferidor
procura cada caminho do gabarito dentro do índice daquela rodada, e caminho que não está lá
derruba a conferência. Gabarito de outra pasta é outra rodada, com o `--gabarito` dela.

São dois caminhos, e o primeiro é o preferido.

**Caminho 1, existe lista feita à mão.** Quase toda área tem: a planilha de controle de
documentos, a lista de procedimentos vigentes, o índice de projetos. Salve as colunas
`caminho`, `data_do_documento` e `assunto` num CSV com ponto e vírgula, e rode o conferidor
com `--gabarito`. Ele compara campo a campo e grava `gabarito-conferido.csv`.

**Caminho 2, não existe lista.** A pessoa escolhe cinco documentos que conhece de cor e,
**antes de rodar**, escreve num papel o caminho, a data e o assunto de cada um. Esses cinco
viram o CSV do gabarito. Escrever depois de ver a saída não é gabarito, é concordância.

Como preencher as três colunas:

- `caminho`: o caminho relativo à raiz varrida, com barra normal, igual ao que está no
  `inventario.csv`. Caminho absoluto e barra invertida não casam. A data e o assunto são
  anotados antes de rodar; os caminhos podem ser copiados do inventário depois da varredura,
  sem mexer no que foi anotado.
- `data_do_documento`: aceita `aaaa-mm-dd`, `dd/mm/aaaa` e `dd-mm-aaaa`. A comparação é de
  data, não de texto: escrever no formato do documento não reprova.
- `assunto`: em palavras próprias.

**As duas colunas precisam estar preenchidas.** Gabarito com os caminhos certos e as colunas
em branco não compara nada, e o conferidor sai com código 2 dizendo isso, em vez de deixar a
rodada passar por validada.

O conferidor sai com código 2 quando a data diverge, e a skill não é usada no trabalho real
enquanto ele não sair com 0 ou 1. Divergência de assunto sai como `conferir`, porque assunto
tem redação e não tem certo único: quem decide é a pessoa.

**Critério de conclusão:** `gabarito-conferido.csv` tem pelo menos uma linha por documento do
gabarito, a coluna `bate` foi lida linha a linha, a `cobertura.md` traz a linha
`gabarito: N campos comparados` com N maior que zero, e está dito qual dos dois caminhos foi
usado.

---

## Passo 8: conferir e fechar

Rode o conferidor. Ele é mecânico, e é ele que impede a doença desta skill.

```
python3 ~/.claude/skills/indice-do-acervo-da-area/scripts/conferir-indice.py \
    --rodada acervo-2026-09-20 \
    --gabarito gabarito.csv
```

```
py -3 "$env:USERPROFILE\.claude\skills\indice-do-acervo-da-area\scripts\conferir-indice.py" `
    --rodada acervo-2026-09-20 `
    --gabarito gabarito.csv
```

Ele confere, contra quatro arquivos diferentes: uma linha de índice por arquivo do inventário,
caminho preenchido e único em toda linha, nenhum campo em branco, `id` e status iguais aos da
varredura, resumo escrito só onde houve leitura, dado apurado por máquina que chegou ao
índice, o caminho de cada linha presente também no `indice.md`, e o total de não lidos igual
ao que a varredura registrou.

| Código de saída | Significado |
|---|---|
| 0 | O índice cobre o inventário inteiro e todo documento foi lido |
| 1 | O índice cobre o inventário inteiro, e há documento sem leitura, por falha da varredura, por falha na leitura ou por escolha. Todos nomeados |
| 2 | O gabarito não bateu, ou foi passado e não comparou nenhum campo. A skill não vai para o trabalho real assim |
| 3 | Índice inválido: documento faltando, caminho em branco, resumo escrito para documento não lido, coluna faltando, `id` que não é o da varredura, linha do `indice.md` sem caminho, dado apurado por máquina que o índice descartou, ou fechamento que não fecha |

As identidades de fechamento, todas contadas no laço e nenhuma derivada por subtração:

```
linhas em inventario.csv    = linhas em indice.csv
linhas em indice.csv        = lidas + falha_da_varredura + falha_na_leitura + escolha
arquivos em nao-lidos.csv   = falha_da_varredura no indice
```

A terceira é a que importa, porque ela confere o índice contra um arquivo que o modelo não
escreveu.

**Critério de conclusão:** o conferidor saiu com 0 ou com 1, a `cobertura.md` tem
`status: completo` ou `status: completo com pendencias`, com o `, nao validado` no fim quando
a rodada não teve gabarito, a mesma `cobertura.md` traz a linha que começa com `gabarito:`, e
a resposta diz o caminho de cada arquivo gravado e quantos documentos ficaram sem leitura, em
cada um dos três baldes.

---

## Contrato de saída

Um diretório com a data da rodada. A cobertura é escrita primeiro, antes de qualquer índice,
e reescrita por último com o fechamento.

| Arquivo | Quem escreve | Conteúdo |
|---|---|---|
| `cobertura.md` | script | O que foi varrido, o que não foi lido nomeado item a item, ruído filtrado, nomes marcados como remuneração, duplicatas, alerta de data concentrada, fechamento e limite declarado |
| `inventario.csv` | script | Uma linha por arquivo encontrado, inclusive os que não puderam ser lidos |
| `nao-lidos.csv` | script | O subconjunto que precisa de resposta, mais as pastas e atalhos que ficaram fora |
| `ruido-filtrado.csv` | script | Só com `--sem-ruido`. Cada arquivo filtrado, nomeado, com o padrão que o filtrou |
| `termos-por-documento.csv` | script | Só com `--extrair-texto`. Uma linha por arquivo inventariado, com a data apurada no texto, as entidades citadas, o trecho de busca e, quando não deu para extrair, o motivo |
| `indice.csv` | modelo | O índice em tabela, uma linha por arquivo do inventário |
| `indice.md` | modelo | O índice que a pessoa consulta, com o caminho entre crases na coluna `Caminho` |
| `gabarito-conferido.csv` | conferidor | Só com `--gabarito`. Campo a campo, o que bateu e o que não bateu |
| `nao-lidos-na-leitura.csv` | conferidor | Os documentos que o modelo abriu e não conseguiu entender. Eles não estão no `nao-lidos.csv`, que é da varredura, e alguém responde por eles do mesmo jeito |

Colunas de `inventario.csv`: `id`, `caminho`, `caminho_absoluto`, `nome`, `extensao`,
`tamanho_bytes`, `modificado_em`, `paginas`, `base_da_contagem`, `classe_de_conteudo`,
`status_leitura`, `motivo`, `marca`, `grupo_de_duplicata`.

Arquivo que não pôde ser lido aparece nos dois CSV, de propósito: em `inventario.csv` porque
ele existe na pasta e não pode sumir do índice, e em `nao-lidos.csv` porque alguém tem que
responder por ele.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir da varredura da pasta do acervo. Revisar antes de assinar.
Não substitui responsabilidade técnica.
```

---

## Modo de dado sensível

A pasta da área tem de tudo, e por isso o modo sensível aqui é o caminho normal. Os três
níveis, com o nível 2 como padrão quando a pessoa não decide.

**Nível 1, só a lista de nomes.** A varredura roda na máquina da pessoa e ela cola apenas o
`nao-lidos.csv` e a contagem por classe. Nenhum nome de documento precisa subir. Serve para
decidir o que fazer com o que não foi lido. Rodando com `--raiz-como`, nem o texto de erro do
sistema leva o caminho do servidor: o rótulo entra também na coluna `motivo`.

**O `termos-por-documento.csv` não sobe nos níveis 1 e 2.** Ele é gravado na máquina da pessoa
e carrega um trecho do texto de cada documento, que é conteúdo. Ele serve para a pessoa
pesquisar localmente, e para ela copiar as colunas de data e entidades para o índice.

**Nível 2, varredura local e leitura escolhida (padrão).** A pessoa roda o
`inventariar.py` na máquina dela, com `--raiz-como`. Ela lê o inventário, escolhe os
arquivos liberados e traz só esses para leitura. O que não foi liberado continua no índice,
com NAO LIDO: nao liberado nesta rodada.

**Nível 3, nada sai.** O modelo entrega as duas linhas de comando e o gabarito do
`indice.csv`, e a pessoa preenche. O conferidor roda na máquina dela e ela responde apenas
"fechou" ou "não fechou", e qual identidade quebrou.

O caminho é obrigatório em toda linha, e o caminho relativo pode nomear cliente, pessoa ou
projeto na própria estrutura de pastas. `--raiz-como` esconde o prefixo absoluto e não
resolve isso. Sendo esse o caso, o índice fica na máquina, e é o que a cobertura declara.

Regra que não se quebra: folha de pagamento, salário e remuneração individual não entram em
nenhum dos três níveis. Os arquivos ficam no índice, nomeados, e não são abertos.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**Pasta em servidor de rede que a máquina não monta.** O script varre o que o sistema de
arquivos mostra. Não havendo a unidade montada, não há varredura. Monte a pasta, ou copie
para a máquina, sabendo que a cópia reescreve toda data de modificação.

**Desenho de engenharia.** Formato de CAD não abre em biblioteca padrão e o modelo não lê. O
arquivo entra no índice com `formato nao suportado` e a instrução de exportar para PDF. O
índice de um acervo de engenharia sai com uma parte assim, e isso é informação, não falha.

**Pacote compactado.** Um `.zip` com trinta documentos entra como um arquivo só, com
`formato nao suportado`. Descompacte numa pasta e varra de novo. Contar o que está dentro
sem descompactar daria um número que ninguém consegue abrir.

**Documento manuscrito ou digitalização ruim.** A leitura de manuscrito tem limite conhecido
e medido. O documento entra com NAO LIDO: ilegivel e o motivo. Precisando dos dados de
dentro dele, a skill é `extracao-de-documento-para-tabela`, que mede a taxa de acerto contra
gabarito antes de liberar o uso.

**Formato binário antigo de escritório.** `.doc`, `.xls`, `.ppt` e `.msg` não abrem em
nenhuma ferramenta do kit. Eles entram no índice com `formato antigo de escritorio` e a
instrução de salvar como PDF ou no formato novo. Isso é limite de ferramenta, e por isso não
é contado como decisão de ninguém: o balde é falha, não escolha.

**Contagem de páginas de PDF.** A contagem é por leitura de estrutura, e em PDF com índice
comprimido as duas contagens independentes podem divergir. Divergindo, a coluna sai como
`nao apurado` com os dois números. Número de página chutado num índice de acervo vira
critério de triagem errado.

**PDF que declara senha.** O PDF com `/Encrypt` recebe a marca de que pode exigir senha ou
ter apenas restrição de permissão, e **continua no índice como legível**. Senha só de
proprietário é o caso mais comum em acervo técnico, e abre em qualquer leitor: tirar esse
documento da leitura mandava a pessoa procurar uma senha que não existe.

**Extração de texto de PDF.** Ela é parcial e declara que é. PDF gerado por editor de texto
sai com texto; digitalização e PDF com fonte embutida por código saem sem texto, nomeados no
`termos-por-documento.csv`, com o motivo. Nunca sai texto embaralhado, porque texto
embaralhado num índice não se distingue de texto bom.

**Revisão vigente.** O índice não diz qual é a revisão que vale. Ele diz quais revisões
existem e onde estão. Quem declara a vigente assina por isso.

**Pasta sem gabarito nenhum.** A skill roda, entrega e marca a saída como não validada. A
marca fica na `cobertura.md`, no status e na linha `gabarito: nao rodado nesta rodada, saida
nao validada`, e é repetida na resposta. Ela não deixa de rodar, e também não finge que foi
conferida.

---

## Referência

A pasta da skill fica em `~/.claude/skills/indice-do-acervo-da-area/` depois de instalada.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/indice-do-acervo-da-area/references/campos-do-indice.md` | Os cinco campos do índice, cada um com regra de preenchimento, regra de recusa e o erro típico. Traz a tabela de motivos de não leitura e o que fazer com cada um. Leia antes de preencher a primeira linha |
| `~/.claude/skills/indice-do-acervo-da-area/scripts/inventariar.py` | A varredura da árvore inteira e a extração de texto na máquina local, em Python de biblioteca padrão. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções |
| `~/.claude/skills/indice-do-acervo-da-area/scripts/conferir-indice.py` | O conferidor do índice contra o inventário, contra o `nao-lidos.csv` e contra o `termos-por-documento.csv`. É ele que torna mecânicas a lei de ferro 1, a 4 e a 10 |
| `~/.claude/skills/indice-do-acervo-da-area/scripts/testar.py` | Teste de regressão dos dois scripts, biblioteca padrão apenas, 64 casos. Os casos não foram escritos a partir das funcionalidades, e sim da pergunta "existe caminho em que isto sai com sucesso tendo perdido documento". Três deles são de sabotagem: a cópia do script com o ramo de gravação mutilado, a cópia que perde a linha sem mexer no contador e a cópia que grava a mesma linha duas vezes têm que ser derrubadas pelo fechamento, e não sair com 0. Os outros cobrem arquivo de zero byte, formato não suportado, formato antigo de escritório, arquivo sem extensão, arquivo oculto, filtro de ruído por nome exato e não por trecho, pasta que não pode ser listada, atalho de pasta não seguido, atalho quebrado, ciclo de atalho que volta para a raiz, par de atalhos que apontam um para o outro, pasta ignorada com barra no fim e nome que não casa com nada, vazamento do caminho da raiz com `--raiz-como`, duplicata, data concentrada, PDF que declara senha, contagens de página divergentes, pacote que não abre, extração de texto com data e entidade apuradas, arquivo de remuneração que a extração não abre, PDF sem texto legível, saída dentro da pasta varrida, e do lado do índice: documento faltando, resumo escrito para documento não lido, caminho em branco, caminho repetido, campo em branco, `id` trocado e `id` em branco, documento inventado, status reescrito à mão, linha do `indice.md` sem caminho, cabeçalho de tabela que não começa por `Id`, rodapé sem prefixo, marca de não lido entre crases, falha na leitura contada em balde próprio, dado apurado por máquina descartado pelo índice, arquivo sem as marcas, sem rodapé e ausente, gabarito que bate, que não bate, que aponta fora do índice, que compara zero campos, e a data em formato diferente do índice. Rode `python3 ~/.claude/skills/indice-do-acervo-da-area/scripts/testar.py` depois de qualquer mudança, ou `py -3 "$env:USERPROFILE\.claude\skills\indice-do-acervo-da-area\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
