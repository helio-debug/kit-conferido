#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do inventariar.py e do conferir-indice.py.

Biblioteca padrao apenas. Monta cada caso numa pasta temporaria, roda o script
nela e confere o codigo de saida e trechos dos arquivos gravados.

Os casos nao foram escritos a partir das funcionalidades. Foram escritos a
partir de uma pergunta so, feita uma vez por caminho do codigo:

    existe caminho em que isto sai com sucesso tendo perdido documento?

Por isso ha caso de sabotagem: uma copia do script com um ramo mutilado tem
que ser derrubada pelo fechamento, e nao sair com codigo 0.

Rode depois de qualquer mudanca nos scripts:

    python3 ~/.claude/skills/indice-do-acervo-da-area/scripts/testar.py

No PowerShell:

    py -3 "$env:USERPROFILE\.claude\skills\indice-do-acervo-da-area\scripts\testar.py"

Sai com 1 se algum caso falhar.
"""

import csv
import io
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
INVENTARIAR = AQUI / "inventariar.py"
CONFERIR = AQUI / "conferir-indice.py"
SKILL = AQUI.parent / "SKILL.md"

falhas = []
pulados = []

PDF_OK = (b"%PDF-1.4\n1 0 obj\n<< /Type /Pages /Kids [2 0 R 3 0 R] /Count 2 "
          b">>\nendobj\n2 0 obj\n<< /Type /Page >>\nendobj\n3 0 obj\n"
          b"<< /Type /Page >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF\n")
PDF_DIVERGE = (b"%PDF-1.4\n1 0 obj\n<< /Type /Pages /Count 5 >>\nendobj\n"
               b"2 0 obj\n<< /Type /Page >>\nendobj\n3 0 obj\n"
               b"<< /Type /Page >>\nendobj\n%%EOF\n")
PDF_SENHA = (b"%PDF-1.4\ntrailer\n<< /Root 1 0 R /Encrypt 9 0 R >>\n"
             b"1 0 obj\n<< /Type /Page >>\nendobj\n%%EOF\n")


def docx_bytes(paginas):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("docProps/app.xml",
                   "<Properties><Pages>%d</Pages></Properties>" % paginas)
        z.writestr("word/document.xml", "<document/>")
    return buf.getvalue()


def docx_com_texto(texto):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("docProps/app.xml", "<Properties><Pages>4</Pages></Properties>")
        z.writestr("word/document.xml",
                   "<w:document><w:p><w:r><w:t>%s</w:t></w:r></w:p></w:document>"
                   % texto)
    return buf.getvalue()


def xlsx_com_texto(texto):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("xl/workbook.xml", "<workbook><sheet/></workbook>")
        z.writestr("xl/sharedStrings.xml",
                   "<sst><si><t>%s</t></si></sst>" % texto)
    return buf.getvalue()


def registrar(nome, erros):
    if erros:
        falhas.append((nome, erros))
        print("FALHOU  %s" % nome)
        for e in erros:
            print("        %s" % e)
    else:
        print("ok      %s" % nome)


def pular(nome, motivo):
    pulados.append((nome, motivo))
    print("PULADO  %s (%s)" % (nome, motivo))


def montar(base, arquivos):
    """arquivos: dict caminho_relativo -> bytes ou str."""
    for rel, conteudo in arquivos.items():
        alvo = base / rel
        alvo.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(conteudo, bytes):
            alvo.write_bytes(conteudo)
        else:
            alvo.write_text(conteudo, encoding="utf-8")


def rodar(cmd):
    return subprocess.run([sys.executable] + cmd, capture_output=True,
                          text=True)


def ler_csv(caminho):
    if not Path(caminho).exists():
        return []
    with open(str(caminho), encoding="utf-8-sig", newline="") as fh:
        leitor = csv.DictReader(fh, delimiter=";")
        campos = leitor.fieldnames or []
        linhas = []
        for linha in leitor:
            if (linha.get(campos[0]) or "").startswith("# "):
                continue
            linhas.append(linha)
    return linhas


def caso_inventario(nome, arquivos, esperado, checagens, extra=None,
                    script=None, antes=None, depois=None, saida_dentro=False):
    """checagens: lista de (alvo, texto, deve_aparecer).

    alvo: 'stdout', 'stderr', 'cobertura', 'inventario', 'nao-lidos',
    'ruido'."""
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        pasta = base / "acervo"
        pasta.mkdir()
        montar(pasta, arquivos)
        saida = (pasta / "saida") if saida_dentro else (base / "saida")
        if antes:
            antes(pasta, saida)
        cmd = [str(script or INVENTARIAR), "--pasta", str(pasta),
               "--saida", str(saida)]
        if extra:
            cmd += extra
        proc = rodar(cmd)
        erros = []
        if proc.returncode != esperado:
            erros.append("codigo de saida %d, esperado %d. stderr: %s"
                         % (proc.returncode, esperado,
                            proc.stderr.strip()[:400]))
        mapa = {
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "cobertura": leia(saida / "cobertura.md"),
            "inventario": leia(saida / "inventario.csv"),
            "nao-lidos": leia(saida / "nao-lidos.csv"),
            "ruido": leia(saida / "ruido-filtrado.csv"),
            "termos": leia(saida / "termos-por-documento.csv"),
        }
        for alvo, texto, deve in checagens:
            conteudo = mapa[alvo]
            presente = texto in conteudo
            if presente != deve:
                erros.append("%s: %s '%s'"
                             % (alvo, "nao devia conter" if presente
                                else "devia conter", texto))
        if depois:
            erros.extend(depois(saida, proc) or [])
        registrar(nome, erros)
        return erros


def leia(caminho):
    p = Path(caminho)
    if not p.exists():
        return ""
    return p.read_text(encoding="utf-8-sig", errors="replace")


# ---------------------------------------------------------------- inventario

def testes_inventario():
    caso_inventario(
        "arvore inteira varrida, nada perdido, codigo 0",
        {"procedimentos/PR-01 inspecao.pdf": PDF_OK,
         "atas/2026-03 ata da reuniao.txt": "ata",
         "atas/antigas/2024 proposta.docx": docx_bytes(3),
         "planilha de controle.csv": "a;b\n1;2\n"},
        0,
        [("inventario", "procedimentos/PR-01 inspecao.pdf", True),
         ("inventario", "atas/antigas/2024 proposta.docx", True),
         ("inventario", "planilha de controle.csv", True),
         ("stdout", "fecha", True),
         ("stdout", "QUEBRA", False),
         ("cobertura", "Nenhum item. Todo arquivo encontrado foi "
                       "inventariado.", True)])

    caso_inventario(
        "arquivo de zero byte nao some: entra nos dois arquivos",
        {"relatorio vazio.pdf": b"", "ok.txt": "conteudo"},
        1,
        [("inventario", "vazio, zero bytes", True),
         ("inventario", "relatorio vazio.pdf", True),
         ("nao-lidos", "relatorio vazio.pdf", True),
         ("cobertura", "relatorio vazio.pdf", True)])

    caso_inventario(
        "formato nao suportado entra no inventario, nomeado",
        {"desenhos/TQ-100 tanque.dwg": b"AC1024xxxx", "ok.txt": "c"},
        1,
        [("inventario", "desenhos/TQ-100 tanque.dwg", True),
         ("inventario", "formato nao suportado", True),
         ("nao-lidos", "desenhos/TQ-100 tanque.dwg", True),
         ("nao-lidos", "Exporte para PDF", True)])

    caso_inventario(
        "arquivo sem extensao nao some e nao e adivinhado",
        {"RELATORIO FINAL": "texto sem extensao", "ok.txt": "c"},
        1,
        [("inventario", "RELATORIO FINAL", True),
         ("inventario", "indefinida, arquivo sem extensao", True),
         ("nao-lidos", "RELATORIO FINAL", True)])

    caso_inventario(
        "arquivo oculto e inventariado como qualquer outro",
        {".relatorio-anual-2026.pdf": PDF_OK, "ok.txt": "c"},
        0,
        [("inventario", ".relatorio-anual-2026.pdf", True)])

    # O caso do "GERAL": filtro por trecho apagando item real.
    caso_inventario(
        "filtro de ruido e por nome exato, nunca por trecho",
        {".DS_Store": b"\x00\x01",
         "~$orcamento.docx": docx_bytes(1),
         "Instrucao-Thumbs.db-revisao.pdf": PDF_OK,
         "Mapa~$Rev2.pdf": PDF_OK,
         "relatorio.tmp.pdf": PDF_OK,
         "ok.txt": "c"},
        1,
        [("ruido", ".DS_Store", True),
         ("ruido", "~$orcamento.docx", True),
         ("ruido", "Instrucao-Thumbs.db-revisao.pdf", False),
         ("ruido", "Mapa~$Rev2.pdf", False),
         ("ruido", "relatorio.tmp.pdf", False),
         ("inventario", "Instrucao-Thumbs.db-revisao.pdf", True),
         ("inventario", "Mapa~$Rev2.pdf", True),
         ("inventario", "relatorio.tmp.pdf", True),
         ("cobertura", ".DS_Store", True)],
        extra=["--sem-ruido"])

    caso_inventario(
        "sem --sem-ruido o ruido fica no inventario, so marcado",
        {".DS_Store": b"\x00", "ok.txt": "c"},
        1,
        [("inventario", "ruido provavel", True),
         ("inventario", ".DS_Store", True),
         ("nao-lidos", ".DS_Store", True)])

    caso_inventario(
        "nome que sugere remuneracao e marcado e nao removido",
        {"rh/folha de pagamento marco.xlsx": b"x", "ok.txt": "c"},
        0,
        [("inventario", "rh/folha de pagamento marco.xlsx", True),
         ("inventario", "nao entra em nenhum modo de leitura", True),
         ("cobertura", "Isto nao e prova de ausencia", False),
         ("cobertura", "nao entram em nenhum modo", True)])

    caso_inventario(
        "pasta ignorada sai nomeada e o que esta dentro nao e contado",
        {"arquivo morto/velho.pdf": PDF_OK, "ok.txt": "c"},
        1,
        [("nao-lidos", "pasta ignorada por pedido", True),
         ("nao-lidos", "arquivo morto", True),
         ("inventario", "velho.pdf", False),
         ("cobertura", "nao foi contado", True)],
        extra=["--ignorar-pasta", "arquivo morto"])

    caso_inventario(
        "--raiz-como troca o absoluto e mantem o relativo",
        {"pasta/doc.pdf": PDF_OK},
        0,
        [("inventario", "ACERVO/pasta/doc.pdf", True),
         ("inventario", "pasta/doc.pdf", True)],
        extra=["--raiz-como", "ACERVO"])

    caso_inventario(
        "--contar-paginas: pdf coerente devolve o numero",
        {"doc.pdf": PDF_OK},
        0,
        [("inventario", "conferido com /Count", True)],
        extra=["--contar-paginas"])

    caso_inventario(
        "--contar-paginas: contagens divergentes nao viram numero",
        {"doc.pdf": PDF_DIVERGE},
        0,
        [("inventario", "nao apurado: /Type /Page deu 2 e /Count deu 5", True)],
        extra=["--contar-paginas"])

    # PDF com senha so de proprietario abre em qualquer leitor sem senha. O
    # /Encrypt marca, e nao tira o documento da leitura: rebaixar mandava a
    # pessoa procurar uma senha que nao existe.
    caso_inventario(
        "pdf com /Encrypt e marcado e continua legivel, nao rebaixado",
        {"doc.pdf": PDF_SENHA, "ok.txt": "c"},
        0,
        [("inventario", "pdf declara /Encrypt", True),
         ("inventario", "doc.pdf", True),
         ("inventario", "protegido por senha", False),
         ("nao-lidos", "doc.pdf", False)],
        extra=["--contar-paginas"])

    caso_inventario(
        "formato antigo de escritorio e falha de ferramenta, nao escolha",
        {"Controle OS 2014.xls": b"legado", "PQ-014.doc": b"legado",
         "Apresentacao.ppt": b"legado", "ok.txt": "c"},
        1,
        [("inventario", "formato antigo de escritorio", True),
         ("inventario", "documento, leitura pelo modelo", False),
         ("nao-lidos", "Salve como PDF ou no formato novo", True),
         ("nao-lidos", "Controle OS 2014.xls", True),
         ("cobertura", "formato antigo de escritorio | 3", True)])

    caso_inventario(
        "--ignorar-pasta aceita o nome com barra no fim, como o terminal escreve",
        {"04 - RH/Folha de pagamento 09-2019.xlsx": b"x", "ok.txt": "c"},
        1,
        [("inventario", "Folha de pagamento", False),
         ("nao-lidos", "pasta ignorada por pedido", True),
         ("cobertura", "| pastas ignoradas | 1 |", True)],
        extra=["--ignorar-pasta", "04 - RH/"])

    caso_inventario(
        "--ignorar-pasta que nao casa com nada derruba antes de gravar",
        {"04 - RH/Folha de pagamento 09-2019.xlsx": b"x", "ok.txt": "c"},
        3,
        [("stderr", "nao casou com nenhuma pasta encontrada", True),
         ("inventario", "ok.txt", False)],
        extra=["--ignorar-pasta", "RH"])

    caso_inventario(
        "--extrair-texto apura data e entidade por maquina, e nao so conta pagina",
        {"procedimentos/PQ-014 rev3.txt":
         "PQ-014 rev3\nEmitido em 04/07/2018\nInspecao de solda conforme "
         "ABNT NBR 15239.\nEquipamento TQ-100, OS 4471.\n"},
        0,
        [("termos", "2018-07-04", True),
         ("termos", "ABNT NBR 15239", True),
         ("termos", "TQ-100", True),
         ("termos", "OS 4471", True),
         ("termos", "padrao dd/mm/aaaa", True),
         ("cobertura", "arquivos com data apurada por maquina | 1", True)],
        extra=["--extrair-texto"])

    # A regra de dado sensivel valendo tambem na extracao: o arquivo cujo nome
    # sugere remuneracao individual nao entra em nenhum modo de leitura, e
    # extracao de texto e leitura.
    caso_inventario(
        "--extrair-texto nao abre arquivo marcado como remuneracao",
        {"rh/folha de pagamento marco.csv":
         "nome;salario\nfulano;12/03/2019\n", "ok.txt": "data 05/06/2020"},
        0,
        [("termos", "nao entra em nenhum modo de leitura", True),
         ("termos", "2019-03-12", False),
         ("termos", "2020-06-05", True)],
        extra=["--extrair-texto"])

    caso_inventario(
        "--extrair-texto: pacote de escritorio tem o texto lido por zipfile",
        {"analise.docx": docx_com_texto("Analise critica de projeto. Data da "
                                        "reuniao: 18/11/2022. Equipamento "
                                        "BM-420, norma ISO 9001."),
         "controle.xlsx": xlsx_com_texto("Controle de OS 7781 em 03/02/2020")},
        0,
        [("termos", "2022-11-18", True),
         ("termos", "BM-420", True),
         ("termos", "ISO 9001", True),
         ("termos", "word/document.xml", True),
         ("termos", "2020-02-03", True),
         ("termos", "xl/sharedStrings.xml", True)],
        extra=["--extrair-texto"])

    caso_inventario(
        "--extrair-texto: pdf sem texto legivel sai nomeado e nao inventa data",
        {"digitalizado.pdf": b"%PDF-1.4\n1 0 obj\n<< /Type /Page >>\nendobj\n"
                             b"%%EOF\n"},
        0,
        [("termos", "nao extraido", True),
         ("termos", "nao apurado", True),
         ("cobertura", "arquivos sem texto extraido", True)],
        extra=["--extrair-texto"])

    caso_inventario(
        "--contar-paginas: docx declara as paginas, xlsx as abas",
        {"doc.docx": docx_bytes(7)},
        0,
        [("inventario", "docProps/app.xml", True),
         ("inventario", ";7;", True)],
        extra=["--contar-paginas"])

    caso_inventario(
        "--contar-paginas: pacote que nao abre vira protegido, nao sumico",
        {"falso.docx": b"nao sou um zip", "ok.txt": "c"},
        1,
        [("inventario", "falso.docx", True),
         ("nao-lidos", "protegido por senha", True)],
        extra=["--contar-paginas"])

    caso_inventario(
        "duplicatas saem agrupadas e nenhuma copia some",
        {"a/proposta.pdf": PDF_OK, "b/proposta (1).pdf": PDF_OK,
         "c/outro.txt": "x"},
        0,
        [("inventario", "a/proposta.pdf", True),
         ("inventario", "b/proposta (1).pdf", True),
         ("inventario", "G001", True),
         ("cobertura", "seis copias ha seis lugares", True)],
        extra=["--marcar-duplicatas"])

    caso_inventario(
        "datas concentradas viram alerta contra usar mtime como data",
        {"a%d.txt" % i: "x" for i in range(6)},
        0,
        [("cobertura", "Pasta copiada de rede ou de backup", True)])

    caso_inventario(
        "saida dentro da pasta varrida e recusada",
        {"ok.txt": "c"}, 3,
        [("stderr", "esta dentro da pasta varrida", True)],
        saida_dentro=True)

    def cria_saida(pasta, saida):
        saida.mkdir(parents=True)

    caso_inventario(
        "diretorio de saida existente sem --forcar e recusado",
        {"ok.txt": "c"}, 3,
        [("stderr", "ja existe", True)],
        antes=cria_saida)

    with tempfile.TemporaryDirectory() as tmp:
        proc = rodar([str(INVENTARIAR), "--pasta",
                      str(Path(tmp) / "nao existe"), "--saida",
                      str(Path(tmp) / "s")])
        registrar("pasta inexistente e recusada com codigo 3",
                  [] if proc.returncode == 3 and "nao existe" in proc.stderr
                  else ["codigo %d, stderr %s" % (proc.returncode,
                                                  proc.stderr.strip())])


def testes_sistema_de_arquivos():
    if os.name != "posix":
        pular("pasta que nao pode ser listada sai nomeada",
              "so roda em posix")
        pular("atalho de pasta nao seguido sai nomeado", "so roda em posix")
        pular("atalho quebrado sai nomeado", "so roda em posix")
        pular("ciclo de atalho nao inventaria o mesmo documento duas vezes",
              "so roda em posix")
        pular("par de atalhos apontando um para o outro nao repete documento",
              "so roda em posix")
        pular("--raiz-como nao deixa o caminho da raiz em arquivo gravado",
              "so roda em posix")
        return
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        pular("pasta que nao pode ser listada sai nomeada",
              "rodando como root, a permissao nao barra")
        pular("--raiz-como nao deixa o caminho da raiz em arquivo gravado",
              "rodando como root, a permissao nao barra")
    else:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            pasta = base / "acervo"
            pasta.mkdir()
            montar(pasta, {"ok.txt": "c", "fechada/dentro.pdf": PDF_OK})
            fechada = pasta / "fechada"
            os.chmod(str(fechada), 0o000)
            try:
                proc = rodar([str(INVENTARIAR), "--pasta", str(pasta),
                              "--saida", str(base / "saida")])
                nao = leia(base / "saida" / "nao-lidos.csv")
                cob = leia(base / "saida" / "cobertura.md")
                erros = []
                if proc.returncode != 1:
                    erros.append("codigo %d, esperado 1. stderr %s"
                                 % (proc.returncode, proc.stderr.strip()))
                if "pasta nao pode ser listada" not in nao:
                    erros.append("nao-lidos.csv nao nomeia a pasta fechada")
                if "fechada" not in cob:
                    erros.append("a cobertura nao nomeia a pasta fechada")
                registrar("pasta que nao pode ser listada sai nomeada", erros)
            finally:
                os.chmod(str(fechada), 0o755)

        # --raiz-como e vendida como o mecanismo que permite o indice circular
        # sem o nome do servidor e o do usuario. O texto do erro do sistema
        # operacional carrega o caminho absoluto inteiro, e ele passava para a
        # coluna motivo do nao-lidos.csv e para a cobertura, que sao justamente
        # os dois arquivos que o nivel 1 do modo de dado sensivel manda colar.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            pasta = base / "acervo"
            pasta.mkdir()
            montar(pasta, {"ok.txt": "c", "fechada/dentro.pdf": PDF_OK})
            fechada = pasta / "fechada"
            os.chmod(str(fechada), 0o000)
            try:
                saida = base / "saida"
                proc = rodar([str(INVENTARIAR), "--pasta", str(pasta),
                              "--saida", str(saida), "--raiz-como",
                              "ACERVO_ENGENHARIA"])
                erros = []
                if proc.returncode != 1:
                    erros.append("codigo %d, esperado 1" % proc.returncode)
                alvo = str(pasta)
                for nome in ("inventario.csv", "nao-lidos.csv",
                             "cobertura.md"):
                    conteudo = leia(saida / nome)
                    if alvo in conteudo:
                        erros.append("%s carrega o caminho da raiz" % nome)
                    if "ACERVO_ENGENHARIA" not in conteudo:
                        erros.append("%s nao traz o rotulo" % nome)
                if "pasta nao pode ser listada" not in leia(saida
                                                            / "nao-lidos.csv"):
                    erros.append("a pasta fechada deixou de sair nomeada")
                registrar("--raiz-como nao deixa o caminho da raiz em arquivo "
                          "gravado", erros)
            finally:
                os.chmod(str(fechada), 0o755)

    # O caso que produzia 33 linhas de inventario para 1 documento, com as
    # quatro identidades de fechamento dando fecha e codigo de saida 1.
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        pasta = base / "acervo"
        (pasta / "projetos").mkdir(parents=True)
        (pasta / "projetos" / "doc.txt").write_text("c", encoding="utf-8")
        os.symlink(str(pasta), str(pasta / "projetos" / "volta para a raiz"))
        saida = base / "saida"
        proc = rodar([str(INVENTARIAR), "--pasta", str(pasta), "--saida",
                      str(saida), "--seguir-atalhos"])
        inv = leia(saida / "inventario.csv")
        cob = leia(saida / "cobertura.md")
        erros = []
        if proc.returncode != 1:
            erros.append("codigo %d, esperado 1" % proc.returncode)
        linhas_doc = [l for l in inv.splitlines() if "doc.txt" in l]
        if len(linhas_doc) != 1:
            erros.append("doc.txt aparece em %d linhas do inventario, "
                         "esperado 1" % len(linhas_doc))
        if "ciclo" not in cob:
            erros.append("a cobertura nao diz a palavra ciclo")
        if "ciclo de atalho" not in leia(saida / "nao-lidos.csv"):
            erros.append("o ciclo nao saiu nomeado em nao-lidos.csv")
        if "QUEBRA" in proc.stdout:
            erros.append("o fechamento quebrou numa rodada que deveria fechar")
        registrar("ciclo de atalho nao inventaria o mesmo documento duas vezes",
                  erros)

    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        pasta = base / "acervo"
        (pasta / "a").mkdir(parents=True)
        (pasta / "b").mkdir()
        (pasta / "a" / "doc.txt").write_text("c", encoding="utf-8")
        os.symlink(str(pasta / "b"), str(pasta / "a" / "para b"))
        os.symlink(str(pasta / "a"), str(pasta / "b" / "para a"))
        saida = base / "saida"
        proc = rodar([str(INVENTARIAR), "--pasta", str(pasta), "--saida",
                      str(saida), "--seguir-atalhos"])
        inv = leia(saida / "inventario.csv")
        erros = []
        if proc.returncode != 1:
            erros.append("codigo %d, esperado 1" % proc.returncode)
        linhas_doc = [l for l in inv.splitlines() if "doc.txt" in l]
        if len(linhas_doc) != 1:
            erros.append("doc.txt aparece em %d linhas do inventario, "
                         "esperado 1" % len(linhas_doc))
        if "ciclo de atalho" not in leia(saida / "nao-lidos.csv"):
            erros.append("o par de atalhos nao saiu nomeado")
        registrar("par de atalhos apontando um para o outro nao repete "
                  "documento", erros)

    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        pasta = base / "acervo"
        (pasta / "sub").mkdir(parents=True)
        fora = base / "fora"
        fora.mkdir()
        (fora / "escondido.pdf").write_bytes(PDF_OK)
        (pasta / "ok.txt").write_text("c", encoding="utf-8")
        os.symlink(str(fora), str(pasta / "atalho"))
        proc = rodar([str(INVENTARIAR), "--pasta", str(pasta), "--saida",
                      str(base / "saida")])
        nao = leia(base / "saida" / "nao-lidos.csv")
        inv = leia(base / "saida" / "inventario.csv")
        erros = []
        if proc.returncode != 1:
            erros.append("codigo %d, esperado 1" % proc.returncode)
        if "atalho para pasta, nao seguido" not in nao:
            erros.append("o atalho de pasta nao saiu nomeado")
        if "escondido.pdf" in inv:
            erros.append("entrou no atalho sem --seguir-atalhos")
        registrar("atalho de pasta nao seguido sai nomeado", erros)

    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        pasta = base / "acervo"
        pasta.mkdir()
        (pasta / "ok.txt").write_text("c", encoding="utf-8")
        os.symlink(str(base / "nao existe.pdf"), str(pasta / "quebrado.pdf"))
        proc = rodar([str(INVENTARIAR), "--pasta", str(pasta), "--saida",
                      str(base / "saida")])
        nao = leia(base / "saida" / "nao-lidos.csv")
        inv = leia(base / "saida" / "inventario.csv")
        erros = []
        if proc.returncode != 1:
            erros.append("codigo %d, esperado 1" % proc.returncode)
        if "atalho quebrado" not in nao or "quebrado.pdf" not in nao:
            erros.append("o atalho quebrado nao saiu nomeado")
        if "quebrado.pdf" not in inv:
            erros.append("o atalho quebrado sumiu do inventario")
        registrar("atalho quebrado sai nomeado e fica no inventario", erros)


def testes_sabotagem():
    """A pergunta que gerou estes dois: existe caminho em que o script sai com
    sucesso tendo perdido arquivo? Aqui o ramo e mutilado de proposito."""
    original = INVENTARIAR.read_text(encoding="utf-8")
    ancora = ('    reg.contagem["arquivos_inventariados"] += 1\n'
              '    reg.inventario.append({\n')
    if ancora not in original:
        registrar("sabotagem: ancora do ramo de gravacao",
                  ["a ancora mudou, os dois casos de sabotagem nao rodaram"])
        return

    variantes = [
        ("sabotagem: contador sobe e a linha nao e gravada",
         '    reg.contagem["arquivos_inventariados"] += 1\n'
         '    if "sumir" in nome:\n        return\n'
         '    reg.inventario.append({\n'),
        ("sabotagem: a linha some sem o contador subir",
         '    if "sumir" in nome:\n        return\n'
         '    reg.contagem["arquivos_inventariados"] += 1\n'
         '    reg.inventario.append({\n'),
    ]
    for nome, substituto in variantes:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            copia = base / "inventariar_sabotado.py"
            copia.write_text(original.replace(ancora, substituto),
                             encoding="utf-8")
            pasta = base / "acervo"
            pasta.mkdir()
            montar(pasta, {"relatorio-sumir.pdf": PDF_OK, "ok.txt": "c"})
            proc = rodar([str(copia), "--pasta", str(pasta), "--saida",
                          str(base / "saida")])
            erros = []
            if proc.returncode != 3:
                erros.append("codigo %d, esperado 3: o script perdeu arquivo "
                             "e nao foi derrubado" % proc.returncode)
            if "QUEBRA" not in proc.stdout:
                erros.append("nenhuma identidade acusou QUEBRA")
            if "relatorio-sumir.pdf" not in (proc.stdout
                                             + leia(base / "saida"
                                                    / "cobertura.md")):
                erros.append("o arquivo perdido nao foi nomeado")
            registrar(nome, erros)

    # A outra ponta da lei de ferro 'uma linha por documento': arquivo contado
    # duas vezes. Era assim que o ciclo de atalho passava, e por isso a
    # identidade nao pode depender de ninguem ter lembrado do ciclo.
    ancora_dupla = "    escrever_csv(arq_inv, COLUNAS_INVENTARIO, reg.inventario)"
    if ancora_dupla not in original:
        registrar("sabotagem: a mesma linha gravada duas vezes",
                  ["a ancora da gravacao do inventario mudou"])
        return
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        copia = base / "inventariar_duplicado.py"
        copia.write_text(original.replace(
            ancora_dupla,
            "    escrever_csv(arq_inv, COLUNAS_INVENTARIO,\n"
            "                 reg.inventario + [l for l in reg.inventario\n"
            "                                   if 'dobrar' in l['nome']])"),
            encoding="utf-8")
        pasta = base / "acervo"
        pasta.mkdir()
        montar(pasta, {"proposta-dobrar.pdf": PDF_OK, "ok.txt": "c"})
        proc = rodar([str(copia), "--pasta", str(pasta), "--saida",
                      str(base / "saida")])
        erros = []
        if proc.returncode != 3:
            erros.append("codigo %d, esperado 3: o mesmo documento entrou duas "
                         "vezes e o fechamento fechou" % proc.returncode)
        if "QUEBRA" not in proc.stdout:
            erros.append("nenhuma identidade acusou QUEBRA")
        if "proposta-dobrar.pdf" not in proc.stdout:
            erros.append("o caminho repetido nao foi nomeado")
        registrar("sabotagem: a mesma linha gravada duas vezes", erros)


# ------------------------------------------------------------------- indice

CAB_INDICE = ["id", "caminho", "data_do_documento", "origem_da_data",
              "assunto", "resumo", "entidades", "status_leitura"]


def indice_padrao(saida):
    """O indice que a skill manda escrever, com os campos que a varredura ja
    apurou copiados do termos-por-documento.csv quando ele existe."""
    termos = {}
    for linha in ler_csv(saida / "termos-por-documento.csv"):
        termos[linha["caminho"]] = linha
    linhas = []
    for linha in ler_csv(saida / "inventario.csv"):
        status = linha["status_leitura"]
        if status == "inventariado":
            resumo = "Resumo de uma linha do documento."
        else:
            resumo = "NAO LIDO: %s" % (linha["motivo"] or status)
        termo = termos.get(linha["caminho"], {})
        data = termo.get("data_no_texto") or ""
        entidades = termo.get("entidades_no_texto") or ""
        linhas.append({
            "id": linha["id"],
            "caminho": linha["caminho"],
            "data_do_documento": (data if data and data != "nao apurado"
                                  else "2026-03-14"),
            "origem_da_data": (termo.get("origem_da_data")
                               if data and data != "nao apurado"
                               else "cabecalho do documento"),
            "assunto": "inspecao de solda",
            "resumo": resumo,
            "entidades": entidades or "nao apurado",
            "status_leitura": status,
        })
    return linhas


def gravar_indice(saida, linhas, com_marcas=True, com_rodape=True,
                  md_sem_caminho=False, sem_md=False, caminho_primeiro=False,
                  rodape_sem_prefixo=False):
    with (saida / "indice.csv").open("w", encoding="utf-8-sig",
                                     newline="") as fh:
        w = csv.writer(fh, delimiter=";", lineterminator="\r\n")
        w.writerow(CAB_INDICE)
        for l in linhas:
            w.writerow([l.get(c, "") for c in CAB_INDICE])
        rodape = ("Gerado com apoio de IA a partir da varredura da pasta do "
                  "acervo. Revisar antes de assinar. Nao substitui "
                  "responsabilidade tecnica.")
        w.writerow([rodape if rodape_sem_prefixo else "# " + rodape]
                   + [""] * 7)
    if sem_md:
        return
    corpo = ["# Indice do acervo da area", ""]
    if com_marcas:
        corpo.append("<!-- inicio do indice -->")
    corpo.append("")
    if caminho_primeiro:
        corpo.append("| Caminho | Data | Assunto | Resumo | Entidades |")
        corpo.append("|---|---|---|---|---|")
    else:
        corpo.append("| Id | Data | Assunto | Resumo | Entidades | Caminho |")
        corpo.append("|---|---|---|---|---|---|")
    for i, l in enumerate(linhas):
        caminho = "" if (md_sem_caminho and i == 0) else "`%s`" % l["caminho"]
        if caminho_primeiro:
            corpo.append("| %s | %s | %s | %s | %s |"
                         % (caminho, l["data_do_documento"], l["assunto"],
                            l["resumo"], l["entidades"]))
        else:
            corpo.append("| %s | %s | %s | %s | %s | %s |"
                         % (l["id"], l["data_do_documento"], l["assunto"],
                            l["resumo"], l["entidades"], caminho))
    corpo.append("")
    if com_marcas:
        corpo.append("<!-- fim do indice -->")
    corpo.append("")
    if com_rodape:
        corpo.append("Gerado com apoio de IA a partir da varredura da pasta "
                     "do acervo. Revisar antes de assinar. Nao substitui "
                     "responsabilidade tecnica.")
    (saida / "indice.md").write_text("\n".join(corpo), encoding="utf-8")


def caso_indice(nome, arquivos, mutar, esperado, checagens, gabarito=None,
                extra_inv=None, **kw):
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        pasta = base / "acervo"
        pasta.mkdir()
        montar(pasta, arquivos)
        saida = base / "saida"
        cmd_inv = [str(INVENTARIAR), "--pasta", str(pasta), "--saida",
                   str(saida)]
        if extra_inv:
            cmd_inv += extra_inv
        proc = rodar(cmd_inv)
        if proc.returncode not in (0, 1):
            registrar(nome, ["a varredura falhou: %s" % proc.stderr.strip()])
            return
        linhas = indice_padrao(saida)
        if mutar:
            linhas = mutar(linhas)
        gravar_indice(saida, linhas, **kw)
        cmd = [str(CONFERIR), "--rodada", str(saida)]
        if gabarito is not None:
            arq = base / "gabarito.csv"
            arq.write_text(gabarito, encoding="utf-8")
            cmd += ["--gabarito", str(arq)]
        proc2 = rodar(cmd)
        erros = []
        if proc2.returncode != esperado:
            erros.append("codigo de saida %d, esperado %d. stdout: %s"
                         % (proc2.returncode, esperado,
                            proc2.stdout.strip()[-500:]))
        mapa = {"stdout": proc2.stdout, "stderr": proc2.stderr,
                "cobertura": leia(saida / "cobertura.md"),
                "gabarito": leia(saida / "gabarito-conferido.csv"),
                "nao-lidos-na-leitura": leia(saida
                                             / "nao-lidos-na-leitura.csv")}
        for alvo, texto, deve in checagens:
            presente = texto in mapa[alvo]
            if presente != deve:
                erros.append("%s: %s '%s'"
                             % (alvo, "nao devia conter" if presente
                                else "devia conter", texto))
        registrar(nome, erros)


TRES = {"a.pdf": PDF_OK, "b/c.txt": "texto", "d.docx": docx_bytes(2)}
TRES_COM_FALHA = {"a.pdf": PDF_OK, "vazio.pdf": b"",
                  "desenho.dwg": b"AC1024"}


def testes_indice():
    caso_indice(
        "indice completo e tudo lido sai com 0",
        TRES, None, 0,
        [("stdout", "fecha", True), ("stdout", "QUEBRA", False),
         ("cobertura", "status: completo", True)])

    # O caso central desta skill.
    caso_indice(
        "documento faltando no indice derruba a rodada",
        TRES, lambda ls: [l for l in ls if not l["caminho"].endswith("c.txt")],
        3,
        [("stdout", "b/c.txt", True),
         ("stdout", "nunca some", True),
         ("cobertura", "status: invalido, nao fecha", True)])

    # O outro caso central: fingir que leu.
    caso_indice(
        "resumo escrito para documento que a varredura nao leu derruba",
        TRES_COM_FALHA,
        lambda ls: [dict(l, resumo="Relatorio de inspecao de marco.")
                    if l["caminho"] == "vazio.pdf" else l for l in ls],
        3,
        [("stdout", "Resumo de documento nao lido e invencao", True)])

    caso_indice(
        "documento nao lido, marcado como nao lido, sai com 1 e nao com 0",
        TRES_COM_FALHA, None, 1,
        [("stdout", "nao lidos por falha da varredura ........ 2", True),
         ("cobertura", "status: completo com pendencias", True)])

    caso_indice(
        "documento legivel que a leva nao leu continua no indice, codigo 1",
        TRES,
        lambda ls: [dict(l, resumo="NAO LIDO: nao selecionado nesta leva")
                    if l["caminho"] == "a.pdf" else l for l in ls],
        1,
        [("stdout", "nao lidos por escolha, ainda no indice .. 1", True)])

    caso_indice(
        "caminho em branco no indice derruba",
        TRES,
        lambda ls: [dict(l, caminho="") if l["caminho"] == "a.pdf" else l
                    for l in ls],
        3, [("stdout", "Caminho e obrigatorio em toda linha", True)])

    caso_indice(
        "caminho repetido no indice derruba",
        TRES,
        lambda ls: ls + [dict(ls[0])],
        3, [("stdout", "aparece mais de uma vez", True)])

    caso_indice(
        "campo obrigatorio em branco derruba: falta e 'nao apurado' escrito",
        TRES,
        lambda ls: [dict(l, entidades="") if l["caminho"] == "a.pdf" else l
                    for l in ls],
        3, [("stdout", "esta em branco", True)])

    caso_indice(
        "documento que nao esta na pasta derruba: indice nao inventa",
        TRES,
        lambda ls: ls + [dict(ls[0], id="D9999",
                              caminho="inventado/nao existe.pdf")],
        3, [("stdout", "Indice nao inventa documento", True)])

    caso_indice(
        "status de leitura reescrito a mao derruba",
        TRES_COM_FALHA,
        lambda ls: [dict(l, status_leitura="inventariado",
                         resumo="NAO LIDO: x")
                    if l["caminho"] == "vazio.pdf" else l for l in ls],
        3, [("stdout", "nao se reescreve a mao", True)])

    caso_indice(
        "linha do indice.md sem caminho derruba: a lei de ferro e mecanica",
        TRES, None, 3,
        [("stdout", "linha de tabela sem caminho", True)],
        md_sem_caminho=True)

    caso_indice(
        "indice.md sem as marcas de inicio e fim derruba",
        TRES, None, 3,
        [("stdout", "nao tem as marcas", True)], com_marcas=False)

    caso_indice(
        "indice.md sem o rodape obrigatorio derruba",
        TRES, None, 3,
        [("stdout", "nao traz o rodape obrigatorio", True)], com_rodape=False)

    caso_indice(
        "indice.md ausente derruba: o indice que a pessoa consulta e ele",
        TRES, None, 3,
        [("stdout", "indice.md nao existe", True)], sem_md=True)

    caso_indice(
        "gabarito que bate nao muda o codigo",
        TRES, None, 0,
        [("gabarito", "sim", True)],
        gabarito=("caminho;data_do_documento;assunto\n"
                  "a.pdf;2026-03-14;inspecao de solda\n"))

    caso_indice(
        "gabarito que nao bate sai com 2 e nao vai para o trabalho real",
        TRES, None, 2,
        [("stderr", "o gabarito nao bateu", True),
         ("cobertura", "status: gabarito nao bateu", True)],
        gabarito=("caminho;data_do_documento;assunto\n"
                  "a.pdf;2025-01-02;inspecao de solda\n"))

    caso_indice(
        "gabarito que aponta documento fora do indice derruba",
        TRES, None, 3,
        [("stdout", "que nao esta no indice", True),
         ("stdout", "caminho relativo a raiz varrida", True)],
        gabarito=("caminho;data_do_documento;assunto\n"
                  "nao existe.pdf;2026-03-14;x\n"))

    # O portao que libera o uso no trabalho real passava comparando zero campos.
    caso_indice(
        "gabarito com as colunas em branco nao valida nada: codigo 2",
        TRES, None, 2,
        [("stderr", "nao comparou nenhum campo", True),
         ("stdout", "gabarito: 0 campos comparados", True),
         ("cobertura", "status: gabarito nao comparou nada", True)],
        gabarito=("caminho;data_do_documento;assunto\n"
                  "a.pdf;;\n"
                  "b/c.txt;;\n"))

    caso_indice(
        "rodada sem gabarito marca a saida como nao validada no arquivo",
        TRES, None, 0,
        [("cobertura", "gabarito: nao rodado nesta rodada, saida nao validada",
          True),
         ("cobertura", "status: completo, nao validado", True)])

    # O conferidor derrubava todo indice.md cuja tabela nao comecasse pela
    # coluna Id, e a mensagem culpava a linha de cabecalho.
    caso_indice(
        "indice.md com Caminho na primeira coluna nao derruba a rodada",
        TRES, None, 0,
        [("stdout", "linha de tabela sem caminho", False),
         ("stdout", "fecha", True)],
        caminho_primeiro=True)

    caso_indice(
        "data certa no formato do documento bate contra o indice em aaaa-mm-dd",
        TRES, None, 0,
        [("gabarito", "sim", True), ("gabarito", "nao", False)],
        gabarito=("caminho;data_do_documento;assunto\n"
                  "a.pdf;14/03/2026;inspecao de solda\n"))

    caso_indice(
        "NAO LIDO entre crases nao e acusado de invencao de resumo",
        TRES_COM_FALHA,
        lambda ls: [dict(l, resumo="`%s`" % l["resumo"]) for l in ls],
        1,
        [("stdout", "Resumo de documento nao lido e invencao", False),
         ("stdout", "que nao esta no inventario", False)])

    caso_indice(
        "rodape do indice.csv sem o prefixo nao vira linha de dado",
        TRES, None, 0,
        [("stdout", "sem caminho", False), ("stdout", "fecha", True)],
        rodape_sem_prefixo=True)

    caso_indice(
        "documento aberto e nao entendido conta como falha na leitura",
        TRES,
        lambda ls: [dict(l, resumo="NAO LIDO: ilegivel, digitalizacao torta")
                    if l["caminho"] == "a.pdf" else l for l in ls],
        1,
        [("stdout", "nao lidos por falha na leitura .......... 1", True),
         ("stdout", "nao lidos por escolha, ainda no indice .. 0", True),
         ("nao-lidos-na-leitura", "a.pdf", True),
         ("cobertura", "nao-lidos-na-leitura.csv | 1", True)])

    caso_indice(
        "id trocado no indice derruba: o id vem da varredura",
        TRES,
        lambda ls: [dict(l, id="D9999") if l["caminho"] == "a.pdf" else l
                    for l in ls],
        3, [("stdout", "o id do indice diz", True)])

    caso_indice(
        "id em branco no indice derruba",
        TRES,
        lambda ls: [dict(l, id="") if l["caminho"] == "a.pdf" else l
                    for l in ls],
        3, [("stdout", "a coluna id esta em branco", True)])

    # O principio acima dos achados: a rodada nao fecha tendo descartado dado
    # que ela mesma ja apurou.
    caso_indice(
        "indice que descarta a data apurada por maquina derruba",
        {"procedimentos/PQ-014.txt":
         "PQ-014 rev3\nEmitido em 04/07/2018\nInspecao de solda, TQ-100.\n"},
        lambda ls: [dict(l, resumo="NAO LIDO: nao selecionado nesta leva",
                         data_do_documento="nao apurado",
                         origem_da_data="nao apurado",
                         entidades="nao apurado") for l in ls],
        3,
        [("stdout", "a extracao por maquina apurou a data", True),
         ("stdout", "nao se descarta", True)],
        extra_inv=["--extrair-texto"])

    caso_indice(
        "linha nao lida com a data da maquina copiada fecha com 1",
        {"procedimentos/PQ-014.txt":
         "PQ-014 rev3\nEmitido em 04/07/2018\nInspecao de solda, TQ-100.\n"},
        lambda ls: [dict(l, resumo="NAO LIDO: nao selecionado nesta leva")
                    for l in ls],
        1,
        [("stdout", "nao lidos por escolha, ainda no indice .. 1", True),
         ("stdout", "nao se descarta", False)],
        extra_inv=["--extrair-texto"])

    # O caso normal, e o que a guarda invertida deixava passar: documento
    # LIDO. A checagem exigia tambem que a linha estivesse marcada como NAO
    # LIDO, que e justamente a linha sem dado apurado. Documento lido podia
    # zerar data e entidades e a rodada fechava com codigo 0.
    caso_indice(
        "indice que descarta o dado apurado em documento LIDO derruba",
        {"procedimentos/PQ-014.txt":
         "PQ-014 rev3\nEmitido em 04/07/2018\nInspecao de solda, TQ-100.\n"},
        lambda ls: [dict(l, data_do_documento="nao apurado",
                         origem_da_data="nao apurado",
                         entidades="nao apurado") for l in ls],
        3,
        [("stdout", "a extracao por maquina apurou a data", True),
         ("stdout", "a extracao por maquina apurou as entidades", True),
         ("stdout", "nao se descarta", True),
         ("cobertura", "status: invalido, nao fecha", True)],
        extra_inv=["--extrair-texto"])

    caso_indice(
        "documento LIDO com o dado da maquina copiado fecha com 0",
        {"procedimentos/PQ-014.txt":
         "PQ-014 rev3\nEmitido em 04/07/2018\nInspecao de solda, TQ-100.\n"},
        None, 0,
        [("stdout", "nao se descarta", False),
         ("cobertura", "status: completo", True)],
        extra_inv=["--extrair-texto"])


# ------------------------------------------------- a ficha da area por maquina

FICHA_GABARITO = u"""# Ficha da area

status: rascunho, nao conferida contra documento da pessoa
gravada em: 2026-09-20 21:49
ficha em: /Users/<voce>/.kit-industrial/ficha-da-area.md
linhas de fato: 13 (derivadas de arquivo 4, respondidas pela pessoa 6, \
lacunas 3)
lacunas distintas: 3
fontes nomeadas: IT-042-rev3.pdf; export-apontamento.csv; \
certificado-iso-2024.pdf

## Área e posto
- Usinagem, planta 2. Coordenação de produção, três \
turnos. [respondida pela pessoa]

## Vocabulário local
- OP é ordem de produção, OS é ordem de serviço da \
manutenção. [derivada de IT-042-rev3.pdf]
- "Parada" é máquina parada com apontamento aberto, não \
intervalo de turno. [respondida pela pessoa]

## Sistemas e o que cada um exporta
- O ERP exporta a carteira em CSV, mas quem tira é o PCP. \
[respondida pela pessoa]
- Não sei se o sistema de manutenção exporta alguma coisa. \
[lacuna]

## Ritos e prazos
- Fechamento no terceiro dia útil. [derivada de IT-042-rev3.pdf]

## Normas e certificações
- Escopo certificado: usinagem e montagem, planta 2. [derivada de \
certificado-iso-2024.pdf]
- ISO 9001 é a norma da casa. Ninguém aqui leu a cláusula na \
cópia vigente da empresa. [respondida pela pessoa]

## Lacunas declaradas
- Ritos e prazos: nao sei qual indicador a diretoria olha. [lacuna]

Gerado com apoio de IA a partir de IT-042-rev3.pdf. Revisar antes de assinar. \
Nao substitui responsabilidade tecnica.
"""

DOC_DA_CASA = ("Registro de parada da OP 4471.\n"
               "Emitido em 04/07/2018. O operador registrou a opcao no ERP.\n")


def rodar_com_ficha(texto_da_ficha, arquivos, extra=None):
    """Roda a varredura com --extrair-texto contra uma ficha da area.

    Devolve (proc, cobertura, termos). A ficha fica FORA da pasta varrida: ela
    nao e documento do acervo."""
    tmp = tempfile.mkdtemp()
    base = Path(tmp)
    pasta = base / "acervo"
    pasta.mkdir()
    montar(pasta, arquivos)
    ficha = base / "ficha-da-area.md"
    ficha.write_text(texto_da_ficha, encoding="utf-8")
    saida = base / "saida"
    cmd = [str(INVENTARIAR), "--pasta", str(pasta), "--saida", str(saida),
           "--extrair-texto", "--ficha", str(ficha)]
    if extra:
        cmd += extra
    proc = rodar(cmd)
    return (proc, leia(saida / "cobertura.md"),
            leia(saida / "termos-por-documento.csv"))


def ficha_do_gabarito_da_skill():
    """O bloco de gabarito da ficha, lido da SKILL.md do ficha-da-area.

    Este e o teste que pega mudanca de formato do lado do escritor. O leitor
    ja saiu de sincronia uma vez: ele procurava termo entre crases, e a ficha
    nao tem crase nenhuma no corpo."""
    alvo = AQUI.parent.parent / "ficha-da-area" / "SKILL.md"
    if not alvo.exists():
        return None
    texto = alvo.read_text(encoding="utf-8")
    for bloco in re.findall(r"```markdown\n(.*?)\n```", texto, re.S):
        if "## Vocabul" in bloco and "[derivada de" in bloco:
            return bloco
    return None


def testes_ficha_da_area():
    """A ficha e a unica fonte de vocabulario da casa que o kit le por maquina.

    Zero termo de vocabulario tem que aparecer como zero. Ele ja apareceu como
    tres: a leitura raspava nome de arquivo de dentro da marca de origem, e a
    cobertura imprimia 'ficha da area lida: 3 termo(s)', que le como sucesso."""
    proc, cobertura, termos = rodar_com_ficha(
        FICHA_GABARITO, {"apontamentos/registro.txt": DOC_DA_CASA})
    erros = []
    if proc.returncode != 0:
        erros.append("codigo %d, esperado 0. stderr: %s"
                     % (proc.returncode, proc.stderr.strip()[:300]))
    for exigido, motivo in (
            ("| Vocabulario local | 3 |",
             "o vocabulario local da ficha nao chegou com os tres termos"),
            ("| Normas e certificacoes | 1 |",
             "a secao de normas nao chegou com a norma que a ficha declara"),
            ("Secao da ficha da area",
             "a cobertura nao diz de qual secao veio cada termo"),
            ("ficha da area lida: 7 termo(s) (vocabulario local 3",
             "a contagem da ficha sai sem decomposicao por secao, e foi "
             "assim que zero termo de vocabulario leu como sucesso")):
        if exigido not in cobertura:
            erros.append("%s: a cobertura nao traz '%s'" % (motivo, exigido))
    # Nome de arquivo dentro da marca de origem nao e termo da casa. Estes dois
    # sao o que a leitura antiga devolvia, e 'ISO 2024' nao e norma nenhuma.
    for proibido in ("ISO 2024", "IT-042"):
        if proibido in cobertura:
            erros.append("a cobertura traz '%s', raspado de nome de arquivo "
                         "dentro da marca de origem" % proibido)
    if "Parada" not in termos:
        erros.append("o termo de vocabulario local nao casou com o documento")
    registrar("a ficha da area entra pelas secoes, nao por crase", erros)

    # Casamento por palavra inteira. 'OP' dentro de 'operador' e de 'opcao'
    # enchia a coluna de entidades de termo que o documento nao cita.
    erros = []
    _, _, termos = rodar_com_ficha(
        FICHA_GABARITO,
        {"apontamentos/solto.txt": "O operador registrou a opcao de compra.\n"})
    for linha in ler_csv_texto(termos):
        if linha.get("caminho") == "apontamentos/solto.txt":
            achado = linha.get("entidades_no_texto") or ""
            if "OP" in achado.split(", "):
                erros.append("'OP' entrou como entidade de um texto que so "
                             "tem 'operador' e 'opcao': %s" % achado)
    registrar("termo curto da ficha casa como palavra, nao como pedaco", erros)

    # Ficha sem a secao de vocabulario sai como zero, nao como sucesso.
    erros = []
    sem_vocabulario = FICHA_GABARITO.replace(u"## Vocabulário local",
                                             u"## Ritos e prazos")
    _, cobertura, _ = rodar_com_ficha(
        sem_vocabulario, {"apontamentos/registro.txt": DOC_DA_CASA})
    if "| Vocabulario local | 0 |" not in cobertura:
        erros.append("a ficha sem a secao de vocabulario nao sai com zero na "
                     "cobertura")
    registrar("ficha sem vocabulario local sai como zero na cobertura", erros)

    # O outro lado da prova: o formato que o escritor documenta.
    gabarito = ficha_do_gabarito_da_skill()
    if gabarito is None:
        pular("o gabarito da ficha documentado casa com o leitor",
              "SKILL.md do ficha-da-area fora da arvore")
        return
    erros = []
    _, cobertura, _ = rodar_com_ficha(
        gabarito, {"apontamentos/registro.txt": DOC_DA_CASA})
    m = re.search(r"\| Vocabulario local \| (\d+) \|", cobertura)
    if not m:
        erros.append("a cobertura nao traz a linha do vocabulario local")
    elif m.group(1) == "0":
        erros.append("o gabarito documentado do ficha-da-area passa pelo "
                     "leitor com zero termo de vocabulario local: o leitor "
                     "saiu de sincronia com o formato da ficha")
    for proibido in ("ISO 2024", "IT-042"):
        if proibido in cobertura:
            erros.append("o gabarito documentado devolve '%s', que e nome de "
                         "arquivo da marca de origem" % proibido)
    registrar("o gabarito da ficha documentado casa com o leitor", erros)


def ler_csv_texto(texto):
    if not texto:
        return []
    leitor = csv.DictReader(io.StringIO(texto), delimiter=";")
    campos = leitor.fieldnames or []
    return [l for l in leitor
            if not (l.get(campos[0]) or "").startswith("# ")]


# -------------------------------------------------------------- a skill.md

def testes_skill():
    if not SKILL.exists():
        registrar("SKILL.md existe", ["nao existe %s" % SKILL])
        return
    texto = SKILL.read_text(encoding="utf-8")
    erros = []
    m = re.search(r"^---\n(.*?)\n---\n", texto, re.S)
    if not m:
        erros.append("sem frontmatter")
    else:
        frente = m.group(1)
        if "name: indice-do-acervo-da-area" not in frente:
            erros.append("o name nao e igual ao nome da pasta")
        d = re.search(r"description: >\n(.*)", frente, re.S)
        if not d:
            erros.append("a description nao esta em bloco >")
        else:
            corpo = " ".join(l.strip() for l in d.group(1).splitlines())
            corpo = re.sub(r"\s+", " ", corpo).strip()
            if len(corpo) > 1400:
                erros.append("description com %d caracteres, o limite e 1400"
                             % len(corpo))
            if "NAO use" not in corpo and "NÃO use" not in corpo:
                erros.append("a description nao fecha com o que nao usar")
    for proibido, rotulo in ((chr(0x2014), "travessao"),
                             (chr(0x2013), "meia-risca")):
        if proibido in texto:
            erros.append("o SKILL.md tem %s" % rotulo)
    for exigido in ("O kit prevê dez skills e esta versão traz dez.",
                    "Gerado com apoio de IA",
                    "rodando sem ficha da área",
                    "~/.kit-industrial/ficha-da-area.md",
                    "conferencia-entre-duas-fontes",
                    "indice-do-acervo-da-area"):
        if exigido not in texto:
            erros.append("falta no SKILL.md: %s" % exigido)
    vizinhas = ["conferencia-entre-duas-fontes",
                "extracao-de-documento-para-tabela",
                "triagem-de-caixa-de-email", "comparativo-de-cotacoes",
                "ficha-da-area", "relatorio-recorrente",
                "registro-de-anomalia", "padrao-conferido-contra-norma",
                "linha-de-base-antes-de-automatizar",
                "indice-do-acervo-da-area"]
    for v in vizinhas:
        if v not in texto:
            erros.append("a secao de skills vizinhas nao cita %s" % v)
    for exigido, motivo in (
            ("| Id | Caminho | Data | Assunto | Resumo | Entidades |",
             "o passo 6 nao mostra o cabecalho exato da tabela do indice.md"),
            ("# Gerado com apoio de IA a partir da varredura",
             "o passo 5 nao mostra a linha de rodape pronta do indice.csv"),
            ("--extrair-texto",
             "a SKILL nao traz a opcao que apura data e entidade por maquina"),
            ("caminho relativo à raiz varrida",
             "o passo 7 nao diz em que formato vai o caminho do gabarito")):
        if exigido not in texto:
            erros.append(motivo)
    registrar("SKILL.md no padrao do kit", erros)


def testes_papelada_do_kit():
    """O contrato que nao esta escrito onde a pessoa le nao existe.

    O kit ja publicou duas contagens opostas do proprio estado: a SKILL dizendo
    dez e o 00-LEIA-ME dizendo quatro, com esta skill listada como prevista."""
    leia_me = AQUI.parent.parent.parent / "00-LEIA-ME.md"
    if not leia_me.exists():
        pular("o kit nao contradiz a contagem desta skill",
              "00-LEIA-ME.md fora da arvore, skill instalada em separado")
        return
    texto = leia_me.read_text(encoding="utf-8")
    erros = []
    for frase in ("quatro skills prontas", "das dez previstas",
                  "para as quatro skills", "Tres das quatro",
                  "Três das quatro"):
        if frase in texto:
            erros.append("o 00-LEIA-ME ainda conta quatro skills: %s" % frase)
    for linha in texto.splitlines():
        if "`indice-do-acervo-da-area`" in linha and "Prevista" in linha:
            erros.append("o 00-LEIA-ME lista esta skill como prevista")
    if "ainda não existe" in texto and "ficha-da-area" in texto:
        erros.append("o 00-LEIA-ME diz que a skill da ficha da area nao existe")
    registrar("o kit nao contradiz a contagem desta skill", erros)


def main():
    testes_inventario()
    testes_sistema_de_arquivos()
    testes_sabotagem()
    testes_indice()
    testes_ficha_da_area()
    testes_skill()
    testes_papelada_do_kit()
    print("")
    if pulados:
        print("%d caso(s) pulados neste sistema:" % len(pulados))
        for nome, motivo in pulados:
            print("  %s (%s)" % (nome, motivo))
    if falhas:
        print("%d CASO(S) FALHARAM" % len(falhas))
        return 1
    print("todos os casos passaram")
    return 0


if __name__ == "__main__":
    sys.exit(main())
