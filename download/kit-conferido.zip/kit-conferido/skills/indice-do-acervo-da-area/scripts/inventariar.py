#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
inventariar.py, varredura da pasta do acervo da area.

Biblioteca padrao apenas, Python 3.8 ou superior. Sem rede. Nao escreve nada
dentro da pasta varrida.

O que ele faz, e o que ele nao faz:

  - Varre a arvore INTEIRA a partir da pasta indicada e grava uma linha por
    arquivo encontrado, com nome, caminho, extensao, tamanho e data de
    modificacao. Uma linha por documento, sempre: a varredura nao desce duas
    vezes na mesma pasta, mesmo quando um atalho fecha ciclo.
  - No modo padrao ele NAO abre nenhum arquivo. Le so o que o sistema de
    arquivos informa. A contagem de paginas exige abrir, e por isso vem
    desligada, em --contar-paginas.
  - Com --extrair-texto ele abre os formatos que a biblioteca padrao le, na
    maquina local, e apura por maquina a data escrita dentro do documento, as
    entidades citadas e um trecho de busca, em termos-por-documento.csv. E o
    que faz o indice responder "onde esta o documento que fala daquele
    equipamento" sem depender de leitura documento por documento.
  - Nada sai da maquina. O script nao tem rede.
  - O que a varredura nao conseguiu ler sai NOMEADO em nao-lidos.csv e
    continua em inventario.csv, com o motivo. Arquivo que a rodada nao leu
    nao some do inventario.

Codigos de saida:

  0  varreu, todo arquivo encontrado foi inventariado, nenhuma pasta ficou
     fora e nada foi filtrado
  1  varreu, e ha itens que nao entram na leitura: arquivos nao lidos, pastas
     que nao puderam ser listadas, pastas ignoradas por pedido, atalhos nao
     seguidos, atalho em ciclo ou ruido filtrado. Todos saem nomeados
  3  erro de entrada, nome pedido em --ignorar-pasta que nao casou com nenhuma
     pasta encontrada, ou fechamento que nao fecha

Uso:

    python3 ~/.claude/skills/indice-do-acervo-da-area/scripts/inventariar.py \
        --pasta "/caminho/da/pasta/da/area" --saida acervo-2026-09-20

No PowerShell:

    py -3 "$env:USERPROFILE\.claude\skills\indice-do-acervo-da-area\scripts\inventariar.py" `
        --pasta "C:\caminho\da\pasta" --saida acervo-2026-09-20
"""

import argparse
import csv
import hashlib
import os
import re
import sys
import unicodedata
import zipfile
import zlib
from datetime import datetime
from pathlib import Path

VERSAO = "1.1"

RODAPE = ("Gerado com apoio de IA a partir da varredura da pasta do acervo. "
          "Revisar antes de assinar. Nao substitui responsabilidade tecnica.")

EXT_TEXTO = {".txt", ".md", ".csv", ".tsv", ".log", ".json", ".xml", ".htm",
             ".html", ".yml", ".yaml", ".ini", ".cfg", ".srt", ".vtt"}
EXT_DOCUMENTO = {".pdf", ".docx", ".xlsx", ".xlsm", ".pptx", ".odt", ".ods",
                 ".odp", ".rtf", ".eml"}
# Formato binario antigo de escritorio. Nenhuma ferramenta do kit abre .doc,
# .xls, .ppt e .msg, e por isso eles NAO entram na classe de leitura pelo
# modelo: entrar la prometia leitura que nao existe, e o documento acabava
# contado como "nao lido por escolha", que e o balde errado. Nao foi escolha,
# foi limite de ferramenta, e e isso que o motivo diz.
EXT_LEGADO = {".doc", ".xls", ".ppt", ".msg"}
EXT_IMAGEM = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".gif",
              ".webp", ".heic"}
EXT_DESENHO = {".dwg", ".dxf", ".dwf", ".step", ".stp", ".iges", ".igs",
               ".sldprt", ".sldasm", ".slddrw", ".ipt", ".iam", ".idw",
               ".catpart", ".catproduct", ".prt", ".x_t"}

CLASSE_TEXTO = "texto"
CLASSE_DOCUMENTO = "documento, leitura pelo modelo"
CLASSE_IMAGEM = "imagem, leitura pelo modelo"
CLASSE_DESENHO = "desenho de engenharia"
CLASSE_LEGADO = "formato antigo de escritorio"
CLASSE_SEM_EXT = "indefinida, arquivo sem extensao"
CLASSE_NAO_SUPORTADO = "formato nao suportado"

ST_OK = "inventariado"
ST_FORMATO = "formato nao suportado"
ST_LEGADO = "formato antigo de escritorio"
ST_SENHA = "protegido por senha"
ST_VAZIO = "vazio, zero bytes"
ST_ILEGIVEL = "ilegivel, erro ao abrir"
ST_PERMISSAO = "sem permissao de leitura"
ST_SUMIU = "arquivo desapareceu durante a varredura"
ST_NOME = "nome ilegivel no sistema de arquivos"

TIPO_PASTA_ERRO = "pasta nao pode ser listada"
TIPO_PASTA_IGNORADA = "pasta ignorada por pedido"
TIPO_ATALHO_PASTA = "atalho para pasta, nao seguido"
TIPO_ATALHO_CICLO = "atalho em ciclo, nao seguido"
TIPO_ATALHO_QUEBRADO = "atalho quebrado"
TIPO_ARQUIVO = "arquivo"

# Nomes exatos de ruido de sistema operacional, e so eles. A comparacao e por
# nome exato, nunca por trecho: "Instrucao-Thumbs.db-revisao.pdf" e documento,
# nao ruido. Foi um filtro por trecho que ja apagou item real em outra skill
# desta casa.
RUIDO_NOME_EXATO = {".ds_store", "thumbs.db", "desktop.ini", ".localized",
                    "icon\r", ".spotlight-v100", ".trashes", "ehthumbs.db"}
RUIDO_PREFIXO = ("~$",)
RUIDO_SUFIXO = (".tmp", ".crdownload", ".part")

# Heuristica de NOME para a classe que nao entra em nenhum modo de leitura.
# Ela marca, nunca remove a linha, e nunca autoriza leitura. O limite esta
# declarado na cobertura: folha de pagamento salva como "Planilha1.xlsx" nao e
# pega por nenhuma heuristica de nome, e e por isso que a pessoa le a lista.
PADROES_REMUNERACAO = [
    "folha de pagamento", "folhadepagamento", "folha-de-pagamento",
    "folha_de_pagamento", "holerite", "contracheque", "contra-cheque",
    "salario", "salarios", "remuneracao", "rescisao", "13o salario",
    "decimo terceiro", "informe de rendimentos", "espelho de ponto",
    "esocial", "caged", "rais",
]

COLUNAS_INVENTARIO = ["id", "caminho", "caminho_absoluto", "nome", "extensao",
                      "tamanho_bytes", "modificado_em", "paginas",
                      "base_da_contagem", "classe_de_conteudo",
                      "status_leitura", "motivo", "marca",
                      "grupo_de_duplicata"]
COLUNAS_NAO_LIDOS = ["id", "tipo", "caminho", "caminho_absoluto", "nome",
                     "extensao", "tamanho_bytes", "modificado_em", "motivo"]
COLUNAS_RUIDO = ["id", "caminho", "caminho_absoluto", "nome", "tamanho_bytes",
                 "modificado_em", "padrao_que_filtrou"]
COLUNAS_TERMOS = ["id", "caminho", "base_da_extracao", "caracteres_extraidos",
                  "data_no_texto", "origem_da_data", "datas_no_texto",
                  "entidades_no_texto", "trecho_inicial"]


def sem_acento(texto):
    nfkd = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def normalizar_nome(nome):
    return sem_acento(nome).lower()


def mascarar(texto, raiz_texto, rotulo):
    """Troca o caminho da raiz pelo rotulo de --raiz-como em qualquer texto.

    Texto de erro do sistema operacional carrega o caminho absoluto inteiro,
    com nome de servidor e de usuario. Trocar so a coluna caminho_absoluto
    deixava esse caminho vazar pela coluna motivo, que e justamente uma das
    que o nivel 1 do modo de dado sensivel manda colar."""
    if not rotulo or texto is None:
        return texto
    alvo = str(texto)
    if not raiz_texto:
        return alvo
    limpo = rotulo.rstrip("/")
    for variante in {raiz_texto, raiz_texto.replace(os.sep, "/"),
                     raiz_texto.rstrip(os.sep)}:
        if variante:
            alvo = alvo.replace(variante, limpo)
    return alvo


def e_ruido(nome):
    baixo = normalizar_nome(nome)
    if baixo in RUIDO_NOME_EXATO:
        return "nome exato de arquivo de sistema: %s" % nome
    for pref in RUIDO_PREFIXO:
        if nome.startswith(pref):
            return "prefixo %s, arquivo temporario de escritorio" % pref
    for suf in RUIDO_SUFIXO:
        if baixo.endswith(suf):
            return "sufixo %s, arquivo temporario" % suf
    return ""


def marca_de_remuneracao(nome):
    baixo = normalizar_nome(nome)
    for padrao in PADROES_REMUNERACAO:
        if padrao in baixo:
            return ("atencao: o nome sugere folha de pagamento ou remuneracao "
                    "individual (%s). Classe que nao entra em nenhum modo de "
                    "leitura" % padrao)
    return ""


def classificar(ext):
    if ext in EXT_TEXTO:
        return CLASSE_TEXTO, True
    if ext in EXT_DOCUMENTO:
        return CLASSE_DOCUMENTO, True
    if ext in EXT_IMAGEM:
        return CLASSE_IMAGEM, True
    if ext in EXT_LEGADO:
        return CLASSE_LEGADO, False
    if ext in EXT_DESENHO:
        return CLASSE_DESENHO, False
    if ext == "":
        return CLASSE_SEM_EXT, False
    return CLASSE_NAO_SUPORTADO, False


def iso(ts):
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
    except (OverflowError, OSError, ValueError):
        return "nao apurado"


MARCA_ENCRYPT = ("pdf declara /Encrypt: pode exigir senha ou ter apenas "
                 "restricao de permissao. Confira abrindo")


def contar_paginas_pdf(dados):
    """Duas contagens independentes. Divergindo, nao apura.

    Em PDF moderno com xref comprimido os objetos de pagina ficam dentro de
    fluxo comprimido e a contagem por /Type /Page acha zero. Devolver o /Count
    como se fosse conferido seria dar numero que nao se verificou.

    /Encrypt NAO rebaixa o status. PDF com senha so de proprietario, que e o
    caso mais comum de PDF marcado como protegido em acervo tecnico, abre em
    qualquer leitor sem senha nenhuma. Rebaixar mandava a pessoa procurar uma
    senha que nao existe e tirava do indice um documento legivel: a marca
    avisa, o status continua inventariado."""
    marca = MARCA_ENCRYPT if re.search(rb"/Encrypt\b", dados) else ""
    por_tipo = len(re.findall(rb"/Type\s*/Page\b(?![s])", dados))
    contagens = [int(m) for m in re.findall(rb"/Count\s+(\d+)", dados)]
    por_count = max(contagens) if contagens else 0
    if por_tipo > 0 and por_count > 0:
        if por_tipo == por_count:
            return (por_tipo, "pdf: /Type /Page conferido com /Count", ST_OK,
                    "", marca)
        return None, ("nao apurado: /Type /Page deu %d e /Count deu %d"
                      % (por_tipo, por_count)), ST_OK, "", marca
    if por_tipo > 0:
        return por_tipo, "pdf: /Type /Page", ST_OK, "", marca
    if por_count > 0:
        return (por_count, "pdf: /Count, indicativa, sem conferencia", ST_OK,
                "", marca)
    if marca:
        return (None, "nao apurado: o pdf declara /Encrypt e nao devolveu "
                "objeto de pagina legivel", ST_OK, "", marca)
    return (None, "nao apurado: nenhum objeto de pagina legivel neste pdf",
            ST_OK, "", "")


def contar_paginas_ooxml(caminho, ext):
    try:
        with zipfile.ZipFile(str(caminho)) as z:
            nomes = set(z.namelist())
            if ext in (".xlsx", ".xlsm") and "xl/workbook.xml" in nomes:
                bruto = z.read("xl/workbook.xml")
                n = len(re.findall(rb"<sheet\b", bruto))
                if n:
                    return n, "xlsx: abas em xl/workbook.xml", ST_OK, "", ""
            if "docProps/app.xml" in nomes:
                bruto = z.read("docProps/app.xml")
                for etiqueta, base in ((b"Pages", "docx: docProps/app.xml"),
                                       (b"Slides", "pptx: docProps/app.xml")):
                    m = re.search(rb"<" + etiqueta + rb">(\d+)</" + etiqueta
                                  + rb">", bruto)
                    if m:
                        return int(m.group(1)), base, ST_OK, "", ""
            return None, ("nao apurado: o pacote nao declara contagem de "
                          "paginas"), ST_OK, "", ""
    except zipfile.BadZipFile:
        return None, "nao apurado", ST_SENHA, (
            "nao abriu como pacote OOXML: pode estar protegido por senha ou "
            "ser arquivo de formato antigo com extensao nova"), ""
    except RuntimeError as err:
        return None, "nao apurado", ST_SENHA, "pacote cifrado: %s" % err, ""
    except (OSError, KeyError) as err:
        return None, "nao apurado", ST_ILEGIVEL, "erro ao abrir: %s" % err, ""


def contar_linhas(caminho):
    try:
        total = 0
        ultimo = b"\n"
        with open(str(caminho), "rb") as fh:
            while True:
                bloco = fh.read(1 << 20)
                if not bloco:
                    break
                total += bloco.count(b"\n")
                ultimo = bloco[-1:]
        if ultimo not in (b"\n", b""):
            total += 1
        return total, "linhas do arquivo", ST_OK, "", ""
    except OSError as err:
        return None, "nao apurado", ST_ILEGIVEL, "erro ao abrir: %s" % err, ""


def apurar_conteudo(caminho, ext, tamanho, limite):
    """Abre o arquivo na maquina local para contar paginas, abas ou linhas.

    Devolve (paginas, base, status, motivo, marca). Nunca devolve numero
    chutado: nao conseguindo apurar, devolve None e diz por que na base."""
    if tamanho > limite:
        return None, ("nao apurado: arquivo maior que o limite de abertura de "
                      "%d bytes" % limite), ST_OK, "", ""
    if ext == ".pdf":
        try:
            with open(str(caminho), "rb") as fh:
                dados = fh.read()
        except PermissionError as err:
            return None, "nao apurado", ST_PERMISSAO, str(err), ""
        except OSError as err:
            return (None, "nao apurado", ST_ILEGIVEL,
                    "erro ao abrir: %s" % err, "")
        return contar_paginas_pdf(dados)
    if ext in (".docx", ".xlsx", ".xlsm", ".pptx"):
        return contar_paginas_ooxml(caminho, ext)
    if ext in EXT_TEXTO:
        return contar_linhas(caminho)
    try:
        with open(str(caminho), "rb") as fh:
            fh.read(1)
    except PermissionError as err:
        return None, "nao apurado", ST_PERMISSAO, str(err), ""
    except OSError as err:
        return None, "nao apurado", ST_ILEGIVEL, "erro ao abrir: %s" % err, ""
    return None, ("nao apurado: formato sem contagem de paginas em biblioteca "
                  "padrao"), ST_OK, "", ""


# ------------------------------------------------- extracao de texto local
#
# Por que isto existe. Sem extracao, as tres colunas que dao valor ao indice
# (data do documento, entidades citadas e o termo de busca) dependiam de o
# modelo abrir documento por documento, em levas de 40. Numa pasta de dez anos
# o resultado honesto era um indice em que a maioria das linhas dizia "NAO
# LIDO: nao selecionado nesta leva": um documento sobre o trabalho, nao o
# trabalho feito. Aqui a data e as entidades saem por maquina, para TODOS os
# arquivos legiveis, e o modelo fica so com assunto e resumo.
#
# Tres regras que nao se quebram nesta parte:
#   1. Biblioteca padrao apenas, na maquina local, sem rede.
#   2. Arquivo marcado como remuneracao individual NAO e aberto, nem aqui.
#   3. Nada e chutado: nao dando para extrair, a base_da_extracao diz por que,
#      e a data sai como nao apurado.

LIMITE_TRECHO = 240
LIMITE_TEXTO_DATA = 6000

RE_NORMA = re.compile(
    r"\b(ABNT\s*NBR|NBR|ISO/IEC|ISO|IEC|IATF|ASME|API|ASTM|AWS|DIN|ANSI|NR)"
    r"\s*-?\s*(\d{1,5}(?:[-.]\d{1,4})?)", re.I)
RE_CODIGO = re.compile(r"\b([A-Z]{2,5}[-/ ]?\d{2,6}(?:[-/][A-Z0-9]{1,4})?)\b")
RE_ORDEM = re.compile(r"\b(OS|OP|OC|NF|TAG|PO)\s*[-:nº]{0,3}\s*(\d{3,8})\b",
                      re.I)

# As secoes da ficha da area que carregam termo. As outras tres, Area e posto,
# Ritos e prazos e Lacunas declaradas, dizem quem faz e o que falta, nao como a
# casa chama as coisas.
SECOES_DA_FICHA = ("Vocabulario local", "Sistemas e o que cada um exporta",
                   "Normas e certificacoes")
# A marca de origem no fim da linha de fato: [derivada de arquivo.pdf],
# [respondida pela pessoa], [lacuna].
RE_MARCA_DE_ORIGEM = re.compile(r"\[[^\]]*\]")
RE_ASPAS = re.compile(u"[\"“”]([^\"“”]{2,40})"
                      u"[\"“”]")
RE_CRASE = re.compile(r"`([^`]{2,40})`")
# Sigla da casa: maiuscula em bloco, sem letra nem digito colado. E assim que a
# secao Vocabulario local escreve OP, OS, ERP, PCP. O sufixo depois de hifen ou
# barra entra junto, senao 'NORMA-X' era devolvido como 'NORMA', que nao e o
# que a ficha declara.
RE_SIGLA = re.compile(r"(?<![0-9A-Za-z])([A-Z]{2,6}(?:[-/][A-Z0-9]{1,6})?)"
                      r"(?![0-9A-Za-z])")

MESES = {"janeiro": 1, "fevereiro": 2, "marco": 3, "abril": 4, "maio": 5,
         "junho": 6, "julho": 7, "agosto": 8, "setembro": 9, "outubro": 10,
         "novembro": 11, "dezembro": 12, "jan": 1, "fev": 2, "mar": 3,
         "abr": 4, "mai": 5, "jun": 6, "jul": 7, "ago": 8, "set": 9,
         "out": 10, "nov": 11, "dez": 12}

PADROES_DATA = [
    (re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b"), "aaaa-mm-dd", "ymd"),
    (re.compile(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b"), "dd/mm/aaaa", "dmy"),
    (re.compile(r"\b(\d{1,2})-(\d{1,2})-(\d{4})\b"), "dd-mm-aaaa", "dmy"),
    (re.compile(r"\b(\d{1,2})\.(\d{1,2})\.(\d{4})\b"), "dd.mm.aaaa", "dmy"),
    (re.compile(r"\b(\d{1,2})\s+de\s+([a-z]{3,9})\s+de\s+(\d{4})\b"),
     "dd de mes de aaaa", "dmy_mes"),
]


def decodificar(bruto):
    for codec in ("utf-8", "cp1252", "latin-1"):
        try:
            return bruto.decode(codec)
        except UnicodeDecodeError:
            continue
    return bruto.decode("latin-1", "replace")


def comprimir_espaco(texto):
    return re.sub(r"\s+", " ", texto).strip()


def limpar_marcacao(texto):
    texto = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", texto)
    texto = re.sub(r"(?s)<[^>]{0,4000}>", " ", texto)
    for de, para in (("&nbsp;", " "), ("&amp;", "&"), ("&lt;", "<"),
                     ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'")):
        texto = texto.replace(de, para)
    return comprimir_espaco(texto)


def legivel_o_bastante(texto):
    """Guarda contra texto que saiu embaralhado da extracao.

    PDF com fonte embutida por codigo devolve bytes que nao sao letra. Texto
    embaralhado no indice e pior que texto nenhum, porque nao se distingue de
    texto bom numa lista de duzentas linhas."""
    if len(texto) < 20:
        return False
    bons = sum(1 for c in texto if c.isalnum() or c in " .,;:/-()%_")
    return bons * 10 >= len(texto) * 7


def texto_de_arquivo_simples(caminho):
    try:
        with open(str(caminho), "rb") as fh:
            bruto = fh.read(4000000)
    except OSError as err:
        return "", "nao extraido: erro ao abrir: %s" % err
    texto = decodificar(bruto)
    ext = os.path.splitext(str(caminho))[1].lower()
    if ext in (".xml", ".htm", ".html"):
        return limpar_marcacao(texto), "texto direto, marcacao removida"
    return comprimir_espaco(texto), "texto direto do arquivo"


def texto_ooxml(caminho, ext):
    if ext == ".docx":
        alvos = ("word/document.xml",)
    elif ext in (".xlsx", ".xlsm"):
        alvos = ("xl/sharedStrings.xml",)
    elif ext == ".pptx":
        alvos = ("ppt/slides/",)
    else:
        return "", "nao extraido: pacote sem parte de texto conhecida"
    try:
        with zipfile.ZipFile(str(caminho)) as z:
            nomes = [n for n in z.namelist()
                     if any(n == a or n.startswith(a) for a in alvos)]
            nomes = [n for n in sorted(nomes) if n.endswith(".xml")]
            if not nomes:
                return "", ("nao extraido: o pacote nao traz %s"
                            % ", ".join(alvos))
            partes = []
            total = 0
            for nome in nomes:
                bruto = z.read(nome)
                total += len(bruto)
                partes.append(decodificar(bruto))
                if total > 8000000:
                    break
            return (limpar_marcacao(" ".join(partes)),
                    "pacote OOXML: %s" % ", ".join(nomes[:3]))
    except zipfile.BadZipFile:
        return "", ("nao extraido: nao abriu como pacote OOXML, pode estar "
                    "protegido")
    except (OSError, KeyError, RuntimeError, zlib.error) as err:
        return "", "nao extraido: erro ao abrir: %s" % err


def texto_pdf(caminho):
    """Extracao parcial, e ela diz que e parcial.

    Le os fluxos de conteudo, infla os que estao comprimidos e junta os
    literais de texto. Funciona em PDF gerado por editor de texto e nao
    funciona em digitalizacao nem em fonte embutida por codigo: nesses dois
    casos devolve vazio e o motivo, nunca texto embaralhado."""
    try:
        with open(str(caminho), "rb") as fh:
            dados = fh.read(40000000)
    except OSError as err:
        return "", "nao extraido: erro ao abrir: %s" % err
    pedacos = []
    total = 0
    for m in re.finditer(rb"stream\r?\n?(.*?)endstream", dados, re.S):
        bruto = m.group(1)
        try:
            fluxo = zlib.decompress(bruto)
        except zlib.error:
            try:
                fluxo = zlib.decompressobj().decompress(bruto)
            except zlib.error:
                fluxo = bruto
        if b"Tj" not in fluxo and b"TJ" not in fluxo:
            continue
        pedacos.append(fluxo)
        total += len(fluxo)
        if total > 8000000:
            break
    achados = []
    for fluxo in pedacos:
        for m in re.finditer(rb"\(((?:\\.|[^\\()])*)\)", fluxo, re.S):
            pedaco = re.sub(rb"\\([()\\])", rb"\1", m.group(1))
            pedaco = re.sub(rb"\\[nrt]", b" ", pedaco)
            achados.append(pedaco)
    if not achados:
        return "", ("nao extraido: o pdf nao tem literal de texto legivel em "
                    "biblioteca padrao. Provavel digitalizacao, ou fonte "
                    "embutida por codigo")
    texto = comprimir_espaco(decodificar(b" ".join(achados)))
    if not legivel_o_bastante(texto):
        return "", ("nao extraido: o texto do pdf saiu ilegivel na extracao "
                    "por biblioteca padrao")
    return texto, "pdf: literais do fluxo de conteudo, extracao parcial"


def extrair_texto(caminho, ext):
    if ext in (".txt", ".md", ".csv", ".tsv", ".log", ".json", ".xml", ".htm",
               ".html", ".yml", ".yaml", ".ini", ".cfg", ".srt", ".vtt",
               ".eml"):
        return texto_de_arquivo_simples(caminho)
    if ext in (".docx", ".xlsx", ".xlsm", ".pptx"):
        return texto_ooxml(caminho, ext)
    if ext == ".pdf":
        return texto_pdf(caminho)
    return "", ("nao extraido: biblioteca padrao nao abre este formato para "
                "texto")


def datas_do_texto(texto):
    """Devolve (data_iso, origem, todas). Data invalida nao entra.

    Vale a primeira data que aparece no texto, porque data de emissao e de
    revisao ficam no alto do documento. As outras saem na coluna
    datas_no_texto, para a pessoa julgar quando divergirem."""
    inicio = texto[:LIMITE_TEXTO_DATA]
    achados = []
    for padrao, rotulo, ordem in PADROES_DATA:
        for m in padrao.finditer(inicio):
            if ordem == "ymd":
                bruto = (m.group(1), m.group(2), m.group(3))
            elif ordem == "dmy":
                bruto = (m.group(3), m.group(2), m.group(1))
            else:
                bruto = (m.group(3), MESES.get(normalizar_nome(m.group(2)), 0),
                         m.group(1))
            try:
                ano, mes, dia = int(bruto[0]), int(bruto[1]), int(bruto[2])
            except (TypeError, ValueError):
                continue
            if not (1 <= dia <= 31 and 1 <= mes <= 12
                    and 1900 <= ano <= 2100):
                continue
            achados.append((m.start(), "%04d-%02d-%02d" % (ano, mes, dia),
                            rotulo))
    if not achados:
        return "", "", []
    achados.sort()
    todas = []
    for _, valor, _rotulo in achados:
        if valor not in todas:
            todas.append(valor)
    return (achados[0][1],
            "extraido por maquina do texto do arquivo, padrao %s, nos "
            "primeiros %d caracteres" % (achados[0][2], LIMITE_TEXTO_DATA),
            todas[:6])


def entidades_do_texto(texto, termos_da_ficha):
    achados = []

    def por(valor):
        valor = comprimir_espaco(valor)
        if not valor:
            return
        # "NBR 15239" dentro de "ABNT NBR 15239" e a mesma norma escrita duas
        # vezes. Vale a forma mais completa, que e a que o documento traz.
        if any(valor in ja for ja in achados):
            return
        achados.append(valor)

    # O termo da ficha casa como palavra inteira, nao como pedaco de palavra.
    # A ficha declara sigla curta, OP e OS entre elas, e casamento por pedaco
    # achava OP dentro de 'operador' e de 'opcao': a coluna de entidades saia
    # cheia de termo que o documento nao cita.
    baixo = normalizar_nome(texto)
    for termo in termos_da_ficha:
        alvo = normalizar_nome(termo or "").strip()
        if not alvo:
            continue
        if re.search(r"(?<![0-9a-z])%s(?![0-9a-z])" % re.escape(alvo), baixo):
            por(termo)
    for m in RE_NORMA.finditer(texto):
        por("%s %s" % (m.group(1).upper().replace("  ", " "), m.group(2)))
    for m in RE_ORDEM.finditer(texto):
        por("%s %s" % (m.group(1).upper(), m.group(2)))
    for m in RE_CODIGO.finditer(texto):
        por(m.group(1))
        if len(achados) >= 14:
            break
    return achados[:14]


def secoes_da_ficha(texto):
    """Devolve (por_secao, encontradas) lendo o corpo da ficha da area.

    So o conteudo das secoes que carregam termo entra. O cabecalho da ficha
    fica de fora de proposito: a linha 'fontes nomeadas:' dele lista nome de
    arquivo, e nome de arquivo nao e termo da casa."""
    por_secao = dict((s, []) for s in SECOES_DA_FICHA)
    encontradas = []
    oficiais = dict((normalizar_nome(s), s) for s in SECOES_DA_FICHA)
    atual = None
    for bruta in texto.splitlines():
        linha = bruta.strip()
        if linha.startswith("#"):
            titulo = linha.lstrip("#").strip()
            atual = oficiais.get(normalizar_nome(titulo))
            if atual and atual not in encontradas:
                encontradas.append(atual)
            continue
        if atual and linha.startswith("- "):
            por_secao[atual].append(linha[2:].strip())
    return por_secao, encontradas


def termos_de_linha(linha):
    """Termos de uma linha de fato da ficha, com a marca de origem ja fora.

    A marca sai ANTES da extracao. Ela carrega o nome do arquivo de onde o
    fato foi derivado, e nome de arquivo casa com o padrao de codigo e com o
    de norma: '[derivada de certificado-iso-2024.pdf]' entrava como a norma
    'ISO 2024', que nao existe, e '[derivada de IT-042-rev3.pdf]' entrava como
    o codigo 'IT-042' sem que a linha citasse codigo nenhum."""
    corpo = RE_MARCA_DE_ORIGEM.sub(" ", linha)
    achados = []

    def por(valor):
        valor = comprimir_espaco(valor)
        if not (2 <= len(valor) <= 40):
            return
        chave = normalizar_nome(valor)
        # 'ISO' dentro de 'ISO 9001' e a mesma coisa escrita curta. Vale a
        # forma mais completa, que e a que a ficha traz.
        if any(chave in normalizar_nome(ja) for ja in achados):
            return
        achados.append(valor)

    for m in RE_NORMA.finditer(corpo):
        por("%s %s" % (m.group(1).upper().replace("  ", " "), m.group(2)))
    for m in RE_CODIGO.finditer(corpo):
        por(m.group(1))
    for bruto in RE_CRASE.findall(corpo):
        por(bruto)
    for bruto in RE_ASPAS.findall(corpo):
        por(bruto)
    for m in RE_SIGLA.finditer(corpo):
        por(m.group(1))
    return achados


def termos_da_ficha(caminho):
    """Codigo, norma e vocabulario que a ficha da area declara.

    Devolve (termos, resumo, por_secao). A ficha e escrita pela skill
    ficha-da-area. Nao existindo, a extracao continua com os padroes genericos
    e a cobertura diz que rodou sem ficha.

    A leitura e por secao, linha a linha. A versao anterior varria o arquivo
    inteiro atras de crase, e a ficha que o ficha-da-area grava nao tem uma
    unica crase no corpo: ela escreve tudo em prosa, com a marca de origem
    entre colchetes. O resultado era tres termos, NENHUM deles da secao
    Vocabulario local, que e onde estao os codigos da casa, e dois deles
    raspados de nome de arquivo dentro da marca de origem. A cobertura ainda
    imprimia 'ficha da area lida: 3 termo(s)', que le como sucesso. Quem cede
    aqui e o leitor: o formato da ficha nao muda."""
    vazio = []
    if not caminho:
        return [], "rodada sem ficha da area", vazio
    p = Path(caminho).expanduser()
    # O caminho da ficha fica na pasta pessoal e carrega o nome do usuario. A
    # cobertura circula, entao ela diz o fato sem repetir o caminho.
    if not p.exists():
        return [], ("ficha da area nao encontrada no caminho informado, "
                    "extracao com os padroes genericos"), vazio
    try:
        texto = p.read_text(encoding="utf-8", errors="replace")
    except OSError as err:
        return [], ("a ficha da area nao pode ser lida: %s"
                    % (err.strerror or "erro de leitura")), vazio

    por_secao, encontradas = secoes_da_ficha(texto)
    detalhe = []
    termos = []
    lacunas = 0
    for secao in SECOES_DA_FICHA:
        da_secao = []
        for linha in por_secao[secao]:
            # Lacuna e buraco declarado, nao fato apurado. O que ela cita nao
            # e vocabulario confirmado da casa e nao vira termo de casamento.
            if "[lacuna]" in normalizar_nome(linha):
                lacunas += 1
                continue
            for termo in termos_de_linha(linha):
                if termo not in da_secao:
                    da_secao.append(termo)
        detalhe.append((secao, da_secao))
        for termo in da_secao:
            if termo not in termos:
                termos.append(termo)

    termos = termos[:200]
    partes = ["%s %d" % (s.lower(), len(t)) for s, t in detalhe]
    resumo = ("ficha da area lida: %d termo(s) (%s)"
              % (len(termos), ", ".join(partes)))
    faltando = [s for s in SECOES_DA_FICHA if s not in encontradas]
    if faltando:
        resumo += ("; secao nao encontrada na ficha: %s"
                   % ", ".join(faltando))
    if lacunas:
        resumo += "; %d linha(s) de lacuna nao viraram termo" % lacunas
    return termos, resumo, detalhe


def apurar_termos(reg, args, termos_ficha):
    """Uma linha por arquivo inventariado, inclusive quando nao deu para
    extrair. Arquivo que a extracao nao alcancou sai nomeado, com o motivo, e
    nao desaparece deste arquivo."""
    linhas = []
    for linha in reg.inventario:
        if linha["status_leitura"] != ST_OK:
            continue
        alvo = linha.get("_abs_real")
        registro = {
            "id": linha["id"],
            "caminho": linha["caminho"],
            "base_da_extracao": "",
            "caracteres_extraidos": 0,
            "data_no_texto": "nao apurado",
            "origem_da_data": "nao apurado",
            "datas_no_texto": "nao apurado",
            "entidades_no_texto": "nao apurado",
            "trecho_inicial": "nao apurado",
        }
        if "remuneracao" in (linha.get("marca") or ""):
            registro["base_da_extracao"] = (
                "nao extraido: o nome sugere remuneracao individual, classe "
                "que nao entra em nenhum modo de leitura")
            linhas.append(registro)
            continue
        tamanho = linha["tamanho_bytes"]
        if isinstance(tamanho, int) and tamanho > args.max_bytes_abertura:
            registro["base_da_extracao"] = (
                "nao extraido: arquivo maior que o limite de abertura de %d "
                "bytes" % args.max_bytes_abertura)
            linhas.append(registro)
            continue
        if not alvo:
            registro["base_da_extracao"] = "nao extraido: arquivo nao aberto"
            linhas.append(registro)
            continue
        texto, base = extrair_texto(alvo, linha["extensao"])
        registro["base_da_extracao"] = reg.limpar(base)
        if not texto:
            linhas.append(registro)
            continue
        registro["caracteres_extraidos"] = len(texto)
        data, origem, todas = datas_do_texto(texto)
        if data:
            registro["data_no_texto"] = data
            registro["origem_da_data"] = origem
            registro["datas_no_texto"] = ", ".join(todas)
        else:
            registro["origem_da_data"] = ("o texto extraido nao traz data "
                                          "reconhecivel")
        entidades = entidades_do_texto(texto, termos_ficha)
        if entidades:
            registro["entidades_no_texto"] = ", ".join(entidades)
        registro["trecho_inicial"] = reg.limpar(texto[:LIMITE_TRECHO])
        reg.contagem["arquivos_com_texto_extraido"] += 1
        linhas.append(registro)
    return linhas


class Registro(object):
    """Acumula tudo o que a varredura encontrou.

    Cada item encontrado entra por um dos metodos abaixo e e contado no laco,
    um a um. Nenhum contador desta classe e derivado por subtracao: contador
    derivado por subtracao fecha sozinho mesmo com item faltando, e foi esse o
    defeito que custou quatro rodadas nas outras skills do kit."""

    def __init__(self, raiz_texto="", rotulo=""):
        self.inventario = []
        self.nao_lidos = []
        self.ruido = []
        self.vistos = set()
        self.raiz_texto = raiz_texto
        self.rotulo = rotulo
        self.pedidos_casados = set()
        self.contagem = {
            "arquivos_encontrados": 0,
            "arquivos_inventariados": 0,
            "arquivos_nao_lidos": 0,
            "arquivos_filtrados_como_ruido": 0,
            "arquivos_com_texto_extraido": 0,
            "pastas_nao_listadas": 0,
            "pastas_ignoradas": 0,
            "atalhos_de_pasta": 0,
            "atalhos_em_ciclo": 0,
            "atalhos_quebrados": 0,
        }
        self.proximo = 0

    def novo_id(self, prefixo):
        self.proximo += 1
        return "%s%04d" % (prefixo, self.proximo)

    def ver(self, absoluto):
        self.vistos.add(absoluto)

    def limpar(self, texto):
        """Todo texto gravado passa por aqui antes de ir para o arquivo."""
        return mascarar(texto, self.raiz_texto, self.rotulo)


def rel_posix(caminho_abs, raiz):
    try:
        rel = os.path.relpath(caminho_abs, str(raiz))
    except ValueError:
        rel = caminho_abs
    return rel.replace(os.sep, "/")


def rotular(rel, rotulo_raiz, absoluto):
    if rotulo_raiz:
        return "%s/%s" % (rotulo_raiz.rstrip("/"), rel)
    return absoluto


def nome_legivel(nome):
    try:
        nome.encode("utf-8")
        return True
    except UnicodeEncodeError:
        return False


def normalizar_pedido_de_pasta(valor):
    """Aceita o que o tab completion do terminal escreve.

    Nome com barra no fim, nome entre aspas e caminho relativo com barra
    invertida casam todos. Antes, um valor que nao casava com nada varria a
    pasta normalmente e a cobertura dizia 'pastas ignoradas | 0': numa skill
    cujo passo 2 e inteiro sobre dado sensivel, a exclusao que a pessoa pediu
    para a pasta de pessoal simplesmente nao acontecia."""
    v = (valor or "").strip().strip('"').strip("'")
    v = v.replace("\\", "/").strip().strip("/")
    return normalizar_nome(v)


def chave_de_pasta(caminho):
    """Identidade da pasta no sistema de arquivos, para barrar ciclo.

    Devolve None quando o sistema nao da numero de inode confiavel, e nesse
    caso o controle de ciclo nao se aplica: barrar por chave duvidosa deixaria
    pasta de fora sem motivo."""
    try:
        st = os.stat(caminho)
    except OSError:
        return None
    if not st.st_ino:
        return None
    return (st.st_dev, st.st_ino)


def varrer(raiz, args, reg):
    pedidos = [normalizar_pedido_de_pasta(n) for n in (args.ignorar_pasta or [])]
    ignorar_nome = set(p for p in pedidos if "/" not in p)
    ignorar_rel = set(p for p in pedidos if "/" in p)
    erros_dir = []

    def ao_errar(err):
        erros_dir.append(err)

    # Uma linha por documento e lei de ferro. Sem este controle, um atalho que
    # volta para a raiz fazia a varredura reentrar na mesma arvore e inventariar
    # o mesmo documento dezenas de vezes, sob caminhos diferentes, com todas as
    # identidades de fechamento dando fecha.
    visitadas = {}
    chave_raiz = chave_de_pasta(str(raiz))
    if chave_raiz is not None:
        visitadas[chave_raiz] = "."

    for dirpath, dirnames, filenames in os.walk(str(raiz), onerror=ao_errar,
                                                followlinks=args.seguir_atalhos):
        chave_atual = chave_de_pasta(dirpath)
        if chave_atual is not None:
            visitadas.setdefault(chave_atual, rel_posix(dirpath, raiz))
        dirnames.sort()
        filenames.sort()
        mantidos = []
        for d in dirnames:
            cheio = os.path.join(dirpath, d)
            rel_d = normalizar_nome(rel_posix(cheio, raiz))
            if normalizar_nome(d) in ignorar_nome or rel_d in ignorar_rel:
                reg.pedidos_casados.add(normalizar_nome(d))
                reg.pedidos_casados.add(rel_d)
                reg.ver(cheio)
                reg.contagem["pastas_ignoradas"] += 1
                reg.nao_lidos.append(linha_problema(
                    reg, TIPO_PASTA_IGNORADA, cheio, raiz, args,
                    "pasta ignorada por --ignorar-pasta. O que esta dentro "
                    "dela nao foi contado"))
                continue
            if os.path.islink(cheio) and not args.seguir_atalhos:
                reg.ver(cheio)
                reg.contagem["atalhos_de_pasta"] += 1
                reg.nao_lidos.append(linha_problema(
                    reg, TIPO_ATALHO_PASTA, cheio, raiz, args,
                    "atalho para pasta. A varredura nao entrou. Rode de novo "
                    "com --seguir-atalhos, ou varra a pasta de destino "
                    "separadamente"))
                continue
            chave = chave_de_pasta(cheio)
            if chave is not None and chave in visitadas:
                reg.ver(cheio)
                reg.contagem["atalhos_em_ciclo"] += 1
                reg.nao_lidos.append(linha_problema(
                    reg, TIPO_ATALHO_CICLO, cheio, raiz, args,
                    "ciclo de atalho: esta pasta ja foi varrida por outro "
                    "caminho (%s). A varredura nao desceu de novo, e o que "
                    "esta dentro dela ja esta no inventario uma vez"
                    % visitadas[chave]))
                continue
            if chave is not None:
                visitadas[chave] = rel_posix(cheio, raiz)
            mantidos.append(d)
        dirnames[:] = mantidos

        for nome in filenames:
            cheio = os.path.join(dirpath, nome)
            reg.ver(cheio)
            processar_arquivo(cheio, nome, raiz, args, reg)

    for err in erros_dir:
        alvo = getattr(err, "filename", None) or str(raiz)
        reg.ver(alvo)
        reg.contagem["pastas_nao_listadas"] += 1
        reg.nao_lidos.append(linha_problema(
            reg, TIPO_PASTA_ERRO, alvo, raiz, args,
            "a pasta nao pode ser listada: %s. O que esta dentro dela nao foi "
            "contado" % err))


def linha_problema(reg, tipo, caminho_abs, raiz, args, motivo):
    rel = rel_posix(caminho_abs, raiz)
    try:
        st = os.lstat(caminho_abs)
        tamanho = st.st_size
        modificado = iso(st.st_mtime)
    except OSError:
        tamanho = ""
        modificado = "nao apurado"
    nome = os.path.basename(caminho_abs)
    ext = os.path.splitext(nome)[1].lower()
    return {
        "id": reg.novo_id("P"),
        "tipo": tipo,
        "caminho": rel,
        "caminho_absoluto": rotular(rel, args.raiz_como, caminho_abs),
        "nome": nome,
        "extensao": ext,
        "tamanho_bytes": tamanho,
        "modificado_em": modificado,
        "motivo": reg.limpar(motivo),
    }


def processar_arquivo(cheio, nome, raiz, args, reg):
    reg.contagem["arquivos_encontrados"] += 1
    rel = rel_posix(cheio, raiz)
    absoluto = rotular(rel, args.raiz_como, cheio)
    ext = os.path.splitext(nome)[1].lower()

    if not nome_legivel(nome):
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, "", "nao apurado",
                           ST_NOME, "o nome do arquivo tem caractere que o "
                           "sistema nao devolve em texto. Renomeie o arquivo e "
                           "rode de novo", CLASSE_NAO_SUPORTADO)
        return

    if os.path.islink(cheio) and not os.path.exists(cheio):
        # Uma linha so, nos dois arquivos, como qualquer arquivo nao lido. O
        # contador de atalho quebrado e informativo e fica FORA da identidade
        # de fechamento, porque ele e subconjunto de arquivos_nao_lidos:
        # somar duas vezes o mesmo item numa identidade e o jeito mais facil
        # de ela fechar sem querer dizer nada.
        reg.contagem["atalhos_quebrados"] += 1
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, "",
                           "nao apurado", ST_ILEGIVEL,
                           "%s: aponta para arquivo que nao existe"
                           % TIPO_ATALHO_QUEBRADO, CLASSE_NAO_SUPORTADO)
        return

    try:
        st = os.stat(cheio)
    except FileNotFoundError:
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, "",
                           "nao apurado", ST_SUMIU,
                           "o arquivo existia na listagem da pasta e nao "
                           "existia mais no momento de ler os dados dele",
                           CLASSE_NAO_SUPORTADO)
        return
    except PermissionError as err:
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, "",
                           "nao apurado", ST_PERMISSAO, str(err),
                           CLASSE_NAO_SUPORTADO)
        return
    except OSError as err:
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, "",
                           "nao apurado", ST_ILEGIVEL, str(err),
                           CLASSE_NAO_SUPORTADO)
        return

    tamanho = st.st_size
    modificado = iso(st.st_mtime)

    padrao_ruido = e_ruido(nome)
    if padrao_ruido and args.sem_ruido:
        reg.contagem["arquivos_filtrados_como_ruido"] += 1
        reg.ruido.append({
            "id": reg.novo_id("R"),
            "caminho": rel,
            "caminho_absoluto": absoluto,
            "nome": nome,
            "tamanho_bytes": tamanho,
            "modificado_em": modificado,
            "padrao_que_filtrou": padrao_ruido,
        })
        return

    classe, legivel = classificar(ext)
    marca = marca_de_remuneracao(nome)
    if padrao_ruido:
        marca = ("ruido provavel: %s" % padrao_ruido) + (
            " | " + marca if marca else "")

    if tamanho == 0:
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, tamanho,
                           modificado, ST_VAZIO,
                           "arquivo de zero byte: existe e nao tem conteudo",
                           classe, marca)
        return

    if not legivel:
        motivo = {
            CLASSE_DESENHO: ("desenho de engenharia: biblioteca padrao nao "
                             "abre, e o modelo nao le. Exporte para PDF e "
                             "rode de novo"),
            CLASSE_LEGADO: ("formato antigo de escritorio: nenhuma ferramenta "
                            "do kit abre. Salve como PDF ou no formato novo e "
                            "rode de novo"),
            CLASSE_SEM_EXT: ("arquivo sem extensao: nao da para dizer o "
                             "formato pelo nome. Renomeie com a extensao "
                             "correta e rode de novo"),
        }.get(classe, "extensao fora da lista de formatos que o modelo le")
        status = ST_LEGADO if classe == CLASSE_LEGADO else ST_FORMATO
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, tamanho,
                           modificado, status, motivo, classe, marca)
        return

    if not os.access(cheio, os.R_OK):
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, tamanho,
                           modificado, ST_PERMISSAO,
                           "o sistema nega leitura deste arquivo para o "
                           "usuario que rodou a varredura", classe, marca)
        return

    paginas, base, status, motivo, marca_extra = (
        None, "nao apurado: contagem nao pedida, rodada sem --contar-paginas",
        ST_OK, "", "")
    if args.contar_paginas:
        paginas, base, status, motivo, marca_extra = apurar_conteudo(
            Path(cheio), ext, tamanho, args.max_bytes_abertura)
    if marca_extra:
        marca = (marca + " | " + marca_extra) if marca else marca_extra

    if status != ST_OK:
        registrar_nao_lido(reg, args, rel, absoluto, nome, ext, tamanho,
                           modificado, status, motivo, classe, marca,
                           paginas, base)
        return

    reg.contagem["arquivos_inventariados"] += 1
    reg.inventario.append({
        "id": reg.novo_id("D"),
        "caminho": rel,
        "caminho_absoluto": absoluto,
        "nome": nome,
        "extensao": ext,
        "tamanho_bytes": tamanho,
        "modificado_em": modificado,
        "paginas": paginas if paginas is not None else "nao apurado",
        "base_da_contagem": reg.limpar(base),
        "classe_de_conteudo": classe,
        "status_leitura": ST_OK,
        "motivo": "",
        "marca": marca,
        "grupo_de_duplicata": "nao apurado: rodada sem --marcar-duplicatas",
        "_abs_real": cheio,
    })


def registrar_nao_lido(reg, args, rel, absoluto, nome, ext, tamanho,
                       modificado, status, motivo, classe, marca="",
                       paginas=None, base=""):
    """Arquivo que a rodada nao conseguiu ler entra nos DOIS arquivos.

    Em inventario.csv porque ele existe na pasta e nao pode sumir do indice.
    Em nao-lidos.csv porque alguem tem que responder por ele."""
    reg.contagem["arquivos_nao_lidos"] += 1
    motivo = reg.limpar(motivo)
    base = reg.limpar(base)
    reg.inventario.append({
        "id": reg.novo_id("D"),
        "caminho": rel,
        "caminho_absoluto": absoluto,
        "nome": nome,
        "extensao": ext,
        "tamanho_bytes": tamanho,
        "modificado_em": modificado,
        "paginas": paginas if paginas is not None else "nao apurado",
        "base_da_contagem": base or "nao apurado",
        "classe_de_conteudo": classe,
        "status_leitura": status,
        "motivo": motivo,
        "marca": marca,
        "grupo_de_duplicata": "nao apurado: arquivo nao lido",
        "_abs_real": "",
    })
    reg.nao_lidos.append({
        "id": reg.inventario[-1]["id"],
        "tipo": TIPO_ARQUIVO,
        "caminho": rel,
        "caminho_absoluto": absoluto,
        "nome": nome,
        "extensao": ext,
        "tamanho_bytes": tamanho,
        "modificado_em": modificado,
        "motivo": "%s: %s" % (status, motivo) if motivo else status,
    })


def marcar_duplicatas(reg, limite):
    por_hash = {}
    for linha in reg.inventario:
        alvo = linha.get("_abs_real")
        if not alvo:
            continue
        tamanho = linha["tamanho_bytes"]
        if isinstance(tamanho, int) and tamanho > limite:
            linha["grupo_de_duplicata"] = ("nao apurado: arquivo maior que o "
                                           "limite de abertura")
            continue
        try:
            h = hashlib.sha256()
            with open(alvo, "rb") as fh:
                while True:
                    bloco = fh.read(1 << 20)
                    if not bloco:
                        break
                    h.update(bloco)
            digest = h.hexdigest()
        except OSError as err:
            linha["grupo_de_duplicata"] = reg.limpar("nao apurado: %s" % err)
            continue
        por_hash.setdefault(digest, []).append(linha)
    grupos = []
    n = 0
    for digest in sorted(por_hash):
        linhas = por_hash[digest]
        if len(linhas) > 1:
            n += 1
            rotulo = "G%03d" % n
            for linha in linhas:
                linha["grupo_de_duplicata"] = rotulo
            grupos.append((rotulo, [l["caminho"] for l in linhas]))
        else:
            linhas[0]["grupo_de_duplicata"] = "unico"
    return grupos


def escrever_csv(caminho, colunas, linhas):
    with caminho.open("w", encoding="utf-8-sig", newline="") as fh:
        escritor = csv.writer(fh, delimiter=";", quoting=csv.QUOTE_MINIMAL,
                              lineterminator="\r\n")
        escritor.writerow(colunas)
        for linha in linhas:
            escritor.writerow([linha.get(c, "") for c in colunas])
        escritor.writerow(["# " + RODAPE] + [""] * (len(colunas) - 1))


def reler_caminhos(caminho, coluna="caminho"):
    """Le de volta o arquivo gravado e devolve os caminhos que estao nele.

    O fechamento confere o conjunto que a varredura VIU contra o conjunto que
    saiu GRAVADO. Conferir contra a lista em memoria seria conferir o contador
    contra ele mesmo."""
    if not caminho.exists():
        return []
    achados = []
    with caminho.open(encoding="utf-8-sig", newline="") as fh:
        for linha in csv.DictReader(fh, delimiter=";"):
            valor = (linha.get(coluna) or "").strip()
            if not valor or (linha.get("id") or "").startswith("# "):
                continue
            achados.append(valor)
    return achados


def alerta_datas(reg):
    dias = {}
    for linha in reg.inventario:
        valor = str(linha.get("modificado_em") or "")
        if len(valor) >= 10 and valor != "nao apurado":
            dias[valor[:10]] = dias.get(valor[:10], 0) + 1
    total = sum(dias.values())
    if total < 5:
        return ""
    dia, quantos = max(dias.items(), key=lambda kv: (kv[1], kv[0]))
    if quantos * 100 >= total * 60:
        return ("%d dos %d arquivos tem a mesma data de modificacao, %s. "
                "Pasta copiada de rede ou de backup carrega a data da copia "
                "em tudo. Nao use a coluna modificado_em como data do "
                "documento nesta pasta: a data do documento e a que esta "
                "escrita dentro dele." % (quantos, total, dia))
    return ""


def escrever_cobertura(destino, raiz, args, reg, grupos, fechamento, ok_fecha,
                       termos, base_da_ficha, ficha_por_secao=None):
    linhas = []
    ad = linhas.append
    status = "inventario, sem indice" if ok_fecha else "invalido, nao fecha"
    ad("# Cobertura da varredura do acervo")
    ad("")
    ad("status: %s" % status)
    ad("")
    ad("| Item | Valor |")
    ad("|---|---|")
    ad("| Pasta varrida | `%s` |" % (args.raiz_como or str(raiz)))
    ad("| Rodada em | %s |" % datetime.now().strftime("%Y-%m-%d %H:%M"))
    ad("| Versao do script | %s |" % VERSAO)
    ad("| Abriu arquivo para contar pagina | %s |"
       % ("sim, na maquina local" if args.contar_paginas else "nao"))
    ad("| Extraiu texto na maquina | %s |"
       % ("sim, e o resultado esta em termos-por-documento.csv"
          if args.extrair_texto else "nao"))
    ad("| Calculou duplicata | %s |"
       % ("sim, sha256 local" if args.marcar_duplicatas else "nao"))
    ad("| Filtrou ruido de sistema | %s |"
       % ("sim, e os filtrados estao nomeados em ruido-filtrado.csv"
          if args.sem_ruido else "nao"))
    ad("| Seguiu atalho de pasta | %s |"
       % ("sim" if args.seguir_atalhos else "nao"))
    ad("")

    ad("## 1. O que foi encontrado")
    ad("")
    ad("| Contagem | Valor |")
    ad("|---|---|")
    for chave in ("arquivos_encontrados", "arquivos_inventariados",
                  "arquivos_nao_lidos", "arquivos_filtrados_como_ruido",
                  "pastas_nao_listadas", "pastas_ignoradas",
                  "atalhos_de_pasta", "atalhos_em_ciclo"):
        ad("| %s | %d |" % (chave.replace("_", " "), reg.contagem[chave]))
    ad("| atalhos quebrados (subconjunto de arquivos nao lidos) | %d |"
       % reg.contagem["atalhos_quebrados"])
    if reg.contagem["atalhos_em_ciclo"]:
        ad("")
        ad("Atencao: %d atalho(s) fecham ciclo nesta arvore. A varredura nao "
           "desceu de novo pelo caminho repetido, para nao inventariar o mesmo "
           "documento duas vezes. Os caminhos estao na secao 2."
           % reg.contagem["atalhos_em_ciclo"])
    ad("")
    classes = {}
    for linha in reg.inventario:
        classes[linha["classe_de_conteudo"]] = classes.get(
            linha["classe_de_conteudo"], 0) + 1
    ad("| Classe de conteudo | Arquivos |")
    ad("|---|---|")
    for classe in sorted(classes):
        ad("| %s | %d |" % (classe, classes[classe]))
    ad("")

    ad("## 2. O que a varredura nao conseguiu ler, nomeado")
    ad("")
    if not reg.nao_lidos:
        ad("Nenhum item. Todo arquivo encontrado foi inventariado.")
    else:
        ad("Cada um destes continua em `inventario.csv` e tem que aparecer no "
           "indice, com o motivo no lugar do resumo. Documento que a rodada "
           "nao leu nao some do indice.")
        ad("")
        ad("| Tipo | Caminho | Motivo |")
        ad("|---|---|---|")
        for linha in reg.nao_lidos:
            ad("| %s | `%s` | %s |" % (linha["tipo"], linha["caminho"],
                                       linha["motivo"]))
    ad("")

    ad("## 3. Ruido filtrado")
    ad("")
    if not args.sem_ruido:
        ad("A rodada nao filtrou nada. Arquivo de sistema com nome conhecido "
           "entrou no inventario com a marca `ruido provavel`.")
    elif not reg.ruido:
        ad("Nenhum arquivo casou com os padroes de ruido.")
    else:
        ad("| Caminho | Padrao que filtrou |")
        ad("|---|---|")
        for linha in reg.ruido:
            ad("| `%s` | %s |" % (linha["caminho"],
                                  linha["padrao_que_filtrou"]))
    ad("")

    ad("## 4. Nomes que sugerem remuneracao individual")
    ad("")
    marcados = [l for l in reg.inventario if "remuneracao" in l["marca"]]
    if not marcados:
        ad("Nenhum nome de arquivo casou com os padroes. **Isto nao e prova de "
           "ausencia**: a deteccao e por nome, e folha de pagamento salva como "
           "`Planilha1.xlsx` nao e pega. E por isso que a pessoa le a lista "
           "antes de liberar leitura.")
    else:
        ad("Estes ficam no inventario e no indice, e **nao entram em nenhum "
           "modo de leitura**. A marca nao autoriza abrir.")
        ad("")
        ad("| Caminho | Marca |")
        ad("|---|---|")
        for linha in marcados:
            ad("| `%s` | %s |" % (linha["caminho"], linha["marca"]))
    ad("")

    ad("## 5. Duplicatas")
    ad("")
    if not args.marcar_duplicatas:
        ad("Nao apurado: rodada sem `--marcar-duplicatas`.")
    elif not grupos:
        ad("Nenhum arquivo com conteudo identico a outro.")
    else:
        ad("Copia nao e removida do indice. O indice diz onde esta o "
           "documento, e quando ha seis copias ha seis lugares.")
        ad("")
        ad("| Grupo | Caminhos |")
        ad("|---|---|")
        for rotulo, caminhos in grupos:
            ad("| %s | %s |" % (rotulo,
                                ", ".join("`%s`" % c for c in caminhos)))
    ad("")

    ad("## 6. Data de modificacao")
    ad("")
    aviso = alerta_datas(reg)
    ad(aviso if aviso else
       ("Sem concentracao suspeita de datas. Ainda assim, `modificado_em` e a "
        "data do arquivo, nunca a data do documento."))
    ad("")

    ad("## 7. Texto extraido na maquina")
    ad("")
    if not args.extrair_texto:
        ad("Nao apurado: rodada sem `--extrair-texto`. Sem ela, a data do "
           "documento e as entidades citadas dependem de leitura documento por "
           "documento, e numa pasta grande a maior parte do indice sai como "
           "`NAO LIDO: nao selecionado nesta leva`.")
    else:
        com_data = sum(1 for t in termos
                       if t["data_no_texto"] != "nao apurado")
        com_ent = sum(1 for t in termos
                      if t["entidades_no_texto"] != "nao apurado")
        sem_texto = [t for t in termos if not t["caracteres_extraidos"]]
        ad("A extracao rodou na maquina, em biblioteca padrao, e nada foi "
           "enviado a lugar nenhum. Arquivo cujo nome sugere remuneracao "
           "individual nao foi aberto.")
        ad("")
        ad("| Contagem | Valor |")
        ad("|---|---|")
        ad("| arquivos com texto extraido | %d |"
           % reg.contagem["arquivos_com_texto_extraido"])
        ad("| arquivos com data apurada por maquina | %d |" % com_data)
        ad("| arquivos com entidade apurada por maquina | %d |" % com_ent)
        ad("| arquivos sem texto extraido, nomeados no csv | %d |"
           % len(sem_texto))
        ad("| termos da ficha da area usados no casamento | %s |"
           % base_da_ficha)
        ad("")
        # De qual secao veio cada termo. A contagem total sozinha ja leu como
        # sucesso tendo zero termo de vocabulario local: tres termos raspados
        # de nome de arquivo apareciam como 'ficha da area lida: 3 termo(s)'.
        if ficha_por_secao:
            ad("| Secao da ficha da area | Termos | Quais |")
            ad("|---|---|---|")
            for secao, lista in ficha_por_secao:
                ad("| %s | %d | %s |"
                   % (secao, len(lista),
                      ", ".join(lista[:20]) if lista else "nenhum"))
            ad("")
        ad("A data e as entidades desta apuracao vao para o indice com a "
           "origem declarada, inclusive nas linhas que o modelo ainda nao leu: "
           "e o que faz o indice responder onde esta o documento que fala "
           "daquele equipamento sem esperar leitura de tudo. O que a extracao "
           "nao alcancou esta nomeado em `termos-por-documento.csv`, com o "
           "motivo, e sai como `nao apurado`, nunca chutado.")
        if sem_texto:
            ad("")
            ad("| Caminho | Por que nao saiu texto |")
            ad("|---|---|")
            for t in sem_texto[:60]:
                ad("| `%s` | %s |" % (t["caminho"], t["base_da_extracao"]))
    ad("")

    ad("## 8. Fechamento")
    ad("")
    ad("```")
    for linha in fechamento:
        ad(linha)
    ad("```")
    ad("")

    ad("## 9. Limite declarado")
    ad("")
    ad("O script nao acessa rede, nao acessa ERP e nao acessa servidor de "
       "arquivos: ele varre a pasta que recebeu, na maquina em que roda. Ele "
       "nao abre arquivo nenhum no modo padrao, e com `--contar-paginas` e com "
       "`--extrair-texto` abre na maquina local, sem enviar conteudo a lugar "
       "nenhum. Contagem de pagina em PDF e por leitura de estrutura, e sai "
       "como `nao apurado` sempre que as duas contagens independentes "
       "divergirem. A extracao de texto de PDF e parcial e declara que e: "
       "digitalizacao e fonte embutida por codigo saem sem texto, nomeadas, "
       "nunca com texto embaralhado. O que esta dentro de pasta ignorada, de "
       "pasta que nao pode ser listada, de atalho nao seguido e de atalho em "
       "ciclo **nao foi contado**, e os caminhos estao na secao 2.")
    ad("")
    ad(RODAPE)
    ad("")
    destino.write_text("\n".join(linhas), encoding="utf-8")


def montar_fechamento(reg, lidos_inv, lidos_nao, lidos_ruido, lidos_termos,
                      com_termos):
    c = reg.contagem
    linhas = []
    checagens = [
        ("arquivos_encontrados = inventariados + nao_lidos + ruido_filtrado",
         c["arquivos_encontrados"],
         c["arquivos_inventariados"] + c["arquivos_nao_lidos"]
         + c["arquivos_filtrados_como_ruido"]),
        ("linhas em inventario.csv = inventariados + nao_lidos",
         len(lidos_inv),
         c["arquivos_inventariados"] + c["arquivos_nao_lidos"]),
        # A lei de ferro "uma linha por documento" conferida no arquivo
        # gravado. Ciclo de atalho, atalho de pasta que aponta para dentro da
        # propria arvore e raiz alcancada por dois caminhos inventariavam o
        # mesmo documento mais de uma vez, e todas as outras identidades
        # fechavam.
        ("caminhos distintos em inventario.csv = linhas em inventario.csv",
         len(set(lidos_inv)), len(lidos_inv)),
        ("linhas em nao-lidos.csv = nao_lidos + pastas_nao_listadas + "
         "pastas_ignoradas + atalhos_de_pasta + atalhos_em_ciclo",
         len(lidos_nao),
         c["arquivos_nao_lidos"] + c["pastas_nao_listadas"]
         + c["pastas_ignoradas"] + c["atalhos_de_pasta"]
         + c["atalhos_em_ciclo"]),
        ("linhas em ruido-filtrado.csv = ruido_filtrado",
         len(lidos_ruido), c["arquivos_filtrados_como_ruido"]),
    ]
    if com_termos:
        checagens.append(
            ("linhas em termos-por-documento.csv = inventariados",
             len(lidos_termos), c["arquivos_inventariados"]))
    ok = True
    for rotulo, esquerda, direita in checagens:
        fecha = esquerda == direita
        ok = ok and fecha
        linhas.append("%-96s %6d = %6d  %s"
                      % (rotulo, esquerda, direita,
                         "fecha" if fecha else "QUEBRA"))
    repetidos = sorted(set(c for c in lidos_inv if lidos_inv.count(c) > 1))
    if repetidos:
        linhas.append("")
        linhas.append("CAMINHOS QUE APARECEM MAIS DE UMA VEZ NO INVENTARIO: %d"
                      % len(repetidos))
        for rel in repetidos[:50]:
            linhas.append("  %s" % rel)
    return linhas, ok


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Varre a pasta do acervo da area e grava o inventario.")
    p.add_argument("--pasta", required=True,
                   help="pasta raiz do acervo, varrida por inteiro")
    p.add_argument("--saida", required=True,
                   help="diretorio de saida da rodada")
    p.add_argument("--forcar", action="store_true",
                   help="regrava por cima de um diretorio de saida existente")
    p.add_argument("--contar-paginas", action="store_true",
                   help="abre cada arquivo na maquina local para contar "
                        "pagina, aba ou linha")
    p.add_argument("--marcar-duplicatas", action="store_true",
                   help="calcula sha256 local e agrupa arquivos identicos")
    p.add_argument("--extrair-texto", action="store_true",
                   help="abre na maquina local os formatos que a biblioteca "
                        "padrao le e apura por maquina a data do documento, as "
                        "entidades citadas e o trecho de busca, em "
                        "termos-por-documento.csv")
    p.add_argument("--ficha", metavar="CAMINHO",
                   default=str(Path("~/.kit-industrial/ficha-da-area.md")
                               .expanduser()),
                   help="ficha da area, de onde saem os codigos e as normas "
                        "que a extracao procura no texto")
    p.add_argument("--sem-ruido", action="store_true",
                   help="tira do inventario os arquivos de sistema de nome "
                        "conhecido e os nomeia em ruido-filtrado.csv")
    p.add_argument("--ignorar-pasta", action="append", metavar="NOME",
                   help="nome de pasta a nao varrer, repetivel. O que esta "
                        "dentro dela nao e contado, e a pasta sai nomeada")
    p.add_argument("--seguir-atalhos", action="store_true",
                   help="entra em atalho de pasta. Cuidado com ciclo")
    p.add_argument("--raiz-como", metavar="ROTULO", default="",
                   help="troca o caminho absoluto por um rotulo, mantendo o "
                        "caminho relativo, para o indice poder circular")
    p.add_argument("--max-bytes-abertura", type=int, default=40000000,
                   help="acima disso o arquivo nao e aberto e a contagem sai "
                        "como nao apurada (padrao 40000000)")
    args = p.parse_args(argv)

    raiz = Path(args.pasta).expanduser()
    if not raiz.exists():
        sys.stderr.write("erro: a pasta %s nao existe\n" % raiz)
        return 3
    if not raiz.is_dir():
        sys.stderr.write("erro: %s nao e uma pasta\n" % raiz)
        return 3
    raiz = raiz.resolve()

    destino = Path(args.saida).expanduser()
    if destino.exists() and not args.forcar:
        sys.stderr.write("erro: o diretorio %s ja existe. Use --forcar para "
                         "regravar\n" % destino)
        return 3
    try:
        destino.resolve().relative_to(raiz)
        sys.stderr.write("erro: o diretorio de saida esta dentro da pasta "
                         "varrida. Grave fora dela\n")
        return 3
    except ValueError:
        pass
    reg = Registro(str(raiz), args.raiz_como)
    varrer(raiz, args, reg)

    # Nome pedido em --ignorar-pasta que nao casou com nenhuma pasta encontrada
    # derruba a rodada ANTES de gravar qualquer arquivo. Antes, ele era ignorado
    # em silencio: a pessoa pedia para deixar a pasta de pessoal de fora, a
    # pasta era varrida normalmente, a cobertura registrava "pastas ignoradas |
    # 0" e o fechamento fechava.
    nao_casaram = [n for n in (args.ignorar_pasta or [])
                   if normalizar_pedido_de_pasta(n) not in reg.pedidos_casados]
    if nao_casaram:
        for n in nao_casaram:
            sys.stderr.write("erro: --ignorar-pasta '%s' nao casou com nenhuma "
                             "pasta encontrada na varredura. Confira o nome, e "
                             "escreva o nome da pasta, nao o caminho dela\n"
                             % n)
        return 3

    destino.mkdir(parents=True, exist_ok=True)

    grupos = []
    if args.marcar_duplicatas:
        grupos = marcar_duplicatas(reg, args.max_bytes_abertura)

    termos = []
    base_da_ficha = "rodada sem extracao de texto"
    ficha_por_secao = []
    if args.extrair_texto:
        termos_ficha, base_da_ficha, ficha_por_secao = termos_da_ficha(
            args.ficha)
        termos = apurar_termos(reg, args, termos_ficha)

    arq_inv = destino / "inventario.csv"
    arq_nao = destino / "nao-lidos.csv"
    arq_ruido = destino / "ruido-filtrado.csv"
    arq_termos = destino / "termos-por-documento.csv"
    escrever_csv(arq_inv, COLUNAS_INVENTARIO, reg.inventario)
    escrever_csv(arq_nao, COLUNAS_NAO_LIDOS, reg.nao_lidos)
    if args.sem_ruido:
        escrever_csv(arq_ruido, COLUNAS_RUIDO, reg.ruido)
    if args.extrair_texto:
        escrever_csv(arq_termos, COLUNAS_TERMOS, termos)

    lidos_inv = reler_caminhos(arq_inv)
    lidos_nao = reler_caminhos(arq_nao)
    lidos_ruido = reler_caminhos(arq_ruido) if args.sem_ruido else []
    lidos_termos = reler_caminhos(arq_termos) if args.extrair_texto else []

    fechamento, ok_fecha = montar_fechamento(reg, lidos_inv, lidos_nao,
                                             lidos_ruido, lidos_termos,
                                             args.extrair_texto)

    # A prova que nao e tautologia: tudo o que a varredura VIU tem que estar
    # gravado em algum dos arquivos. Sem isto, um ramo de classificacao que
    # esquecesse de anexar a linha sairia com codigo 0 tendo perdido arquivo.
    gravados = set()
    for rel in list(lidos_inv) + list(lidos_nao) + list(lidos_ruido):
        gravados.add(rel)
    perdidos = []
    for absoluto in sorted(reg.vistos):
        if rel_posix(absoluto, raiz) not in gravados:
            perdidos.append(rel_posix(absoluto, raiz))
    if perdidos:
        ok_fecha = False
        fechamento.append("")
        fechamento.append("ITENS VISTOS PELA VARREDURA E NAO GRAVADOS EM "
                          "ARQUIVO NENHUM: %d" % len(perdidos))
        for rel in perdidos[:50]:
            fechamento.append("  %s" % rel)

    escrever_cobertura(destino / "cobertura.md", raiz, args, reg, grupos,
                       fechamento, ok_fecha, termos, base_da_ficha,
                       ficha_por_secao)

    for linha in fechamento:
        print(linha)
    print("")
    print("inventario ...... %s" % arq_inv)
    print("nao lidos ....... %s" % arq_nao)
    if args.sem_ruido:
        print("ruido filtrado .. %s" % arq_ruido)
    if args.extrair_texto:
        print("termos .......... %s" % arq_termos)
    print("cobertura ....... %s" % (destino / "cobertura.md"))

    if not ok_fecha:
        sys.stderr.write("erro: o fechamento nao fecha. A saida nao vale\n")
        return 3

    pendentes = (reg.contagem["arquivos_nao_lidos"]
                 + reg.contagem["arquivos_filtrados_como_ruido"]
                 + reg.contagem["pastas_nao_listadas"]
                 + reg.contagem["pastas_ignoradas"]
                 + reg.contagem["atalhos_de_pasta"]
                 + reg.contagem["atalhos_em_ciclo"])
    if pendentes:
        print("")
        print("%d item(ns) ficaram fora da leitura e estao nomeados em %s"
              % (pendentes, arq_nao))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
