#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
conferir-indice.py, conferidor do indice contra o inventario da varredura.

Biblioteca padrao apenas, Python 3.8 ou superior. Sem rede.

Por que este script existe. O inventario e feito por maquina e nao perde
arquivo. O indice e escrito pelo modelo, e e ai que o documento some: o modelo
le trinta dos duzentos e escreve o indice dos trinta, com cara de completo.
Este script torna esse desaparecimento impossivel de passar, porque a
conferencia e mecanica: uma linha de indice por arquivo do inventario, com
caminho, e resumo escrito so onde houve leitura.

Codigos de saida:

  0  o indice cobre o inventario inteiro e todo documento foi lido nesta
     rodada
  1  o indice cobre o inventario inteiro, e ha documento sem leitura, por
     falha da varredura, por falha na leitura ou por escolha da pessoa. Todos
     saem nomeados
  2  o gabarito nao bateu, ou foi passado e nao comparou nenhum campo. A skill
     nao vai para o trabalho real assim
  3  indice invalido: documento faltando, caminho em branco, resumo escrito
     para documento nao lido, coluna faltando, id que nao e o da varredura,
     linha de indice sem caminho, dado apurado por maquina que o indice
     descartou, ou fechamento que nao fecha

Uso:

    python3 ~/.claude/skills/indice-do-acervo-da-area/scripts/conferir-indice.py \
        --rodada acervo-2026-09-20

No PowerShell:

    py -3 "$env:USERPROFILE\.claude\skills\indice-do-acervo-da-area\scripts\conferir-indice.py" `
        --rodada acervo-2026-09-20
"""

import argparse
import csv
import re
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

VERSAO = "1.1"

RODAPE_MARCA = "Gerado com apoio de IA"
MARCA_INICIO = "<!-- inicio do indice -->"
MARCA_FIM = "<!-- fim do indice -->"
MARCA_FECHAMENTO = "<!-- fechamento do indice -->"
PREFIXO_NAO_LIDO = "NAO LIDO:"

COLUNAS_INDICE = ["id", "caminho", "data_do_documento", "origem_da_data",
                  "assunto", "resumo", "entidades", "status_leitura"]
OBRIGATORIAS_PREENCHIDAS = ["id", "data_do_documento", "origem_da_data",
                            "assunto", "resumo", "entidades", "status_leitura"]
ST_OK = "inventariado"

# Motivo depois de NAO LIDO: que conta como decisao da pessoa. Todo o resto,
# num documento que a varredura leu sem erro, e falha na leitura, e falha na
# leitura nao e escolha: contar as duas no mesmo balde escondia no fechamento
# o documento que o modelo abriu e nao entendeu.
MOTIVOS_DE_ESCOLHA = ("nao selecionado nesta leva", "nao liberado nesta rodada")

COLUNAS_GABARITO_SAIDA = ["caminho", "campo", "valor_no_gabarito",
                          "valor_no_indice", "bate"]
COLUNAS_NAO_LIDOS_LEITURA = ["id", "caminho", "status_da_varredura",
                             "motivo_escrito_no_indice"]

RODAPE = ("Gerado com apoio de IA a partir da varredura da pasta do acervo. "
          "Revisar antes de assinar. Nao substitui responsabilidade tecnica.")


def sem_acento(texto):
    nfkd = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def chave_texto(texto):
    limpo = sem_acento((texto or "").strip().lower())
    limpo = re.sub(r"[\s]+", " ", limpo)
    return limpo.strip(" .;:,")


def limpar_marcas(texto):
    """Tira crase, asterisco e espaco das pontas de um campo.

    A SKILL escreve os exemplos entre crases, e o modelo copia esse habito para
    dentro do campo. Crase no comeco do resumo fazia o teste de prefixo falhar e
    o conferidor acusar invencao de resumo, que e a acusacao mais grave da
    skill, num campo que estava certo."""
    return (texto or "").strip().strip("`*_ ").strip()


def chave_data(texto):
    """Devolve (ano, mes, dia) em aaaa-mm-dd, dd/mm/aaaa ou dd-mm-aaaa.

    Nao reconhecendo, devolve None e a comparacao volta a ser de texto. O
    gabarito existe para pegar divergencia de data, nao divergencia de
    formatacao: a data certa escrita no formato do documento reprovava a skill
    e travava o uso real."""
    bruto = limpar_marcas(texto)
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", bruto)
    if m:
        ano, mes, dia = m.group(1), m.group(2), m.group(3)
    else:
        m = re.match(r"^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$", bruto)
        if not m:
            return None
        dia, mes, ano = m.group(1), m.group(2), m.group(3)
    try:
        ano, mes, dia = int(ano), int(mes), int(dia)
    except ValueError:
        return None
    if not (1 <= dia <= 31 and 1 <= mes <= 12 and 1900 <= ano <= 2100):
        return None
    return (ano, mes, dia)


def ler_csv(caminho):
    """Le o CSV e descarta o rodape, esteja ele prefixado ou nao.

    O rodape e obrigatorio em todo artefato. Exigir que ele fosse a primeira
    coluna prefixada com '# ' era um contrato que existia so dentro deste
    script: escrito do jeito obvio, o rodape virava linha de dado sem caminho e
    derrubava a rodada inteira."""
    with caminho.open(encoding="utf-8-sig", newline="") as fh:
        leitor = csv.DictReader(fh, delimiter=";")
        campos = leitor.fieldnames or []
        linhas = list(leitor)
    # Linha de rodape e a ultima, e ela nao tem caminho. Documento cujo resumo
    # por acaso cite a marca do rodape continua sendo linha de dado, porque tem
    # caminho: descartar linha com caminho seria perder documento em silencio,
    # que e exatamente o que esta script existe para impedir.
    while linhas:
        ultima = linhas[-1]
        valores = [(ultima.get(c) or "") for c in campos]
        primeiro = valores[0] if valores else ""
        tem_caminho = bool((ultima.get("caminho") or "").strip())
        if (primeiro.lstrip().startswith("#")
                or (not tem_caminho and any(RODAPE_MARCA in v
                                            for v in valores))):
            linhas.pop()
            continue
        break
    linhas = [l for l in linhas
              if not ((l.get(campos[0]) or "").lstrip().startswith("#")
                      if campos else False)]
    return campos, linhas


def escrever_csv(caminho, colunas, linhas):
    with caminho.open("w", encoding="utf-8-sig", newline="") as fh:
        escritor = csv.writer(fh, delimiter=";", quoting=csv.QUOTE_MINIMAL,
                              lineterminator="\r\n")
        escritor.writerow(colunas)
        for linha in linhas:
            escritor.writerow([linha.get(c, "") for c in colunas])
        escritor.writerow(["# " + RODAPE] + [""] * (len(colunas) - 1))


def e_separadora(linha):
    return bool(re.match(r"^\|[\s:\-|]+\|$", linha or ""))


def caminhos_no_md(texto):
    """Devolve (linhas_de_tabela, caminhos_citados, problema) do trecho marcado.

    So o trecho entre as marcas e conferido. Sem as marcas nao ha como
    separar a tabela do indice de outra tabela qualquer do arquivo, e adivinhar
    qual e qual e exatamente o tipo de heuristica que apaga linha em silencio.

    O cabecalho e reconhecido pela linha separadora que vem abaixo dele, nunca
    pela palavra da primeira celula. Reconhecer por palavra derrubava com
    codigo 3 todo indice.md cuja tabela nao comecasse pela coluna Id, e a
    mensagem culpava a linha errada.

    O caminho e lido da celula da coluna Caminho, e nao da linha inteira: crase
    em outra celula, como em `NAO LIDO: ...`, era lida como caminho citado e o
    conferidor acusava o indice de citar documento fora do inventario."""
    if MARCA_INICIO not in texto or MARCA_FIM not in texto:
        return None, None, ""
    trecho = texto.split(MARCA_INICIO, 1)[1].split(MARCA_FIM, 1)[0]
    brutas = [l.strip() for l in trecho.splitlines() if l.strip().startswith("|")]
    cabecalho = None
    linhas = []
    for i, linha in enumerate(brutas):
        if e_separadora(linha):
            continue
        if cabecalho is None and i + 1 < len(brutas) and e_separadora(brutas[i + 1]):
            cabecalho = [chave_texto(c) for c in linha.strip("|").split("|")]
            continue
        linhas.append(linha)
    if cabecalho is None:
        return linhas, None, ("a linha de cabecalho da tabela do indice nao foi "
                              "reconhecida: a tabela precisa ter a linha "
                              "separadora |---|---| logo abaixo do cabecalho")
    if "caminho" not in cabecalho:
        return linhas, None, ("a tabela do indice.md nao tem a coluna Caminho "
                              "no cabecalho. O cabecalho lido foi: %s"
                              % ", ".join(cabecalho))
    coluna = cabecalho.index("caminho")
    citados = []
    for linha in linhas:
        celulas = [c.strip() for c in linha.strip("|").split("|")]
        if len(celulas) <= coluna:
            citados.append(set())
            continue
        citados.append(set(re.findall(r"`([^`]+)`", celulas[coluna])))
    return linhas, citados, ""


def bate_o_campo(campo, esperado, obtido):
    if campo == "data_do_documento":
        a, b = chave_data(esperado), chave_data(obtido)
        if a is not None and b is not None:
            return a == b
    return chave_texto(esperado) == chave_texto(obtido)


def conferir_gabarito(gabarito, por_caminho, erros):
    """Devolve (linhas, bate, nao_bate, comparados).

    O contador de campos comparados existe porque o gabarito e o portao que
    libera o uso no trabalho real, e ele passava comparando nada: CSV com os
    caminhos certos e as duas colunas em branco imprimia '0 campo(s) bateram, 0
    nao bateram' e a rodada seguia como validada."""
    campos, linhas = ler_csv(gabarito)
    faltando = [c for c in ("caminho",) if c not in (campos or [])]
    if faltando:
        erros.append("o gabarito nao tem a coluna caminho")
        return [], 0, 0, 0
    saida = []
    bate = 0
    nao_bate = 0
    comparados = 0
    for linha in linhas:
        caminho = (linha.get("caminho") or "").strip()
        if not caminho:
            erros.append("o gabarito tem linha com caminho em branco")
            continue
        alvo = por_caminho.get(caminho)
        if alvo is None:
            erros.append("o gabarito aponta %s, que nao esta no indice desta "
                         "rodada. A coluna caminho do gabarito leva o caminho "
                         "relativo a raiz varrida, com barra normal, igual ao "
                         "que esta no inventario.csv" % caminho)
            continue
        for campo in ("data_do_documento", "assunto"):
            esperado = (linha.get(campo) or "").strip()
            if not esperado:
                continue
            comparados += 1
            obtido = (alvo.get(campo) or "").strip()
            if bate_o_campo(campo, esperado, obtido):
                veredito = "sim"
                bate += 1
            elif campo == "assunto":
                veredito = "conferir"
            else:
                veredito = "nao"
                nao_bate += 1
            saida.append({"caminho": caminho, "campo": campo,
                          "valor_no_gabarito": esperado,
                          "valor_no_indice": obtido, "bate": veredito})
    return saida, bate, nao_bate, comparados


def atualizar_cobertura(cobertura, status, bloco):
    if not cobertura.exists():
        return
    texto = cobertura.read_text(encoding="utf-8")
    texto = re.sub(r"^status: .*$", "status: %s" % status, texto, count=1,
                   flags=re.M)
    if MARCA_FECHAMENTO in texto:
        texto = texto.split(MARCA_FECHAMENTO, 1)[0].rstrip() + "\n\n"
    else:
        texto = texto.rstrip() + "\n\n"
    texto += MARCA_FECHAMENTO + "\n\n" + bloco.rstrip() + "\n"
    cobertura.write_text(texto, encoding="utf-8")


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Confere o indice escrito pelo modelo contra o "
                    "inventario da varredura.")
    p.add_argument("--rodada", required=True,
                   help="diretorio da rodada, com inventario.csv, "
                        "nao-lidos.csv, indice.csv e indice.md")
    p.add_argument("--inventario", help="caminho do inventario.csv, quando "
                                        "estiver fora do diretorio da rodada")
    p.add_argument("--indice", help="caminho do indice.csv")
    p.add_argument("--indice-md", help="caminho do indice.md")
    p.add_argument("--gabarito", help="CSV com caminho, data_do_documento e "
                                      "assunto do caso ja feito a mao")
    args = p.parse_args(argv)

    rodada = Path(args.rodada).expanduser()
    if not rodada.is_dir():
        sys.stderr.write("erro: %s nao e um diretorio\n" % rodada)
        return 3
    arq_inv = Path(args.inventario) if args.inventario else rodada / "inventario.csv"
    arq_ind = Path(args.indice) if args.indice else rodada / "indice.csv"
    arq_md = Path(args.indice_md) if args.indice_md else rodada / "indice.md"
    arq_nao = rodada / "nao-lidos.csv"
    cobertura = rodada / "cobertura.md"

    for arq, rotulo in ((arq_inv, "inventario.csv"), (arq_ind, "indice.csv")):
        if not arq.exists():
            sys.stderr.write("erro: %s nao existe em %s\n" % (rotulo, rodada))
            return 3

    erros = []
    campos_inv, linhas_inv = ler_csv(arq_inv)
    campos_ind, linhas_ind = ler_csv(arq_ind)

    faltam = [c for c in COLUNAS_INDICE if c not in (campos_ind or [])]
    if faltam:
        sys.stderr.write("erro: o indice.csv nao tem as colunas: %s\n"
                         % ", ".join(faltam))
        return 3

    inv_por_caminho = {}
    for linha in linhas_inv:
        caminho = (linha.get("caminho") or "").strip()
        if not caminho:
            erros.append("o inventario tem linha com caminho em branco: a "
                         "varredura precisa ser refeita")
            continue
        inv_por_caminho[caminho] = linha

    # Texto apurado por maquina na varredura, quando a rodada usou
    # --extrair-texto. O que a maquina apurou nao pode ser descartado pelo
    # indice: e dado que a rodada ja tem na mao.
    termos_por_caminho = {}
    arq_termos = rodada / "termos-por-documento.csv"
    if arq_termos.exists():
        _, linhas_termos = ler_csv(arq_termos)
        for linha in linhas_termos:
            chave = (linha.get("caminho") or "").strip()
            if chave:
                termos_por_caminho[chave] = linha

    ind_por_caminho = {}
    vistos = []
    # Contado no laco, linha a linha. Nenhum destes quatro e derivado por
    # subtracao dos outros: contador derivado fecha sozinho mesmo com linha
    # faltando.
    lidas = 0
    nao_lidas_por_falha = 0
    nao_lidas_por_falha_na_leitura = 0
    nao_lidas_por_escolha = 0
    nao_lidas_na_leitura = []

    for linha in linhas_ind:
        caminho = (linha.get("caminho") or "").strip()
        if not caminho:
            erros.append("linha de indice id=%s sem caminho. Caminho e "
                         "obrigatorio em toda linha"
                         % (linha.get("id") or "sem id"))
            continue
        vistos.append(caminho)
        if caminho in ind_por_caminho:
            erros.append("o caminho %s aparece mais de uma vez no indice"
                         % caminho)
            continue
        ind_por_caminho[caminho] = linha

        for campo in OBRIGATORIAS_PREENCHIDAS:
            if not (linha.get(campo) or "").strip():
                erros.append("linha %s: a coluna %s esta em branco. Campo sem "
                             "apuracao se escreve 'nao apurado', nunca em "
                             "branco" % (caminho, campo))

        origem = inv_por_caminho.get(caminho)
        if origem is None:
            erros.append("o indice tem %s, que nao esta no inventario. Indice "
                         "nao inventa documento" % caminho)
            continue

        id_inv = (origem.get("id") or "").strip()
        id_ind = (linha.get("id") or "").strip()
        if id_inv and id_ind and id_inv != id_ind:
            erros.append("linha %s: o id do indice diz '%s' e o inventario diz "
                         "'%s'. O id vem da varredura e se copia, nao se "
                         "escreve" % (caminho, id_ind, id_inv))

        status_inv = (origem.get("status_leitura") or "").strip()
        status_ind = (linha.get("status_leitura") or "").strip()
        if status_inv != status_ind:
            erros.append("linha %s: status_leitura do indice diz '%s' e o "
                         "inventario diz '%s'. O status vem da varredura e "
                         "nao se reescreve a mao"
                         % (caminho, status_ind, status_inv))
            continue

        resumo = limpar_marcas(linha.get("resumo"))
        marcado = resumo.upper().startswith(PREFIXO_NAO_LIDO)
        motivo_no_indice = resumo[len(PREFIXO_NAO_LIDO):].strip() if marcado else ""
        if status_inv != ST_OK:
            if not marcado:
                erros.append("linha %s: a varredura nao conseguiu ler este "
                             "documento (%s) e o indice traz resumo escrito. "
                             "Resumo de documento nao lido e invencao: a "
                             "linha leva '%s <motivo>'"
                             % (caminho, status_inv, PREFIXO_NAO_LIDO))
                continue
            nao_lidas_por_falha += 1
        elif marcado:
            if chave_texto(motivo_no_indice) in [chave_texto(m)
                                                 for m in MOTIVOS_DE_ESCOLHA]:
                nao_lidas_por_escolha += 1
            else:
                nao_lidas_por_falha_na_leitura += 1
                nao_lidas_na_leitura.append({
                    "id": id_ind or id_inv,
                    "caminho": caminho,
                    "status_da_varredura": status_inv,
                    "motivo_escrito_no_indice": motivo_no_indice,
                })
        else:
            lidas += 1

        # O que a varredura apurou por maquina nao se perde na passagem para o
        # indice. Sem esta conferencia, a data e as entidades extraidas ficavam
        # gravadas em termos-por-documento.csv e o indice saia com 'nao
        # apurado', e a rodada fechava como completa.
        #
        # A guarda vale para toda linha que tenha termo apurado, lida ou nao.
        # Ela ja exigiu tambem 'marcado', e 'marcado' e o documento NAO LIDO:
        # a checagem so rodava justamente na linha que nao tem dado apurado, e
        # o caso normal, o documento lido, podia zerar data e entidades sem que
        # o conferidor dissesse nada. A tabela de codigos promete codigo 3 para
        # 'dado apurado por maquina que o indice descartou' e a promessa nao
        # era cumprida.
        termo = termos_por_caminho.get(caminho)
        if termo:
            for campo_termo, campo_indice, rotulo in (
                    ("data_no_texto", "data_do_documento", "a data"),
                    ("entidades_no_texto", "entidades", "as entidades")):
                apurado = (termo.get(campo_termo) or "").strip()
                no_indice = limpar_marcas(linha.get(campo_indice))
                if (apurado and apurado != "nao apurado"
                        and chave_texto(no_indice) == "nao apurado"):
                    erros.append(
                        "linha %s: a extracao por maquina apurou %s ('%s') e o "
                        "indice traz 'nao apurado'. Copie o valor e a origem do "
                        "termos-por-documento.csv: dado que a rodada ja apurou "
                        "nao se descarta" % (caminho, rotulo, apurado[:60]))

    faltantes = sorted(set(inv_por_caminho) - set(ind_por_caminho))
    for caminho in faltantes:
        erros.append("o inventario tem %s e o indice nao. Documento que a "
                     "rodada nao leu entra no indice com o motivo, nunca some"
                     % caminho)

    # Terceira fonte: nao-lidos.csv, gravado pela varredura. Confere o que o
    # indice diz sobre falha de leitura contra o que a varredura registrou.
    nao_lidos_arquivos = 0
    if arq_nao.exists():
        _, linhas_nao = ler_csv(arq_nao)
        nao_lidos_arquivos = sum(1 for l in linhas_nao
                                 if (l.get("tipo") or "").strip() == "arquivo")

    # indice.md
    md_ok = True
    if arq_md.exists():
        texto = arq_md.read_text(encoding="utf-8")
        linhas_md, citados, problema_md = caminhos_no_md(texto)
        if linhas_md is None:
            erros.append("o indice.md nao tem as marcas %s e %s em volta da "
                         "tabela do indice" % (MARCA_INICIO, MARCA_FIM))
            md_ok = False
        elif citados is None:
            erros.append("o indice.md: %s" % problema_md)
            md_ok = False
        else:
            citados_todos = set()
            for i, conjunto in enumerate(citados):
                if not conjunto:
                    erros.append("o indice.md tem linha de tabela sem caminho "
                                 "entre crases na coluna Caminho: %s"
                                 % linhas_md[i][:120])
                citados_todos |= conjunto
            sem_linha = sorted(set(ind_por_caminho) - citados_todos)
            for caminho in sem_linha[:50]:
                erros.append("o caminho %s esta no indice.csv e nao aparece "
                             "no indice.md" % caminho)
            sobrando = sorted(citados_todos - set(inv_por_caminho))
            for caminho in sobrando[:50]:
                erros.append("o indice.md cita `%s`, que nao esta no "
                             "inventario" % caminho)
        if RODAPE_MARCA not in texto:
            erros.append("o indice.md nao traz o rodape obrigatorio")
    else:
        erros.append("o indice.md nao existe em %s. O indice que a pessoa "
                     "consulta e ele" % rodada)
        md_ok = False

    fechamento = []
    checagens = [
        ("linhas em inventario.csv = linhas em indice.csv",
         len(inv_por_caminho), len(ind_por_caminho)),
        ("linhas em indice.csv = lidas + falha_da_varredura + "
         "falha_na_leitura + escolha",
         len(ind_por_caminho),
         lidas + nao_lidas_por_falha + nao_lidas_por_falha_na_leitura
         + nao_lidas_por_escolha),
        ("arquivos em nao-lidos.csv = nao_lidas_por_falha no indice",
         nao_lidos_arquivos, nao_lidas_por_falha),
    ]
    fecha_tudo = True
    for rotulo, esquerda, direita in checagens:
        fecha = esquerda == direita
        fecha_tudo = fecha_tudo and fecha
        fechamento.append("%-70s %6d = %6d  %s"
                          % (rotulo, esquerda, direita,
                             "fecha" if fecha else "QUEBRA"))

    # Documento que o modelo abriu e nao entendeu sai nomeado em arquivo
    # proprio. Ele nao esta no nao-lidos.csv, que e da varredura, e alguem tem
    # que responder por ele do mesmo jeito.
    if nao_lidas_na_leitura:
        escrever_csv(rodada / "nao-lidos-na-leitura.csv",
                     COLUNAS_NAO_LIDOS_LEITURA, nao_lidas_na_leitura)

    gab_linhas, gab_bate, gab_nao, gab_comparados = ([], 0, 0, 0)
    if args.gabarito:
        arq_gab = Path(args.gabarito).expanduser()
        if not arq_gab.exists():
            sys.stderr.write("erro: o gabarito %s nao existe\n" % arq_gab)
            return 3
        gab_linhas, gab_bate, gab_nao, gab_comparados = conferir_gabarito(
            arq_gab, ind_por_caminho, erros)
        escrever_csv(rodada / "gabarito-conferido.csv",
                     COLUNAS_GABARITO_SAIDA, gab_linhas)

    if args.gabarito:
        linha_gabarito = "gabarito: %d campos comparados" % gab_comparados
    else:
        linha_gabarito = ("gabarito: nao rodado nesta rodada, saida nao "
                          "validada")

    for linha in fechamento:
        print(linha)
    print("")
    print("documentos lidos nesta rodada ........... %d" % lidas)
    print("nao lidos por falha da varredura ........ %d" % nao_lidas_por_falha)
    print("nao lidos por falha na leitura .......... %d"
          % nao_lidas_por_falha_na_leitura)
    print("nao lidos por escolha, ainda no indice .. %d"
          % nao_lidas_por_escolha)
    print(linha_gabarito)
    if args.gabarito:
        print("gabarito: %d campo(s) bateram, %d nao bateram, %d para "
              "conferencia humana"
              % (gab_bate, gab_nao,
                 sum(1 for l in gab_linhas if l["bate"] == "conferir")))

    if erros:
        print("")
        print("PROBLEMAS QUE INVALIDAM O INDICE: %d" % len(erros))
        for erro in erros[:80]:
            print("  - %s" % erro)
        if len(erros) > 80:
            print("  ... e mais %d" % (len(erros) - 80))

    contagens = (lidas, nao_lidas_por_falha, nao_lidas_por_falha_na_leitura,
                 nao_lidas_por_escolha)

    if erros or not fecha_tudo:
        bloco = bloco_cobertura("invalido, nao fecha", fechamento, contagens,
                                erros, gab_linhas, linha_gabarito)
        atualizar_cobertura(cobertura, "invalido, nao fecha", bloco)
        sys.stderr.write("erro: o indice nao passou na conferencia\n")
        return 3

    if args.gabarito and gab_comparados == 0:
        bloco = bloco_cobertura("gabarito nao comparou nada", fechamento,
                                contagens, erros, gab_linhas, linha_gabarito)
        atualizar_cobertura(cobertura, "gabarito nao comparou nada", bloco)
        sys.stderr.write("erro: o gabarito nao comparou nenhum campo: preencha "
                         "data_do_documento e assunto antes de rodar. Gabarito "
                         "em branco nao valida nada\n")
        return 2

    if gab_nao:
        bloco = bloco_cobertura("gabarito nao bateu", fechamento, contagens,
                                erros, gab_linhas, linha_gabarito)
        atualizar_cobertura(cobertura, "gabarito nao bateu", bloco)
        sys.stderr.write("erro: o gabarito nao bateu em %d campo(s). A skill "
                         "nao vai para o trabalho real assim\n" % gab_nao)
        return 2

    pendentes = (nao_lidas_por_falha + nao_lidas_por_falha_na_leitura
                 + nao_lidas_por_escolha)
    status = "completo com pendencias" if pendentes else "completo"
    if not args.gabarito:
        # A lei do gabarito fica conferivel no arquivo, e nao so na conversa.
        status += ", nao validado"
    bloco = bloco_cobertura(status, fechamento, contagens, erros, gab_linhas,
                            linha_gabarito)
    atualizar_cobertura(cobertura, status, bloco)
    if not md_ok:
        return 3
    if pendentes:
        print("")
        print("%d documento(s) estao no indice sem leitura, nomeados na "
              "coluna resumo com o prefixo %s" % (pendentes, PREFIXO_NAO_LIDO))
        return 1
    return 0


def bloco_cobertura(status, fechamento, contagens, erros, gab_linhas,
                    linha_gabarito):
    lidas, falha, falha_leitura, escolha = contagens
    linhas = ["## 10. Fechamento do indice", "",
              "status do indice: %s" % status,
              linha_gabarito,
              "conferido em %s, conferir-indice.py %s"
              % (datetime.now().strftime("%Y-%m-%d %H:%M"), VERSAO), "",
              "```"]
    linhas.extend(fechamento)
    linhas.append("```")
    linhas.extend(["",
                   "| Situacao | Documentos |", "|---|---|",
                   "| lidos nesta rodada | %d |" % lidas,
                   "| nao lidos por falha da varredura | %d |" % falha,
                   "| nao lidos por falha na leitura, nomeados em "
                   "nao-lidos-na-leitura.csv | %d |" % falha_leitura,
                   "| nao lidos por escolha, no indice com o motivo | %d |"
                   % escolha, ""])
    if gab_linhas:
        linhas.extend(["### Gabarito", "",
                       "| Caminho | Campo | No gabarito | No indice | Bate |",
                       "|---|---|---|---|---|"])
        for l in gab_linhas:
            linhas.append("| `%s` | %s | %s | %s | %s |"
                          % (l["caminho"], l["campo"], l["valor_no_gabarito"],
                             l["valor_no_indice"], l["bate"]))
        linhas.append("")
    if erros:
        linhas.extend(["### Problemas", ""])
        for erro in erros[:80]:
            linhas.append("- %s" % erro)
        linhas.append("")
    linhas.append(RODAPE)
    return "\n".join(linhas)


if __name__ == "__main__":
    sys.exit(main())
