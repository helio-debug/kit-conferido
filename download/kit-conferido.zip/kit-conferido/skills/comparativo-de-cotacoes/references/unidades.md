# Armadilhas de unidade em cotação industrial

Cada item traz como se manifesta, como se detecta, como se corrige, e o risco de corrigir
errado. O risco é a parte que costuma faltar, e é a que estraga o comparativo.

Princípio geral: **a unidade é decidida por item, olhando todas as propostas daquele item,
nunca linha a linha.** Decisão tomada linha a linha produz um item com duas réguas dentro
dele, e o comparativo continua com cara de certo.

Ordem de trabalho: primeiro as três classes de fator (o fator pode ser aplicado?), depois o
grupo 1 (a dimensão é a mesma?), depois o grupo 2 (a embalagem esconde quanto?), depois o
grupo 3 (o preço cobre o quê?), e por último os grupos 4 e 5.

---

## As três classes de fator

É a distinção mais importante deste arquivo. Ela separa o que se pode converter do que só a
proposta pode dizer.

| Classe | O que é | Exemplos | O que fazer |
|---|---|---|---|
| **Fixo** | O fator é físico ou aritmético e vale em qualquer proposta, de qualquer fornecedor, em qualquer região | 1 t = 1000 kg, 1 km = 1000 m, 1 mL = 0,001 L, 1 milheiro = 1000 unidades, 1 dúzia = 12 | Aplicar, e declarar na nota |
| **Declarado** | O fator existe, mas quem o define é a proposta | caixa com 100 unidades, barra de 6 m, saco de 25 kg, rolo de 100 m, tambor de 200 L | Aplicar quando a proposta declarou. Sem declaração, a linha não é comparável |
| **Proibido** | O fator varia por fornecedor, por produto e por região, e "todo mundo sabe" não é fonte | galão, saco, tambor, bombona, barra, arroba, resma | Nunca aplicar sem declaração, nem com o valor de mercado. A linha sai do comparativo e vira pergunta ao fornecedor |

A regra prática: **fator que você sabe de cabeça, mas que muda de fornecedor para
fornecedor, é proibido.** Ele é mais perigoso que a unidade desconhecida, porque a unidade
desconhecida trava e o fator "sabido" passa.

### Tabela de fator fixo

| Dimensão | Base | Fatores |
|---|---|---|
| Comprimento | m | mm 0,001; cm 0,01; m 1; km 1000; pé 0,3048 |
| Massa | kg | mg 0,000001; g 0,001; kg 1; t 1000; lb 0,45359237 |
| Volume | L | mL 0,001; cm³ 0,001; L 1; m³ 1000 |
| Área | m² | cm² 0,0001; m² 1; ha 10000 |
| Contagem | un | un 1; par 2; dúzia 12; cento 100; milheiro 1000 |

A polegada não está na tabela, e a ausência é deliberada: em tubo, conexão, válvula e
mangueira a polegada cotada é designação nominal, que é nome e não medida, conforme o item
5.4. O script trata `pol`, `polegada` e `in` como unidade ambígua e manda a linha para
`nao-comparaveis.csv` com a pergunta pronta.

Na sua tabela de itens, escreva o símbolo como símbolo: o quilograma é `kg` e a tonelada é
`t`. O script aceita as grafias que os fornecedores usam de fato, inclusive `Ton` e `T`, e
registra na nota o fator que aplicou. O cadastro é outra história: cadastro que aceita duas
grafias acaba com duas colunas para a mesma coisa, e `T` ainda é símbolo de outra
grandeza.

---

## Grupo 1: a dimensão não é a mesma

### 1.1 Peça contra metro, a armadilha central

*Manifesta:* o mesmo item cotado como 10 unidades de 1 metro por um fornecedor e como 1
unidade de 10 metros por outro. Os preços unitários, 30,00 e 280,00, parecem diferir por
dez. Por metro, são 30,00 e 28,00.

*Detecta:* a unidade cotada é de contagem (peça, unidade, barra, rolo) e o item é medido em
comprimento, massa ou volume. Sinal adicional: os preços unitários do mesmo item diferem
por uma ordem de grandeza redonda, dez ou cem ou mil.

*Corrige:* converter pela quantidade declarada dentro da peça. A declaração manda sobre a
unidade de contagem: `peça` mais `barra de 6 m` vale 6 metros, não 1 peça.

*Risco:* comparar peça com peça quando as peças têm tamanhos diferentes. É o erro que esta
skill existe para impedir, e ele não deixa rastro: o comparativo sai completo, ordenado e
errado.

### 1.2 Milheiro e cento

*Manifesta:* parafuso cotado a 1.240,00 o milheiro contra 1,19 a peça. A leitura ingênua
conclui que um fornecedor está mil vezes mais caro.

*Detecta:* unidade `milheiro`, `mil`, `mlh`, `cento`. Frequente em parafuso, arruela,
rebite, terminal, conector, etiqueta.

*Corrige:* fator fixo. Milheiro é 1000 unidades, cento é 100, por definição.

*Risco:* baixo no fator, alto na leitura. O perigo é alguém ler a coluna de preço unitário
sem olhar a coluna de unidade, que é exatamente o que acontece quando o comparativo é
montado à mão sob prazo.

### 1.3 Tonelada, quilo e saco

*Manifesta:* insumo cotado em R$/t por um fornecedor, R$/kg por outro e R$/saco por um
terceiro.

*Detecta:* a mesma dimensão em três unidades diferentes na mesma linha de item.

*Corrige:* tonelada e quilo são fator fixo. Saco é **proibido**: 20, 25, 40 e 50 kg
aparecem todos, conforme o produto e o fornecedor. Sem a massa declarada na proposta, a
linha não entra.

*Risco:* assumir 50 kg porque "saco é sempre 50". Um erro de 25 para 50 é um erro de 100%
no preço unitário, e ele passa despercebido porque o número continua plausível.

### 1.4 Litro, galão e tambor

*Manifesta:* óleo, tinta, solvente e desengraxante cotados em litro, em galão, em balde e
em tambor.

*Detecta:* unidade de volume que não é litro nem múltiplo do litro.

*Corrige:* litro e mililitro são fixos. Galão é **proibido**: 3,785 L no padrão americano e
4,546 L no imperial, uma diferença de 20%. Tambor é proibido: 200 L e 208 L, ambos comuns.
Bombona é proibida: 20, 50 e 200 L. Balde e lata só com o volume declarado.

*Risco:* converter galão pelo padrão americano numa proposta de origem europeia. O erro é
de 20%, fica dentro da faixa de variação normal entre fornecedores, e por isso nunca é
questionado.

### 1.5 A unidade que significa duas coisas

*Manifesta:* `ML` na proposta. Pode ser mililitro e pode ser metro linear. As duas leituras
diferem por um fator de mil e por dimensão.

*Detecta:* unidade na lista de ambíguas. Além de `ML`, aparecem `CS` (caixa ou conjunto) e
`PT` (ponto ou pote).

*Corrige:* não corrige por inferência. A linha sai do comparativo e vira pergunta ao
fornecedor, que se responde por e-mail em um minuto.

*Risco:* deduzir pela dimensão do item. Funciona quase sempre, e é justamente o quase que
produz o caso em que a dedução falha sem ninguém notar.

### 1.6 Dimensão diferente: kg contra m² contra peça

*Manifesta:* chapa cotada em R$/kg por um fornecedor e em R$ por chapa por outro. Cabo
cotado em R$/m e em R$/kg de cobre.

*Detecta:* as propostas do mesmo item resolvem para dimensões diferentes.

*Corrige:* **não converte.** A conversão existe, mas exige dado de engenharia que não está
na cotação, e está no grupo 5. A unidade de referência do item é declarada no pedido, e as
linhas de outra dimensão saem numa lista separada.

*Risco:* converter com densidade ou espessura de catálogo. O comparativo passa a comparar a
cotação com a suposição de quem montou o comparativo.

---

## Grupo 2: a embalagem esconde a quantidade

### 2.1 Caixa, fardo, pacote e engradado

*Manifesta:* `3 CX` a R$ 398,00. Não se sabe quanto vale uma caixa.

*Detecta:* a unidade é de embalagem e o campo de conteúdo está vazio.

*Corrige:* pedir o conteúdo. Com `caixa com 20 kg` declarado, o fator é declarado e a linha
entra.

*Risco:* usar a caixa da rodada anterior do mesmo fornecedor. Embalagem muda sem aviso, e a
proposta nova não tem obrigação de manter a antiga.

### 2.2 Barra, rolo, bobina e chapa

*Manifesta:* perfil, vergalhão, cabo e chapa cotados por peça inteira.

*Detecta:* unidade de embalagem em item contínuo.

*Corrige:* barra é **proibida** sem declaração: 3, 6 e 12 metros são todos usuais conforme
o perfil. Rolo e bobina, idem: 100 m é comum em cabo, mas 50 m e 200 m existem. Chapa
depende de formato e espessura.

*Risco:* assumir 6 metros. Metade dos perfis vem em 6 metros, e é essa proporção que torna
a suposição atraente e o erro invisível.

### 2.3 Embalagem multiplicada

*Manifesta:* `caixa com 12 x 1 L`, `fardo com 4 pacotes de 5 kg`.

*Detecta:* dois números antes da unidade.

*Corrige:* multiplicar os dois. 12 x 1 L são 12 litros por caixa.

*Risco:* ler só o último número. `12 x 1 L` virando 1 litro é um erro de fator doze.

### 2.4 A embalagem declarada em outra embalagem

*Manifesta:* `pallet com 40 sacos`.

*Detecta:* o conteúdo declarado está numa unidade que também precisa de declaração.

*Corrige:* não resolve em um passo. Falta a massa do saco. A linha sai e a pergunta ao
fornecedor é uma só.

*Risco:* resolver o primeiro nível e esquecer o segundo, o que produz um número em "sacos
por pallet" tratado como se fosse quilo.

---

## Grupo 3: o preço não se refere ao que parece

### 3.1 Preço unitário contra preço de lote

*Manifesta:* a mesma coluna traz 612,00 (por rolo) em uma proposta e 2.950,00 (o total dos
cinco rolos) em outra.

*Detecta:* o valor da linha dividido pela quantidade dá um número redondo em um lado e não
no outro. Ou a proposta traz as duas colunas, unitário e total, e a extração pegou a
errada.

*Corrige:* declarar, por linha, se o preço é unitário ou de lote. Sem essa declaração a
linha não entra: chutar entre as duas é errar por um fator igual à quantidade.

*Risco:* deduzir pelo tamanho do número. Funciona até o dia em que a quantidade é 1.

### 3.2 Com e sem frete

*Manifesta:* uma proposta é posta na fábrica, outra é retirada no depósito do fornecedor.
A segunda parece mais barata, e pode não ser.

*Detecta:* condição escrita no corpo da proposta, muitas vezes fora da tabela, em uma linha
de observação.

*Corrige:* **não somar frete estimado.** Separar a ordenação por escopo: preços entregues
ordenam entre si, preços a retirar ordenam entre si. O frete real se cota à parte, e aí a
comparação volta a ser possível.

*Risco:* somar um frete estimado para "deixar comparável". O comparativo passa a conter um
número que nenhum fornecedor ofereceu, e ninguém depois lembra qual valor era cotado e qual
era estimado.

### 3.3 Com e sem imposto

*Manifesta:* "valores acrescidos dos impostos", em nota de rodapé.

*Detecta:* mesma coisa que 3.2, e costuma estar na mesma linha de observação.

*Corrige:* mesma coisa que 3.2. Escopo declarado por linha, ordenação separada por escopo.

*Risco:* tratar como detalhe. Entre preço com e sem tributo a diferença ultrapassa com
folga a diferença entre fornecedores, e é ela que decide a ordenação quando se mistura.

### 3.4 Moeda

*Manifesta:* uma proposta em real e outra em dólar ou euro.

*Detecta:* símbolo ou sigla na coluna de preço.

*Corrige:* **não converter.** Ordenar cada moeda em separado e dizer isso. A conversão
depende da data, da taxa contratada e de quem assume a variação, e nada disso está na
cotação.

*Risco:* converter pela cotação do dia. O comparativo envelhece em horas e ninguém sabe
qual taxa foi usada.

### 3.5 Desconto condicionado e validade

*Manifesta:* "preço válido para pagamento à vista", "desconto de 5% acima de 1000
unidades", "proposta válida por 10 dias".

*Detecta:* texto condicional perto do preço.

*Corrige:* o preço que entra no comparativo é o preço da condição que a empresa vai
praticar de fato. A condição entra como campo, não como desconto aplicado em silêncio.

*Risco:* aplicar o desconto no comparativo e descobrir no pedido que a condição não se
cumpre. O preço comparado deixa de existir.

---

## Grupo 4: o fornecedor não vende a quantidade que você pediu

### 4.1 Quantidade mínima

*Manifesta:* preço unitário melhor, com mínimo de 500 peças, para um pedido de 200.

*Detecta:* campo de mínimo preenchido acima da quantidade pedida.

*Corrige:* manter o preço unitário no comparativo e marcar o item. Sobra pedir menos e
pagar mais, ou comprar 500 e estocar 300, e essa é uma decisão de quem compra, não do
comparativo.

*Risco:* descartar a linha por causa do mínimo, e perder de vista que o preço existia.

### 4.2 Múltiplo de venda

*Manifesta:* venda só em caixa fechada de 100, para um pedido de 250.

*Detecta:* o pedido não é divisível pelo múltiplo.

*Corrige:* registrar a quantidade que de fato vai ser comprada, que é o múltiplo acima do
pedido, e marcar. O preço por unidade não muda, o valor total sim.

*Risco:* comparar o total do pedido contra o total da caixa fechada, que são coisas
diferentes.

### 4.3 Item similar no lugar do pedido

*Manifesta:* a proposta responde com um item parecido e mais barato, sem dizer que trocou.

*Detecta:* a descrição da proposta difere da descrição do pedido em alguma característica
técnica: material, classe de pressão, norma de fabricação, acabamento, classe de
resistência.

*Corrige:* a linha não é do mesmo item. Ela sai do comparativo daquele item e vira uma
pergunta de engenharia, não de compras. O script faz uma parte disso e não faz a outra:
havendo `descricao` nas duas pontas, ele compara os termos com dígito do pedido contra a
descrição da proposta e emite alerta por item para o termo que não aparece. Ele não decide
equivalência, e não confere a linha cuja proposta veio sem descrição, e a nota diz quantas
foram.

*Risco:* comparar parafuso inox 304 com inox 316, ou classe 8.8 com 4.8. O mais barato
ganha o comparativo e perde na aplicação.

---

## Grupo 5: conversões que exigem dado que não está na cotação

Este grupo é o que separa quem conhece o material de quem só sabe converter unidade. As
conversões abaixo existem, são corretas, e mesmo assim não entram no comparativo, porque o
dado que elas exigem vem da engenharia e não da proposta.

### 5.1 Chapa e perfil: R$/kg contra R$/m²

A conversão exige espessura e massa específica. Uma chapa de 6,35 mm de aço carbono, com
massa específica de 7850 kg/m³, tem cerca de 49,8 kg/m². O número é correto e ainda assim
não deve ser usado para transformar uma cotação em outra: espessura tem tolerância, a
massa específica muda com a liga, e o resultado carrega essas duas incertezas para dentro
de uma comparação de preço. Peça ao fornecedor que cote na unidade do pedido.

### 5.2 Cabo: R$/m contra R$/kg

Cabo de cobre é comprado por metro e precificado pela cotação do cobre. A conversão exige a
massa linear do cabo, que muda com a seção, com a têmpera e com a espessura da isolação. O
mesmo `2,5 mm²` tem massa linear diferente entre fabricantes.

### 5.3 Peso teórico contra peso real

Aço estrutural é frequentemente faturado por peso teórico, calculado a partir da dimensão
nominal, e não pelo peso da balança. Duas propostas em R$/kg podem estar falando de dois
quilos diferentes. Quando o campo existe, ele entra como campo próprio, e a comparação de
R$/kg entre uma proposta em peso teórico e outra em peso real precisa ser declarada.

### 5.4 Diâmetro nominal não é medida

Um tubo de 1 polegada não tem 25,4 mm de diâmetro. A designação nominal é um nome, não uma
medida, e a relação entre ela e as dimensões reais muda com a série do tubo. Nunca converta
designação nominal para milímetro dentro de um comparativo: ela é parte da descrição do
item, não uma quantidade.

### 5.5 Rendimento

Tinta, adesivo, eletrodo e consumível em geral se comparam por rendimento, não por litro
nem por quilo. Dois eletrodos ao mesmo R$/kg têm custo por metro de solda diferente
conforme a eficiência de deposição. O comparativo desta skill entrega R$/kg, que é o passo
que faltava, e não entrega R$ por metro de solda: esse depende de dado de processo da
própria fábrica.

---

## O que este catálogo não resolve

Nenhum item acima decide fornecedor. Todos eles servem para que os números fiquem
comparáveis. Depois que ficam, ainda faltam prazo de entrega, histórico de atraso,
qualidade recebida, capacidade de atender o pico, condição de pagamento e risco de
fornecedor único, e nada disso está na cotação.
