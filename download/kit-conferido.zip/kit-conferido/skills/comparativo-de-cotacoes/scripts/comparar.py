#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
comparar.py, comparativo de cotacoes com a unidade normalizada.

Le um CSV com as linhas ja extraidas das propostas dos fornecedores, resolve a
unidade de cada linha ate uma unidade de referencia por item, calcula o preco por
unidade de referencia, ordena dentro de cada grupo comparavel e escreve cinco
arquivos no diretorio de --saida.

Tres arquivos saem antes de qualquer ordenacao, e por isso saem tambem na rodada
--so-nota: nota-de-normalizacao-de-unidade.md, nao-comparaveis.csv e
perguntas-aos-fornecedores.md. Dois saem na rodada de comparacao: comparativo.csv
e pedido-com-unidade-travada.md. O de-para da anonimizacao, e o conteudo bruto
das linhas descartadas na leitura, saem apenas com --anonimizar-fornecedor e sao
gravados FORA do diretorio da rodada, ao lado dele, porque o diretorio da rodada
e o que se compartilha.

Com --anonimizar-fornecedor o nome real e trocado pelo rotulo em todo texto que
entra no diretorio, e nao so na coluna fornecedor: linha bruta, descricao,
origem, detalhe, nota e alerta. Rotular so a coluna deixa o diretorio
reidentificar sozinho todo fornecedor que teve linha fora do comparativo. A
excecao e uma so, e e declarada no proprio arquivo e na nota:
perguntas-aos-fornecedores.md sai com o nome real, porque ele nao e o arquivo
que se compartilha, e o que se envia ao fornecedor. Quem compartilha a rodada
tira esse arquivo do diretorio antes de compactar.

O script NAO le PDF, NAO le .eml, NAO le xlsx e NAO acessa rede nem caixa de
e-mail. A extracao das propostas para o CSV de entrada e feita antes, com leitura
dos arquivos. Este script faz a parte que a leitura nao faz bem: aritmetica de
unidade repetivel, com rastro e sem enviar preco de fornecedor identificado para
fora da maquina.

Depois da instalacao o script fica em
~/.claude/skills/comparativo-de-cotacoes/scripts/comparar.py, e a rodada acontece
na pasta dos arquivos de trabalho. Chame o script pelo caminho completo: caminho
relativo como scripts/comparar.py so funciona de dentro da pasta da skill.

DEPENDENCIA DECLARADA: biblioteca padrao do Python 3.8 ou superior, e nada mais.
Modulos usados: argparse, csv, re, sys, unicodedata, datetime, decimal, pathlib.
Nao instala pacote, nao acessa rede, nao escreve nos arquivos de entrada.

Nenhum preco vai para a saida padrao. O terminal recebe o bloco de fechamento, os
alertas e o caminho do diretorio gerado, para que a tela possa ser copiada sem
vazar valor de proposta.

Codigos de saida:
  0  rodou, todo item tem grupo ordenado, nada abaixo do limiar, nada irresolvido,
     nenhum alerta por item em aberto
  1  rodou, ha linha abaixo do limiar de confianca ou marcada para conferencia
  2  --estrito e sobrou linha irresolvida ou marcada para conferencia
  3  erro de entrada, fechamento que nao fecha, ou nenhuma linha comparavel
  4  rodada em --so-nota, nenhuma ordenacao foi feita
  5  rodou, nada a conferir, mas sobrou linha fora da ordenacao, item do pedido
     sem nenhuma proposta, ou alerta por item nao resolvido

Nenhuma linha some: toda linha lida termina em comparativo.csv ou em
nao-comparaveis.csv, e o fechamento prova isso relendo os dois arquivos gravados.

Regra que o script nao quebra: linha cuja unidade nao foi possivel resolver nunca
entra na ordenacao. Na duvida entre descartar em silencio e reportar, ele reporta.
"""

import argparse
import csv
import re
import sys
import unicodedata
from datetime import datetime
from decimal import Decimal, InvalidOperation, getcontext
from pathlib import Path

VERSAO = "1.1"
getcontext().prec = 28

ENCODINGS_TENTADOS = ("utf-8-sig", "utf-8", "cp1252", "latin-1")
DELIMITADORES = (";", ",", "\t", "|")

RODAPE_BASE = ("# Gerado com apoio de IA a partir das propostas dos fornecedores. "
               "Revisar antes de assinar. Nao substitui responsabilidade tecnica.")

# ---------------------------------------------------------------------------
# 1. Tabela de unidades
# ---------------------------------------------------------------------------
# Tres classes de fator, e a distincao entre elas e a coisa mais importante
# deste arquivo:
#   fixo       o fator e fisico ou aritmetico, vale em qualquer proposta
#   declarado  o fator existe, mas quem o define e a proposta (caixa com quantos)
#   proibido   o fator varia por fornecedor e por regiao, e "todo mundo sabe"
#              nao e fonte. Sem declaracao na proposta, a linha nao e comparavel.

BASE_DA_DIMENSAO = {
    "comprimento": "m",
    "massa": "kg",
    "volume": "L",
    "area": "m2",
    "contagem": "un",
}


def _fixas(dimensao, fator, *nomes):
    return {nome: (dimensao, Decimal(fator)) for nome in nomes}


UNIDADES_FIXAS = {}
UNIDADES_FIXAS.update(_fixas("comprimento", "0.001", "mm", "milimetro", "milimetros"))
UNIDADES_FIXAS.update(_fixas("comprimento", "0.01", "cm", "centimetro", "centimetros"))
UNIDADES_FIXAS.update(_fixas("comprimento", "1", "m", "mt", "mts", "metro", "metros",
                             "metro linear", "metros lineares", "m linear"))
UNIDADES_FIXAS.update(_fixas("comprimento", "1000", "km", "quilometro", "quilometros"))
UNIDADES_FIXAS.update(_fixas("comprimento", "0.3048", "pe", "pes", "ft"))
UNIDADES_FIXAS.update(_fixas("massa", "0.000001", "mg", "miligrama", "miligramas"))
UNIDADES_FIXAS.update(_fixas("massa", "0.001", "g", "grama", "gramas"))
UNIDADES_FIXAS.update(_fixas("massa", "1", "kg", "quilo", "quilos", "quilograma", "quilogramas"))
UNIDADES_FIXAS.update(_fixas("massa", "1000", "t", "ton", "tonelada", "toneladas"))
UNIDADES_FIXAS.update(_fixas("massa", "0.45359237", "lb", "libra", "libras"))
UNIDADES_FIXAS.update(_fixas("volume", "0.001", "mililitro", "mililitros", "cm3", "cc"))
UNIDADES_FIXAS.update(_fixas("volume", "1", "l", "lt", "lts", "litro", "litros"))
UNIDADES_FIXAS.update(_fixas("volume", "1000", "m3", "metro cubico", "metros cubicos"))
UNIDADES_FIXAS.update(_fixas("area", "0.0001", "cm2"))
UNIDADES_FIXAS.update(_fixas("area", "1", "m2", "metro quadrado", "metros quadrados"))
UNIDADES_FIXAS.update(_fixas("area", "10000", "ha", "hectare", "hectares"))
UNIDADES_FIXAS.update(_fixas("contagem", "1", "un", "und", "unid", "unidade", "unidades",
                             "pc", "pca", "pcs", "peca", "pecas", "ea"))
UNIDADES_FIXAS.update(_fixas("contagem", "2", "par", "pares"))
UNIDADES_FIXAS.update(_fixas("contagem", "12", "dz", "duzia", "duzias"))
UNIDADES_FIXAS.update(_fixas("contagem", "100", "cento", "centos"))
UNIDADES_FIXAS.update(_fixas("contagem", "1000", "mil", "milheiro", "milheiros", "mlh"))

# Unidades de contagem: quando a proposta declara o conteudo da peca, a
# declaracao manda, porque e ela que resolve a armadilha central da skill
# (10 pecas de 1 m contra 1 peca de 10 m). A declaracao so manda quando muda de
# dimensao: embalagem de contagem sobre unidade de contagem e informacao de
# entrega, nao fator, e multiplicar por ela inverte a ordenacao.
UNIDADES_DE_CONTAGEM = {nome for nome, (dim, _f) in UNIDADES_FIXAS.items() if dim == "contagem"}

# Embalagem: o fator existe na proposta, nao na tabela.
UNIDADES_DE_EMBALAGEM = {
    "cx", "caixa", "caixas", "pacote", "pacotes", "pct", "fardo", "fardos", "fd",
    "rolo", "rolos", "bobina", "bobinas", "lata", "latas", "balde", "baldes",
    "pallet", "palete", "paletes", "engradado", "frasco", "frascos", "kit",
    "kits", "jogo", "jogos", "cj", "conjunto", "conjuntos", "bisnaga", "bisnagas",
    "cartela", "cartelas", "bandeja", "chapa", "chapas", "placa", "placas",
}

# Embalagem cujo fator "todo mundo sabe", e que por isso e a mais perigosa.
UNIDADES_DE_FATOR_PROIBIDO = {
    "sc": "saco, que aparece em 20, 25, 40 e 50 kg conforme o produto e o fornecedor",
    "saco": "saco, que aparece em 20, 25, 40 e 50 kg conforme o produto e o fornecedor",
    "sacos": "saco, que aparece em 20, 25, 40 e 50 kg conforme o produto e o fornecedor",
    "saca": "saca, que muda de massa conforme o produto",
    "sacas": "saca, que muda de massa conforme o produto",
    "tambor": "tambor, que aparece em 200 e em 208 litros",
    "tambores": "tambor, que aparece em 200 e em 208 litros",
    "bombona": "bombona, que aparece em 20, 50 e 200 litros",
    "bombonas": "bombona, que aparece em 20, 50 e 200 litros",
    "gal": "galao, que tem 3,785 litros no padrao americano e 4,546 no imperial",
    "galao": "galao, que tem 3,785 litros no padrao americano e 4,546 no imperial",
    "galoes": "galao, que tem 3,785 litros no padrao americano e 4,546 no imperial",
    "barra": "barra, que aparece em 3, 6 e 12 metros conforme o perfil",
    "barras": "barra, que aparece em 3, 6 e 12 metros conforme o perfil",
    "vergalhao": "vergalhao, cujo comprimento de barra muda por fornecedor",
    "vergalhoes": "vergalhao, cujo comprimento de barra muda por fornecedor",
    "resma": "resma, que ja foi 400, 480 e 500 folhas",
    "resmas": "resma, que ja foi 400, 480 e 500 folhas",
    "arroba": "arroba, que tem 15 kg no Brasil e 14,69 kg em Portugal",
    "arrobas": "arroba, que tem 15 kg no Brasil e 14,69 kg em Portugal",
    "barril": "barril, que muda conforme o produto",
    "barris": "barril, que muda conforme o produto",
}

# Unidades que significam duas coisas diferentes no mesmo setor.
_POLEGADA = ("polegada. Em tubo, conexao, valvula e mangueira a polegada cotada e "
             "designacao nominal, que e nome e nao medida: tubo de 1 pol nao tem "
             "25,4 mm. Em chapa, barra e corte ela e comprimento de 0,0254 m. As "
             "duas leituras aparecem no mesmo pedido")
UNIDADES_AMBIGUAS = {
    "ml": ("mililitro ou metro linear. Em industria as duas leituras aparecem, e "
           "elas diferem por um fator de mil e por dimensao"),
    "cs": ("caixa ou conjunto, conforme o fornecedor"),
    "pt": ("ponto ou pote, conforme o fornecedor"),
    "pol": _POLEGADA,
    "polegada": _POLEGADA,
    "polegadas": _POLEGADA,
    "in": _POLEGADA,
    '"': _POLEGADA,
}

BASES_DE_PRECO = {
    "unitario": "unitario",
    "unitaria": "unitario",
    "unit": "unitario",
    "por unidade": "unitario",
    "preco unitario": "unitario",
    "lote": "lote",
    "total": "lote",
    "por lote": "lote",
    "preco total": "lote",
    "global": "lote",
}

ESCOPOS = {
    "com frete e imposto", "sem frete", "sem imposto",
    "sem frete e sem imposto", "nao declarado",
}

ESCOPO_SINONIMOS = {
    "cif": "com frete e imposto",
    "posto na fabrica": "com frete e imposto",
    "entregue": "com frete e imposto",
    "com tudo": "com frete e imposto",
    "fob": "sem frete",
    "retirar": "sem frete",
    "a retirar": "sem frete",
    "frete a combinar": "sem frete",
    "mais impostos": "sem imposto",
    "sem impostos": "sem imposto",
    "": "nao declarado",
}

COLUNAS_OBRIGATORIAS = ("item", "fornecedor", "quantidade", "unidade", "preco",
                        "base do preco")
COLUNAS_OPCIONAIS = ("descricao", "embalagem", "moeda", "escopo do preco",
                     "quantidade minima", "multiplo", "prazo", "confianca", "origem")


# ---------------------------------------------------------------------------
# 2. Texto
# ---------------------------------------------------------------------------

def sem_acento(texto):
    decomposto = unicodedata.normalize("NFD", texto)
    return "".join(c for c in decomposto if unicodedata.category(c) != "Mn")


def chave(texto):
    """Normaliza nome de coluna ou de unidade: sem acento, minusculo, espaco unico."""
    if texto is None:
        return ""
    t = sem_acento(str(texto)).lower()
    t = t.replace(" ", " ").replace("_", " ").replace("-", " ")
    t = t.replace("³", "3").replace("²", "2")
    t = re.sub(r"[.º°]", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def chave_unidade(texto):
    """Como chave(), mas tira a barra final que aparece em 'R$/kg'."""
    t = chave(texto)
    t = t.rstrip("/")
    return t


_SEPARADORES = "-_./\\"


def _normalizar_para_busca(texto):
    """Devolve (texto normalizado, indices) para busca sem acento, sem
    diferenca de maiuscula e com hifen, ponto, barra e sublinhado tratados como
    espaco, que e como o nome do fornecedor aparece em nome de arquivo.
    indices[k] e a posicao no texto original do caractere normalizado k."""
    partes, indices = [], []
    for i, ch in enumerate(texto):
        if ch in _SEPARADORES or ch.isspace():
            normal = " "
        else:
            normal = sem_acento(ch).lower() or ch.lower()
        partes.append(normal)
        indices.extend([i] * len(normal))
    indices.append(len(texto))
    return "".join(partes), indices


# Conectivo e palavra de razao social nao identificam ninguem sozinhos, e
# trecho feito so deles casa com texto tecnico: "de cabos" apareceria em "rolo
# de cabos". Trecho que comeca ou termina em conectivo, e trecho todo generico,
# ficam de fora.
_CONECTORES = {"do", "da", "de", "dos", "das", "e", "em", "com", "para",
               "a", "o", "as", "os", "no", "na"}
_GENERICOS = _CONECTORES | {
    "ltda", "me", "epp", "eireli", "sa", "cia", "comercio", "comercial",
    "industria", "industrial", "industrias", "distribuidora", "distribuicao",
    "representacoes", "representacao", "materiais", "material", "servicos",
    "servico", "produtos", "suprimentos", "equipamentos", "importacao",
    "exportacao", "brasil", "grupo", "filial", "matriz",
}


def variantes_do_nome(nome):
    """O nome do fornecedor nao aparece so inteiro: em nome de arquivo ele vem
    encurtado, sem a razao social e com hifen no lugar do espaco. Devolve o nome
    inteiro mais todo trecho de duas palavras ou mais, do maior para o menor."""
    fichas = [f for f in _normalizar_para_busca(nome)[0].split(" ") if f]
    if not fichas:
        return []
    variantes = {" ".join(fichas)}
    for i in range(len(fichas)):
        for j in range(i + 2, len(fichas) + 1):
            trecho = fichas[i:j]
            if trecho[0] in _CONECTORES or trecho[-1] in _CONECTORES:
                continue
            if all(f in _GENERICOS for f in trecho):
                continue
            variantes.add(" ".join(trecho))
    return sorted(variantes, key=len, reverse=True)


class Mascarador:
    """Troca o nome real do fornecedor pelo rotulo em qualquer texto que entra
    no diretorio da rodada.

    Rotular so a coluna fornecedor nao anonimiza a rodada: o nome real volta
    pela linha bruta de nao-comparaveis.csv, pela descricao da proposta e pelo
    nome do arquivo de origem, sempre com o valor ao lado. Preco de fornecedor
    identificado e classe de dado sensivel, e o de-para so fica fora do
    diretorio porque o diretorio inteiro tem que poder ser compactado."""

    def __init__(self, ativo):
        self.ativo = bool(ativo)
        self.mapa = {}
        self._variantes = {}
        self._contador = 0

    def rotular(self, bruto):
        bruto = (bruto or "").strip()
        if not self.ativo or not bruto:
            return bruto
        if bruto not in self.mapa:
            rotulo, n = "", self._contador
            while True:
                rotulo = chr(ord("A") + n % 26) + rotulo
                n = n // 26 - 1
                if n < 0:
                    break
            self.mapa[bruto] = "Fornecedor " + rotulo
            self._variantes[bruto] = variantes_do_nome(bruto)
            self._contador += 1
        return self.mapa[bruto]

    def mascarar(self, texto):
        if not self.ativo or not self.mapa or not texto:
            return texto
        texto = str(texto)
        alvo, indices = _normalizar_para_busca(texto)
        achados = []
        for real, rotulo in self.mapa.items():
            for agulha in self._variantes.get(real, ()):
                inicio = alvo.find(agulha)
                while inicio != -1:
                    fim = inicio + len(agulha)
                    antes = inicio - 1
                    if ((antes < 0 or not alvo[antes].isalnum())
                            and (fim >= len(alvo) or not alvo[fim].isalnum())):
                        achados.append((inicio, fim, rotulo))
                    inicio = alvo.find(agulha, inicio + 1)
        if not achados:
            return texto
        achados.sort(key=lambda a: (a[0], a[0] - a[1]))
        saida, cursor = [], 0
        for inicio, fim, rotulo in achados:
            o_inicio, o_fim = indices[inicio], indices[fim]
            if o_inicio < cursor:
                continue
            saida.append(texto[cursor:o_inicio])
            saida.append(rotulo)
            cursor = o_fim
        saida.append(texto[cursor:])
        return "".join(saida)

    def linha(self, celulas):
        return [self.mascarar(c) if isinstance(c, str) else c for c in celulas]


def em_alguma_tabela(u):
    return (u in UNIDADES_FIXAS or u in UNIDADES_AMBIGUAS
            or u in UNIDADES_DE_FATOR_PROIBIDO or u in UNIDADES_DE_EMBALAGEM)


def normalizar_unidade(u):
    """Plural simples que nao esta em nenhuma tabela cai no singular que esta.
    Existe para que 'bombonas' receba a causa de 'bombona', e nao a causa
    generica de unidade fora da tabela, que manda a pergunta errada ao
    fornecedor."""
    if not u or em_alguma_tabela(u):
        return u
    if u.endswith("s") and em_alguma_tabela(u[:-1]):
        return u[:-1]
    return u


# ---------------------------------------------------------------------------
# 3. Leitura de CSV
# ---------------------------------------------------------------------------

def ler_texto(caminho):
    dados = Path(caminho).read_bytes()
    for enc in ENCODINGS_TENTADOS:
        try:
            return dados.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return dados.decode("latin-1", errors="replace"), "latin-1 com substituicao"


def detectar_delimitador(texto):
    linhas = [l for l in texto.splitlines() if l.strip()][:10]
    if not linhas:
        return ";"
    melhor, melhor_nota = ";", -1
    for d in DELIMITADORES:
        contagens = [len(next(csv.reader([l], delimiter=d))) for l in linhas]
        if not contagens or max(contagens) < 2:
            continue
        mais_comum = max(set(contagens), key=contagens.count)
        nota = contagens.count(mais_comum) * 100 + mais_comum
        if mais_comum >= 2 and nota > melhor_nota:
            melhor, melhor_nota = d, nota
    return melhor


def ler_csv(caminho):
    """Devolve (cabecalho_normalizado, linhas, descartadas, info)."""
    texto, enc = ler_texto(caminho)
    delim = detectar_delimitador(texto)
    leitor = csv.reader(texto.splitlines(), delimiter=delim)
    cabecalho, linhas, descartadas = None, [], []
    numero = 0
    for bruta in leitor:
        numero += 1
        if cabecalho is None:
            if not any(c.strip() for c in bruta):
                continue
            cabecalho = [chave(c) for c in bruta]
            continue
        if not any(c.strip() for c in bruta):
            continue
        if len(bruta) != len(cabecalho):
            descartadas.append((numero, "contagem de coluna diferente do cabecalho",
                                delim.join(bruta)))
            continue
        linhas.append((numero, dict(zip(cabecalho, bruta))))
    if cabecalho is None:
        raise ValueError("arquivo sem cabecalho: %s" % caminho)
    info = {
        "arquivo": Path(caminho).name,
        "bytes": Path(caminho).stat().st_size,
        "modificado": datetime.fromtimestamp(
            Path(caminho).stat().st_mtime).strftime("%d/%m/%Y %H:%M"),
        "encoding": enc,
        "delimitador": {";": "ponto e virgula", ",": "virgula", "\t": "tabulacao",
                        "|": "barra vertical"}[delim],
        "colunas": len(cabecalho),
        "registros": len(linhas),
        "descartadas": len(descartadas),
    }
    return cabecalho, linhas, descartadas, info


def contar_registros(caminho):
    """Conta os registros de um CSV ja gravado por este script, ignorando o
    cabecalho e a linha de rodape. E a contagem que fecha contra a memoria."""
    caminho = Path(caminho)
    if not caminho.exists():
        return 0
    texto, _enc = ler_texto(caminho)
    n = 0
    for i, bruta in enumerate(csv.reader(texto.splitlines(), delimiter=";")):
        if i == 0:
            continue
        if not any(c.strip() for c in bruta):
            continue
        if len(bruta) == 1 and bruta[0].startswith("#"):
            continue
        n += 1
    return n


# ---------------------------------------------------------------------------
# 4. Numero
# ---------------------------------------------------------------------------
# A regra decimal nao e decidida uma vez para a coluna inteira e aplicada a
# forca: numa cotacao os fornecedores escrevem numero em formatos diferentes, e
# planilha exportada com ponto decimal convive com proposta digitada com
# virgula. Cada valor e lido pela evidencia que ele mesmo carrega, e a coluna
# so decide o unico caso que o valor sozinho nao resolve: um separador so,
# seguido de exatamente tres digitos (1.436 pode ser mil e quatrocentos ou um
# e pouco). Nesse caso, ou a coluna tem evidencia e resolve sem chute, ou a
# coluna mistura os dois formatos e a linha sai do comparativo, ou nao ha
# evidencia nenhuma e a linha entra marcada para conferencia humana.

def limpar_numero(bruto):
    if bruto is None:
        return None
    t = str(bruto).strip().replace(" ", " ")
    t = re.sub(r"[R$US€A-Za-z\s]", "", t)
    return t or None


def _tres_digitos(t, sep):
    return re.search(re.escape(sep) + r"\d{3}$", t) is not None


def analisar_coluna(valores):
    """Devolve a evidencia da coluna sobre qual sinal e o separador decimal.
    decimal: ',' ou '.' quando ha evidencia, senao o assumido.
    conflito: a coluna prova os dois, e valor ambiguo nao se le sem chute.
    ambigua: nao ha evidencia nenhuma e o separador foi assumido."""
    brutos = [limpar_numero(v) for v in valores]
    brutos = [b for b in brutos if b]
    decimais = set()
    tem_ponto_solto = tem_virgula_solta = False
    for v in brutos:
        p, c = "." in v, "," in v
        if p and c:
            decimais.add("," if v.rfind(",") > v.rfind(".") else ".")
        elif v.count(".") > 1:
            decimais.add(",")
        elif v.count(",") > 1:
            decimais.add(".")
        elif p:
            if _tres_digitos(v, "."):
                tem_ponto_solto = True
            else:
                decimais.add(".")
        elif c:
            if _tres_digitos(v, ","):
                tem_virgula_solta = True
            else:
                decimais.add(",")
    if len(decimais) == 1:
        return {"decimal": decimais.pop(), "conflito": False, "ambigua": False}
    if len(decimais) > 1:
        return {"decimal": ",", "conflito": True, "ambigua": False}
    if tem_ponto_solto and tem_virgula_solta:
        return {"decimal": ",", "conflito": True, "ambigua": False}
    if tem_ponto_solto:
        return {"decimal": ",", "conflito": False, "ambigua": True}
    if tem_virgula_solta:
        return {"decimal": ".", "conflito": False, "ambigua": True}
    return {"decimal": ",", "conflito": False, "ambigua": False}


def descrever_coluna(coluna):
    if coluna["conflito"]:
        return ("mista: a coluna usa os dois formatos, e cada valor foi lido pelo "
                "separador que ele mesmo carrega")
    nome = "virgula decimal" if coluna["decimal"] == "," else "ponto decimal"
    return nome + (" (assumida)" if coluna["ambigua"] else "")


def ler_numero(bruto, coluna):
    """Devolve (valor, situacao). situacao e None quando o valor se le sem
    suposicao, 'assumida' quando o separador veio de assuncao declarada, e
    'irresolvivel' quando a coluna mistura formatos e este valor nao se le."""
    t = limpar_numero(bruto)
    if t is None:
        return None, None
    negativo = t.startswith("(") and t.endswith(")")
    t = t.strip("()")
    if t.endswith("-"):
        negativo, t = True, t[:-1]
    if t.startswith("-"):
        negativo, t = True, t[1:]
    if not t:
        return None, None
    p, c = "." in t, "," in t
    situacao = None
    if p and c:
        decimal = "," if t.rfind(",") > t.rfind(".") else "."
    elif t.count(".") > 1:
        decimal = ","
    elif t.count(",") > 1:
        decimal = "."
    elif p or c:
        sep = "." if p else ","
        if _tres_digitos(t, sep):
            if coluna["conflito"]:
                return None, "irresolvivel"
            decimal = coluna["decimal"]
            situacao = "assumida" if coluna["ambigua"] else None
        else:
            decimal = sep
    else:
        decimal = ","
    if decimal == ",":
        t = t.replace(".", "").replace(",", ".")
    else:
        t = t.replace(",", "")
    try:
        valor = Decimal(t)
    except InvalidOperation:
        return None, None
    return (-valor if negativo else valor), situacao


def para_decimal(bruto, regra):
    """Leitura simples, para campo que nao entra na ordenacao de preco."""
    coluna = {"decimal": "," if regra == "virgula decimal" else ".",
              "conflito": False, "ambigua": False}
    valor, _sit = ler_numero(bruto, coluna)
    return valor


def fmt(valor, casas=6):
    """Numero em notacao brasileira, sem zero a direita e sem notacao
    cientifica. Nunca usar normalize() aqui: Decimal("70").normalize() vira
    7E+1, e um rstrip de zeros em cima disso transforma 70 em 7."""
    if valor is None:
        return ""
    texto = format(valor.quantize(Decimal(1).scaleb(-casas)), "f")
    if "." in texto:
        texto = texto.rstrip("0").rstrip(".")
    return texto.replace(".", ",") if texto else "0"


# ---------------------------------------------------------------------------
# 5. Unidade
# ---------------------------------------------------------------------------
# A embalagem e lida em duas formas: '12 x 1 L' e a forma escrita em portugues,
# 'fardo com 4 pacotes de 5 kg'. Quando sobra numero no texto que o padrao nao
# consumiu, a embalagem nao e resolvida no chute: ler so o ultimo numero de uma
# embalagem multiplicada erra por um fator inteiro e nao deixa rastro.

_NUMERO = r"\d+(?:[.,]\d+)?"
_LIGACAO = r"(?:[x×]|[A-Za-zçãáéíóúêôà]+\s+(?:de|com)\s+|(?:de|com)\s+)"
PADRAO_EMBALAGEM = re.compile(
    r"(?:(?<![\w.,])(" + _NUMERO + r")\s*" + _LIGACAO + r")?"
    r"(" + _NUMERO + r")\s*"
    r"([A-Za-z²³çãúíéó\"]+(?:\s+[A-Za-z]+)?)\s*$")

PADRAO_NUMERO_SOLTO = re.compile(r"(?<![\w.,])" + _NUMERO)


def parse_embalagem(bruto, regra):
    """Le 'caixa com 100 un', 'barra de 6 m', '12 x 1 L', 'fardo com 4 pacotes
    de 5 kg'. Devolve (dimensao, fator, detalhe) ou (None, causa, detalhe)."""
    if not bruto or not bruto.strip():
        return None, "embalagem nao declarada", "o campo embalagem veio vazio"
    texto = bruto.strip()
    numeros = PADRAO_NUMERO_SOLTO.findall(texto)
    m = PADRAO_EMBALAGEM.search(texto)
    if m is None:
        if len(numeros) >= 2:
            return None, "embalagem com mais de um numero nao resolvida", (
                "a embalagem tem mais de um numero e o conteudo total nao pode ser "
                "lido sem chute: %s" % texto)
        m2 = re.search(r"(" + _NUMERO + r")\s*([A-Za-z²³]+)", texto)
        if m2 is None:
            return None, "embalagem ilegivel", "sem numero e unidade legiveis em: %s" % texto
        multiplicador = Decimal(1)
        quantidade = para_decimal(m2.group(1), regra)
        nome = normalizar_unidade(chave_unidade(m2.group(2)))
        consumidos = 1
    else:
        multiplicador = para_decimal(m.group(1), regra) if m.group(1) else Decimal(1)
        quantidade = para_decimal(m.group(2), regra)
        nome = normalizar_unidade(chave_unidade(m.group(3)))
        consumidos = 2 if m.group(1) else 1
    if quantidade is None or multiplicador is None:
        return None, "embalagem ilegivel", "numero ilegivel em: %s" % texto
    if len(numeros) > consumidos:
        return None, "embalagem com mais de um numero nao resolvida", (
            "o padrao le %s %s por embalagem e sobra numero no texto, e embalagem "
            "dentro de embalagem multiplica: %s"
            % (fmt(multiplicador * quantidade, 4), nome, texto))
    if nome in UNIDADES_AMBIGUAS:
        return None, "embalagem em unidade ambigua", "%s significa %s" % (
            nome, UNIDADES_AMBIGUAS[nome])
    if nome not in UNIDADES_FIXAS:
        return None, "embalagem em unidade sem fator fixo", (
            "a embalagem foi declarada em %s, que tambem precisa de declaracao: %s"
            % (nome, texto))
    dimensao, fator = UNIDADES_FIXAS[nome]
    total = multiplicador * quantidade * fator
    detalhe = "%s %s por embalagem" % (fmt(multiplicador * quantidade, 4), nome)
    return dimensao, total, detalhe


def resolver_unidade(unidade_bruta, embalagem_bruta, regra):
    """Devolve (dimensao, fator, classe, detalhe, causa, causa_detalhe, aviso).
    Em caso de sucesso, causa e causa_detalhe sao None. aviso e preenchido
    quando a linha entra no comparativo mas precisa de olho humano."""
    u = normalizar_unidade(chave_unidade(unidade_bruta))
    tem_embalagem = bool(embalagem_bruta and embalagem_bruta.strip())

    def pela_embalagem():
        dim, fator_ou_causa, detalhe = parse_embalagem(embalagem_bruta, regra)
        if dim is not None:
            return dim, fator_ou_causa, "declarado", detalhe, None, None, None
        return None, None, None, "", fator_ou_causa, detalhe, None

    def falhar(causa, detalhe, r):
        """A causa especifica da embalagem prevalece sempre que a pessoa
        preencheu o campo: dizer que o fornecedor nao declarou, quando ele
        declarou, manda a pergunta errada para ele."""
        if tem_embalagem and r[4]:
            return r
        return None, None, None, "", causa, detalhe, None

    if not u:
        return None, None, None, "", "unidade nao declarada", (
            "a proposta nao disse em que unidade cotou"), None
    if u in UNIDADES_AMBIGUAS:
        r = pela_embalagem()
        if r[0] is not None:
            return r
        return falhar("unidade ambigua", "%s significa %s" % (u, UNIDADES_AMBIGUAS[u]), r)
    if u in UNIDADES_DE_CONTAGEM:
        dimensao, fator = UNIDADES_FIXAS[u]
        r = pela_embalagem()
        # A embalagem so manda sobre unidade de contagem quando muda de
        # dimensao. Embalagem de contagem sobre unidade de contagem e a caixa
        # de entrega: multiplicar por ela poe o fornecedor mais caro em
        # primeiro lugar, e a razao fica abaixo do alerta de fator.
        if r[0] is not None and r[0] != "contagem":
            return r
        aviso = None
        if r[0] == "contagem" and r[1] != fator:
            aviso = ("embalagem em unidade de contagem ignorada: a unidade cotada "
                     "(%s) ja e de contagem. Confira na proposta se a quantidade "
                     "esta em %s ou em embalagem" % (u, u))
        return dimensao, fator, "fixo", "%s vale %s un" % (
            u, fmt(fator, 4)), None, None, aviso
    if u in UNIDADES_FIXAS:
        dimensao, fator = UNIDADES_FIXAS[u]
        return dimensao, fator, "fixo", "%s vale %s %s" % (
            u, fmt(fator, 6), BASE_DA_DIMENSAO[dimensao]), None, None, None
    if u in UNIDADES_DE_FATOR_PROIBIDO:
        r = pela_embalagem()
        if r[0] is not None:
            return r
        return falhar("fator proibido sem declaracao",
                      "%s, e o fator nao foi declarado na proposta"
                      % UNIDADES_DE_FATOR_PROIBIDO[u], r)
    if u in UNIDADES_DE_EMBALAGEM:
        r = pela_embalagem()
        if r[0] is not None:
            return r
        return falhar("embalagem sem conteudo declarado",
                      "a proposta cotou em %s e nao declarou quanto vale uma %s"
                      % (u, u), r)
    r = pela_embalagem()
    if r[0] is not None:
        return r
    return falhar("unidade fora da tabela",
                  "%s nao esta na tabela de unidades e a embalagem nao resolveu"
                  % u, r)


# ---------------------------------------------------------------------------
# 6. Pergunta ao fornecedor
# ---------------------------------------------------------------------------
# A skill promete a pergunta pronta. Linha irresolvida so vira trabalho a menos
# quando sai daqui como texto que se copia e manda, e nao como diagnostico.

def pergunta_da_causa(causa, unidade, embalagem, unidade_ref):
    # A unidade entra na pergunta no singular normalizado: perguntar o
    # conteudo de "1 bombonas" faz o texto parecer automatico, e texto que
    # parece automatico nao e respondido.
    u = normalizar_unidade(chave_unidade(unidade)) or unidade.strip() or "a unidade cotada"
    if causa == "fator proibido sem declaracao":
        return ("Qual o conteudo exato de 1 %s deste item, em %s? Sem esse numero a "
                "linha nao entra no comparativo." % (u, unidade_ref or "unidade de medida"))
    if causa == "embalagem sem conteudo declarado":
        return ("Quanto vale 1 %s deste item, em %s? Declare o conteudo na propria "
                "linha da proposta." % (u, unidade_ref or "unidade de medida"))
    if causa in ("embalagem ilegivel", "embalagem em unidade sem fator fixo",
                 "embalagem com mais de um numero nao resolvida"):
        return ("A embalagem informada (%s) nao fecha o conteudo total. Declare "
                "quanto vale 1 %s em m, kg, L, m2 ou un."
                % (embalagem.strip() or "sem texto", u))
    if causa == "embalagem em unidade ambigua":
        return ("A unidade usada na embalagem (%s) tem mais de uma leitura. Reescreva "
                "o conteudo em m, kg, L, m2 ou un." % (embalagem.strip() or u))
    if causa == "unidade ambigua":
        return ("Em que unidade esta linha foi cotada? %s tem mais de uma leitura no "
                "setor, e as leituras diferem entre si." % u)
    if causa == "unidade nao declarada":
        return "Em que unidade esta linha foi cotada?"
    if causa == "unidade fora da tabela":
        return ("Cote esta linha em %s, ou declare quanto vale 1 %s nessa unidade."
                % (unidade_ref or "m, kg, L, m2 ou un", u))
    if causa == "base do preco nao declarada":
        return "O preco informado nesta linha e unitario ou de lote?"
    if causa == "preco ilegivel ou nao positivo":
        return "Confirme o preco desta linha: o valor recebido nao e um preco valido."
    if causa == "quantidade ilegivel ou nao positiva":
        return "Confirme a quantidade desta linha: o valor recebido nao e uma quantidade."
    if causa == "dimensao diferente da referencia":
        return ("Cote esta linha em %s, que e a unidade de referencia do item. A "
                "conversao entre as duas exige dado que a proposta nao traz."
                % (unidade_ref or "unidade do pedido"))
    if causa == "formato de numero divergente na coluna":
        return ("Confirme os numeros desta linha: a proposta mistura ponto e virgula "
                "decimal e o valor nao pode ser lido sem chute.")
    return None


# ---------------------------------------------------------------------------
# 7. Escrita
# ---------------------------------------------------------------------------

def escrever_csv(caminho, cabecalho, linhas, rodape):
    with open(caminho, "w", encoding="utf-8-sig", newline="") as f:
        escritor = csv.writer(f, delimiter=";")
        escritor.writerow(cabecalho)
        for linha in linhas:
            escritor.writerow(linha)
        f.write(rodape + "\n")


# ---------------------------------------------------------------------------
# 8. Programa
# ---------------------------------------------------------------------------

def fator_decimal(texto):
    """--alerta-fator 2,5 e a digitacao esperada de quem escreve em portugues.
    Decimal levanta InvalidOperation, que desce de ArithmeticError e nao de
    ValueError, e por isso o argparse nao captura e o usuario recebe traceback."""
    try:
        valor = Decimal(str(texto).replace(",", "."))
    except InvalidOperation:
        raise argparse.ArgumentTypeError(
            "valor invalido para --alerta-fator: %s. Use um numero, por exemplo "
            "3 ou 2,5" % texto)
    if valor <= 1:
        raise argparse.ArgumentTypeError(
            "--alerta-fator tem que ser maior que 1, e veio %s" % texto)
    return valor


def construir_parser():
    p = argparse.ArgumentParser(
        description="Comparativo de cotacoes com a unidade normalizada.",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--cotacoes", required=True,
                   help="CSV com as linhas extraidas das propostas")
    p.add_argument("--pedido", default=None,
                   help="CSV do pedido: item, unidade de referencia, quantidade "
                        "pedida, escopo de preco pedido")
    p.add_argument("--saida", required=True, help="diretorio de saida")
    p.add_argument("--limiar", type=int, default=80,
                   help="limiar de confianca por linha, padrao 80")
    p.add_argument("--alerta-fator", type=fator_decimal, default=Decimal(3),
                   help="alerta quando o maior preco do grupo passa do menor por "
                        "este fator, padrao 3")
    p.add_argument("--gabarito-conferido", type=int, default=0,
                   help="quantas rodadas de gabarito sem erro ja foram conferidas. "
                        "Abaixo de 3 todo artefato sai marcado como nao validado")
    p.add_argument("--so-nota", action="store_true",
                   help="escreve a nota, as nao comparaveis e as perguntas, e nao ordena")
    p.add_argument("--estrito", action="store_true",
                   help="sai com 2 se sobrar linha irresolvida ou a conferir")
    p.add_argument("--anonimizar-fornecedor", action="store_true",
                   help="troca o nome do fornecedor por Fornecedor A, B, C e grava "
                        "o de-para fora do diretorio da rodada")
    p.add_argument("--forcar", action="store_true",
                   help="grava em diretorio que ja existe")
    return p


def main(argv=None):
    args = construir_parser().parse_args(argv)
    saida = Path(args.saida)
    if saida.exists() and not args.forcar:
        print("ERRO: o diretorio %s ja existe. Use --forcar para gravar nele."
              % saida, file=sys.stderr)
        return 3
    saida.mkdir(parents=True, exist_ok=True)

    gabarito = max(0, args.gabarito_conferido)
    if gabarito < 3:
        validacao = ("Validacao: nao validada, %d de 3 rodadas de gabarito "
                     "conferidas." % gabarito)
    else:
        validacao = "Validacao: %d rodadas de gabarito conferidas." % gabarito
    rodape = RODAPE_BASE + " " + validacao

    try:
        cab, linhas, descartadas, info = ler_csv(args.cotacoes)
    except (OSError, ValueError) as erro:
        print("ERRO ao ler %s: %s" % (args.cotacoes, erro), file=sys.stderr)
        return 3

    faltando = [c for c in COLUNAS_OBRIGATORIAS if c not in cab]
    if faltando:
        print("ERRO: faltam colunas obrigatorias em %s: %s"
              % (args.cotacoes, ", ".join(faltando)), file=sys.stderr)
        print("Colunas encontradas: %s" % ", ".join(cab), file=sys.stderr)
        return 3

    # Pedido, opcional.
    referencia_do_pedido, quantidade_pedida = {}, {}
    escopo_pedido, descricao_pedido, itens_do_pedido = {}, {}, []
    info_pedido = None
    if args.pedido:
        try:
            cabp, linhasp, _descp, info_pedido = ler_csv(args.pedido)
        except (OSError, ValueError) as erro:
            print("ERRO ao ler %s: %s" % (args.pedido, erro), file=sys.stderr)
            return 3
        if "item" not in cabp:
            print("ERRO: o CSV do pedido precisa da coluna item.", file=sys.stderr)
            return 3
        coluna_qp = analisar_coluna([d.get("quantidade pedida", "") for _n, d in linhasp])
        regra_qp = "virgula decimal" if coluna_qp["decimal"] == "," else "ponto decimal"
        for _n, d in linhasp:
            it = d["item"].strip()
            if not it:
                continue
            if it not in itens_do_pedido:
                itens_do_pedido.append(it)
            ur = chave_unidade(d.get("unidade de referencia", ""))
            if ur:
                if ur not in UNIDADES_FIXAS:
                    print("ERRO: a unidade de referencia do item %s (%s) nao tem "
                          "fator fixo. Use metro, quilo, litro, metro quadrado ou "
                          "unidade." % (it, ur), file=sys.stderr)
                    return 3
                referencia_do_pedido[it] = (ur, d["unidade de referencia"].strip())
            qp = para_decimal(d.get("quantidade pedida", ""), regra_qp)
            if qp is not None:
                quantidade_pedida[it] = qp
            ep = chave(d.get("escopo de preco pedido", ""))
            ep = ESCOPO_SINONIMOS.get(ep, ep)
            if ep in ESCOPOS and ep != "nao declarado":
                escopo_pedido[it] = ep
            dp = d.get("descricao", "").strip()
            if dp:
                descricao_pedido[it] = dp

    # Evidencia numerica por coluna.
    coluna_preco = analisar_coluna([d["preco"] for _n, d in linhas])
    coluna_qtd = analisar_coluna([d["quantidade"] for _n, d in linhas])
    regra_qtd = "virgula decimal" if coluna_qtd["decimal"] == "," else "ponto decimal"

    # Anonimizacao. O rotulo troca o nome na coluna fornecedor, e o mascarador
    # troca o mesmo nome em todo o resto que entra no diretorio.
    mascarador = Mascarador(args.anonimizar_fornecedor)
    nome_fornecedor = mascarador.rotular
    mapa_fornecedor = mascarador.mapa

    # A linha descartada na leitura nao tem coluna fornecedor legivel, e por
    # isso nao da para garantir a troca pelo rotulo dentro dela. Em vez de
    # prometer protecao que nao entrega, o conteudo bruto sai do diretorio.
    caminho_descartadas = None
    if args.anonimizar_fornecedor and descartadas:
        caminho_descartadas = saida.parent / (saida.name + "-linhas-descartadas.csv")

    # Itens, na ordem em que aparecem no arquivo de entrada, e depois os itens
    # do pedido que nenhum fornecedor respondeu. Item sem nenhuma resposta e a
    # informacao mais urgente de uma rodada de cotacao, e e a que some quando a
    # lista e montada so com o que chegou.
    itens = []
    for _n, d in linhas:
        it = d["item"].strip()
        if it and it not in itens:
            itens.append(it)
    itens_com_linha = set(itens)
    for it in itens_do_pedido:
        if it not in itens:
            itens.append(it)
    itens_sem_proposta = [it for it in itens_do_pedido if it not in itens_com_linha]
    # A inversa, que faltava: fornecedor cotou item que o pedido nao pediu. Isso
    # e achado e nao ruido, porque ou o pedido esqueceu o item, ou o codigo
    # trocou, ou entrou oferta que ninguem pediu. Sem marca, a linha entra no
    # comparativo com a mesma cara de quem respondeu o que foi pedido.
    itens_fora_do_pedido = ([it for it in itens
                             if it in itens_com_linha and it not in itens_do_pedido]
                            if itens_do_pedido else [])

    def situacao_no_pedido(it):
        if not itens_do_pedido:
            return "pedido nao informado"
        if it in itens_fora_do_pedido:
            return "NAO, cotado sem estar no pedido"
        if it in itens_sem_proposta:
            return "sim, e sem nenhuma proposta"
        return "sim"

    # Primeira passada: resolve unidade linha a linha.
    resolvidas, nao_comparaveis, perguntas = [], [], []

    def reprovar(item, fornecedor, numero, causa, detalhe, bruta, pergunta=None,
                 fornecedor_real=None):
        nao_comparaveis.append([item, fornecedor, numero, causa, detalhe, bruta])
        if pergunta:
            perguntas.append((fornecedor_real or fornecedor, fornecedor, item,
                              numero, causa, pergunta))

    for numero, d in linhas:
        item = d["item"].strip()
        fornecedor_real = d["fornecedor"].strip()
        fornecedor = nome_fornecedor(fornecedor_real)
        bruta = "; ".join("%s=%s" % (k, v) for k, v in d.items() if v)
        if not item or not fornecedor:
            reprovar(item, fornecedor, numero, "item ou fornecedor em branco",
                     "a linha nao diz a que item ou a que fornecedor pertence", bruta)
            continue
        quantidade, sit_q = ler_numero(d["quantidade"], coluna_qtd)
        preco, sit_p = ler_numero(d["preco"], coluna_preco)
        base = BASES_DE_PRECO.get(chave(d["base do preco"]))
        unidade_txt = d["unidade"].strip()
        embalagem_txt = d.get("embalagem", "").strip()
        if "irresolvivel" in (sit_q, sit_p):
            qual = "quantidade" if sit_q == "irresolvivel" else "preco"
            reprovar(item, fornecedor, numero, "formato de numero divergente na coluna",
                     "a coluna %s mistura ponto decimal e virgula decimal, e este "
                     "valor nao pode ser lido sem chute: %s"
                     % (qual, d[qual]), bruta,
                     pergunta_da_causa("formato de numero divergente na coluna",
                                       unidade_txt, embalagem_txt, None),
                     fornecedor_real=fornecedor_real)
            continue
        if quantidade is None or quantidade <= 0:
            reprovar(item, fornecedor, numero, "quantidade ilegivel ou nao positiva",
                     d["quantidade"], bruta,
                     pergunta_da_causa("quantidade ilegivel ou nao positiva",
                                       unidade_txt, embalagem_txt, None),
                     fornecedor_real=fornecedor_real)
            continue
        if preco is None or preco <= 0:
            reprovar(item, fornecedor, numero, "preco ilegivel ou nao positivo",
                     d["preco"], bruta,
                     pergunta_da_causa("preco ilegivel ou nao positivo",
                                       unidade_txt, embalagem_txt, None),
                     fornecedor_real=fornecedor_real)
            continue
        if base is None:
            reprovar(item, fornecedor, numero, "base do preco nao declarada",
                     "esperado unitario ou lote, veio: %s" % d["base do preco"], bruta,
                     pergunta_da_causa("base do preco nao declarada",
                                       unidade_txt, embalagem_txt, None),
                     fornecedor_real=fornecedor_real)
            continue
        dimensao, fator, classe, detalhe, causa, causa_detalhe, aviso = resolver_unidade(
            unidade_txt, embalagem_txt, regra_qtd)
        if causa:
            un_ref_txt = None
            if item in referencia_do_pedido:
                un_ref_txt = referencia_do_pedido[item][1]
            reprovar(item, fornecedor, numero, causa, causa_detalhe, bruta,
                     pergunta_da_causa(causa, unidade_txt, embalagem_txt, un_ref_txt),
                     fornecedor_real=fornecedor_real)
            continue
        escopo = chave(d.get("escopo do preco", ""))
        escopo = ESCOPO_SINONIMOS.get(escopo, escopo)
        if escopo not in ESCOPOS:
            escopo = "nao declarado"
        moeda = (d.get("moeda", "") or "BRL").strip().upper() or "BRL"
        confianca = para_decimal(d.get("confianca", ""), "ponto decimal")
        marcas = []
        if aviso:
            marcas.append(aviso)
        if "assumida" in (sit_q, sit_p):
            marcas.append("separador decimal assumido: tres digitos depois do sinal "
                          "e nenhuma outra evidencia na coluna")
        resolvidas.append({
            "linha": numero, "item": item, "fornecedor": fornecedor,
            "fornecedor_real": fornecedor_real,
            "descricao": d.get("descricao", "").strip(),
            "quantidade": quantidade, "unidade": unidade_txt,
            "embalagem": embalagem_txt,
            "dimensao": dimensao, "fator": fator, "classe": classe,
            "detalhe": detalhe, "preco": preco, "base": base,
            "moeda": moeda, "escopo": escopo, "confianca": confianca,
            "quantidade minima": d.get("quantidade minima", "").strip(),
            "multiplo": d.get("multiplo", "").strip(),
            "prazo": d.get("prazo", "").strip(),
            "origem": d.get("origem", "").strip(),
            "bruta": bruta, "marcas": marcas,
        })

    # Unidade de referencia por item.
    referencia, motivo_referencia, exibicao = {}, {}, {}
    for it in itens:
        if it in referencia_do_pedido:
            u, texto_original = referencia_do_pedido[it]
            referencia[it] = (UNIDADES_FIXAS[u][0], u)
            exibicao[it] = texto_original
            motivo_referencia[it] = "declarada no pedido"
            continue
        contagem = {}
        for r in resolvidas:
            if r["item"] == it:
                contagem[r["dimensao"]] = contagem.get(r["dimensao"], 0) + 1
        if not contagem:
            referencia[it] = (None, None)
            if it in itens_sem_proposta:
                motivo_referencia[it] = ("indefinida: nenhum fornecedor cotou este "
                                         "item e o pedido nao declarou a unidade")
            else:
                motivo_referencia[it] = ("indefinida: nenhuma proposta deste item teve a "
                                         "unidade resolvida, e o pedido nao declarou")
            continue
        maior = max(contagem.values())
        vencedoras = sorted(d for d, c in contagem.items() if c == maior)
        if len(vencedoras) > 1:
            referencia[it] = (None, None)
            motivo_referencia[it] = ("indefinida: as propostas se dividem entre %s "
                                     "e o pedido nao declarou a unidade"
                                     % " e ".join(vencedoras))
            continue
        dim = vencedoras[0]
        referencia[it] = (dim, chave_unidade(BASE_DA_DIMENSAO[dim]))
        exibicao[it] = BASE_DA_DIMENSAO[dim]
        motivo_referencia[it] = ("derivada da dimensao da maioria das propostas "
                                 "(%d de %d linhas)" % (maior, sum(contagem.values())))

    # Segunda passada: preco por unidade de referencia.
    comparaveis = []
    for r in resolvidas:
        dim_ref, un_ref = referencia[r["item"]]
        if dim_ref is None:
            reprovar(r["item"], r["fornecedor"], r["linha"],
                     "unidade de referencia indefinida",
                     motivo_referencia[r["item"]], r["bruta"],
                     fornecedor_real=r["fornecedor_real"])
            continue
        if r["dimensao"] != dim_ref:
            reprovar(r["item"], r["fornecedor"], r["linha"],
                     "dimensao diferente da referencia",
                     "a proposta cotou em %s e a referencia do item e %s"
                     % (r["dimensao"], dim_ref), r["bruta"],
                     pergunta_da_causa("dimensao diferente da referencia",
                                       r["unidade"], r["embalagem"],
                                       exibicao.get(r["item"], un_ref)),
                     fornecedor_real=r["fornecedor_real"])
            continue
        fator_base = UNIDADES_FIXAS[un_ref][1]
        quantidade_ref = r["quantidade"] * r["fator"] / fator_base
        if quantidade_ref <= 0:
            reprovar(r["item"], r["fornecedor"], r["linha"],
                     "quantidade em unidade de referencia nao positiva",
                     "a quantidade depois do fator nao e positiva", r["bruta"],
                     fornecedor_real=r["fornecedor_real"])
            continue
        total = r["preco"] if r["base"] == "lote" else r["preco"] * r["quantidade"]
        r["quantidade_ref"] = quantidade_ref
        r["unidade_ref"] = exibicao.get(r["item"], un_ref)
        r["total"] = total
        r["por_referencia"] = total / quantidade_ref
        r["ordenavel"] = "nao"
        r["motivo"] = "rodada --so-nota, nenhuma ordenacao foi feita"
        r["posicao"] = ""
        comparaveis.append(r)

    # Conferencia de descricao: termo tecnico do pedido que nao aparece na
    # proposta. Nao decide equivalencia, que e engenharia, e nao e compras.
    def termos_tecnicos(texto):
        return [t for t in re.findall(r"[0-9][0-9a-z,./x-]*", chave(texto))
                if any(c.isdigit() for c in t)]

    divergencias_descricao, sem_descricao = [], 0
    for r in comparaveis:
        alvo = descricao_pedido.get(r["item"])
        if not alvo:
            continue
        if not r["descricao"]:
            sem_descricao += 1
            continue
        proposta = chave(r["descricao"])
        faltantes = [t for t in termos_tecnicos(alvo) if t not in proposta]
        if faltantes:
            divergencias_descricao.append((r["item"], r["fornecedor"], faltantes))

    # Grupos de ordenacao: item, escopo, moeda. Escopo nao declarado nao ordena.
    # A rodada --so-nota nao chega aqui: ela existe justamente para a pessoa
    # aprovar as decisoes de unidade antes de ver qualquer ordenacao de preco.
    ordenou = not args.so_nota
    grupos, alertas_do_item = {}, {}
    if ordenou:
        for r in comparaveis:
            grupos.setdefault((r["item"], r["escopo"], r["moeda"]), []).append(r)

    for (item, escopo, moeda), membros in grupos.items():
        if escopo == "nao declarado":
            for r in membros:
                r["ordenavel"] = "nao"
                r["motivo"] = "escopo do preco nao declarado"
                r["posicao"] = ""
            alertas_do_item.setdefault(item, []).append(
                "escopo do preco nao declarado em %d linha(s)" % len(membros))
            continue
        distintos = {r["fornecedor"] for r in membros}
        if len(membros) > len(distintos):
            alertas_do_item.setdefault(item, []).append(
                "o mesmo fornecedor responde mais de uma vez no grupo %s / %s, e "
                "duas linhas do mesmo fornecedor nao sao dois fornecedores"
                % (escopo, moeda))
        if len(distintos) < 2:
            for r in membros:
                r["ordenavel"] = "nao"
                r["motivo"] = ("um so fornecedor no grupo %s / %s, e ordenacao de um "
                               "nao e ordenacao" % (escopo, moeda))
                r["posicao"] = ""
            alertas_do_item.setdefault(item, []).append(
                "um so fornecedor comparavel no grupo %s / %s" % (escopo, moeda))
            continue
        ordenados = sorted(membros, key=lambda x: (x["por_referencia"], x["fornecedor"]))
        posicao, anterior = 0, None
        for r in ordenados:
            if anterior is None or r["por_referencia"] != anterior:
                posicao += 1
                anterior = r["por_referencia"]
            r["posicao"] = str(posicao)
            r["ordenavel"] = "sim"
            r["motivo"] = ""
        menor = ordenados[0]["por_referencia"]
        maior = ordenados[-1]["por_referencia"]
        if menor > 0 and maior / menor >= args.alerta_fator:
            alertas_do_item.setdefault(item, []).append(
                "o maior preco do grupo %s / %s passa do menor por %sx, o que em "
                "cotacao costuma ser unidade errada e nao preco"
                % (escopo, moeda, fmt(maior / menor, 1)))
        primeiro = ordenados[0]
        if primeiro["confianca"] is None or primeiro["confianca"] < args.limiar:
            alertas_do_item.setdefault(item, []).append(
                "a primeira posicao do grupo %s / %s esta abaixo do limiar de "
                "confianca e precisa ser conferida na proposta antes de qualquer "
                "conversa" % (escopo, moeda))
        if primeiro["marcas"]:
            alertas_do_item.setdefault(item, []).append(
                "a primeira posicao do grupo %s / %s esta marcada para conferencia: %s"
                % (escopo, moeda, primeiro["marcas"][0]))
        # Valor lido sob assuncao em qualquer posicao poe a ordem em duvida, nao
        # so a primeira: e a ordem que vira recomendacao de compra.
        assumidos = [r for r in ordenados
                     if any("separador decimal assumido" in m for m in r["marcas"])]
        if assumidos:
            alertas_do_item.setdefault(item, []).append(
                "a ordenacao do grupo %s / %s depende de separador decimal assumido "
                "em %d linha(s), e a ordem pode inverter: confira o numero na "
                "proposta antes de usar" % (escopo, moeda, len(assumidos)))

    for item in (itens if ordenou else []):
        escopos = {r["escopo"] for r in comparaveis if r["item"] == item}
        moedas = {r["moeda"] for r in comparaveis if r["item"] == item}
        if len(escopos - {"nao declarado"}) > 1:
            alertas_do_item.setdefault(item, []).append(
                "escopos diferentes no mesmo item (%s), ordenados em separado"
                % ", ".join(sorted(escopos)))
        if len(moedas) > 1:
            alertas_do_item.setdefault(item, []).append(
                "moedas diferentes no mesmo item (%s), e o script nao converte moeda"
                % ", ".join(sorted(moedas)))
        if item in escopo_pedido:
            for r in comparaveis:
                if r["item"] == item and r["escopo"] != escopo_pedido[item]:
                    alertas_do_item.setdefault(item, []).append(
                        "%s respondeu em escopo %s e o pedido pediu %s, e por isso a "
                        "linha nao concorre com as que responderam no escopo pedido"
                        % (r["fornecedor"], r["escopo"], escopo_pedido[item]))
        if item in quantidade_pedida:
            for r in comparaveis:
                if r["item"] != item:
                    continue
                qmin = para_decimal(r["quantidade minima"], regra_qtd)
                if qmin is not None and qmin > quantidade_pedida[item]:
                    alertas_do_item.setdefault(item, []).append(
                        "%s exige quantidade minima acima do pedido" % r["fornecedor"])
        for it_d, forn, faltantes in divergencias_descricao:
            if it_d == item:
                alertas_do_item.setdefault(item, []).append(
                    "a descricao de %s nao traz o termo %s que o pedido traz, e "
                    "equivalencia tecnica e engenharia, nao compras"
                    % (forn, ", ".join(faltantes)))
    if ordenou:
        for item in itens_sem_proposta:
            alertas_do_item.setdefault(item, []).append(
                "nenhum fornecedor cotou este item")
        for item in itens_fora_do_pedido:
            quem = sorted({r["fornecedor"] for r in comparaveis if r["item"] == item})
            if not quem:
                quem = sorted({n[1] for n in nao_comparaveis if n[0] == item and n[1]})
            alertas_do_item.setdefault(item, []).append(
                "item cotado sem estar no pedido, por %s. Decida se ele entra no "
                "pedido da proxima rodada ou se a linha e devolvida"
                % (", ".join(quem) or "fornecedor nao identificado"))

    # Confianca e marcas de conferencia.
    for r in comparaveis:
        marcas = list(r["marcas"])
        if r["confianca"] is None:
            marcas.insert(0, "confianca nao declarada pela extracao")
        elif r["confianca"] < args.limiar:
            marcas.insert(0, "confianca abaixo do limiar de %d" % args.limiar)
        r["conferir"] = "sim" if marcas else "nao"
        r["motivo_conferir"] = "; ".join(marcas)

    # Contagens.
    lidas = len(linhas) + len(descartadas)
    n_irresolvidas = len(nao_comparaveis)
    for numero, causa, conteudo in descartadas:
        nao_comparaveis.append(["", "", numero, "descartada na leitura", causa, conteudo])
    for it in itens_sem_proposta:
        nao_comparaveis.append([it, "", "", "item do pedido sem nenhuma proposta",
                                "o item esta no pedido e nao aparece em nenhuma "
                                "proposta", "item=%s" % it])
    n_sem_proposta = len(itens_sem_proposta)
    n_comp = len(comparaveis)
    n_nao = len(nao_comparaveis)
    n_ordenaveis = sum(1 for r in comparaveis if r["ordenavel"] == "sim")
    n_nao_ordenaveis = sum(1 for r in comparaveis if r["ordenavel"] == "nao")
    n_com_posicao = sum(1 for r in comparaveis if r["posicao"])
    n_conferir = sum(1 for r in comparaveis if r["conferir"] == "sim")
    itens_com_ordenacao = sorted({r["item"] for r in comparaveis if r["ordenavel"] == "sim"})
    itens_sem_ordenacao = [i for i in itens if i not in itens_com_ordenacao]
    itens_no_comparativo = {r["item"] for r in comparaveis}
    itens_so_em_nao_comparaveis = [i for i in itens if i not in itens_no_comparativo]

    hoje = datetime.now().strftime("%d/%m/%Y %H:%M")

    # ------------------------------------------------------------------
    # Nota
    # ------------------------------------------------------------------
    def escrever_nota(status, identidades):
        linhas_nota = []
        A = linhas_nota.append
        A("# Nota de normalizacao de unidade")
        A("")
        A("status: %s" % status)
        A("%s" % validacao)
        A("")
        A("Rodada em %s, comparar.py versao %s. Esta nota sai antes do comparativo, "
          "sempre. Comparativo com unidade errada e pior do que nenhum comparativo: "
          "ele parece certo." % (hoje, VERSAO))
        A("")
        A("## 1. Fontes")
        A("")
        A("| Arquivo | Bytes | Modificado | Encoding | Delimitador | Colunas | Registros |")
        A("|---|---|---|---|---|---|---|")
        A("| %s | %d | %s | %s | %s | %d | %d |" % (
            info["arquivo"], info["bytes"], info["modificado"], info["encoding"],
            info["delimitador"], info["colunas"], info["registros"]))
        if info_pedido:
            A("| %s | %d | %s | %s | %s | %d | %d |" % (
                info_pedido["arquivo"], info_pedido["bytes"], info_pedido["modificado"],
                info_pedido["encoding"], info_pedido["delimitador"],
                info_pedido["colunas"], info_pedido["registros"]))
        A("")
        if descartadas and caminho_descartadas:
            A("Linhas descartadas na leitura, por contagem de coluna diferente do "
              "cabecalho: %d. Estao em nao-comparaveis.csv, com a causa. O conteudo "
              "bruto delas nao entra neste diretorio: a linha descartada nao tem "
              "coluna fornecedor legivel para trocar pelo rotulo, e por isso ele foi "
              "gravado em %s, fora do diretorio da rodada."
              % (len(descartadas), caminho_descartadas.name))
        elif descartadas:
            A("Linhas descartadas na leitura, por contagem de coluna diferente do "
              "cabecalho: %d. Estao em nao-comparaveis.csv, com o conteudo."
              % len(descartadas))
        else:
            A("Nenhuma linha foi descartada na leitura: todas tem a mesma "
              "contagem de coluna do cabecalho.")
        A("")
        A("## 2. Regra numerica, decidida pela evidencia de cada valor")
        A("")
        A("| Coluna | Regra | Valor lido no chute |")
        A("|---|---|---|")
        A("| preco | %s | %s |" % (descrever_coluna(coluna_preco),
                                   "nao, nenhum" if not coluna_preco["ambigua"]
                                   else "nao: os valores ambiguos saem marcados"))
        A("| quantidade | %s | %s |" % (descrever_coluna(coluna_qtd),
                                        "nao, nenhum" if not coluna_qtd["ambigua"]
                                        else "nao: os valores ambiguos saem marcados"))
        A("")
        A("Cada valor e lido pelo separador que ele mesmo carrega. A coluna so decide "
          "o caso que o valor sozinho nao resolve, que e um sinal so seguido de tres "
          "digitos. Sem evidencia na coluna, a linha entra marcada para conferencia; "
          "com evidencia dos dois formatos na mesma coluna, a linha sai do "
          "comparativo com a causa escrita.")
        A("")
        A("## 3. Unidade de referencia por item")
        A("")
        A("| Item | Unidade de referencia | Origem da escolha | No pedido |")
        A("|---|---|---|---|")
        for it in itens:
            A("| %s | %s | %s | %s |" % (it, exibicao.get(it) or "indefinida",
                                         motivo_referencia[it], situacao_no_pedido(it)))
        A("")
        if itens_fora_do_pedido:
            A("Itens cotados fora do pedido: %s. A linha continua no comparativo, "
              "marcada na coluna fora_do_pedido, porque fornecedor que cota o que "
              "nao foi pedido e achado e nao ruido: ou o pedido esqueceu o item, ou "
              "o codigo trocou, ou entrou oferta que ninguem pediu."
              % ", ".join(itens_fora_do_pedido))
            A("")
        A("## 4. Fatores aplicados, por classe")
        A("")
        A("| Classe do fator | Linhas | O que significa |")
        A("|---|---|---|")
        for classe, texto in (
                ("fixo", "o fator e fisico ou aritmetico e vale em qualquer proposta"),
                ("declarado", "o fator veio da propria proposta, no campo embalagem")):
            quantas = sum(1 for r in comparaveis if r["classe"] == classe)
            A("| %s | %d | %s |" % (classe, quantas, texto))
        sem_fator = sum(1 for n in nao_comparaveis
                        if n[3] not in ("descartada na leitura",
                                        "item do pedido sem nenhuma proposta"))
        A("| nenhum | %d | o fator nao foi possivel resolver, e a linha nao entra "
          "no comparativo. Causa a causa na secao 7 |" % sem_fator)
        A("")
        A("## 5. Linhas resolvidas pela embalagem declarada")
        A("")
        declaradas = [r for r in comparaveis if r["classe"] == "declarado"]
        if declaradas:
            A("Sao as linhas em que a unidade cotada sozinha nao dizia a quantidade, "
              "e a proposta declarou o conteudo. E aqui que mora a armadilha central: "
              "dez pecas de um metro contra uma peca de dez metros.")
            A("")
            A("| Item | Fornecedor | Unidade cotada | Embalagem declarada | Fator |")
            A("|---|---|---|---|---|")
            for r in declaradas:
                A("| %s | %s | %s | %s | %s %s |" % (
                    r["item"], r["fornecedor"], r["unidade"], r["embalagem"],
                    fmt(r["fator"], 6), BASE_DA_DIMENSAO[r["dimensao"]]))
        else:
            A("Nenhuma. Todas as linhas comparaveis resolveram por fator fixo.")
        A("")
        A("## 6. O que nao foi normalizado, por decisao")
        A("")
        A("- Moeda. O script nao converte moeda, e ordena cada moeda em separado.")
        A("- Frete e imposto. O script nao soma nem estima nenhum dos dois. Ele "
          "separa a ordenacao por escopo declarado, e deixa fora da ordenacao a "
          "linha cujo escopo a proposta nao declarou.")
        A("- Prazo, qualidade e historico. Nao entram em conta nenhuma, e por isso "
          "este arquivo nao recomenda fornecedor.")
        A("- Designacao nominal. Polegada de tubo, conexao, valvula e mangueira e "
          "nome e nao medida, e por isso nao e convertida: a linha sai como unidade "
          "ambigua.")
        if descricao_pedido:
            A("- Equivalencia tecnica. O script compara termo com digito da descricao "
              "do pedido contra a descricao da proposta e sinaliza o que falta. Ele "
              "nao decide equivalencia. Linhas comparaveis sem descricao na proposta, "
              "e por isso nao conferidas: %d." % sem_descricao)
        else:
            A("- Equivalencia tecnica. O pedido nao trouxe descricao, e por isso "
              "nenhuma linha foi conferida por termo. Inox 304 respondido com 316 "
              "passa sem sinal.")
        A("")
        A("## 7. Linhas que nao entraram no comparativo")
        A("")
        if n_nao:
            causas = {}
            for n in nao_comparaveis:
                causas[n[3]] = causas.get(n[3], 0) + 1
            A("| Causa | Linhas |")
            A("|---|---|")
            for causa in sorted(causas):
                A("| %s | %d |" % (causa, causas[causa]))
            A("")
            A("Todas estao em nao-comparaveis.csv, uma a uma, com o detalhe e o "
              "conteudo, e a pergunta de cada uma esta em "
              "perguntas-aos-fornecedores.md. Linha irresolvida fora do comparativo "
              "e resultado, nao sobra: ela e o que o pedido de cotacao da proxima "
              "rodada precisa travar.")
        else:
            A("Nenhuma.")
        A("")
        A("## 8. Confianca por linha")
        A("")
        A("Limiar: %d. Linhas a conferir: %d de %d no comparativo. Confianca nao "
          "declarada pela extracao conta como abaixo do limiar, nunca como acima."
          % (args.limiar, n_conferir, n_comp))
        A("")
        A("## 9. Alertas por item")
        A("")
        if not ordenou:
            A("Nao calculados: a rodada --so-nota para antes da ordenacao, de "
              "proposito. Aprove as decisoes de unidade acima e repita o comando "
              "sem --so-nota e com --forcar.")
        elif alertas_do_item:
            for it in itens:
                for alerta in alertas_do_item.get(it, []):
                    A("- **%s**: %s" % (it, alerta))
        else:
            A("Nenhum.")
        A("")
        A("## 10. Fechamento")
        A("")
        if not identidades:
            A("Ainda nao conferido: esta gravacao da nota aconteceu antes do fim da "
              "rodada. Nota com este texto quer dizer que a rodada caiu no meio.")
        else:
            A("As identidades abaixo releem os arquivos gravados e conferem contra a "
              "contagem em memoria. Elas provam que nenhuma linha lida sumiu entre a "
              "entrada e os arquivos gravados, e nao que a rodada prestou. O que pode "
              "falhar de fato esta no bloco de verificacoes.")
            A("")
            A("| Identidade | Esquerda | Direita | Estado |")
            A("|---|---|---|---|")
            for texto, a, b in identidades:
                A("| %s | %d | %d | %s |" % (texto, a, b,
                                              "fecha" if a == b else "NAO FECHA"))
        A("")
        A("| Verificacao | Numero |")
        A("|---|---|")
        A("| itens distintos | %d |" % len(itens))
        A("| itens do pedido sem nenhuma proposta | %d |" % n_sem_proposta)
        A("| itens cotados fora do pedido | %d |" % len(itens_fora_do_pedido))
        if ordenou:
            A("| itens com pelo menos um grupo ordenado | %d |" % len(itens_com_ordenacao))
            A("| itens sem nenhuma ordenacao | %d |" % len(itens_sem_ordenacao))
            A("| linhas ordenaveis | %d |" % n_ordenaveis)
            A("| linhas com posicao atribuida | %d |" % n_com_posicao)
            A("| linhas no comparativo fora da ordenacao | %d |" % n_nao_ordenaveis)
        A("| linhas com a unidade resolvida | %d |" % n_comp)
        A("| linhas a conferir | %d |" % n_conferir)
        A("| linhas nao comparaveis | %d |" % n_nao)
        A("| itens sem nenhuma linha comparavel | %d |" % len(itens_so_em_nao_comparaveis))
        if ordenou and itens_sem_ordenacao:
            A("")
            A("Itens sem nenhuma ordenacao: %s. Para esses itens nao existe "
              "comparativo, existe uma proposta so ou nenhuma proposta comparavel."
              % ", ".join(itens_sem_ordenacao))
        A("")
        A("## 11. Limite declarado")
        A("")
        A("Este script nao le PDF, nao le .eml, nao le xlsx, nao acessa caixa de "
          "e-mail, nao acessa ERP e nao acessa servidor de arquivos. Ele faz "
          "aritmetica de unidade sobre o CSV que recebeu. Ele tambem nao recomenda "
          "fornecedor: ordena por um numero so, e escolha de fornecedor nao se faz "
          "com um numero so.")
        A("")
        if args.anonimizar_fornecedor:
            A("Anonimizacao ligada. O nome real do fornecedor foi trocado pelo rotulo "
              "em todo arquivo deste diretorio, inclusive dentro da linha bruta de "
              "nao-comparaveis.csv. A excecao declarada e "
              "perguntas-aos-fornecedores.md, que sai com o nome real porque e o "
              "arquivo que se envia ao fornecedor e nao o que se compartilha: %s O "
              "de-para esta fora do diretorio."
              % ("nesta rodada ele traz nome real, e por isso tire-o do diretorio "
                 "antes de compactar." if leva_nome_real else
                 "nesta rodada ele nao traz nome nenhum, porque nao houve pergunta a "
                 "fornecedor nem item cotado fora do pedido."))
            A("")
            A("Limite da troca: ela pega o nome como escrito e todo trecho de duas "
              "palavras ou mais dele, sem acento e com hifen, ponto e barra tratados "
              "como espaco, que e como o nome aparece em nome de arquivo. Apelido e "
              "sigla que nao estejam no nome nao sao pegos: renomeie os arquivos de "
              "origem antes de rodar.")
            A("")
        A("Gerado com apoio de IA a partir das propostas dos fornecedores. Revisar "
          "antes de assinar. Nao substitui responsabilidade tecnica.")
        A("")
        (saida / "nota-de-normalizacao-de-unidade.md").write_text(
            mascarador.mascarar("\n".join(linhas_nota)), encoding="utf-8")

    def escrever_perguntas():
        texto = []
        C = texto.append
        C("# Perguntas aos fornecedores")
        C("")
        C("%s" % validacao)
        C("")
        if leva_nome_real:
            C("**Este e o unico arquivo deste diretorio que carrega o nome real do "
              "fornecedor, e isso e de proposito: ele nao e o arquivo que se "
              "compartilha, e o que se envia ao fornecedor. Tire este arquivo do "
              "diretorio antes de compactar a rodada.** Os outros arquivos saem com "
              "o rotulo, e o de-para esta fora do diretorio.")
            C("")
        C("Uma secao por fornecedor, com a pergunta pronta de cada linha que ficou "
          "fora do comparativo. Copiar e mandar. Cada resposta destrava uma linha "
          "desta rodada e vira exigencia do pedido da proxima.")
        C("")
        por_fornecedor, rotulo_de = {}, {}
        for real, rotulo, item, numero, _causa, pergunta in perguntas:
            nome = real or "sem fornecedor"
            por_fornecedor.setdefault(nome, []).append((item, numero, pergunta))
            rotulo_de[nome] = rotulo
        if por_fornecedor:
            for fornecedor in sorted(por_fornecedor):
                rotulo = rotulo_de.get(fornecedor)
                if args.anonimizar_fornecedor and rotulo and rotulo != fornecedor:
                    C("## %s (%s nos outros arquivos da rodada)" % (fornecedor, rotulo))
                else:
                    C("## %s" % fornecedor)
                C("")
                for item, numero, pergunta in por_fornecedor[fornecedor]:
                    C("- **%s** (linha %s do cotacoes.csv): %s"
                      % (item, numero, pergunta))
                C("")
        else:
            C("Nenhuma. Nenhuma linha ficou fora do comparativo por falta de "
              "informacao do fornecedor.")
            C("")
        if itens_sem_proposta:
            C("## Itens sem nenhuma resposta, para todos os fornecedores")
            C("")
            for it in itens_sem_proposta:
                C("- **%s**: o item esta no pedido e nao veio em nenhuma proposta. "
                  "Confirme se ha ou nao ha cotacao para ele." % it)
            C("")
        if itens_fora_do_pedido:
            C("## Itens cotados fora do pedido")
            C("")
            for it in itens_fora_do_pedido:
                quem = sorted({r["fornecedor_real"] for r in comparaveis
                               if r["item"] == it})
                C("- **%s**: cotado por %s e nao esta no pedido. Confirme se a linha "
                  "substitui algum item do pedido ou se e oferta adicional."
                  % (it, ", ".join(quem) or "fornecedor nao identificado"))
            C("")
        internas = [n for n in nao_comparaveis
                    if n[3] in ("descartada na leitura", "item ou fornecedor em branco",
                                "unidade de referencia indefinida",
                                "quantidade em unidade de referencia nao positiva")]
        if internas:
            C("## Pendencias da casa, que nao se perguntam ao fornecedor")
            C("")
            for n in internas:
                C("- **%s** (linha %s): %s. %s" % (n[0] or "sem item", n[2], n[3], n[4]))
            C("")
        if leva_nome_real:
            C("Os nomes acima sao os nomes reais, para a mensagem poder ser enviada "
              "sem abrir o de-para linha a linha. Nos outros arquivos da rodada eles "
              "saem como rotulo. Este arquivo nao acompanha a rodada compartilhada.")
            C("")
        C("Gerado com apoio de IA a partir das propostas dos fornecedores. Revisar "
          "antes de assinar. Nao substitui responsabilidade tecnica.")
        C("")
        (saida / "perguntas-aos-fornecedores.md").write_text(
            "\n".join(texto), encoding="utf-8")

    # ------------------------------------------------------------------
    # Escrita: nota, nao comparaveis e perguntas primeiro, sempre.
    # ------------------------------------------------------------------
    # O aviso de nome real so sai quando ele existe nesta rodada. Aviso que
    # aparece sempre vira ruido, e ruido apaga o aviso que importa.
    leva_nome_real = bool(args.anonimizar_fornecedor
                          and (perguntas or itens_fora_do_pedido))
    escrever_nota("incompleto", [])
    if caminho_descartadas:
        escrever_csv(caminho_descartadas, ["linha", "conteudo_da_linha"],
                     [[numero, conteudo] for numero, _causa, conteudo in descartadas],
                     rodape)
    linhas_nao_comp = []
    for registro in nao_comparaveis:
        celulas = mascarador.linha(registro)
        if caminho_descartadas and registro[3] == "descartada na leitura":
            celulas[5] = ("conteudo suprimido pela anonimizacao: a linha foi "
                          "descartada antes da leitura das colunas e o fornecedor "
                          "nao pode ser trocado pelo rotulo com garantia. O conteudo "
                          "esta em %s, fora do diretorio da rodada"
                          % caminho_descartadas.name)
        linhas_nao_comp.append(celulas)
    escrever_csv(saida / "nao-comparaveis.csv",
                 ["item", "fornecedor", "linha", "causa", "detalhe", "conteudo_da_linha"],
                 linhas_nao_comp, rodape)
    escrever_perguntas()

    if args.anonimizar_fornecedor and mapa_fornecedor:
        caminho_de_para = saida.parent / (saida.name + "-de-para-fornecedor.csv")
        escrever_csv(caminho_de_para, ["rotulo", "fornecedor_real"],
                     [[v, k] for k, v in mapa_fornecedor.items()], rodape)
        print("De-para gravado FORA do diretorio da rodada, em %s" % caminho_de_para)
        print("Ele reidentifica todos os fornecedores: nao compartilhe.")
    if caminho_descartadas:
        print("Conteudo bruto das linhas descartadas na leitura gravado FORA do "
              "diretorio da rodada, em %s" % caminho_descartadas)
        print("Ele pode trazer nome de fornecedor: nao compartilhe.")
    if leva_nome_real:
        print("perguntas-aos-fornecedores.md sai com o nome real do fornecedor, de "
              "proposito: e o arquivo que se envia, nao o que se compartilha. Tire-o "
              "do diretorio antes de compactar a rodada.")

    identidade_nao_comp = (
        "registros gravados em nao-comparaveis.csv = descartadas na leitura + "
        "irresolvidas + itens do pedido sem proposta",
        contar_registros(saida / "nao-comparaveis.csv"),
        len(descartadas) + n_irresolvidas + n_sem_proposta)

    if args.so_nota:
        if not args.anonimizar_fornecedor:
            print("AVISO: sem --anonimizar-fornecedor a nota traz o nome do "
                  "fornecedor nas secoes 5 e 9, e nao-comparaveis.csv traz o nome "
                  "com a linha bruta ao lado. Nao cole os arquivos em canal "
                  "externo.", file=sys.stderr)
        apagados = []
        for nome in ("comparativo.csv", "pedido-com-unidade-travada.md"):
            antigo = saida / nome
            if antigo.exists():
                antigo.unlink()
                apagados.append(nome)
        identidades = [identidade_nao_comp]
        fecha_tudo = all(a == b for _t, a, b in identidades)
        escrever_nota("so-nota, sem comparativo" if fecha_tudo
                      else "invalido, nao fecha", identidades)
        print("Rodada --so-nota. Escritos: nota-de-normalizacao-de-unidade.md, "
              "nao-comparaveis.csv e perguntas-aos-fornecedores.md em %s" % saida)
        if apagados:
            print("Apagados deste diretorio, por serem de rodada anterior: %s"
                  % ", ".join(apagados))
        print("Confira a nota e repita o comando sem --so-nota e com --forcar.")
        if not fecha_tudo:
            print("ERRO: o fechamento nao fecha. A saida nao vale.", file=sys.stderr)
            return 3
        return 4

    # ------------------------------------------------------------------
    # comparativo.csv
    # ------------------------------------------------------------------
    cabecalho = [
        "item", "unidade_de_referencia", "fora_do_pedido", "posicao", "fornecedor",
        "descricao_na_proposta", "linha_de_origem", "quantidade_cotada",
        "unidade_cotada", "embalagem_declarada", "classe_do_fator", "fator_aplicado",
        "quantidade_em_unidade_de_referencia", "preco_informado", "base_do_preco",
        "preco_total_da_linha", "moeda", "escopo_do_preco",
        "preco_por_unidade_de_referencia", "confianca", "conferir",
        "motivo_conferir", "ordenavel", "motivo_nao_ordenavel", "quantidade_minima",
        "multiplo", "prazo", "origem",
    ]

    def ordem(r):
        return (itens.index(r["item"]), r["escopo"], r["moeda"],
                r["por_referencia"], r["fornecedor"])

    marca_pedido = ("nao conferido" if not itens_do_pedido else None)
    corpo = []
    for r in sorted(comparaveis, key=ordem):
        corpo.append(mascarador.linha([
            r["item"], r["unidade_ref"],
            marca_pedido or ("sim" if r["item"] in itens_fora_do_pedido else "nao"),
            r["posicao"], r["fornecedor"],
            r["descricao"], r["linha"], fmt(r["quantidade"], 4), r["unidade"],
            r["embalagem"], r["classe"], fmt(r["fator"], 6),
            fmt(r["quantidade_ref"], 4), fmt(r["preco"], 4), r["base"],
            fmt(r["total"], 4), r["moeda"], r["escopo"],
            fmt(r["por_referencia"], 6),
            fmt(r["confianca"], 0) if r["confianca"] is not None else "",
            r["conferir"], r["motivo_conferir"], r["ordenavel"], r["motivo"],
            r["quantidade minima"], r["multiplo"], r["prazo"], r["origem"],
        ]))
    escrever_csv(saida / "comparativo.csv", cabecalho, corpo, rodape)

    # ------------------------------------------------------------------
    # pedido-com-unidade-travada.md
    # ------------------------------------------------------------------
    trava = []
    B = trava.append
    B("# Pedido de cotacao com unidade travada")
    B("")
    B("%s" % validacao)
    B("")
    B("Texto para a proxima rodada, derivado do que travou nesta. Cada item abaixo "
      "traz a unidade em que a resposta tem que vir. Fornecedor que responder em "
      "outra unidade tem a linha devolvida antes do comparativo, nao depois.")
    B("")
    B("## Como responder")
    B("")
    B("1. Cotar na unidade de referencia indicada em cada item. Cotando em "
      "embalagem, declarar o conteudo dela na propria linha: caixa com quantas "
      "unidades, barra de quantos metros, saco de quantos quilos, tambor de "
      "quantos litros.")
    B("2. Dizer se o preco e unitario ou de lote.")
    B("3. Dizer se o preco tem frete e se tem imposto. Preco sem essa informacao "
      "nao entra em comparativo nenhum.")
    B("4. Informar quantidade minima e multiplo de venda.")
    B("5. Informar a moeda quando nao for real.")
    B("6. Polegada de tubo, conexao, valvula e mangueira e designacao, nao medida: "
      "informe tambem o comprimento e a quantidade na unidade pedida.")
    B("")
    B("## Itens")
    B("")
    B("| Item | Unidade em que a resposta tem que vir | Observacao desta rodada |")
    B("|---|---|---|")
    for it in itens:
        un = exibicao.get(it)
        pendencias = []
        for n in nao_comparaveis:
            if n[0] == it:
                pendencias.append("%s: %s" % (n[1] or "sem fornecedor", n[3]))
        for r in comparaveis:
            if r["item"] == it and r["ordenavel"] == "nao":
                pendencias.append("%s: %s" % (r["fornecedor"], r["motivo"]))
        if it in escopo_pedido:
            for r in comparaveis:
                if r["item"] == it and r["escopo"] != escopo_pedido[it]:
                    pendencias.append("%s: respondeu em escopo %s e o pedido pediu %s"
                                      % (r["fornecedor"], r["escopo"], escopo_pedido[it]))
        if it in itens_fora_do_pedido:
            pendencias.append("item cotado sem estar no pedido: decidir se ele entra "
                              "no pedido da proxima rodada")
        obs = "; ".join(sorted(set(pendencias))) or "nenhuma pendencia nesta rodada"
        B("| %s | %s | %s |" % (it, un or "A DEFINIR, o pedido nao declarou", obs))
    fora = sorted({n[0] for n in nao_comparaveis if n[0]})
    if fora:
        B("")
        B("## Itens em que alguma resposta ficou fora do comparativo")
        B("")
        B("Estes sao os itens que custaram tempo nesta rodada. Travar a unidade "
          "deles no pedido e o que impede a proxima rodada de custar o mesmo. A "
          "pergunta de cada linha esta em perguntas-aos-fornecedores.md.")
        B("")
        for it in fora:
            B("- %s" % it)
    B("")
    B("Gerado com apoio de IA a partir das propostas dos fornecedores. Revisar "
      "antes de assinar. Nao substitui responsabilidade tecnica.")
    B("")
    (saida / "pedido-com-unidade-travada.md").write_text(
        mascarador.mascarar("\n".join(trava)), encoding="utf-8")

    # ------------------------------------------------------------------
    # Fechamento, relendo o que foi gravado.
    # ------------------------------------------------------------------
    identidades = [
        ("linhas lidas = descartadas na leitura + irresolvidas + comparativo",
         lidas, len(descartadas) + n_irresolvidas + n_comp),
        identidade_nao_comp,
        ("registros gravados em comparativo.csv = linhas com a unidade resolvida",
         contar_registros(saida / "comparativo.csv"), n_comp),
    ]
    fecha_tudo = all(a == b for _t, a, b in identidades)

    if not fecha_tudo:
        status = "invalido, nao fecha"
    elif n_comp == 0:
        status = "invalido, nenhuma linha comparavel"
    else:
        status = "completo"
    escrever_nota(status, identidades)

    # ------------------------------------------------------------------
    # Terminal
    # ------------------------------------------------------------------
    print("FECHAMENTO")
    for texto, a, b in identidades:
        print("  %-78s %6d = %-6d %s" % (texto[:78], a, b,
                                         "fecha" if a == b else "NAO FECHA"))
    print("")
    print("VERIFICACOES")
    print("  itens distintos                          %d" % len(itens))
    print("  itens do pedido sem nenhuma proposta     %d" % n_sem_proposta)
    print("  itens cotados fora do pedido             %d" % len(itens_fora_do_pedido))
    print("  itens com pelo menos um grupo ordenado   %d" % len(itens_com_ordenacao))
    print("  itens sem nenhuma ordenacao              %d" % len(itens_sem_ordenacao))
    print("  linhas ordenaveis                        %d" % n_ordenaveis)
    print("  linhas com posicao atribuida             %d" % n_com_posicao)
    print("  linhas fora da ordenacao                 %d" % n_nao_ordenaveis)
    print("  linhas a conferir                        %d" % n_conferir)
    print("  linhas nao comparaveis                   %d" % n_nao)
    if alertas_do_item:
        print("")
        print("ALERTAS")
        for it in itens:
            for alerta in alertas_do_item.get(it, []):
                print(mascarador.mascarar("  [%s] %s" % (it, alerta)))
    print("")
    print("status: %s" % status)
    print(validacao)
    print("Arquivos em %s" % saida)

    if not fecha_tudo:
        print("ERRO: o fechamento nao fecha. A saida nao vale e nao deve ser "
              "entregue.", file=sys.stderr)
        return 3
    if n_comp == 0:
        print("ERRO: nenhuma linha comparavel. Leia nao-comparaveis.csv.",
              file=sys.stderr)
        return 3
    if args.estrito and (n_conferir or n_nao):
        return 2
    if n_conferir:
        return 1
    if n_nao or n_nao_ordenaveis or itens_sem_ordenacao or alertas_do_item:
        return 5
    return 0


if __name__ == "__main__":
    sys.exit(main())
