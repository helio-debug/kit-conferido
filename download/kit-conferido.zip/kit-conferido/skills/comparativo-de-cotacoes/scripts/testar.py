#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do comparar.py.

Biblioteca padrao apenas. Gera cada caso num diretorio temporario, roda o
comparar.py nele e compara o codigo de saida e trechos dos arquivos gerados com
o esperado. Um caso por defeito conhecido.

Rode depois de qualquer mudanca no comparar.py:

    python3 ~/.claude/skills/comparativo-de-cotacoes/scripts/testar.py

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\comparativo-de-cotacoes\\scripts\\testar.py"

Sai com 1 se algum caso falhar.
"""

import re
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
COMPARAR = AQUI / "comparar.py"
SKILL = AQUI.parent / "SKILL.md"

CABECALHO = ("item;fornecedor;descricao;quantidade;unidade;embalagem;preco;"
             "base do preco;moeda;escopo do preco;quantidade minima;multiplo;"
             "prazo;confianca;origem")

falhas = []


def registrar(nome, erros):
    if erros:
        falhas.append((nome, erros))
        print("FALHOU  %s" % nome)
        for e in erros:
            print("        %s" % e)
    else:
        print("ok      %s" % nome)


def rodar(nome, cotacoes, esperado_codigo, checagens, pedido=None, extra=None,
          nomes_reais=(), excecoes=()):
    """checagens: lista de (arquivo, texto, deve_aparecer).
    arquivo aceita 'stdout', 'stderr', um nome dentro do diretorio de saida, ou
    um caminho com '..' para conferir arquivo gravado fora do diretorio.

    nomes_reais: nomes que nao podem aparecer em NENHUM arquivo do diretorio de
    saida, conferidos arquivo por arquivo. Conferir um arquivo so nao prova
    anonimizacao: o que se compartilha e o diretorio inteiro. excecoes lista os
    arquivos que carregam o nome real por decisao declarada."""
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        arq = base / "cotacoes.csv"
        arq.write_text(CABECALHO + "\n" + cotacoes, encoding="utf-8")
        cmd = [sys.executable, str(COMPARAR), "--cotacoes", str(arq),
               "--saida", str(base / "saida")]
        if pedido is not None:
            arqp = base / "pedido.csv"
            arqp.write_text(pedido, encoding="utf-8")
            cmd += ["--pedido", str(arqp)]
        if extra:
            cmd += extra
        proc = subprocess.run(cmd, capture_output=True, text=True)
        erros = []
        if proc.returncode != esperado_codigo:
            erros.append("codigo de saida %d, esperado %d. stderr: %s"
                         % (proc.returncode, esperado_codigo, proc.stderr.strip()))
        for arquivo, texto, deve in checagens:
            if arquivo == "stdout":
                conteudo = proc.stdout
            elif arquivo == "stderr":
                conteudo = proc.stderr
            else:
                caminho = base / "saida" / arquivo
                if not caminho.exists():
                    if deve:
                        erros.append("arquivo ausente: %s" % arquivo)
                    continue
                conteudo = caminho.read_text(encoding="utf-8")
            presente = texto in conteudo
            if presente != deve:
                erros.append("%s: %s %r" % (
                    arquivo, "nao devia conter" if presente else "devia conter", texto))
        if nomes_reais:
            vistos = 0
            for caminho in sorted((base / "saida").rglob("*")):
                if not caminho.is_file() or caminho.name in excecoes:
                    continue
                vistos += 1
                conteudo = caminho.read_text(encoding="utf-8", errors="replace").lower()
                for real in nomes_reais:
                    if real.lower() in conteudo:
                        erros.append("%s reidentifica o fornecedor %r"
                                     % (caminho.name, real))
            if not vistos:
                erros.append("a varredura nao achou arquivo nenhum no diretorio")
        registrar(nome, erros)


# ---------------------------------------------------------------------------
# Armadilhas de unidade
# ---------------------------------------------------------------------------

# 1. A armadilha central. Dez pecas de um metro contra uma peca de dez metros.
#    Sem normalizar, 30,00 parece dez vezes mais barato que 280,00.
rodar(
    "armadilha central: 10 pecas de 1 m contra 1 peca de 10 m",
    "TUBO;A;;10;pc;1 m;30,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "TUBO;B;;1;pc;10 m;280,00;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("comparativo.csv", ";30;", True),    # preco por metro do A
     ("comparativo.csv", ";28;", True)],   # preco por metro do B
    pedido="item;unidade de referencia\nTUBO;m\n")

# 2. Milheiro contra peca. Fator mil, e o erro parece preco.
rodar(
    "milheiro contra peca",
    "PARAF;A;;2;milheiro;;1240,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "PARAF;B;;2000;pc;;1,19;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("comparativo.csv", ";1,24;", True),
     ("comparativo.csv", ";1,19;", True)],
    pedido="item;unidade de referencia\nPARAF;un\n")

# 3. Fator proibido sem declaracao: tambor nao vale 200 L por decreto.
rodar(
    "tambor sem litragem declarada nao entra no comparativo",
    "OLEO;A;;2;tambor;;3980,00;unitario;BRL;com frete e imposto;;;;92;\n"
    "OLEO;B;;2;tambor;tambor de 200 L;7760,00;lote;BRL;com frete e imposto;;;;97;\n",
    5,
    [("nao-comparaveis.csv", "fator proibido sem declaracao", True),
     ("comparativo.csv", "3980", False)],
    pedido="item;unidade de referencia\nOLEO;L\n")

# 4. Galao: 3,785 contra 4,546 litros. Nunca converte sozinho.
rodar(
    "galao sem litragem declarada nao entra no comparativo",
    "TINTA;A;;4;galao;;210,00;unitario;BRL;com frete e imposto;;;;90;\n"
    "TINTA;B;;18;L;;48,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "fator proibido sem declaracao", True),
     ("nao-comparaveis.csv", "3,785", True)],
    pedido="item;unidade de referencia\nTINTA;L\n")

# 5. ML e ambiguo: mililitro ou metro linear, fator mil e dimensao diferente.
rodar(
    "ml sem declaracao sai como unidade ambigua",
    "DESENG;A;;10;ML;;12,00;unitario;BRL;com frete e imposto;;;;80;\n"
    "DESENG;B;;5;L;;94,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "unidade ambigua", True)],
    pedido="item;unidade de referencia\nDESENG;L\n")

# 6. Embalagem sem conteudo declarado.
rodar(
    "caixa sem conteudo declarado nao entra no comparativo",
    "PECA;A;;3;caixa;;120,00;unitario;BRL;com frete e imposto;;;;88;\n"
    "PECA;B;;300;un;;1,30;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "embalagem sem conteudo declarado", True)],
    pedido="item;unidade de referencia\nPECA;un\n")

# 7. Escopo nao declarado fica fora da ordenacao, e nao vira comparacao torta.
rodar(
    "escopo do preco nao declarado fica fora da ordenacao",
    "CABO;A;;100;m;;6,00;unitario;BRL;;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("comparativo.csv", "escopo do preco nao declarado", True),
     ("nota-de-normalizacao-de-unidade.md", "nao declarado", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 8. Moeda diferente no mesmo item: ordena em separado, nunca converte.
rodar(
    "moeda diferente ordena em separado",
    "ROLAM;A;;10;un;;180,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "ROLAM;B;;10;un;;32,00;unitario;USD;com frete e imposto;;;;95;\n",
    5,
    [("nota-de-normalizacao-de-unidade.md", "moedas diferentes no mesmo item", True),
     ("comparativo.csv", "um so fornecedor no grupo", True)],
    pedido="item;unidade de referencia\nROLAM;un\n")

# 9. Confianca abaixo do limiar na primeira posicao vira alerta nomeado.
rodar(
    "primeira posicao abaixo do limiar vira alerta",
    "ELET;A;;10;kg;;19,40;unitario;BRL;com frete e imposto;;;;70;\n"
    "ELET;B;;10;kg;;19,90;unitario;BRL;com frete e imposto;;;;98;\n",
    1,
    [("stdout", "primeira posicao", True)],
    pedido="item;unidade de referencia\nELET;kg\n")

# 10. Confianca em branco conta como abaixo do limiar, nunca como acima.
rodar(
    "confianca em branco conta como abaixo do limiar",
    "ELET;A;;10;kg;;19,40;unitario;BRL;com frete e imposto;;;;;\n"
    "ELET;B;;10;kg;;19,90;unitario;BRL;com frete e imposto;;;;98;\n",
    1,
    [("comparativo.csv", "confianca nao declarada pela extracao", True)],
    pedido="item;unidade de referencia\nELET;kg\n")

# 11. Dimensao diferente da referencia: kg contra m2 nao se compara.
rodar(
    "dimensao diferente da referencia sai do comparativo",
    "CHAPA;A;;1000;kg;;7,85;unitario;BRL;com frete e imposto;;;;95;\n"
    "CHAPA;B;;30;m2;;260,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "dimensao diferente da referencia", True)],
    pedido="item;unidade de referencia\nCHAPA;kg\n")

# 12. Fator dez dentro do grupo dispara o alerta de unidade suspeita, e alerta
#     aberto nao sai com codigo 0: quem chama num .bat le o numero e segue.
rodar(
    "diferenca de uma ordem de grandeza dispara alerta e muda o codigo de saida",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;61,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("stdout", "costuma ser unidade errada e nao preco", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 13. --so-nota para antes da ordenacao e nao vaza ordem de preco.
rodar(
    "--so-nota para antes da ordenacao",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    4,
    [("nota-de-normalizacao-de-unidade.md", "so-nota, sem comparativo", True),
     ("nota-de-normalizacao-de-unidade.md", "Nao calculados", True)],
    pedido="item;unidade de referencia\nCABO;m\n",
    extra=["--so-nota"])

# 14. Base do preco nao declarada: nao se chuta entre unitario e lote.
rodar(
    "base do preco nao declarada nao entra no comparativo",
    "CABO;A;;100;m;;600,00;;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "base do preco nao declarada", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 15. Sem --pedido, a unidade de referencia sai da dimensao da maioria.
rodar(
    "sem pedido, a referencia e declarada e nao chutada",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;0,1;km;;6000,00;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("nota-de-normalizacao-de-unidade.md", "derivada da dimensao da maioria", True)])

# 16. Linha com contagem de coluna errada nao some em silencio.
rodar(
    "linha com coluna faltando aparece em nao-comparaveis",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m\n"
    "CABO;C;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "descartada na leitura", True),
     ("nota-de-normalizacao-de-unidade.md", "descartadas na leitura", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 17. Diretorio existente sem --forcar e erro de entrada, nao fechamento.
with tempfile.TemporaryDirectory() as tmp:
    base = Path(tmp)
    (base / "saida").mkdir()
    arq = base / "cotacoes.csv"
    arq.write_text(CABECALHO + "\nCABO;A;;100;m;;6,00;unitario;BRL;com frete e "
                   "imposto;;;;95;\n", encoding="utf-8")
    proc = subprocess.run([sys.executable, str(COMPARAR), "--cotacoes", str(arq),
                           "--saida", str(base / "saida")],
                          capture_output=True, text=True)
    registrar("diretorio existente sem --forcar sai com 3",
              [] if (proc.returncode == 3 and "ja existe" in proc.stderr)
              else [proc.stderr.strip()])

# 18. Coluna obrigatoria ausente para a rodada antes de ler valor nenhum.
with tempfile.TemporaryDirectory() as tmp:
    base = Path(tmp)
    arq = base / "cotacoes.csv"
    arq.write_text("item;fornecedor;preco\nCABO;A;6,00\n", encoding="utf-8")
    proc = subprocess.run([sys.executable, str(COMPARAR), "--cotacoes", str(arq),
                           "--saida", str(base / "saida")],
                          capture_output=True, text=True)
    registrar("coluna obrigatoria ausente sai com 3",
              [] if (proc.returncode == 3
                     and "faltam colunas obrigatorias" in proc.stderr)
              else [proc.stderr.strip()])

# 19. --estrito bloqueia o que a rodada normal apenas marca.
rodar(
    "--estrito bloqueia linha abaixo do limiar",
    "ELET;A;;10;kg;;19,40;unitario;BRL;com frete e imposto;;;;70;\n"
    "ELET;B;;10;kg;;19,90;unitario;BRL;com frete e imposto;;;;98;\n",
    2,
    [],
    pedido="item;unidade de referencia\nELET;kg\n",
    extra=["--estrito"])

# 20. Anonimizacao. Rotular a coluna fornecedor nao anonimiza a rodada: o nome
#     real volta pela linha bruta de nao-comparaveis.csv, pela descricao da
#     proposta e pelo nome do arquivo de origem, sempre com o valor ao lado. A
#     varredura e do DIRETORIO INTEIRO, porque o que se compacta e o diretorio.
rodar(
    "--anonimizar-fornecedor: nenhum arquivo do diretorio reidentifica o fornecedor",
    "OLEO;Metalurgica Tal;Oleo da Metalurgica Tal;2;tambor;;3980,00;unitario;BRL;"
    "com frete e imposto;;;;92;proposta-metalurgica-tal.pdf\n"
    "OLEO;Outra Tal Ltda;;2;tambor;tambor de 200 L;7760,00;lote;BRL;"
    "com frete e imposto;;;;97;proposta-outra-tal.pdf\n"
    "CABO;Metalurgica Tal;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;Outra Tal Ltda;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "descricao=Oleo da Fornecedor A", True),
     ("nao-comparaveis.csv", "origem=proposta-Fornecedor A.pdf", True),
     ("comparativo.csv", "Fornecedor B", True),
     ("de-para-fornecedor.csv", "Metalurgica Tal", False),
     ("../saida-de-para-fornecedor.csv", "Metalurgica Tal", True),
     ("stdout", "nao compartilhe", True)],
    pedido="item;unidade de referencia\nOLEO;L\nCABO;m\n",
    extra=["--anonimizar-fornecedor"],
    nomes_reais=("Metalurgica Tal", "Outra Tal", "metalurgica-tal", "outra-tal"),
    excecoes=("perguntas-aos-fornecedores.md",))

# 21. O arquivo que se envia ao fornecedor sai com o nome real, e diz isso na
#     cara. Enderecar a mensagem a "Fornecedor A" obriga a abrir o de-para linha
#     a linha antes de mandar, e o de-para esta fora do diretorio de proposito.
rodar(
    "com anonimizacao, so perguntas-aos-fornecedores.md leva o nome real",
    "OLEO;Metalurgica Tal;;2;tambor;;3980,00;unitario;BRL;com frete e imposto;;;;92;\n"
    "OLEO;Outra Tal Ltda;;2;tambor;tambor de 200 L;7760,00;lote;BRL;"
    "com frete e imposto;;;;97;\n",
    5,
    [("perguntas-aos-fornecedores.md",
      "## Metalurgica Tal (Fornecedor A nos outros arquivos da rodada)", True),
     ("perguntas-aos-fornecedores.md",
      "unico arquivo deste diretorio que carrega o nome real", True),
     ("nota-de-normalizacao-de-unidade.md",
      "nesta rodada ele traz nome real, e por isso tire-o do diretorio", True),
     ("stdout", "Tire-o do diretorio antes de compactar", True)],
    pedido="item;unidade de referencia\nOLEO;L\n",
    extra=["--anonimizar-fornecedor"],
    nomes_reais=("Metalurgica Tal", "Outra Tal"),
    excecoes=("perguntas-aos-fornecedores.md",))

# 22. A linha descartada na leitura nao tem coluna fornecedor legivel, e por isso
#     o conteudo bruto dela nao pode ser trocado pelo rotulo com garantia. Ele
#     sai do diretorio em vez de sair uma promessa que nao se cumpre.
rodar(
    "com anonimizacao, o conteudo da linha descartada sai do diretorio",
    "CABO;Metalurgica Tal;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;Fornecedora Nunca Lida;;100;m\n"
    "CABO;Outra Tal Ltda;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "conteudo suprimido pela anonimizacao", True),
     ("nao-comparaveis.csv", "descartada na leitura", True),
     ("../saida-linhas-descartadas.csv", "Fornecedora Nunca Lida", True),
     ("stdout", "linhas descartadas na leitura gravado FORA", True),
     ("nota-de-normalizacao-de-unidade.md", "fora do diretorio da rodada", True)],
    pedido="item;unidade de referencia\nCABO;m\n",
    extra=["--anonimizar-fornecedor"],
    nomes_reais=("Metalurgica Tal", "Fornecedora Nunca Lida", "Outra Tal"),
    excecoes=("perguntas-aos-fornecedores.md",))

# 23. Numero em notacao brasileira com separador de milhar.
rodar(
    "separador de milhar nao vira fator mil",
    "CHAPA;A;;1.436,8;kg;;7,85;unitario;BRL;com frete e imposto;;;;95;\n"
    "CHAPA;B;;1.436,8;kg;;8,20;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("comparativo.csv", "1436,8", True),
     ("comparativo.csv", ";7,85;", True)],
    pedido="item;unidade de referencia\nCHAPA;kg\n")

# 24. Item sem nenhuma linha comparavel continua no relatorio.
rodar(
    "item sem nenhuma linha comparavel nao some do relatorio",
    "OLEO;A;;2;tambor;;3980,00;unitario;BRL;com frete e imposto;;;;92;\n"
    "CABO;B;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;C;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("pedido-com-unidade-travada.md", "OLEO", True),
     ("nota-de-normalizacao-de-unidade.md", "itens sem nenhuma linha comparavel | 1", True)],
    pedido="item;unidade de referencia\nOLEO;L\nCABO;m\n")

# ---------------------------------------------------------------------------
# Um caso por achado gravissimo
# ---------------------------------------------------------------------------

# 25. Polegada e designacao nominal, nao medida. Tubo de 1 polegada nao tem
#     25,4 mm. Converter em silencio e o erro que a skill existe para impedir.
rodar(
    "polegada nao e convertida: sai como unidade ambigua",
    "TUBO;A;;10;pol;;180,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "TUBO;B;;10;m;;18,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "unidade ambigua", True),
     ("nao-comparaveis.csv", "designacao nominal", True),
     ("comparativo.csv", ";pol;", False),
     ("comparativo.csv", "0,0254", False),
     ("perguntas-aos-fornecedores.md", "Em que unidade esta linha foi cotada", True)],
    pedido="item;unidade de referencia\nTUBO;m\n")

# 26. Coluna que mistura ponto e virgula decimal: o valor que nao se le sem
#     chute sai do comparativo, e nao entra lido com fator dez.
rodar(
    "valor ambiguo em coluna de formato misto sai do comparativo",
    "CABO;A;;100;m;;6,15;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6.40;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;C;;100;m;;1.200;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "formato de numero divergente na coluna", True),
     ("comparativo.csv", ";6,15;", True),
     ("comparativo.csv", ";6,4;", True),
     ("nota-de-normalizacao-de-unidade.md", "mista", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 27. Na mesma coluna misturada, o valor que se le pela propria evidencia e
#     lido certo: 6,15 nunca vira 615.
rodar(
    "planilha em ponto decimal no meio de proposta em virgula nao vira fator cem",
    "CABO;A;;100;m;;6,15;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6.40;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("comparativo.csv", ";6,15;unitario;", True),
     ("comparativo.csv", ";6,4;unitario;", True),
     ("comparativo.csv", ";615;unitario;", False),
     ("comparativo.csv", ";640;unitario;", False)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 28. Embalagem multiplicada escrita em portugues: fardo com 4 pacotes de 5 kg
#     sao 20 kg, nao 5 kg.
rodar(
    "fardo com 4 pacotes de 5 kg vale 20 kg",
    "CIM;A;;10;fardo;fardo com 4 pacotes de 5 kg;600,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CIM;B;;200;kg;;30,00;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("comparativo.csv", ";declarado;20;200;", True),  # fator 20 kg e 200 kg
     ("comparativo.csv", ";declarado;5;50;", False),  # o erro de ler so o ultimo numero
     ("comparativo.csv", ";30;95;nao;", True)],   # mesmo preco por kg nos dois
    pedido="item;unidade de referencia\nCIM;kg\n")

# 29. Embalagem com numero sobrando nao e resolvida pelo ultimo numero: errar
#     por um fator inteiro sem deixar rastro e pior do que nao resolver.
rodar(
    "embalagem com numero sobrando nao e resolvida no chute",
    "SUCO;A;;5;cx;caixa 12 x 1 L, 6 caixas por pallet;80,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "SUCO;B;;60;L;;1,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "embalagem com mais de um numero nao resolvida", True),
     ("perguntas-aos-fornecedores.md", "nao fecha o conteudo total", True)],
    pedido="item;unidade de referencia\nSUCO;L\n")

# 30. Embalagem em unidade de contagem sobre unidade de contagem e a caixa de
#     entrega, nao fator. Multiplicar por ela poe o mais caro em primeiro lugar,
#     e a razao fica abaixo do alerta de fator.
rodar(
    "embalagem de contagem nao multiplica unidade de contagem",
    "PARAF;A;;1000;pc;caixa com 2 un;1,20;unitario;BRL;com frete e imposto;;;;95;\n"
    "PARAF;B;;1000;pc;;1,25;unitario;BRL;com frete e imposto;;;;95;\n",
    1,
    [("comparativo.csv", ";1,2;", True),
     ("comparativo.csv", ";0,6;", False),
     ("comparativo.csv", "embalagem em unidade de contagem ignorada", True)],
    pedido="item;unidade de referencia\nPARAF;un\n")

# 31. Item que esta no pedido e que nenhum fornecedor cotou e a informacao mais
#     urgente da rodada, e era a unica que sumia de todos os artefatos.
rodar(
    "item do pedido sem nenhuma proposta aparece em todos os artefatos",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "item do pedido sem nenhuma proposta", True),
     ("pedido-com-unidade-travada.md", "FILTRO-AR", True),
     ("perguntas-aos-fornecedores.md", "FILTRO-AR", True),
     ("nota-de-normalizacao-de-unidade.md",
      "itens do pedido sem nenhuma proposta | 1", True),
     ("stdout", "nenhum fornecedor cotou este item", True)],
    pedido="item;unidade de referencia\nCABO;m\nFILTRO-AR;un\n")

# 32. A inversa do item sem proposta: fornecedor cotou o que nao foi pedido. A
#      linha entrava no comparativo com a mesma cara de quem respondeu o pedido.
rodar(
    "item cotado fora do pedido entra no comparativo marcado",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n"
    "FITA;A;;10;un;;3,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "FITA;B;;10;un;;3,20;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("comparativo.csv", "FITA;un;sim;", True),
     ("comparativo.csv", "CABO;m;nao;", True),
     ("nota-de-normalizacao-de-unidade.md", "NAO, cotado sem estar no pedido", True),
     ("nota-de-normalizacao-de-unidade.md", "| itens cotados fora do pedido | 1 |", True),
     ("pedido-com-unidade-travada.md", "item cotado sem estar no pedido", True),
     ("perguntas-aos-fornecedores.md", "Itens cotados fora do pedido", True),
     ("stdout", "item cotado sem estar no pedido, por A, B", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 33. Sem pedido nao existe "fora do pedido", e a coluna diz isso em vez de
#      dizer "nao" e passar por conferencia que nao houve.
rodar(
    "sem pedido, a coluna fora_do_pedido nao finge conferencia",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("comparativo.csv", "CABO;m;nao conferido;", True),
     ("nota-de-normalizacao-de-unidade.md", "| pedido nao informado |", True),
     ("stdout", "item cotado sem estar no pedido", False)])

# ---------------------------------------------------------------------------
# Um caso por achado grave
# ---------------------------------------------------------------------------

# 34. O fechamento rele os arquivos gravados. Identidade que compara um numero
#     com max dele mesmo fecha sempre e saiu da lista.
rodar(
    "o fechamento rele o arquivo gravado e nao traz identidade que fecha sempre",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("nota-de-normalizacao-de-unidade.md",
      "registros gravados em comparativo.csv", True),
     ("nota-de-normalizacao-de-unidade.md",
      "registros gravados em nao-comparaveis.csv", True),
     ("nota-de-normalizacao-de-unidade.md", "itens sem ordenacao >=", False),
     ("stdout", "NAO FECHA", False)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 35. A nota traz nome de fornecedor nas secoes 5 e 9. A rodada --so-nota sem
#     anonimizacao avisa, porque e essa nota que a pessoa cola.
rodar(
    "--so-nota sem anonimizacao avisa que a nota leva o nome do fornecedor",
    "CABO;Metalurgica Tal;;100;m;rolo de 100 m;600,00;lote;BRL;com frete e imposto;;;;95;\n"
    "CABO;Outra Tal;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    4,
    [("stderr", "nome do fornecedor", True)],
    pedido="item;unidade de referencia\nCABO;m\n",
    extra=["--so-nota"])

# 36. A marca de validacao do gabarito fica no arquivo, nao na lembranca.
rodar(
    "sem gabarito conferido, todo artefato sai marcado como nao validado",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("nota-de-normalizacao-de-unidade.md",
      "Validacao: nao validada, 1 de 3 rodadas", True),
     ("comparativo.csv", "Validacao: nao validada, 1 de 3 rodadas", True),
     ("nao-comparaveis.csv", "Validacao: nao validada, 1 de 3 rodadas", True),
     ("pedido-com-unidade-travada.md", "Validacao: nao validada, 1 de 3 rodadas", True),
     ("perguntas-aos-fornecedores.md", "Validacao: nao validada, 1 de 3 rodadas", True)],
    pedido="item;unidade de referencia\nCABO;m\n",
    extra=["--gabarito-conferido", "1"])

rodar(
    "com tres rodadas de gabarito, a marca de nao validada some",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    0,
    [("nota-de-normalizacao-de-unidade.md", "nao validada", False),
     ("nota-de-normalizacao-de-unidade.md",
      "Validacao: 3 rodadas de gabarito conferidas", True)],
    pedido="item;unidade de referencia\nCABO;m\n",
    extra=["--gabarito-conferido", "3"])

# 37. Status calculado antes de gravar: nota marcada completo num diretorio que
#     o proprio script invalidou e o pior dos casos, porque a marca fica.
rodar(
    "rodada sem nenhuma linha comparavel nao grava nota marcada completo",
    "OLEO;A;;2;tambor;;3980,00;unitario;BRL;com frete e imposto;;;;92;\n",
    3,
    [("nota-de-normalizacao-de-unidade.md",
      "status: invalido, nenhuma linha comparavel", True),
     ("nota-de-normalizacao-de-unidade.md", "status: completo", False)],
    pedido="item;unidade de referencia\nOLEO;L\n")

# 38. --so-nota depois de uma rodada completa nao deixa o comparativo antigo na
#     pasta ao lado de uma nota que diz que nao houve comparativo.
with tempfile.TemporaryDirectory() as tmp:
    base = Path(tmp)
    arq = base / "cotacoes.csv"
    arq.write_text(CABECALHO + "\n"
                   "TERM;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
                   "TERM;B;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
                   encoding="utf-8")
    arqp = base / "pedido.csv"
    arqp.write_text("item;unidade de referencia\nTERM;m\n", encoding="utf-8")
    comum = [sys.executable, str(COMPARAR), "--cotacoes", str(arq),
             "--pedido", str(arqp), "--saida", str(base / "saida")]
    subprocess.run(comum, capture_output=True, text=True)
    proc = subprocess.run(comum + ["--so-nota", "--forcar"],
                          capture_output=True, text=True)
    erros = []
    if proc.returncode != 4:
        erros.append("codigo de saida %d, esperado 4" % proc.returncode)
    if (base / "saida" / "comparativo.csv").exists():
        erros.append("o comparativo.csv da rodada anterior continua no diretorio")
    if (base / "saida" / "pedido-com-unidade-travada.md").exists():
        erros.append("o pedido travado da rodada anterior continua no diretorio")
    registrar("--so-nota apaga o comparativo da rodada anterior", erros)

# 39. Descricao: termo com digito do pedido que nao aparece na proposta vira
#     alerta. A skill nao decide equivalencia, e agora nao finge que compara.
rodar(
    "termo tecnico do pedido ausente na descricao da proposta vira alerta",
    "PARAF;A;Parafuso M8x30 inox 304;100;pc;;1,20;unitario;BRL;com frete e imposto;;;;95;\n"
    "PARAF;B;Parafuso M8x30 inox 316;100;pc;;1,10;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("stdout", "equivalencia tecnica e engenharia", True),
     ("stdout", "304", True)],
    pedido="item;descricao;unidade de referencia\n"
           "PARAF;Parafuso M8x30 inox 304;un\n")

# 40. A description nao promete ler PDF, traz o termo que suprimentos usa, e
#     cabe no limite com folga conferida por script.
with open(SKILL, encoding="utf-8") as f:
    texto_skill = f.read()
m = re.search(r"^description: >\n((?:  .*\n)+)", texto_skill, re.M)
erros = []
if m is None:
    erros.append("nao achei a description no SKILL.md")
else:
    desc = " ".join(l.strip() for l in m.group(1).splitlines())
    if len(desc) > 1400:
        erros.append("description com %d caracteres, acima do teto de 1400" % len(desc))
    for proibido in ("como elas chegaram", "PDF, corpo de e-mail, planilha"):
        if proibido in desc:
            erros.append("a description ainda promete ler arquivo: %r" % proibido)
    for exigido in ("equaliza essas propostas", "mapa de concorrência",
                    "extracao-de-documento-para-tabela"):
        if exigido not in desc:
            erros.append("falta na description: %r" % exigido)
registrar("description honesta, com os gatilhos de suprimentos e dentro de 1400", erros)

# 41. O comando --so-nota do SKILL.md leva --anonimizar-fornecedor.
erros = []
bloco = re.search(r"--saida cotacao-\d{4}-\d{2}-\d{2} --so-nota[^\n`]*", texto_skill)
if bloco is None:
    erros.append("nao achei o comando --so-nota no SKILL.md")
elif "--anonimizar-fornecedor" not in bloco.group(0):
    erros.append("o comando --so-nota do SKILL.md nao leva --anonimizar-fornecedor")
registrar("o comando --so-nota documentado leva a anonimizacao", erros)

# 42. O vocabulario de causa documentado e o que o script emite, nos dois
#     sentidos: causa documentada e inalcancavel engana tanto quanto causa
#     emitida e nao documentada.
CAUSAS = [
    "item ou fornecedor em branco",
    "quantidade ilegivel ou nao positiva",
    "preco ilegivel ou nao positivo",
    "base do preco nao declarada",
    "unidade nao declarada",
    "unidade ambigua",
    "unidade fora da tabela",
    "fator proibido sem declaracao",
    "embalagem sem conteudo declarado",
    "embalagem ilegivel",
    "embalagem em unidade ambigua",
    "embalagem em unidade sem fator fixo",
    "embalagem com mais de um numero nao resolvida",
    "dimensao diferente da referencia",
    "unidade de referencia indefinida",
    "quantidade em unidade de referencia nao positiva",
    "formato de numero divergente na coluna",
    "item do pedido sem nenhuma proposta",
    "descartada na leitura",
]
fonte = COMPARAR.read_text(encoding="utf-8")
erros = []
for causa in CAUSAS:
    if '"%s"' % causa not in fonte:
        erros.append("causa documentada que o script nao emite: %s" % causa)
    if causa not in texto_skill:
        erros.append("causa emitida que o SKILL.md nao documenta: %s" % causa)
registrar("vocabulario de causa igual nos dois arquivos", erros)

# ---------------------------------------------------------------------------
# Um caso por achado medio que muda saida
# ---------------------------------------------------------------------------

# 43. Embalagem preenchida e ilegivel recebe a causa da embalagem, nao a causa
#     generica que diz ao fornecedor que ele nao declarou o que ele declarou.
rodar(
    "embalagem declarada e nao lida recebe a causa da embalagem",
    "SOLV;A;;3;cx;caixa com 12 frascos;240,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "SOLV;B;;36;L;;6,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "embalagem em unidade sem fator fixo", True),
     ("nao-comparaveis.csv", "nao declarou quanto vale uma cx", False)],
    pedido="item;unidade de referencia\nSOLV;L\n")

# 44. --alerta-fator com virgula decimal nao derruba o script com traceback.
rodar(
    "--alerta-fator aceita virgula decimal",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;18,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("stdout", "passa do menor por 3x", True),
     ("stderr", "Traceback", False)],
    pedido="item;unidade de referencia\nCABO;m\n",
    extra=["--alerta-fator", "2,5"])

# 45. Escopo pedido no pedido.csv deixou de ser coluna lida e nunca usada.
rodar(
    "resposta em escopo diferente do pedido vira alerta nomeado",
    "CABO;A;;100;m;;6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;5,40;unitario;BRL;sem imposto;;;;95;\n",
    5,
    [("stdout", "respondeu em escopo sem imposto e o pedido pediu com frete e imposto",
      True),
     ("pedido-com-unidade-travada.md", "respondeu em escopo sem imposto", True)],
    pedido="item;unidade de referencia;escopo de preco pedido\n"
           "CABO;m;com frete e imposto\n")

# 46. Plural de unidade de fator proibido recebe a causa certa, e por isso a
#     pergunta certa vai para o fornecedor.
rodar(
    "bombonas recebe a causa de bombona, nao a de unidade fora da tabela",
    "DESENG;A;;6;bombonas;;900,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "DESENG;B;;120;L;;7,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "fator proibido sem declaracao", True),
     ("nao-comparaveis.csv", "20, 50 e 200 litros", True),
     ("nao-comparaveis.csv", "unidade fora da tabela", False)],
    pedido="item;unidade de referencia\nDESENG;L\n")

# 47. A coluna conteudo_da_linha guarda a linha inteira tambem nas causas da
#     segunda passada: e ela que impede o descarte silencioso.
rodar(
    "conteudo_da_linha traz a linha inteira na segunda passada",
    "CHAPA;A;;1000;kg;;7,85;unitario;BRL;com frete e imposto;;;;95;\n"
    "CHAPA;B;;30;m2;;260,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "unidade=m2", True),
     ("nao-comparaveis.csv", "preco=260,00", True)],
    pedido="item;unidade de referencia\nCHAPA;kg\n")

# ---------------------------------------------------------------------------
# Dois casos que a revisao nao nomeou
# ---------------------------------------------------------------------------

# 48. Preco nao positivo ordenava em primeiro lugar. Parentese de contabilidade,
#     sinal trocado na digitacao e linha zerada por brinde viravam o menor preco
#     do grupo, que e recomendacao de compra.
rodar(
    "preco nao positivo nunca chega ao primeiro lugar da ordenacao",
    "CABO;A;;100;m;;-6,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;0,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;C;;100;m;;6,40;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("nao-comparaveis.csv", "preco ilegivel ou nao positivo", True),
     ("comparativo.csv", ";-6;", False),
     ("comparativo.csv", ";0;", False),
     ("perguntas-aos-fornecedores.md", "Confirme o preco desta linha", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 49. Coluna sem evidencia nenhuma sobre o separador: 1.200 contra 800 inverte
#     a ordem conforme a leitura. A linha entra marcada, nunca em silencio, e a
#     rodada nao sai com codigo 0.
rodar(
    "valor lido sob assuncao entra marcado e poe a ordenacao em duvida",
    "CABO;A;;100;m;;1.200;unitario;BRL;com frete e imposto;;;;95;\n"
    "CABO;B;;100;m;;800;unitario;BRL;com frete e imposto;;;;95;\n",
    1,
    [("comparativo.csv", "separador decimal assumido", True),
     ("stdout", "a ordem pode inverter", True),
     ("nota-de-normalizacao-de-unidade.md", "(assumida)", True)],
    pedido="item;unidade de referencia\nCABO;m\n")

# 50. Duas linhas do mesmo fornecedor no mesmo grupo nao sao dois fornecedores.
#     O grupo saia ordenado, com posicao 1 e 2, e o quadro parecia comparativo.
rodar(
    "duas linhas do mesmo fornecedor no grupo nao viram ordenacao",
    "ROLAM;A;;10;un;;180,00;unitario;BRL;com frete e imposto;;;;95;\n"
    "ROLAM;A;;10;un;;190,00;unitario;BRL;com frete e imposto;;;;95;\n",
    5,
    [("stdout", "nao sao dois fornecedores", True),
     ("comparativo.csv", "ordenacao de um nao e ordenacao", True),
     ("nota-de-normalizacao-de-unidade.md", "| linhas ordenaveis | 0 |", True)],
    pedido="item;unidade de referencia\nROLAM;un\n")

print("")
if falhas:
    print("%d caso(s) falharam." % len(falhas))
    sys.exit(1)
print("Todos os casos passaram.")
sys.exit(0)
