---
name: comparativo-de-cotacoes
description: >
  Recebe as linhas já extraídas das propostas num CSV e devolve o comparativo por item com a
  unidade normalizada, confiança por linha, as linhas irresolvidas numa lista separada, a
  pergunta pronta para cada fornecedor e o texto do pedido com unidade travada para a
  próxima rodada. A leitura do PDF, do e-mail, da planilha e do .eml é feita antes, pela
  skill extracao-de-documento-para-tabela. Trata a armadilha que faz o comparativo
  manual errar: cada fornecedor responde na unidade dele, e 10 unidades de 1 metro contra 1
  unidade de 10 metros muda o preço unitário por dez sem o quadro parecer errado. Cobre
  metro contra peça contra caixa contra milheiro, quilo contra tonelada contra saco, litro
  contra galão contra tambor, preço unitário contra preço de lote, e preço com e sem frete e
  imposto. Use SEMPRE que aparecer: "compara essas cotações", "monta o mapa de cotação",
  "equaliza essas propostas", "monta o mapa de concorrência", "qual fornecedor está mais
  barato de verdade", "esses fornecedores cotaram em unidades diferentes", "recebi três
  propostas do mesmo item", "toda semana eu monto esse quadro na mão". NÃO use para
  escolher fornecedor: ela normaliza e mostra, não recomenda. NÃO use para extrair dado de
  um documento só, para conferir duas listas iguais (conferencia-entre-duas-fontes) nem
  para triar a caixa de e-mail (triagem-de-caixa-de-email).
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que esta skill
ocupe o lugar das outras.

| Caso | Skill | Relação com esta |
|---|---|---|
| Tirar dado de um documento e pôr em tabela, sem comparar nada | `extracao-de-documento-para-tabela` (construída) | Ela é o passo 4 desta aqui, e pode ser chamada em separado quando a cotação é uma só |
| Separar o que responder na caixa de e-mail cheia de propostas | `triagem-de-caixa-de-email` (construída) | Ela indexa e prioriza. As propostas que ela separar entram aqui |
| Duas listas que deveriam dizer a mesma coisa | `conferencia-entre-duas-fontes` (construída) | O critério é o propósito: lá se procura divergência entre fontes da mesma verdade, aqui se compara oferta de fornecedores diferentes |
| Medir quanto tempo a montagem manual do comparativo custa hoje | `linha-de-base-antes-de-automatizar` (construída) | Cronometre três rodadas e anote, antes de mudar o processo |
| Descrever a área uma vez para as outras skills lerem | `ficha-da-area` (construída) | Rode-a antes. Ela escreve `~/.kit-industrial/ficha-da-area.md`, que o passo 1 desta lê |

As dez skills do kit estão nesta versão, inclusive `relatorio-recorrente`,
`registro-de-anomalia`, `padrao-conferido-contra-norma` e `indice-do-acervo-da-area`.

---

# Comparativo de cotações

Chegaram três respostas do mesmo pedido. Uma em PDF com tabela, uma no corpo do e-mail em
texto corrido, uma em planilha com o cabeçalho na linha 6. A pessoa abre as três, digita os
preços num quadro, roda o olho e decide. Faz isso toda semana, sob o prazo que as etapas
anteriores já consumiram.

Esta skill termina em arquivo. A saída é um conjunto de cinco arquivos gravados em disco,
no diretório de trabalho, e o caminho é informado. Resposta em prosa dizendo qual
fornecedor está mais barato é falha de execução, por dois motivos: não deixa rastro, e
dizer quem está mais barato não é o que esta skill faz.

Um dos cinco é `perguntas-aos-fornecedores.md`, e ele é o que tira trabalho da mesa: cada
linha que não fecha sai de lá como pergunta pronta, por fornecedor, para copiar e mandar.
Documento sobre o problema não resolve o problema.

**Ela não acessa caixa de e-mail, não acessa ERP e não acessa portal de fornecedor.** Os
arquivos são salvos numa pasta local antes, e ela diz isso na cara antes de começar.

---

## Leis de ferro

1. **A nota de normalização de unidade sai antes do comparativo.** Comparativo com unidade
   errada é pior do que nenhum comparativo: ele sai completo, ordenado, com cara de certo,
   e é assinado. A nota é o primeiro arquivo escrito, sempre.
2. **Linha cuja unidade não foi possível resolver não entra na ordenação.** Ela sai numa
   lista separada, com a causa. Item irresolvido não é sobra: é o que o pedido da próxima
   rodada precisa travar. Vale igual para o número: valor que não se lê sem chute não vira
   posição na ordenação, e ordenação é o que alguém lê como recomendação de compra.
3. **A skill não recomenda fornecedor.** Ela normaliza e mostra. Critério de escolha envolve
   prazo, histórico de atraso, qualidade recebida e risco de fornecedor único, e nada disso
   está na cotação. Ordenar por um número não é escolher.
4. **Fator que muda de fornecedor para fornecedor só entra declarado pela proposta.** Saco,
   tambor, galão, barra e arroba não têm valor de tabela. "Todo mundo sabe que é 50 kg" não
   é fonte.
5. **Gabarito antes do uso real.** A primeira rodada é feita sobre uma cotação já decidida, e
   confere se a skill ordenaria do mesmo jeito. Sem isso a skill não vai para o trabalho real.
6. **Confiança não declarada conta como abaixo do limiar.** Campo vazio nunca vira campo
   aprovado.
7. **Na dúvida entre descartar e reportar, reporte.** Heurística que apaga dado em silêncio
   sai. Heurística que marca para conferência humana fica, e marca no arquivo, não na
   conversa: linha marcada aparece em `conferir`, com o motivo, e a rodada nunca sai com
   código 0.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Existindo, use o vocabulário da área, o código de
item que a casa usa e as unidades de compra já praticadas. Não existindo, declare em voz
alta "rodando sem ficha da área" e siga normalmente.

Rodar sem ficha não degrada o comparativo: só obriga a confirmar a unidade de referência de
cada item com a pessoa, que é o passo 3.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi carregada ou se a
rodada está sem ficha e, carregada, repete o status gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir o arquivo

Quatro perguntas, nesta ordem:

1. **O dado é sensível?** As cinco classes: nome de pessoa; folha de pagamento, salário e
   remuneração individual; preço de fornecedor identificado; dado de cliente identificado;
   projeto sob sigilo. Folha, salário e remuneração individual não entram em nenhum modo.
   **Nesta skill a resposta é quase sempre sim**, porque preço de fornecedor identificado é
   o conteúdo da tarefa. Ofereça sempre o modo derivado, que aqui é `--anonimizar-fornecedor`
   mais o script local: a proposta fica na máquina e o nome do fornecedor fica fora dos
   artefatos.
2. **Essa cotação se repete?** Sendo semanal ou mensal, rode pelo script mesmo cabendo na
   leitura: o valor está em repetir igual, e leitura não repete igual.
3. **Quantos fornecedores e quantos itens?** Define leitura ou script pela tabela do passo 6.
4. **Existe uma rodada já decidida para servir de gabarito?** Existindo, ela é a primeira a
   rodar. Não existindo, diga no passo 7 o que fazer.

**Critério de conclusão:** as quatro respostas estão registradas e a escolha entre leitura e
script está feita antes de qualquer arquivo ser aberto.

---

## Passo 3: declarar o item e a unidade de referência

Diga qual item do pedido cada linha de proposta responde, e em que unidade o comparativo vai
sair. A unidade de referência é do item, não do fornecedor.

Escreva o `pedido.csv`, com uma linha por item pedido:

```
item;descricao;unidade de referencia;quantidade pedida;escopo de preco pedido
CABO-2,5-PT;Cabo flexivel de cobre 2,5 mm2 750 V preto;m;500;com frete e imposto
```

A unidade de referência tem que ter fator fixo: metro, quilo, litro, metro quadrado ou
unidade, ou um múltiplo deles. Declarar `caixa` como referência é adiar o problema.

Sem o pedido, a unidade de referência é derivada da dimensão da maioria das propostas de
cada item, e isso é declarado na nota. Quando as propostas se dividem em dimensões
diferentes sem maioria, o item para e a pergunta vai para a pessoa.

**Critério de conclusão:** cada item tem uma unidade de referência nomeada, e a pessoa
concordou com ela.

---

## Passo 4: extrair as propostas para uma tabela

Abra cada resposta e escreva uma linha por item cotado no `cotacoes.csv`. Uma proposta pode
ficar em qualquer formato: PDF, corpo de e-mail, planilha, `.eml` com anexo. O que sai daqui
é sempre a mesma tabela.

| Coluna | Obrigatória | Conteúdo |
|---|---|---|
| `item` | sim | O código do item do pedido, não a descrição do fornecedor |
| `fornecedor` | sim | Quem respondeu |
| `descricao` | não | A descrição como está na proposta, que é o que denuncia item similar |
| `quantidade` | sim | Quantas unidades daquela unidade a linha cobre |
| `unidade` | sim | Como o fornecedor escreveu: `ROLO`, `CX`, `milheiro`, `m` |
| `embalagem` | não | O conteúdo declarado: `rolo de 100 m`, `caixa com 20 kg`, `12 x 1 L` |
| `preco` | sim | O número como está na proposta |
| `base do preco` | sim | `unitario` ou `lote`. Sem isso a linha não entra |
| `moeda` | não | Padrão `BRL` |
| `escopo do preco` | não | `com frete e imposto`, `sem frete`, `sem imposto`, `sem frete e sem imposto` |
| `quantidade minima`, `multiplo` | não | Como declarados |
| `prazo` | não | Contexto, não entra em conta nenhuma |
| `confianca` | não | 0 a 100, a confiança da extração naquela linha. Vazio conta como abaixo do limiar |
| `origem` | não | Arquivo e linha de onde o valor saiu |

Três regras na extração, e elas são as mesmas da skill de extração:

- **Campo ausente fica vazio.** Nunca preenchido por inferência, nem pelo que o mesmo
  fornecedor mandou na rodada passada.
- **A unidade sai como o fornecedor escreveu.** Traduzir na extração apaga a evidência.
- **A confiança é por linha, não por proposta.** Numa mesma proposta, a linha da tabela e a
  linha escondida numa observação em texto corrido não têm a mesma confiança.

Como atribuir o número da coluna `confianca`, para o campo não sair inventado nem vazio:

- **95** quando o valor está numa célula de tabela legível da proposta.
- **80** quando o valor está em texto corrido ou em observação fora da tabela.
- **50** quando o valor foi lido de PDF escaneado, de imagem ou de tabela torta.
- **Vazio** só quando a linha foi digitada sem consultar a proposta, e nesse caso ela sai
  marcada para conferência, o que é o comportamento correto e não um alarme falso.

**Critério de conclusão:** o `cotacoes.csv` existe, tem uma linha por item cotado de cada
fornecedor, e a contagem de linhas bate com a contagem feita à mão nas propostas.

---

## Passo 5: decidir regra por regra

Leia `references/unidades.md` e percorra os cinco grupos de armadilha. Cada decisão tomada, e
cada decisão deixada em aberto, entra na nota.

A decisão que mais importa é a classe do fator, item por item: fixo, declarado ou proibido.
Fator fixo se aplica. Fator declarado se aplica com o que a proposta disse. Fator proibido
não se aplica, e a linha vira pergunta ao fornecedor, que se responde por e-mail em um
minuto e economiza o comparativo inteiro.

**Critério de conclusão:** existe uma decisão declarada para cada item e para cada unidade
que apareceu, e as ambíguas estão marcadas como ambíguas em vez de resolvidas no chute.

---

## Passo 6: rodar

| Tamanho da rodada | Como rodar |
|---|---|
| Até 40 linhas cotadas, sem repetição e sem preço de fornecedor identificado | Leitura em contexto, com fechamento obrigatório |
| Acima de 40 linhas | Script obrigatório |
| Preço de fornecedor identificado, que é quase sempre | Script obrigatório |
| A cotação se repete | Script obrigatório |
| Mais de uma unidade diferente no mesmo item | Script obrigatório |

**Por que a última linha faz a leitura ser a exceção.** Mais de uma unidade no mesmo item é
a situação normal em cotação, e é justamente a conta que a leitura erra sem avisar: o fator
é aplicado numa linha e esquecido na seguinte, e a saída sai plausível. O teste que decide: não
sendo possível reemitir a lista completa das linhas com o fator aplicado a cada uma e fechar
as contagens, aquilo foi amostragem. Diga que foi amostragem e rode o script.

**Dependência declarada:** Python 3.8 ou superior, biblioteca padrão apenas. Sem instalação,
sem rede, sem escrita nos arquivos de entrada.

**Onde o script está depois de instalado.** A instalação copia a pasta da skill para
`~/.claude/skills/comparativo-de-cotacoes/`. A rodada acontece na pasta dos arquivos de
trabalho, e por isso o script é sempre chamado pelo caminho completo. Caminho relativo como
`scripts/comparar.py` só funciona de dentro da pasta da skill.

Primeiro a rodada que só escreve a nota, para a pessoa aprovar as decisões de unidade antes
de ver qualquer preço ordenado:

```
python3 ~/.claude/skills/comparativo-de-cotacoes/scripts/comparar.py \
    --cotacoes cotacoes.csv --pedido pedido.csv \
    --saida cotacao-2026-09-20 --so-nota --anonimizar-fornecedor
```

A anonimização entra já nesta rodada, não só na segunda: sem `--anonimizar-fornecedor` a
nota traz o nome do fornecedor nas seções 5 e 9, e a `nao-comparaveis.csv` traz o nome com
a linha bruta e o preço ao lado. O script avisa no terminal quando a rodada `--so-nota`
roda sem ela.

Com a anonimização ligada, o nome real é trocado pelo rótulo em todo texto que entra no
diretório, e não só na coluna `fornecedor`: linha bruta, descrição, nome do arquivo de
origem, detalhe, nota e alerta. **A exceção é uma só e é declarada: o
`perguntas-aos-fornecedores.md` sai com o nome real**, porque ele não é o arquivo que se
compartilha, é o que se envia ao fornecedor. Tire esse arquivo do diretório antes de
compactar a rodada.

Aprovada a nota, a mesma linha sem `--so-nota` e com `--forcar`, porque a rodada grava no
mesmo diretório:

```
python3 ~/.claude/skills/comparativo-de-cotacoes/scripts/comparar.py \
    --cotacoes cotacoes.csv --pedido pedido.csv \
    --saida cotacao-2026-09-20 --anonimizar-fornecedor --forcar
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho vai entre
aspas com `$env:USERPROFILE` no lugar do `~`, e a linha continua com acento grave no lugar da
barra invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\comparativo-de-cotacoes\scripts\comparar.py" `
    --cotacoes cotacoes.csv --pedido pedido.csv `
    --saida cotacao-2026-09-20 --anonimizar-fornecedor --forcar
```

Outras opções: `--limiar` muda o limiar de confiança, que vem em 80; `--alerta-fator` muda o
fator que dispara o alerta de unidade suspeita, que vem em 3 e aceita vírgula decimal;
`--estrito` transforma em bloqueio o que a rodada normal apenas marca;
`--gabarito-conferido` diz quantas rodadas de gabarito já foram conferidas.

| Código de saída | Significado |
|---|---|
| 0 | Rodou, todo item tem grupo ordenado, nada a conferir, nada irresolvido, nenhum alerta em aberto |
| 1 | Rodou, há linha abaixo do limiar de confiança ou marcada para conferência |
| 2 | `--estrito`, e sobrou linha irresolvida ou a conferir |
| 3 | Erro de entrada, fechamento que não fecha, ou nenhuma linha comparável |
| 4 | Rodada em `--so-nota`, nenhuma ordenação foi feita |
| 5 | Rodou, nada a conferir, mas sobrou linha fora da ordenação, item do pedido sem nenhuma proposta, ou alerta por item não resolvido |

O código 3 para fechamento que não fecha é intencional: rodada cujas contagens não fecham não
é resultado parcial, é resultado inválido. O código 5 existe porque 0 é lido como "o
comparativo está completo": ele só pode sair quando não sobrou nada para o leitor resolver.
Alerta por item entra no código de saída, porque quem chama o script num `.bat` ou num
`make` lê o número e segue.

### Ler os alertas antes de abrir o comparativo

O script fecha a saída com um bloco de alertas por item. Três deles mudam a rodada, e o
passo é resolver antes de entregar:

- **O maior preço do grupo passa do menor por três vezes ou mais.** Em cotação de item
  padronizado isso quase nunca é preço, é unidade que sobrou errada. Volte à proposta antes
  de acreditar no número.
- **A primeira posição está abaixo do limiar de confiança.** O número que está ganhando a
  ordenação é o número que a extração menos garante. Confira na proposta antes de qualquer
  conversa com fornecedor.
- **Escopos diferentes no mesmo item.** Um cotou entregue e outro cotou a retirar. O script
  ordena em separado e não soma frete estimado. Ou se cota o frete, ou a comparação não
  existe.
- **Item cotado sem estar no pedido.** O fornecedor respondeu algo que ninguém pediu. Ou o
  pedido esqueceu o item, ou o código trocou, ou entrou oferta adicional. É achado, não
  ruído: decida antes de entregar se o item entra no pedido da próxima rodada.

**Critério de conclusão:** na rodada `--so-nota`, o diretório tem a nota com
`status: so-nota, sem comparativo`, a `nao-comparaveis.csv` e o
`perguntas-aos-fornecedores.md`, o comparativo de rodada anterior foi apagado do diretório,
e o código de saída é 4. Na rodada de comparação, o diretório tem os cinco arquivos, o
bloco de fechamento tem `fecha` em todas as linhas, e cada alerta foi lido e respondido.

---

## Passo 7: gabarito

É a lei de ferro 5, e é o passo que decide se a skill entra no trabalho real.

**Primeira vez, sobre uma rodada já decidida.** Pegue uma cotação do trimestre passado que
já foi decidida, rode a skill sobre as propostas originais e responda três perguntas: a
ordenação por preço normalizado põe na primeira posição o mesmo fornecedor que foi
escolhido? Não pondo, o motivo da escolha na época foi prazo, qualidade ou histórico, que a
skill de propósito não vê, ou foi um erro de unidade que passou despercebido? E as linhas
que a skill não conseguiu resolver, alguém resolveu na época, e como?

A terceira pergunta costuma ser a mais útil: ela mostra a suposição que a área aplica sem
escrever.

**Rodadas seguintes, cinco linhas.** Antes de entregar, escolha três linhas do topo da
ordenação e duas do meio, abra a proposta original de cada uma e confira quantidade,
unidade, embalagem e preço. Estando qualquer uma errada, o comparativo não é entregue.

Enquanto `--gabarito-conferido` for menor que 3, os cinco arquivos saem com a linha
`Validacao: nao validada, N de 3 rodadas de gabarito conferidas`, no cabeçalho dos `.md` e
no rodapé dos `.csv`. A marca não depende da lembrança de ninguém dentro da conversa: ela
fica no arquivo. Passe `--gabarito-conferido 1` depois da primeira rodada de gabarito sem
erro, `2` depois da segunda, e assim por diante.

**Critério de conclusão:** está dito qual dos dois caminhos foi usado, e as linhas conferidas
estão identificadas com fornecedor e número de linha.

---

## Passo 8: fechamento

Confira as identidades. São três, todas devem fechar, e os números vão na nota:

```
linhas lidas = descartadas na leitura + irresolvidas + comparativo
registros gravados em nao-comparaveis.csv = descartadas + irresolvidas + itens do pedido sem proposta
registros gravados em comparativo.csv     = linhas com a unidade resolvida
```

As duas últimas releem os arquivos gravados em disco e conferem contra a contagem em
memória. São três e não sete de propósito: identidade que soma dois predicados
complementares da mesma lista, ou que compara um número com `max` dele mesmo, fecha sempre
e não prova nada. As que ficaram provam uma coisa só, que é a que interessa: nenhuma linha
lida sumiu entre a entrada e os arquivos gravados.

O que pode falhar de fato vem no bloco de verificações: itens do pedido sem nenhuma
proposta, itens sem nenhuma ordenação, linhas fora da ordenação, linhas a conferir, linhas
não comparáveis e itens sem nenhuma linha comparável. Item sem ordenação não é falha do
script, é resultado: quer dizer que para aquele item não existe comparativo, e alguém
precisa saber disso antes de comprar.

Identidade que fecha é condição, não conclusão: a rodada pode fechar com todas as linhas
em `nao-comparaveis.csv`. Por isso o status só é `completo` quando fecha **e** existe pelo
menos uma linha comparável.

**Critério de conclusão:** as identidades foram impressas com os números e todas fecham, e
cada linha do bloco de verificações foi lida e respondida.

---

## Contrato de saída

Cinco arquivos num diretório com a data da rodada. Ordem de escrita: a nota, a
`nao-comparaveis.csv` e o `perguntas-aos-fornecedores.md` saem antes de qualquer ordenação,
os dois outros saem depois, e a nota é reescrita por último, com o fechamento. Dois
arquivos saem **fora** do diretório, e só com `--anonimizar-fornecedor`: o de-para e o
conteúdo bruto das linhas descartadas na leitura.

### 1. `nota-de-normalizacao-de-unidade.md`, primeiro, sempre

Abre com `status: incompleto` e só vira `status: completo` na última gravação. O status é
calculado antes de gravar, nunca depois: nota marcada `completo` num diretório que o
próprio script invalidou é o pior dos casos, porque quem abre a pasta lê a marca. Os cinco
valores possíveis são `incompleto` (a rodada caiu no meio e a saída não vale),
`so-nota, sem comparativo`, `completo`, `invalido, nao fecha` e
`invalido, nenhuma linha comparavel`.

A segunda linha do arquivo é a marca de validação do passo 7.

Seções: fontes, com tamanho e data de modificação; regra numérica decidida por coluna;
unidade de referência por item, com a origem da escolha; fatores aplicados por classe;
linhas resolvidas pela embalagem declarada, uma a uma; o que não foi normalizado por
decisão; linhas que não entraram no comparativo, por causa; confiança por linha; alertas por
item; fechamento; e o limite declarado.

### 2. `comparativo.csv`

Uma linha por item e fornecedor, ordenada por item, escopo, moeda e preço normalizado.

| Coluna | Conteúdo |
|---|---|
| `item`, `unidade_de_referencia` | O item do pedido e a unidade em que ele é comparado |
| `fora_do_pedido` | `sim` quando o fornecedor cotou item que não está no pedido, `nao` quando está, `nao conferido` quando a rodada não recebeu `pedido.csv` |
| `posicao` | Posição na ordenação dentro do grupo. Vazia quando a linha não é ordenável |
| `fornecedor`, `descricao_na_proposta`, `linha_de_origem` | De onde a linha veio |
| `quantidade_cotada`, `unidade_cotada`, `embalagem_declarada` | Como o fornecedor respondeu |
| `classe_do_fator`, `fator_aplicado` | `fixo` ou `declarado`, e o número aplicado |
| `quantidade_em_unidade_de_referencia` | A quantidade depois do fator |
| `preco_informado`, `base_do_preco`, `preco_total_da_linha` | O preço como veio e o total da linha |
| `moeda`, `escopo_do_preco` | Nunca convertidos, só declarados |
| `preco_por_unidade_de_referencia` | O número que torna a comparação possível |
| `confianca`, `conferir`, `motivo_conferir` | Confiança da extração e se a linha precisa de olho humano |
| `ordenavel`, `motivo_nao_ordenavel` | Por que a linha ficou fora da ordenação |
| `quantidade_minima`, `multiplo`, `prazo`, `origem` | Contexto, fora de qualquer conta |

A ordenação acontece dentro do grupo de item, escopo e moeda, e só quando o grupo tem dois
fornecedores ou mais. Ordenação de um não é ordenação, e sai dita.

### 3. `nao-comparaveis.csv`

Escrita junto com a nota, antes de qualquer ordenação. Uma linha por linha que ficou fora,
com `item`, `fornecedor`, `linha`, `causa`, `detalhe` e `conteudo_da_linha`. Nenhuma linha
sai sem aparecer aqui, e o total entra no fechamento: é o arquivo que impede o descarte
silencioso.

Vocabulário de `causa`, que é exatamente o conjunto que o script emite, conferido pelo
`testar.py` nos dois sentidos:

- `item ou fornecedor em branco`
- `quantidade ilegivel ou nao positiva`
- `preco ilegivel ou nao positivo`
- `base do preco nao declarada`
- `unidade nao declarada`
- `unidade ambigua`
- `unidade fora da tabela`
- `fator proibido sem declaracao`
- `embalagem sem conteudo declarado`
- `embalagem ilegivel`
- `embalagem em unidade ambigua`
- `embalagem em unidade sem fator fixo`
- `embalagem com mais de um numero nao resolvida`
- `dimensao diferente da referencia`
- `unidade de referencia indefinida`
- `quantidade em unidade de referencia nao positiva`
- `formato de numero divergente na coluna`
- `item do pedido sem nenhuma proposta`
- `descartada na leitura`

Quando o fornecedor preencheu o campo `embalagem` e ele não pôde ser lido, a causa é a
específica da embalagem, nunca a genérica do ramo: dizer que ele não declarou, quando ele
declarou, manda a pergunta errada para ele e queima a rodada seguinte.

Com `--anonimizar-fornecedor`, o `conteudo_da_linha` sai com o rótulo no lugar do nome
real, e não só a coluna `fornecedor`. A linha descartada na leitura é a exceção: ela não
tem coluna `fornecedor` legível, a troca não pode ser garantida dentro dela, e por isso o
conteúdo bruto dela vai para um arquivo fora do diretório e a coluna diz onde ele está.

### 4. `pedido-com-unidade-travada.md`

O texto do pedido para a próxima rodada, derivado do que travou nesta. Traz a unidade em que
cada item tem que ser respondido, as cinco regras de resposta, e a observação do que cada
fornecedor deixou em aberto desta vez.

É o arquivo que faz a rodada seguinte custar menos. Cada linha irresolvida desta rodada vira
uma exigência explícita da próxima, e a lista deixa de crescer.

### 5. `perguntas-aos-fornecedores.md`

Uma seção por fornecedor, com a pergunta pronta de cada linha que ficou fora do
comparativo: qual o conteúdo de um tambor, quanto vale uma caixa, se o preço é unitário ou
de lote, em que unidade a linha foi cotada. Sai junto com a nota, antes de qualquer
ordenação, e por isso já existe ao fim da rodada `--so-nota`.

Traz também três seções à parte: os itens do pedido que ninguém cotou, que se perguntam a
todos, os itens cotados fora do pedido, e as pendências da casa, que não se perguntam a
fornecedor nenhum.

É o arquivo que tira trabalho da mesa. Os outros quatro descrevem o problema, este é a
mensagem que o resolve.

**Este é o único arquivo do diretório que carrega nome de fornecedor quando a anonimização
está ligada, e isso é de propósito.** Mensagem endereçada a `Fornecedor A` obriga a abrir o
de-para e reidentificar linha a linha antes de mandar, e o de-para está fora do diretório
justamente para não circular. O arquivo avisa disso no próprio cabeçalho nas rodadas em
que leva algum nome, e a seção de cada fornecedor traz o rótulo entre parênteses para
cruzar com os outros arquivos. **Não inclua
este arquivo ao compartilhar a rodada:** tire-o do diretório antes de compactar.

### `<nome-da-rodada>-de-para-fornecedor.csv`, só com `--anonimizar-fornecedor`

O de-para entre `Fornecedor A` e o nome real. É gravado **ao lado** do diretório da rodada,
nunca dentro dele, porque compartilhar a rodada é compactar o diretório. Ele reidentifica
todos os fornecedores. O script diz no terminal onde ele ficou e que ele não se
compartilha.

### `<nome-da-rodada>-linhas-descartadas.csv`, só com `--anonimizar-fornecedor`

Sai só quando alguma linha foi descartada na leitura por contagem de coluna diferente do
cabeçalho. O conteúdo bruto dessas linhas fica aqui, fora do diretório, porque nelas a
coluna `fornecedor` não pôde ser lida e a troca pelo rótulo não teria garantia. Nenhum dado
se perde: a linha continua na `nao-comparaveis.csv`, com a causa e com o caminho deste
arquivo.

### O limite da troca, declarado

A troca pega o nome como está escrito e todo trecho de duas palavras ou mais dele, sem
acento e tratando hífen, ponto, barra e sublinhado como espaço, que é como o nome aparece
em nome de arquivo (`proposta-santa-rita.pdf` sai como `proposta-Fornecedor A.pdf`).
Apelido e sigla que não estejam no nome não são pegos: renomeie os arquivos de origem antes
de rodar. A nota declara esse limite na seção 11.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir das propostas dos fornecedores. Revisar antes de assinar.
Não substitui responsabilidade técnica.
```

---

## Modo de dado sensível

Preço de fornecedor identificado é uma das cinco classes, e é o conteúdo desta tarefa. Por
isso o modo sensível aqui é o caminho normal, não a exceção. Ofereça os três níveis antes de
pedir o arquivo. O padrão, quando a pessoa não decide, é o nível 2.

**Nível 1, só a estrutura.** A pessoa cola apenas o cabeçalho das propostas e duas ou três
linhas com os valores trocados por exemplos inventados que preservem o formato. Com isso dá
para escolher a unidade de referência, os pares de item e a linha de comando pronta. Nenhum
preço real é lido.

**Nível 2, script local com anonimização (padrão).** A pessoa roda o script na máquina dela,
com `--anonimizar-fornecedor`. Depois cola só a nota, que por construção não contém preço:
só nome de arquivo, tamanho, data, nome de item, nome de regra e contagem. Nome de arquivo
costuma identificar o fornecedor ou o projeto: sendo o caso, renomeie os arquivos antes de
rodar, ou apague a seção 1 da nota antes de colar. O modelo confere as decisões e o
fechamento e diz se a rodada é válida.

A nota não contém preço por construção, e isso é verdade quanto ao preço e não quanto à
identidade: sem `--anonimizar-fornecedor`, a seção 5 traz uma coluna Fornecedor com o nome
real e a seção 9 nomeia o fornecedor no alerta de quantidade mínima. Preço de fornecedor
identificado é a primeira classe que não sobe. Por isso a anonimização entra já na rodada
`--so-nota`.

Com a anonimização ligada, compactar o diretório é seguro depois de tirar dele o
`perguntas-aos-fornecedores.md`, que é o único arquivo que sai com o nome real. Os dois
arquivos que reidentificam, o de-para e o conteúdo das linhas descartadas, já nascem fora
do diretório.

**Nível 3, nada sai.** O modelo entrega a linha de comando e a explicação de como ler os
cinco arquivos. A pessoa responde apenas "fechou" ou "não fechou" e, não fechando, qual
identidade quebrou.

Regra que não se quebra: sendo o dado sensível, a leitura é local. Nunca peça o
`comparativo.csv` colado para resumir.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**Unidade de fator proibido sem declaração.** Saco, tambor, galão, bombona, barra e arroba
não têm valor de tabela. A linha sai do comparativo e a skill escreve a pergunta pronta para
o fornecedor. Preencher com o valor usual é fabricar dado, e o erro típico, 25 kg tratado
como 50 kg, é de 100% no preço unitário.

**Dimensões diferentes no mesmo item.** Chapa cotada em quilo por um e em peça por outro,
cabo em metro e em quilo. A conversão existe, exige espessura, massa específica ou massa
linear, e nada disso está na cotação. A skill separa e pede a cotação na unidade do pedido.

**Item similar no lugar do pedido.** Inox 304 respondido com inox 316, classe 8.8 respondida
com 4.8. Havendo `descricao` no `pedido.csv` e `descricao` na linha da proposta, o script
compara os termos com dígito de uma contra a outra (304, 316, 8.8, ISO68) e emite alerta
por item para cada termo do pedido que não aparece na proposta. Ele não decide equivalência
técnica: isso é engenharia, não compras.

O limite está declarado: proposta sem `descricao` não é conferida, e a nota diz quantas
linhas ficaram nessa situação. Pedido sem `descricao` não é conferido de jeito nenhum, e a
nota diz isso também.

**Designação nominal no lugar de medida.** Polegada de tubo, conexão, válvula e mangueira
é nome, não medida: tubo de 1 polegada não tem 25,4 mm. O script não converte polegada, e a
linha sai como `unidade ambigua` com a pergunta pronta. Converter designação nominal dentro
de um comparativo é exatamente o erro que a skill existe para impedir.

**PDF escaneado com tabela torta.** É extração, e extração sem medição contra gabarito não
serve de base para comparativo de preço: cada erro de leitura vira diferença de preço que
não existe. A skill `extracao-de-documento-para-tabela` faz a extração com confiança por
campo, e é ela que roda antes. Sem ela, a digitação é manual e o fato entra na nota.

**Rodada sem gabarito.** Não existindo nenhuma cotação já decidida para comparar, a skill
roda, entrega e marca a saída como não validada, com essa frase na resposta. Ela não deixa
de rodar, e também não finge que foi conferida.

---

## Referência

A pasta da skill fica em `~/.claude/skills/comparativo-de-cotacoes/` depois de instalada. Os
arquivos de referência são lidos por esse caminho, e os scripts são chamados pelo caminho
completo.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/comparativo-de-cotacoes/references/unidades.md` | Catálogo das armadilhas de unidade em cinco grupos, mais as três classes de fator (fixo, declarado, proibido) e a tabela de fator fixo. Cada item com manifestação, detecção, correção e o risco de corrigir errado. Leia antes de decidir regra por regra. |
| `~/.claude/skills/comparativo-de-cotacoes/scripts/comparar.py` | Implementação em Python de biblioteca padrão. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/comparativo-de-cotacoes/scripts/testar.py` | Teste de regressão do `comparar.py`, biblioteca padrão apenas. Cinquenta casos, um por defeito conhecido, e os piores têm caso próprio: nome real de fornecedor sobrevivendo dentro do diretório com a anonimização ligada, conferido por varredura do diretório inteiro e não de um arquivo só; polegada convertida como se fosse medida; coluna que mistura ponto e vírgula decimal; embalagem multiplicada escrita em português; embalagem de contagem multiplicando unidade de contagem; e item do pedido que ninguém cotou. Os outros cobrem a armadilha central de peça contra metro, milheiro contra peça, tambor e galão sem litragem, `ML` ambíguo, caixa sem conteúdo, escopo não declarado, escopo diferente do pedido, moeda diferente, primeira posição abaixo do limiar, confiança em branco, dimensão diferente da referência, alerta no código de saída, `--so-nota` e a limpeza do comparativo antigo, base de preço não declarada, referência derivada sem pedido, linha com coluna faltando, diretório existente, coluna obrigatória ausente, `--estrito`, de-para gravado fora do diretório, conteúdo da linha descartada fora do diretório, nome real só no arquivo de perguntas, item cotado fora do pedido, marca de validação do gabarito, status antes da gravação, fechamento relido do arquivo, divergência de descrição, vocabulário de causa igual nos dois arquivos, tamanho da `description`, `--alerta-fator` com vírgula, plural de unidade proibida, preço não positivo e duas linhas do mesmo fornecedor no mesmo grupo. Rode `python3 ~/.claude/skills/comparativo-de-cotacoes/scripts/testar.py` depois de qualquer mudança no script, ou `py -3 "$env:USERPROFILE\.claude\skills\comparativo-de-cotacoes\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
