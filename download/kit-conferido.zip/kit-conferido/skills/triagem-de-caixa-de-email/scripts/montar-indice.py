#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
montar-indice.py, escrita do indice triado.

Le o rastro do extrair.py (threads.csv, nao-lidos.csv, nota-de-leitura.md)
mais dois arquivos de julgamento escritos pelo modelo, e grava o entregavel:
indice-triado-<AAAA-MM-DD>.md e triagem-<AAAA-MM-DD>.csv.

O julgamento e do modelo. A ordenacao, a contagem, o formato, o fechamento e a
recusa sao deste script, porque e ai que a triagem manual perde linha.

    classes.csv    thread_id;classe;vence;o_que_e_pedido;motivo
    decisoes.csv   arquivo;decisao

O script RECUSA a rodada, sem gravar nada, quando:

  - falta thread_id de threads.csv em classes.csv, ou sobra id que nao existe;
  - a classe nao e uma das seis;
  - falta `o_que_e_pedido` em thread que exige acao;
  - falta `motivo` em `ruido` ou em `nao_classificada`;
  - `vence` nao esta em AAAA-MM-DD;
  - `respondida_por_outro` numa thread cujo rastro diz
    `colega_respondeu_anterior` diferente de `sim`;
  - alguma linha de nao-lidos.csv esta sem decisao registrada.

Nao existe modo de gravar o indice pulando uma thread. Rodada que nao leu tudo
nao vira arquivo: e a unica coisa que a skill promete.

O que o script nao recusa, ele marca. Prazo no rastro que nao virou prazo no
indice, prazo no indice sem marca no rastro, thread montada por assunto,
thread sem data, thread com anexo e corpo mudo: tudo isso entra no bloco de
conferencia do indice, nomeado thread a thread.

DEPENDENCIA DECLARADA: biblioteca padrao do Python 3.8 ou superior. Modulos:
argparse, csv, datetime, pathlib, re, sys. Sem rede, sem instalacao.

Codigos de saida: 0 indice gravado e validado, 2 indice gravado com
`validacao: nao validada` (nao serve para trabalho real), 3 recusa, nada
gravado.
"""

import argparse
import csv
import re
import sys
from datetime import datetime
from pathlib import Path

VERSAO = "1.0"

RODAPE = ("Gerado com apoio de IA a partir de e-mails salvos em pasta local. "
          "Revisar antes de assinar. N\u00e3o substitui responsabilidade "
          "t\u00e9cnica.")

RESSALVA = ("A caixa n\u00e3o sabe o que j\u00e1 foi resolvido por telefone "
            "ou por mensagem instant\u00e2nea. Confirme antes de cobrar.")

CLASSES = (
    "cobranca_com_prazo",
    "exige_resposta_sua",
    "respondida_por_outro",
    "so_ciencia",
    "ruido",
    "nao_classificada",
)

EXIGEM_PEDIDO = ("cobranca_com_prazo", "exige_resposta_sua",
                 "respondida_por_outro")
EXIGEM_MOTIVO = ("ruido", "nao_classificada")

BLOCOS = [
    ("1. Exige a\u00e7\u00e3o sua",
     ("cobranca_com_prazo", "exige_resposta_sua")),
    ("2. J\u00e1 respondido por outro na thread", ("respondida_por_outro",)),
    ("3. S\u00f3 ci\u00eancia", ("so_ciencia",)),
    ("4. Ru\u00eddo", ("ruido",)),
    ("5. N\u00e3o classificado", ("nao_classificada",)),
]

COLUNAS_INDICE = ["vence", "remetente", "assunto", "data", "o_que_e_pedido",
                  "classe", "thread", "arquivo"]

COLUNAS_CSV = ["bloco", "vence", "prazo_derivado", "remetente", "assunto",
               "data", "o_que_e_pedido", "classe", "motivo", "thread",
               "arquivo", "thread_id", "conferir"]

DATA = re.compile(r"^(\d{4}-\d{2}-\d{2})(\s*\(derivado de .+\))?$")
SEM_PRAZO = "sem prazo declarado"

FORMA_VALIDACAO = re.compile(
    r"^(nao validada|"
    r"\d{4}-\d{2}-\d{2},\s*\d+\s*threads comparadas,\s*"
    r"erro que importa\s*\d+)$", re.IGNORECASE)


# ---------------------------------------------------------------------------
# 1. Leitura
# ---------------------------------------------------------------------------

def ler_csv(caminho, obrigatorias, rotulo, recusas):
    if not caminho.is_file():
        recusas.append("%s nao encontrado: %s" % (rotulo, caminho))
        return []
    with caminho.open(encoding="utf-8-sig", newline="") as fh:
        linhas = list(csv.DictReader(fh, delimiter=";"))
    if not linhas:
        return []
    faltando = [c for c in obrigatorias if c not in linhas[0]]
    if faltando:
        recusas.append("%s sem as colunas %s. Separador esperado: ponto e "
                       "virgula." % (rotulo, ", ".join(faltando)))
        return []
    return [{k: (v or "").strip() for k, v in linha.items() if k} for linha in linhas]


def ler_bloco_da_rodada(caminho):
    """Le o bloco `chave: valor` de nota-de-leitura.md."""
    dados = {}
    if not caminho.is_file():
        return dados
    texto = caminho.read_text(encoding="utf-8")
    trecho = re.search(r"## Rodada\s*\n.*?```\n(.*?)```", texto, re.S)
    if not trecho:
        return dados
    for linha in trecho.group(1).splitlines():
        if ":" in linha:
            chave, valor = linha.split(":", 1)
            dados[chave.strip()] = valor.strip()
    return dados


# ---------------------------------------------------------------------------
# 2. Conferencia de entrada
# ---------------------------------------------------------------------------

def conferir_classes(threads, classes, recusas):
    ids_rastro = [t["thread_id"] for t in threads]
    por_id = {}
    for linha in classes:
        tid = linha.get("thread_id", "")
        if not tid:
            recusas.append("classes.csv tem linha sem thread_id.")
            continue
        if tid in por_id:
            recusas.append("classes.csv repete o thread_id %s." % tid)
            continue
        por_id[tid] = linha

    if not classes:
        recusas.append(
            "classes.csv esta vazio e threads.csv tem %d thread(s). Escreva "
            "uma linha por thread antes de montar o indice: "
            "thread_id;classe;vence;o_que_e_pedido;motivo."
            % len(ids_rastro))
        return {}

    faltando = [t for t in ids_rastro if t not in por_id]
    if faltando:
        recusas.append(
            "%d thread(s) de threads.csv sem linha em classes.csv: %s. Toda "
            "thread do rastro precisa de uma classe, nem que seja "
            "nao_classificada com o motivo da duvida. Indice que pula thread "
            "e a falha que esta skill existe para eliminar."
            % (len(faltando), ", ".join(faltando)))
    sobrando = [t for t in por_id if t not in ids_rastro]
    if sobrando:
        recusas.append(
            "classes.csv traz thread_id que nao existe em threads.csv: %s."
            % ", ".join(sobrando))

    for tid in ids_rastro:
        linha = por_id.get(tid)
        if linha is None:
            continue
        classe = linha.get("classe", "")
        if classe not in CLASSES:
            recusas.append("thread %s com classe %r. As seis sao: %s."
                           % (tid, classe, ", ".join(CLASSES)))
            continue
        if classe in EXIGEM_PEDIDO and not linha.get("o_que_e_pedido"):
            recusas.append("thread %s e %s e esta sem o_que_e_pedido. Uma "
                           "linha, no imperativo, com o verbo do pedido."
                           % (tid, classe))
        if classe in EXIGEM_MOTIVO and not linha.get("motivo"):
            recusas.append("thread %s e %s e esta sem motivo. Em ruido o "
                           "motivo e a evidencia positiva; em "
                           "nao_classificada e a duvida em uma linha."
                           % (tid, classe))
        vence = linha.get("vence", "")
        if vence and vence.lower() != SEM_PRAZO and not DATA.match(vence):
            recusas.append("thread %s com vence %r. Use AAAA-MM-DD, ou "
                           "AAAA-MM-DD (derivado de \"ate sexta\"), ou %s."
                           % (tid, vence, SEM_PRAZO))
    return por_id


def conferir_classe_tres(threads, por_id, recusas):
    for t in threads:
        linha = por_id.get(t["thread_id"])
        if not linha or linha.get("classe") != "respondida_por_outro":
            continue
        sinal = t.get("colega_respondeu_anterior", "")
        if sinal == "sim":
            continue
        recusas.append(
            "thread %s foi classificada como respondida_por_outro e o rastro "
            "diz colega_respondeu_anterior = %s. Colega so responde o que "
            "alguem perguntou antes: thread de mensagem unica, ou em que o "
            "colega apenas repete a propria mensagem, nao entra nesta classe. "
            "Sem --colegas declarado o sinal sai desconhecido e a classe nao "
            "pode ser afirmada." % (t["thread_id"], sinal or "vazio"))


def conferir_decisoes(nao_lidos, decisoes, recusas):
    por_arquivo = {}
    for linha in decisoes:
        arquivo = linha.get("arquivo", "")
        if arquivo:
            por_arquivo[arquivo] = linha.get("decisao", "")
    faltando = [l["arquivo"] for l in nao_lidos
                if not por_arquivo.get(l.get("arquivo", ""))]
    if faltando:
        recusas.append(
            "%d arquivo(s) de nao-lidos.csv sem decisao registrada: %s. Cada "
            "linha precisa de uma decisao por escrito em decisoes.csv: ou a "
            "mensagem e rebaixada com o motivo, ou ela volta em .eml e a "
            "rodada e refeita." % (len(faltando), ", ".join(faltando)))
    return por_arquivo


# ---------------------------------------------------------------------------
# 3. Ordem
# ---------------------------------------------------------------------------

def data_de_vencimento(vence):
    achado = DATA.match(vence or "")
    if not achado:
        return None, False
    return achado.group(1), bool(achado.group(2))


def chave_de_ordem(item, hoje):
    """Ordem do indice, conforme references/classificacao.md."""
    prioridade = 0 if item["classe"] == "cobranca_com_prazo" else 1
    if item["data_vence"]:
        if item["data_vence"] < hoje:
            return (0, item["data_vence"], prioridade, item["thread_id"])
        if item["data_vence"] == hoje:
            return (1, "", prioridade, item["thread_id"])
        return (2, item["data_vence"], prioridade, item["thread_id"])
    dias = item["dias"] if item["dias"] is not None else -1
    return (3, "%06d" % (999999 - dias), prioridade, item["thread_id"])


# ---------------------------------------------------------------------------
# 4. Montagem
# ---------------------------------------------------------------------------

def inteiro(bruto):
    try:
        return int(str(bruto).strip())
    except (TypeError, ValueError):
        return None


def montar_itens(threads, por_id, hoje):
    itens = []
    for t in threads:
        linha = por_id[t["thread_id"]]
        vence = linha.get("vence", "") or SEM_PRAZO
        data_vence, derivado = data_de_vencimento(vence)
        remetente = t.get("ultimo_remetente", "")
        email = t.get("ultimo_remetente_email", "")
        if email:
            remetente = ("%s <%s>" % (remetente, email)).strip()
        n = inteiro(t.get("n_mensagens")) or 1
        thread = "%d mensagem" % n if n == 1 else "%d mensagens" % n
        if t.get("metodo_da_thread") == "assunto":
            thread += ", juntada por assunto"
        itens.append({
            "thread_id": t["thread_id"],
            "classe": linha["classe"],
            "vence": vence if data_vence else SEM_PRAZO,
            "data_vence": data_vence,
            "derivado": derivado,
            "remetente": remetente or "sem remetente no cabecalho",
            "assunto": t.get("assunto") or t.get("assunto_normalizado") or "",
            "data": t.get("ultima_data") or "sem data no cabecalho",
            "o_que_e_pedido": linha.get("o_que_e_pedido", ""),
            "motivo": linha.get("motivo", ""),
            "thread": thread,
            "arquivo": t.get("arquivos", ""),
            "dias": inteiro(t.get("dias_desde_a_ultima")),
            "rastro": t,
        })
    itens.sort(key=lambda i: chave_de_ordem(i, hoje))
    return itens


def conferencias(itens, total):
    """O que o script nao recusa, ele nomeia. Nada sai em silencio."""
    avisos = []
    for i in itens:
        t = i["rastro"]
        if t.get("marcas_de_prazo") and not i["data_vence"]:
            avisos.append(
                "%s: o rastro achou marca de prazo (%s) e o indice saiu sem "
                "prazo. Abra a thread e confirme antes de aceitar a ordem."
                % (i["thread_id"], t["marcas_de_prazo"]))
        if i["data_vence"] and not t.get("marcas_de_prazo"):
            avisos.append(
                "%s: prazo %s no indice sem nenhuma marca de prazo no rastro. "
                "Diga de onde ele veio." % (i["thread_id"], i["vence"]))
        if i["derivado"]:
            avisos.append("%s: prazo derivado, nao escrito. %s"
                          % (i["thread_id"], i["vence"]))
        if t.get("metodo_da_thread") == "assunto":
            avisos.append(
                "%s: thread montada por assunto, nao por cabecalho de "
                "resposta. Confirme que e o mesmo caso." % i["thread_id"])
        if not t.get("ultima_data"):
            avisos.append(
                "%s: thread sem data no cabecalho. A posicao dela na ordem "
                "nao vale." % i["thread_id"])
        if t.get("respondi_depois_da_ultima_externa") == "indeterminado":
            avisos.append(
                "%s: falta data em alguma mensagem da thread, entao nao da "
                "para dizer se voce respondeu depois do ultimo pedido."
                % i["thread_id"])
        if (inteiro(t.get("n_anexos")) or 0) > 0 and \
                len(t.get("trecho_da_ultima", "")) < 40:
            avisos.append(
                "%s: tem anexo e o corpo quase nao diz nada. O pedido pode "
                "estar dentro do anexo, que esta skill nao abre."
                % i["thread_id"])
        if i["classe"] == "ruido" and not t.get("sinal_automatico") and \
                t.get("resposta_automatica") != "sim":
            avisos.append(
                "%s: foi para ruido sem nenhum sinal automatico no rastro. A "
                "evidencia positiva tem que estar escrita no motivo."
                % i["thread_id"])
    nao_classificadas = sum(1 for i in itens if i["classe"] == "nao_classificada")
    if total and nao_classificadas == 0:
        avisos.append(
            "Bloco nao classificado vazio. Em rodada de caixa real isso "
            "costuma ser sinal de que a triagem adivinhou em vez de "
            "classificar.")
    if total and nao_classificadas * 5 > total:
        avisos.append(
            "Bloco nao classificado com %d de %d threads, acima de um quinto. "
            "Quase sempre falta declaracao do passo 3, e quase sempre e a "
            "lista de colegas." % (nao_classificadas, total))
    return avisos


def celula(texto):
    return (texto or "").replace("|", "\\|").replace("\n", " ").strip() or "-"


def escrever_indice(caminho, itens, rodada, nao_lidos, decisoes, avisos,
                    validacao, data_indice):
    total = len(itens)
    contagem = dict((c, 0) for c in CLASSES)
    for i in itens:
        contagem[i["classe"]] += 1

    L = []
    L.append("# \u00cdndice triado da caixa de e-mail, %s" % data_indice)
    L.append("")
    L.append("| Campo | Valor |")
    L.append("|---|---|")
    L.append("| pasta lida | `%s` |" % celula(rodada.get("pasta", "nao declarada")))
    desde = rodada.get("desde", "sem limite")
    ate = rodada.get("ate", "sem limite")
    if desde == "sem limite" and ate == "sem limite":
        periodo = "toda a pasta, sem recorte de data"
    else:
        periodo = "%s a %s" % (desde, ate)
    L.append("| per\u00edodo | %s |" % celula(periodo))
    L.append("| fuso usado para datar | %s |" % celula(rodada.get("fuso", "nao declarado")))
    L.append("| endere\u00e7os declarados como seus | %s |"
             % celula(rodada.get("meus_enderecos", "nao declarado")))
    L.append("| endere\u00e7os ou dom\u00ednios de colegas | %s |"
             % celula(rodada.get("colegas", "nao declarado")))
    L.append("| corpo lido | %s |"
             % ("n\u00e3o, rodada com --sem-corpo"
                if rodada.get("sem_corpo") == "sim" else "sim"))
    L.append("| valida\u00e7\u00e3o | %s |" % celula(validacao))
    for classe in CLASSES:
        L.append("| %s | %d |" % (classe, contagem[classe]))
    L.append("| total de threads | %d |" % total)
    L.append("")
    if validacao.lower().startswith("nao validada"):
        L.append("> Esta rodada **n\u00e3o foi validada contra os Enviados**. "
                 "Ela n\u00e3o serve para trabalho real: use como rascunho e "
                 "fa\u00e7a o teste do gabarito antes de confiar na ordem.")
        L.append("")
    if rodada.get("sem_corpo") == "sim":
        L.append("> Rodada com `--sem-corpo`. A marca de prazo s\u00f3 pode "
                 "vir do assunto, e prazo escrito no corpo n\u00e3o aparece "
                 "aqui. A ordem vale menos, e cada cobran\u00e7a precisa ser "
                 "aberta no cliente de e-mail antes de ser atendida.")
        L.append("")
    L.append(RESSALVA)
    L.append("")

    for titulo, classes in BLOCOS:
        do_bloco = [i for i in itens if i["classe"] in classes]
        L.append("## %s" % titulo)
        L.append("")
        if not do_bloco:
            L.append("Nenhuma thread.")
            L.append("")
            continue
        L.append("| " + " | ".join(COLUNAS_INDICE) + " |")
        L.append("|" + "---|" * len(COLUNAS_INDICE))
        for i in do_bloco:
            pedido = i["o_que_e_pedido"] or i["motivo"]
            L.append("| " + " | ".join([
                celula(i["vence"]), celula(i["remetente"]),
                celula(i["assunto"]), celula(i["data"]),
                celula(pedido), celula(i["classe"]),
                celula(i["thread"]), celula(i["arquivo"]),
            ]) + " |")
        L.append("")

    L.append("## Fechamento")
    L.append("")
    L.append("```")
    L.append("%-44s %6s = %-6s %s" % ("itens_no_indice = threads no rastro",
                                      total, rodada.get("threads", "?"),
                                      "fecha" if str(total) == str(rodada.get("threads"))
                                      else "NAO FECHA"))
    L.append("%-44s %6s = %-6s %s" % ("threads = soma das seis classes", total,
                                      sum(contagem.values()), "fecha"))
    L.append("%-44s %6s" % ("arquivos_vistos", rodada.get("arquivos_vistos", "?")))
    L.append("%-44s %6s" % ("eml lidos e no csv", rodada.get("mensagens_no_csv", "?")))
    L.append("%-44s %6s" % ("fora do recorte de data", rodada.get("fora_do_recorte", "?")))
    L.append("%-44s %6s" % ("nao lidos, com decisao registrada", len(nao_lidos)))
    # So aparecem quando houve. Rastro de versao antiga do extrair.py nao traz
    # as duas chaves, e nesse caso a linha nao e inventada.
    for rotulo, chave in (("em subpasta, rodada sem --recursivo", "em_subpasta"),
                          ("fora do alcance da leitura", "fora_de_alcance")):
        valor = str(rodada.get(chave, "0")).strip()
        if valor not in ("0", "", "?"):
            L.append("%-44s %6s" % (rotulo, valor))
    L.append("%-44s %6s" % ("arquivos de sistema ignorados", rodada.get("ignorados", "?")))
    L.append("```")
    L.append("")

    L.append("## O que precisa de olho humano")
    L.append("")
    if avisos:
        for aviso in avisos:
            L.append("- %s" % aviso)
    else:
        L.append("- Nenhuma marca\u00e7\u00e3o. Confira mesmo assim as "
                 "threads sem prazo.")
    L.append("")

    L.append("## Arquivos n\u00e3o lidos e a decis\u00e3o de cada um")
    L.append("")
    if not nao_lidos:
        L.append("Nenhum. Todo arquivo da pasta virou mensagem no \u00edndice.")
    else:
        L.append("| arquivo | motivo | decis\u00e3o |")
        L.append("|---|---|---|")
        for linha in nao_lidos:
            L.append("| %s | %s | %s |" % (
                celula(linha.get("arquivo", "")),
                celula(linha.get("motivo", "")),
                celula(decisoes.get(linha.get("arquivo", ""), ""))))
    L.append("")
    L.append(RODAPE)
    L.append("")
    caminho.write_text("\n".join(L), encoding="utf-8")


def escrever_csv_indice(caminho, itens, avisos):
    por_thread = {}
    for aviso in avisos:
        if ":" in aviso:
            tid = aviso.split(":", 1)[0].strip()
            por_thread.setdefault(tid, []).append(aviso.split(":", 1)[1].strip())
    nome_do_bloco = {}
    for titulo, classes in BLOCOS:
        for classe in classes:
            nome_do_bloco[classe] = titulo
    with caminho.open("w", encoding="utf-8-sig", newline="") as fh:
        escritor = csv.writer(fh, delimiter=";", quoting=csv.QUOTE_MINIMAL,
                              lineterminator="\n")
        escritor.writerow(COLUNAS_CSV)
        for i in itens:
            escritor.writerow([
                nome_do_bloco[i["classe"]], i["vence"],
                "sim" if i["derivado"] else "nao",
                i["remetente"], i["assunto"], i["data"], i["o_que_e_pedido"],
                i["classe"], i["motivo"], i["thread"], i["arquivo"],
                i["thread_id"], " | ".join(por_thread.get(i["thread_id"], [])),
            ])


# ---------------------------------------------------------------------------
# 5. Principal
# ---------------------------------------------------------------------------

def montar_argumentos():
    p = argparse.ArgumentParser(
        description="Le o rastro do extrair.py mais a classificacao e grava o "
                    "indice triado. Recusa a rodada que deixou thread de "
                    "fora.")
    p.add_argument("--rastro", required=True,
                   help="Diretorio de --saida do extrair.py.")
    p.add_argument("--classes", required=True,
                   help="CSV com thread_id;classe;vence;o_que_e_pedido;motivo.")
    p.add_argument("--decisoes", default="",
                   help="CSV com arquivo;decisao. Obrigatorio quando "
                        "nao-lidos.csv tem linha.")
    p.add_argument("--saida", default=".",
                   help="Diretorio de trabalho onde o indice e gravado. "
                        "Padrao: o diretorio atual.")
    p.add_argument("--data", default="",
                   help="Data AAAA-MM-DD do indice. Padrao: hoje.")
    p.add_argument("--validacao", required=True,
                   help="'AAAA-MM-DD, N threads comparadas, erro que importa "
                        "N' do teste do gabarito, ou 'nao validada'.")
    return p


def main(argv=None):
    args = montar_argumentos().parse_args(argv)
    recusas = []

    validacao = " ".join((args.validacao or "").split())
    if not FORMA_VALIDACAO.match(validacao):
        recusas.append(
            "--validacao %r fora da forma. Use 'AAAA-MM-DD, N threads "
            "comparadas, erro que importa N', ou 'nao validada' quando o "
            "teste do gabarito ainda nao foi feito." % args.validacao)

    rastro = Path(args.rastro).expanduser()
    if not rastro.is_dir():
        recusas.append("diretorio de rastro nao encontrado: %s" % rastro)
        threads, nao_lidos, rodada = [], [], {}
    else:
        threads = ler_csv(rastro / "threads.csv",
                          ["thread_id", "assunto", "ultima_data"],
                          "threads.csv", recusas)
        nao_lidos = ler_csv(rastro / "nao-lidos.csv", ["arquivo", "motivo"],
                            "nao-lidos.csv", recusas)
        rodada = ler_bloco_da_rodada(rastro / "nota-de-leitura.md")
        if not rodada:
            recusas.append(
                "nota-de-leitura.md sem o bloco `## Rodada`. O rastro veio de "
                "uma versao antiga do extrair.py: rode a extracao de novo.")

    classes = ler_csv(Path(args.classes).expanduser(),
                      ["thread_id", "classe"], "classes.csv", recusas)

    decisoes = []
    if args.decisoes:
        decisoes = ler_csv(Path(args.decisoes).expanduser(),
                           ["arquivo", "decisao"], "decisoes.csv", recusas)
    elif nao_lidos:
        recusas.append(
            "nao-lidos.csv tem %d linha(s) e --decisoes nao foi passado. "
            "Rodada nao fecha com arquivo sem decisao." % len(nao_lidos))

    if not threads and not recusas:
        recusas.append("threads.csv nao tem nenhuma thread. Nao ha indice a "
                       "montar: veja o codigo de saida do extrair.py.")

    por_id = {}
    if threads:
        por_id = conferir_classes(threads, classes, recusas)
        if por_id:
            conferir_classe_tres(threads, por_id, recusas)
        # Rastro misturado: threads.csv de uma rodada e nota de outra. Sem
        # esta conferencia o indice sai fechando contra o numero errado.
        do_rastro = rodada.get("threads")
        if do_rastro is not None and str(do_rastro) != str(len(threads)):
            recusas.append(
                "threads.csv tem %d thread(s) e nota-de-leitura.md declara "
                "%s. Os dois arquivos sao de rodadas diferentes: aponte "
                "--rastro para um diretorio de uma rodada so."
                % (len(threads), do_rastro))
    mapa_decisoes = conferir_decisoes(nao_lidos, decisoes, recusas)

    if recusas:
        sys.stderr.write("RECUSA: o indice nao foi gravado.\n")
        for r in recusas:
            sys.stderr.write("  - %s\n" % r)
        sys.stderr.write(
            "\nNada foi escrito em disco. Corrija e rode de novo: indice "
            "incompleto e pior do que indice nenhum, porque parece completo.\n")
        return 3

    data_indice = args.data.strip() or datetime.now().strftime("%Y-%m-%d")
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", data_indice):
        sys.stderr.write("RECUSA: --data espera AAAA-MM-DD, recebeu %r.\n"
                         % args.data)
        return 3

    itens = montar_itens(threads, por_id, data_indice)
    avisos = conferencias(itens, len(itens))

    saida = Path(args.saida).expanduser()
    saida.mkdir(parents=True, exist_ok=True)
    caminho_md = saida / ("indice-triado-%s.md" % data_indice)
    caminho_csv = saida / ("triagem-%s.csv" % data_indice)
    escrever_indice(caminho_md, itens, rodada, nao_lidos, mapa_decisoes,
                    avisos, validacao, data_indice)
    escrever_csv_indice(caminho_csv, itens, avisos)

    contagem = dict((c, 0) for c in CLASSES)
    for i in itens:
        contagem[i["classe"]] += 1
    print("Indice gravado: %d threads, todas classificadas." % len(itens))
    for classe in CLASSES:
        print("  %-22s %d" % (classe, contagem[classe]))
    print("")
    print("Marcado para olho humano: %d ponto(s)." % len(avisos))
    print("")
    print(str(caminho_md))
    print(str(caminho_csv))

    if validacao.lower().startswith("nao validada"):
        sys.stderr.write(
            "AVISO: indice gravado com 'validacao: nao validada'. Ele nao "
            "serve para trabalho real ate o teste do gabarito passar tres "
            "vezes com erro que importa igual a zero.\n")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
