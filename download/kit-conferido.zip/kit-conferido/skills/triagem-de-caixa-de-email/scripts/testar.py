#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do extrair.py e do montar-indice.py.

Gera uma pasta de arquivos .eml de mentira num diretorio temporario, roda os
dois scripts sobre ela e compara a saida com o esperado. Biblioteca padrao
apenas. Sai com codigo 0 se todos os casos passam, 1 se algum falha.

Cada caso e nomeado pelo defeito que prova, nao pelo tema. Suite que devolve o
mesmo resultado com e sem o defeito nao certifica nada.

Defeitos ja corrigidos que esta suite mantem mortos:

  - mensagem das 22h30 sumindo do recorte do proprio dia por conversao para UTC;
  - linha de citacao do Gmail em portugues nao cortada, fabricando o prazo da
    mensagem antiga como se fosse pedido novo;
  - thread `NC 4412` rachando em duas linhas por o assunto ter menos de oito
    caracteres;
  - colega de mensagem unica saindo como quem respondeu por voce;
  - `eu_ja_respondi` dizendo sim quando fui eu que abri a thread;
  - `.DS_Store` derrubando toda rodada para o codigo 1;
  - pasta so com .msg saindo com mensagem de recorte de data;
  - corpo em HTML do Gmail entrando inteiro no trecho, porque o corte de
    citacao trabalha linha a linha e o <div> de cada paragrafo nao virava
    quebra de linha;
  - arquivos de mesmo nome em subpastas fundidos numa thread so;
  - mensagem em subpasta sumindo sem linha na rodada sem --recursivo, com as
    seis identidades fechando e codigo 0. O caso roda de proposito SEM a
    opcao: a suite so exercitava o caminho com ela, e o defeito passava;
  - link simbolico para pasta, link quebrado e pasta sem permissao saindo da
    rodada sem linha em nao-lidos.csv;
  - rodape gravado como linha de dados dentro do CSV;
  - indice gravado com thread faltando ou com arquivo nao lido sem decisao.

Uso:
    python3 ~/.claude/skills/triagem-de-caixa-de-email/scripts/testar.py
"""

import csv
import os
import shutil
import subprocess
import sys
import tempfile
import time
from email.utils import parsedate_to_datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
EXTRAIR = AQUI / "extrair.py"
INDICE = AQUI / "montar-indice.py"
SKILL = AQUI.parent
SKILLS = SKILL.parent

MEU = "joao.silva@empresa.com.br"
COLEGA = "maria.souza@empresa.com.br"

# Fuso fixo para o pai e para o subprocesso, para que a conversao de data seja
# a mesma nos dois. Em Windows o TZ e ignorado pelos dois igualmente, e as
# asserções abaixo continuam valendo porque comparam contra o valor calculado
# aqui, nunca contra uma hora escrita na mao.
os.environ["TZ"] = "America/Sao_Paulo"
if hasattr(time, "tzset"):
    time.tzset()
AMBIENTE = dict(os.environ)

CAB_NOITE = "Fri, 18 Sep 2026 22:30:00 -0300"

falhas = []
passou = []


def local(cabecalho):
    """Mesma conversao do extrair.py: fuso da maquina, sem tzinfo."""
    return parsedate_to_datetime(cabecalho).astimezone().replace(tzinfo=None)


def conferir(rotulo, obtido, esperado):
    if obtido == esperado:
        passou.append(rotulo)
    else:
        falhas.append("%s\n    esperado: %r\n    obtido:   %r"
                      % (rotulo, esperado, obtido))


def conferir_contem(rotulo, texto, pedaco):
    if pedaco.lower() in (texto or "").lower():
        passou.append(rotulo)
    else:
        falhas.append("%s\n    esperava encontrar %r em %r"
                      % (rotulo, pedaco, (texto or "")[:200]))


def conferir_nao_contem(rotulo, texto, pedaco):
    if pedaco.lower() not in (texto or "").lower():
        passou.append(rotulo)
    else:
        falhas.append("%s\n    nao esperava %r em %r"
                      % (rotulo, pedaco, (texto or "")[:200]))


# ---------------------------------------------------------------------------
# Mensagens de mentira
# ---------------------------------------------------------------------------

def eml(cabecalhos, corpo=""):
    linhas = ["%s: %s" % (k, v) for k, v in cabecalhos]
    return ("\r\n".join(linhas) + "\r\n\r\n" + corpo).encode("utf-8")


def montar_pasta(destino):
    destino.mkdir(parents=True, exist_ok=True)
    arquivos = {}

    # Thread montada por cabecalho: fornecedor, eu, colega.
    arquivos["t1a.eml"] = eml([
        ("From", "Carlos Lima <carlos@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Nao conformidade 4412 na linha 3"),
        ("Date", "Fri, 18 Sep 2026 08:00:00 -0300"),
        ("Message-ID", "<t1a@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "A peca chegou fora de especificacao. Aguardo posicao.")

    arquivos["t1b.eml"] = eml([
        ("From", "Joao Silva <%s>" % MEU),
        ("To", "carlos@fornecedor.com.br"),
        ("Subject", "Re: Nao conformidade 4412 na linha 3"),
        ("Date", "Fri, 18 Sep 2026 09:00:00 -0300"),
        ("Message-ID", "<t1b@empresa.com.br>"),
        ("In-Reply-To", "<t1a@fornecedor.com.br>"),
        ("References", "<t1a@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Vou verificar com a qualidade.")

    arquivos["t1c.eml"] = eml([
        ("From", "Maria Souza <%s>" % COLEGA),
        ("To", "carlos@fornecedor.com.br"),
        ("Cc", MEU),
        ("Subject", "Re: Nao conformidade 4412 na linha 3"),
        ("Date", "Fri, 18 Sep 2026 10:00:00 -0300"),
        ("Message-ID", "<t1c@empresa.com.br>"),
        ("In-Reply-To", "<t1b@empresa.com.br>"),
        ("References", "<t1a@fornecedor.com.br> <t1b@empresa.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Ja abri o registro e respondo o laudo ainda hoje.")

    # Thread montada por assunto: a resposta perdeu o cabecalho de referencia.
    arquivos["t2a.eml"] = eml([
        ("From", "Ana Reis <ana@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Cotacao de valvula de duas polegadas"),
        ("Date", "Fri, 18 Sep 2026 08:30:00 -0300"),
        ("Message-ID", "<t2a@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Segue a cotacao solicitada.")

    arquivos["t2b.eml"] = eml([
        ("From", "Ana Reis <ana@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Res: Cotacao de valvula de duas polegadas"),
        ("Date", "Fri, 18 Sep 2026 11:30:00 -0300"),
        ("Message-ID", "<t2b@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Corrigindo o prazo de entrega da cotacao anterior.")

    # Assunto generico: nao pode juntar thread.
    arquivos["g1.eml"] = eml([
        ("From", "Pedro Alves <pedro@outrofornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Pedido"),
        ("Date", "Fri, 18 Sep 2026 12:00:00 -0300"),
        ("Message-ID", "<g1@outro.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Confirma o pedido?")

    arquivos["g2.eml"] = eml([
        ("From", "Lucia Prado <lucia@terceiro.com.br>"),
        ("To", MEU),
        ("Subject", "Pedido"),
        ("Date", "Fri, 18 Sep 2026 12:05:00 -0300"),
        ("Message-ID", "<g2@terceiro.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Outro pedido, sem relacao com o anterior.")

    # Assunto curto com identificador: TEM que juntar. O nome padrao de
    # assunto no chao de fabrica e codigo mais numero, com menos de oito
    # caracteres, e a reiteracao estava rachando em duas linhas do indice.
    arquivos["nc1.eml"] = eml([
        ("From", "Ivo Castro <ivo@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "NC 4412"),
        ("Date", "Fri, 18 Sep 2026 07:30:00 -0300"),
        ("Message-ID", "<nc1@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Abri a nao conformidade do lote.")

    arquivos["nc2.eml"] = eml([
        ("From", "Ivo Castro <ivo@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Re: NC 4412"),
        ("Date", "Fri, 18 Sep 2026 14:20:00 -0300"),
        ("Message-ID", "<nc2@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Sem retorno ate agora.")

    # Mensagem de lista.
    arquivos["lista.eml"] = eml([
        ("From", "Boletim Tecnico <news@portal.com.br>"),
        ("To", MEU),
        ("Subject", "Boletim semanal de normas tecnicas"),
        ("Date", "Fri, 18 Sep 2026 06:00:00 -0300"),
        ("Message-ID", "<lista@portal.com.br>"),
        ("List-Unsubscribe", "<https://portal.com.br/sair>"),
        ("Precedence", "bulk"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Os destaques da semana.")

    # Resposta automatica de ausencia.
    arquivos["ausencia.eml"] = eml([
        ("From", "Rita Gomes <rita@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Resposta automatica: ausencia temporaria do escritorio"),
        ("Date", "Fri, 18 Sep 2026 07:10:00 -0300"),
        ("Message-ID", "<aus@fornecedor.com.br>"),
        ("Auto-Submitted", "auto-replied"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Estou fora ate segunda.")

    # Marca de prazo no assunto e no corpo.
    arquivos["prazo.eml"] = eml([
        ("From", "Auditoria <auditoria@certificadora.com.br>"),
        ("To", MEU),
        ("Subject", "Envio do relatorio de inspecao ate 25/09"),
        ("Date", "Thu, 10 Sep 2026 14:00:00 -0300"),
        ("Message-ID", "<prazo@cert.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "O prazo e impreterivel.")

    # Eu apareco so em copia.
    arquivos["copia.eml"] = eml([
        ("From", "Setor de Compras <compras@empresa.com.br>"),
        ("To", "outra.pessoa@empresa.com.br"),
        ("Cc", MEU),
        ("Subject", "Alteracao do calendario de recebimento"),
        ("Date", "Fri, 18 Sep 2026 13:00:00 -0300"),
        ("Message-ID", "<copia@empresa.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Para conhecimento de todos.")

    # Mensagem enviada por mim, sozinha.
    arquivos["demim.eml"] = eml([
        ("From", "Joao Silva <%s>" % MEU),
        ("To", "carlos@fornecedor.com.br"),
        ("Subject", "Solicitacao de desenho atualizado do flange"),
        ("Date", "Fri, 18 Sep 2026 15:00:00 -0300"),
        ("Message-ID", "<demim@empresa.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Preciso do desenho revisado.")

    # Eu abri a thread e o outro lado respondeu com pergunta nova. Ter
    # mensagem minha na thread nao quer dizer que o pedido foi atendido.
    arquivos["abri1.eml"] = eml([
        ("From", "Joao Silva <%s>" % MEU),
        ("To", "helena@fornecedor.com.br"),
        ("Subject", "Revisao do cronograma de montagem"),
        ("Date", "Fri, 18 Sep 2026 10:30:00 -0300"),
        ("Message-ID", "<abri1@empresa.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Segue o cronograma para sua avaliacao.")

    arquivos["abri2.eml"] = eml([
        ("From", "Helena Muniz <helena@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Re: Revisao do cronograma de montagem"),
        ("Date", "Fri, 18 Sep 2026 11:00:00 -0300"),
        ("Message-ID", "<abri2@fornecedor.com.br>"),
        ("In-Reply-To", "<abri1@empresa.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Quem assina a liberacao do vao 4?")

    # Colega, mensagem unica, encaminhando pedido de cliente. Nao e resposta
    # de ninguem: nao pode entrar em respondida_por_outro.
    arquivos["interno.eml"] = eml([
        ("From", "Maria Souza <%s>" % COLEGA),
        ("To", MEU),
        ("Subject", "ENC: pedido do cliente Zeta"),
        ("Date", "Fri, 18 Sep 2026 09:40:00 -0300"),
        ("Message-ID", "<interno@empresa.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Joao, confirma a data de entrega com o cliente.")

    # Mensagem depois das 21h no fuso local. Convertida para UTC ela virava o
    # dia seguinte e sumia do recorte de um dia so.
    arquivos["noite.eml"] = eml([
        ("From", "Expedicao <expedicao@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Liberacao do lote 9931 para expedicao"),
        ("Date", CAB_NOITE),
        ("Message-ID", "<noite@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Preciso da sua liberacao do lote 9931.")

    # Corpo em HTML.
    arquivos["html.eml"] = eml([
        ("From", "Sistema PCP <pcp@empresa.com.br>"),
        ("To", MEU),
        ("Subject", "Lista de material da ordem 7712"),
        ("Date", "Fri, 18 Sep 2026 16:00:00 -0300"),
        ("Message-ID", "<html@empresa.com.br>"),
        ("Content-Type", "text/html; charset=utf-8"),
    ], "<html><body><p>Segue a <b>lista de material</b> revisada.</p>"
       "</body></html>")

    # Corpo em iso-8859-1 com acento.
    arquivos["latin.eml"] = (
        b"From: Tiago Reis <tiago@fornecedor.com.br>\r\n"
        b"To: " + MEU.encode("ascii") + b"\r\n"
        b"Subject: =?ISO-8859-1?Q?Agendamento_da_parada?=\r\n"
        b"Date: Fri, 18 Sep 2026 17:00:00 -0300\r\n"
        b"Message-ID: <latin@fornecedor.com.br>\r\n"
        b"Content-Type: text/plain; charset=iso-8859-1\r\n"
        b"Content-Transfer-Encoding: quoted-printable\r\n\r\n"
        b"Precisamos agendar a manuten=E7=E3o do compressor.\r\n"
    )

    # Citacao curta, no formato do Outlook.
    arquivos["citacao.eml"] = eml([
        ("From", "Bruno Dias <bruno@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Fechamento da ordem 8821"),
        ("Date", "Fri, 18 Sep 2026 18:00:00 -0300"),
        ("Message-ID", "<cit@fornecedor.com.br>"),
        ("Content-Type", "text/plain; charset=utf-8"),
    ], "Podemos fechar assim?\r\n\r\n"
       "Em 17/09/2026, Joao Silva escreveu:\r\n"
       "> texto antigo que nao deve entrar no trecho\r\n")

    # Citacao do Gmail em portugues, com endereco na linha de atribuicao: 85
    # caracteres de miolo. O corte antigo parava em 60 e deixava o historico
    # inteiro entrar, com o prazo da mensagem velha virando prazo novo.
    arquivos["citacao-gmail.eml"] = eml([
        ("From", "Nilo Braga <nilo@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Re: Desenho do flange revisado"),
        ("Date", "Fri, 18 Sep 2026 19:00:00 -0300"),
        ("Message-ID", "<citg@fornecedor.com.br>"),
        ("Content-Type", "text/html; charset=utf-8"),
    ], "<div>Consegue confirmar hoje?</div>"
       "<div>Em sex., 11 de set. de 2026 as 10:02, Joao Pereira "
       "&lt;j.pereira@engenhariadoval.com.br&gt; escreveu:</div>"
       "<div>Segue o desenho aprovado, prazo 30/09.</div>")

    # Citacao do Gmail em HTML, com o historico dentro de <blockquote>. Sem
    # quebrar linha nas tags de bloco, o corpo inteiro virava uma linha so e
    # o corte de citacao, que le linha a linha, nunca disparava.
    arquivos["gmail-blockquote.eml"] = eml([
        ("From", "Rosa Lima <rosa@fornecedor.com.br>"),
        ("To", MEU),
        ("Subject", "Re: Inspecao do vaso de pressao"),
        ("Date", "Fri, 18 Sep 2026 20:00:00 -0300"),
        ("Message-ID", "<gblock@fornecedor.com.br>"),
        ("Content-Type", "text/html; charset=utf-8"),
    ], '<div dir="ltr">Pode liberar a inspecao amanha?</div>'
       '<div class="gmail_quote">'
       '<div dir="ltr">Em qui., 10 de set. de 2026 as 08:15, Rosa Lima '
       '&lt;rosa.lima@fornecedorindustrial.com.br&gt; escreveu:</div>'
       '<blockquote class="gmail_quote"><div>Precisamos do laudo ate 12/09, '
       'prazo improrrogavel.</div></blockquote></div>')

    # Arquivo .eml vazio: nada para triar.
    arquivos["vazio.eml"] = b""

    for nome, conteudo in arquivos.items():
        (destino / nome).write_bytes(conteudo)

    # Arquivo arrastado do Outlook de computador.
    (destino / "arrastado.msg").write_bytes(b"\xd0\xcf\x11\xe0" + b"\x00" * 60)
    # Arquivo que o Finder cria sozinho. Nao e mensagem perdida.
    (destino / ".DS_Store").write_bytes(b"\x00\x00\x00\x01Bud1")

    return {"eml": len(arquivos), "vistos": len(arquivos) + 2, "ignorados": 1}


# ---------------------------------------------------------------------------
# Execucao
# ---------------------------------------------------------------------------

def rodar(argumentos, script=None):
    return subprocess.run([sys.executable, str(script or EXTRAIR)]
                          + argumentos, capture_output=True, text=True,
                          env=AMBIENTE)


def ler_csv(caminho):
    with caminho.open(encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh, delimiter=";"))


def ler_texto_ou_vazio(caminho):
    try:
        return caminho.read_text(encoding="utf-8")
    except OSError:
        falhas.append("arquivo esperado nao foi gerado: %s" % caminho)
        return ""


def ler_csv_ou_vazio(caminho):
    try:
        return ler_csv(caminho)
    except OSError:
        falhas.append("arquivo esperado nao foi gerado: %s" % caminho)
        return []


def por_chave(linhas, campo, valor):
    for linha in linhas:
        if linha.get(campo) == valor:
            return linha
    return {}


def escrever(caminho, texto):
    caminho.write_text(texto, encoding="utf-8")


def classes_de(threads, ajustes=None):
    """Uma linha por thread, tudo em nao_classificada, com os ajustes por id."""
    ajustes = ajustes or {}
    linhas = ["thread_id;classe;vence;o_que_e_pedido;motivo"]
    for t in threads:
        tid = t["thread_id"]
        padrao = ("nao_classificada", "", "", "conferir na caixa")
        classe, vence, pedido, motivo = ajustes.get(tid, padrao)
        linhas.append(";".join([tid, classe, vence, pedido, motivo]))
    return "\n".join(linhas) + "\n"


# ---------------------------------------------------------------------------
# Principal
# ---------------------------------------------------------------------------

def main():
    base = Path(tempfile.mkdtemp(prefix="teste-triagem-"))
    try:
        pasta = base / "emails"
        conta = montar_pasta(pasta)
        saida = base / "rastro"

        r = rodar(["--pasta", str(pasta), "--saida", str(saida),
                   "--meus-enderecos", MEU, "--colegas", COLEGA,
                   "--hoje", "2026-09-20"])

        conferir("codigo de saida 1 quando sobra arquivo nao lido",
                 r.returncode, 1)
        conferir_nao_contem("nenhuma identidade quebrada", r.stdout,
                            "NAO FECHA")

        mensagens = ler_csv(saida / "mensagens.csv")
        threads = ler_csv(saida / "threads.csv")
        nao_lidos = ler_csv(saida / "nao-lidos.csv")
        nota = (saida / "nota-de-leitura.md").read_text(encoding="utf-8")

        conferir("23 mensagens lidas", len(mensagens), 23)
        conferir("18 threads", len(threads), 18)
        conferir("2 arquivos nao lidos", len(nao_lidos), 2)
        conferir("nota fecha", "status: completo" in nota, True)

        # -------------------------------------------------------------
        # Defeito: rodape gravado como linha de dados dentro do CSV.
        # -------------------------------------------------------------
        for nome in ("mensagens.csv", "threads.csv", "nao-lidos.csv"):
            bruto = (saida / nome).read_text(encoding="utf-8-sig")
            conferir_nao_contem("%s sem rodape como linha de dados" % nome,
                                bruto, "# Gerado com apoio de IA")
        conferir_contem("rodape fica na nota de leitura", nota,
                        "Gerado com apoio de IA")

        # -------------------------------------------------------------
        # Defeito: .DS_Store derrubando a rodada para nao lido.
        # -------------------------------------------------------------
        nomes_nao_lidos = [l["arquivo"] for l in nao_lidos]
        conferir("arquivo de sistema nao entra em nao-lidos.csv",
                 ".DS_Store" in nomes_nao_lidos, False)
        conferir_contem("ignorados declarados na nota", nota, "ignorados: 1")
        conferir_contem("arquivos_vistos conta o ignorado", nota,
                        "arquivos_vistos: %d" % conta["vistos"])
        conferir_contem("identidade de arquivos inclui ignorados", r.stdout,
                        "arquivos_vistos = eml + outros + subpasta + fora "
                        "+ ignorados")

        # -------------------------------------------------------------
        # Defeito: data convertida para UTC.
        # -------------------------------------------------------------
        m_noite = por_chave(mensagens, "arquivo", "noite.eml")
        conferir("data da mensagem das 22h30 e a hora local do cabecalho",
                 m_noite.get("data_iso"),
                 local(CAB_NOITE).strftime("%Y-%m-%d %H:%M"))
        conferir_contem("fuso declarado na nota", nota, "fuso: ")

        dia_noite = local(CAB_NOITE).strftime("%Y-%m-%d")
        saida_dia = base / "rastro-um-dia"
        r_dia = rodar(["--pasta", str(pasta), "--saida", str(saida_dia),
                       "--meus-enderecos", MEU, "--colegas", COLEGA,
                       "--desde", dia_noite, "--ate", dia_noite,
                       "--hoje", "2026-09-20"])
        m_dia = ler_csv(saida_dia / "mensagens.csv")
        conferir("mensagem das 22h30 fica dentro do recorte do proprio dia",
                 bool(por_chave(m_dia, "arquivo", "noite.eml")), True)
        conferir("recorte de um dia nao derruba a rodada", r_dia.returncode, 1)
        t_noite = por_chave(ler_csv(saida_dia / "threads.csv"),
                            "assunto", "Liberacao do lote 9931 para expedicao")
        conferir("dias_desde_a_ultima nao sai negativo",
                 int(t_noite.get("dias_desde_a_ultima", -1)) >= 0, True)

        # -------------------------------------------------------------
        # Defeito: citacao do Gmail em portugues nao cortada.
        # -------------------------------------------------------------
        m_citg = por_chave(mensagens, "arquivo", "citacao-gmail.eml")
        conferir_contem("texto novo entra no trecho",
                        m_citg["trecho_corpo"], "Consegue confirmar hoje")
        conferir_nao_contem("linha de atribuicao do Gmail e cortada",
                            m_citg["trecho_corpo"], "escreveu")
        conferir_nao_contem("historico citado fica fora do trecho",
                            m_citg["trecho_corpo"], "desenho aprovado")
        conferir("citacao do Gmail nao fabrica prazo da mensagem antiga",
                 m_citg["marcas_de_prazo"], "hoje")

        m_bq = por_chave(mensagens, "arquivo", "gmail-blockquote.eml")
        conferir_contem("corpo em HTML do Gmail entrega o texto novo",
                        m_bq["trecho_corpo"], "Pode liberar a inspecao")
        conferir_nao_contem("o <div> de cada paragrafo vira quebra de linha",
                            m_bq["trecho_corpo"], "escreveu")
        conferir_nao_contem("o historico em <blockquote> fica fora",
                            m_bq["trecho_corpo"], "improrrogavel")
        conferir("blockquote nao fabrica o prazo da mensagem antiga",
                 m_bq["marcas_de_prazo"], "amanha")

        # -------------------------------------------------------------
        # Defeito: assunto curto com identificador nao juntava thread.
        # -------------------------------------------------------------
        t_nc = por_chave(threads, "assunto_normalizado", "nc 4412")
        conferir("NC 4412 vira uma thread so", t_nc.get("n_mensagens"), "2")
        conferir("NC 4412 foi juntada por assunto",
                 t_nc.get("metodo_da_thread"), "assunto")

        # -------------------------------------------------------------
        # Defeito: colega de mensagem unica saindo como respondida_por_outro.
        # -------------------------------------------------------------
        t_interno = por_chave(threads, "assunto", "ENC: pedido do cliente Zeta")
        conferir("colega, ultima mensagem da thread",
                 t_interno.get("ultimo_e_colega"), "sim")
        conferir("colega de mensagem unica nao respondeu ninguem",
                 t_interno.get("colega_respondeu_anterior"), "nao")
        t1 = [l for l in threads if "conformidade 4412" in l["assunto_normalizado"]][0]
        conferir("colega depois de mensagem externa respondeu de fato",
                 t1["colega_respondeu_anterior"], "sim")

        # -------------------------------------------------------------
        # Defeito: eu_ja_respondi dizendo sim em thread que eu abri.
        # -------------------------------------------------------------
        conferir("coluna eu_ja_respondi nao existe mais",
                 "eu_ja_respondi" in threads[0], False)
        t_abri = por_chave(threads, "assunto",
                           "Re: Revisao do cronograma de montagem")
        conferir("tenho mensagem na thread que eu abri",
                 t_abri.get("tenho_mensagem_na_thread"), "sim")
        conferir("mas nao respondi depois do ultimo pedido externo",
                 t_abri.get("respondi_depois_da_ultima_externa"), "nao")
        conferir("na thread em que respondi depois, a coluna diz sim",
                 t1["respondi_depois_da_ultima_externa"], "sim")

        # -------------------------------------------------------------
        # Casos de sempre.
        # -------------------------------------------------------------
        conferir("thread por cabecalho tem 3 mensagens", t1["n_mensagens"], "3")
        conferir("metodo cabecalho", t1["metodo_da_thread"], "cabecalho")
        conferir("ultimo nao e meu", t1["ultimo_e_meu"], "nao")
        conferir("dois remetentes externos a mim",
                 t1["n_remetentes_externos"], "2")
        conferir("dias desde a ultima", t1["dias_desde_a_ultima"], "2")
        conferir("assunto bruto vai para threads.csv",
                 t1["assunto"], "Re: Nao conformidade 4412 na linha 3")

        t2 = [l for l in threads if "valvula" in l["assunto_normalizado"]][0]
        conferir("thread por assunto tem 2 mensagens", t2["n_mensagens"], "2")
        conferir("metodo assunto", t2["metodo_da_thread"], "assunto")
        conferir("aviso de thread por assunto na nota",
                 "Thread formada por assunto" in nota, True)

        genericas = [l for l in threads if l["assunto_normalizado"] == "pedido"]
        conferir("assunto generico gera duas threads", len(genericas), 2)
        conferir("as duas ficam isoladas",
                 sorted(l["metodo_da_thread"] for l in genericas),
                 ["isolada", "isolada"])

        m_lista = por_chave(mensagens, "arquivo", "lista.eml")
        conferir_contem("lista traz sinal automatico",
                        m_lista["sinal_automatico"], "list-unsubscribe")
        conferir_contem("lista traz precedence",
                        m_lista["sinal_automatico"], "precedence")

        conferir("ausencia marcada",
                 por_chave(mensagens, "arquivo", "ausencia.eml")
                 ["resposta_automatica"], "sim")

        m_prazo = por_chave(mensagens, "arquivo", "prazo.eml")
        conferir_contem("marca de prazo encontrada",
                        m_prazo["marcas_de_prazo"], "25/09")
        conferir_contem("palavra de prazo encontrada",
                        m_prazo["marcas_de_prazo"], "prazo")

        conferir("meu papel e copia",
                 por_chave(mensagens, "arquivo", "copia.eml")["meu_papel"],
                 "copia")

        m_demim = por_chave(mensagens, "arquivo", "demim.eml")
        conferir("mensagem enviada por mim", m_demim["meu_papel"], "de_mim")
        conferir("thread so com mensagem minha nao tem papel de recebida",
                 por_chave(threads, "thread_id", m_demim["thread_id"])
                 ["meu_papel_maximo"], "nao_aparece")

        m_html = por_chave(mensagens, "arquivo", "html.eml")
        conferir_contem("html vira texto", m_html["trecho_corpo"],
                        "lista de material")
        conferir_nao_contem("html perdeu a marcacao",
                            m_html["trecho_corpo"], "<")

        m_latin = por_chave(mensagens, "arquivo", "latin.eml")
        conferir_contem("iso-8859-1 decodificado no corpo",
                        m_latin["trecho_corpo"], "manutenção")
        conferir_contem("assunto codificado decodificado",
                        m_latin["assunto"], "Agendamento da parada")

        m_cit = por_chave(mensagens, "arquivo", "citacao.eml")
        conferir_contem("texto novo entra no trecho, formato Outlook",
                        m_cit["trecho_corpo"], "Podemos fechar assim")
        conferir_nao_contem("citacao fica fora do trecho",
                            m_cit["trecho_corpo"], "texto antigo")
        conferir("citacao cortada nao deixa marca de prazo falsa",
                 m_cit["marcas_de_prazo"], "")

        motivos = " ".join(l["motivo"] for l in nao_lidos)
        conferir_contem("msg reportado como nao lido", motivos, ".msg")
        conferir_contem("eml vazio reportado", motivos, "nao ha o que triar")

        # -------------------------------------------------------------
        # Recorte por data e --sem-corpo.
        # -------------------------------------------------------------
        saida2 = base / "rastro-recorte"
        r2 = rodar(["--pasta", str(pasta), "--saida", str(saida2),
                    "--meus-enderecos", MEU, "--desde", "2026-09-15",
                    "--hoje", "2026-09-20"])
        conferir("recorte tambem sai com 1, o .msg continua la",
                 r2.returncode, 1)
        conferir("recorte deixou 22 mensagens",
                 len(ler_csv(saida2 / "mensagens.csv")), 22)
        nota2 = (saida2 / "nota-de-leitura.md").read_text(encoding="utf-8")
        conferir_contem("uma mensagem fora do recorte", nota2,
                        "fora_do_recorte: 1")
        t_sem_colega = ler_csv(saida2 / "threads.csv")[0]
        conferir("sem --colegas a coluna sai desconhecido",
                 t_sem_colega["ultimo_e_colega"], "desconhecido")
        conferir("sem --colegas a classe 3 nao pode ser afirmada",
                 t_sem_colega["colega_respondeu_anterior"], "desconhecido")
        conferir_contem("aviso de --colegas vazio no terminal", r2.stderr,
                        "--colegas veio vazio")

        saida3 = base / "rastro-sem-corpo"
        rodar(["--pasta", str(pasta), "--saida", str(saida3),
               "--meus-enderecos", MEU, "--sem-corpo", "--hoje", "2026-09-20"])
        m3 = ler_csv(saida3 / "mensagens.csv")
        conferir("sem-corpo nao grava trecho",
                 sorted(set(l["trecho_corpo"] for l in m3)), [""])
        conferir_contem("sem-corpo troca destinatario por contagem",
                        por_chave(m3, "arquivo", "copia.eml")["para"],
                        "destinatarios")
        conferir("sem-corpo tambem limpa o trecho da thread",
                 sorted(set(l["trecho_da_ultima"]
                            for l in ler_csv(saida3 / "threads.csv"))), [""])
        nota3 = (saida3 / "nota-de-leitura.md").read_text(encoding="utf-8")
        conferir_contem("sem-corpo avisa que o prazo do corpo nao aparece",
                        nota3, "prazo escrito no corpo nao aparece")

        # -------------------------------------------------------------
        # Defeito proprio: arquivos de mesmo nome em subpastas diferentes.
        # -------------------------------------------------------------
        arvore = base / "arvore"
        (arvore / "setembro").mkdir(parents=True)
        (arvore / "outubro").mkdir(parents=True)
        for sub, corpo in (("setembro", "Primeiro caso, sem relacao."),
                           ("outubro", "Segundo caso, outro assunto.")):
            (arvore / sub / "mensagem.eml").write_bytes(eml([
                ("From", "Alguem <alguem@fornecedor.com.br>"),
                ("To", MEU),
                ("Subject", "Assunto de %s" % sub),
                ("Date", "Fri, 18 Sep 2026 08:00:00 -0300"),
                ("Content-Type", "text/plain; charset=utf-8"),
            ], corpo))
        saida_arv = base / "rastro-arvore"
        rodar(["--pasta", str(arvore), "--saida", str(saida_arv),
               "--meus-enderecos", MEU, "--recursivo", "--hoje", "2026-09-20"])
        t_arv = ler_csv(saida_arv / "threads.csv")
        conferir("nome repetido em subpastas nao funde duas threads",
                 len(t_arv), 2)
        conferir("o indice aponta o caminho, nao so o nome do arquivo",
                 sorted(l["arquivos"] for l in t_arv),
                 ["outubro/mensagem.eml", "setembro/mensagem.eml"])

        r_arv_rasa = rodar(["--pasta", str(arvore),
                            "--saida", str(base / "rastro-arvore-rasa"),
                            "--meus-enderecos", MEU, "--hoje", "2026-09-20"])
        conferir("pasta so de subpastas sem --recursivo sai 1, nao 0",
                 r_arv_rasa.returncode, 1)
        conferir_contem("e diz que o primeiro nivel nao tinha .eml",
                        r_arv_rasa.stderr, "primeiro nivel")

        # -------------------------------------------------------------
        # Defeito proprio: mensagem em subpasta sumindo sem deixar linha
        # numa rodada sem --recursivo. A varredura rasa nem via o arquivo,
        # as seis identidades fechavam e a rodada saia com codigo 0, que a
        # SKILL documenta como "todos os arquivos da pasta foram lidos".
        # O caso roda SEM a flag de proposito: a suite so exercitava o
        # caminho com ela, e por isso o defeito passava.
        # -------------------------------------------------------------
        mista = base / "mista"
        (mista / "setembro").mkdir(parents=True)
        (mista / "raiz.eml").write_bytes(eml([
            ("From", "Alguem <alguem@fornecedor.com.br>"),
            ("To", MEU),
            ("Subject", "Assunto que fica na raiz"),
            ("Date", "Fri, 18 Sep 2026 08:00:00 -0300"),
            ("Content-Type", "text/plain; charset=utf-8"),
        ], "Mensagem no primeiro nivel da pasta."))
        for nome, assunto, corpo in (
                ("prazo.eml", "Cobranca da NC 9981",
                 "Preciso da posicao ate 25/09, senao paramos a linha."),
                ("outro.eml", "Pedido 77120 em aberto",
                 "Aguardo o retorno sobre o pedido.")):
            (mista / "setembro" / nome).write_bytes(eml([
                ("From", "Carlos Lima <carlos@fornecedor.com.br>"),
                ("To", MEU),
                ("Subject", assunto),
                ("Date", "Fri, 18 Sep 2026 09:00:00 -0300"),
                ("Content-Type", "text/plain; charset=utf-8"),
            ], corpo))

        saida_rasa = base / "rastro-sem-recursivo"
        r_rasa = rodar(["--pasta", str(mista), "--saida", str(saida_rasa),
                        "--meus-enderecos", MEU, "--colegas", COLEGA,
                        "--hoje", "2026-09-20"])
        conferir("rodada sem --recursivo nao sai 0 com arquivo em subpasta",
                 r_rasa.returncode, 1)
        conferir_nao_contem("e nenhuma identidade quebra ao dizer isso",
                            r_rasa.stdout, "NAO FECHA")
        conferir_contem("a varredura ve os tres arquivos, nao so o da raiz",
                        r_rasa.stdout, "Arquivos vistos: 3")
        nl_rasa = ler_csv_ou_vazio(saida_rasa / "nao-lidos.csv")
        conferir("cada arquivo de subpasta vira linha em nao-lidos.csv",
                 sorted(l["arquivo"] for l in nl_rasa),
                 ["setembro/outro.eml", "setembro/prazo.eml"])
        conferir_contem("e o motivo nomeia a opcao que faltou",
                        por_chave(nl_rasa, "arquivo",
                                  "setembro/prazo.eml").get("motivo"),
                        "--recursivo")
        m_rasa = ler_csv_ou_vazio(saida_rasa / "mensagens.csv")
        conferir("so a mensagem do primeiro nivel foi lida",
                 [l["arquivo"] for l in m_rasa], ["raiz.eml"])
        nota_rasa = ler_texto_ou_vazio(saida_rasa / "nota-de-leitura.md")
        conferir_contem("a nota declara quantas ficaram na subpasta",
                        nota_rasa, "em_subpasta: 2")
        conferir_contem("e a nota diz como ler a arvore inteira",
                        nota_rasa, "`--recursivo`")
        conferir_contem("o terminal avisa antes de encerrar", r_rasa.stdout,
                        "Em subpasta, nao lidos por falta de --recursivo: 2")

        saida_funda = base / "rastro-com-recursivo"
        r_funda = rodar(["--pasta", str(mista), "--saida", str(saida_funda),
                         "--meus-enderecos", MEU, "--colegas", COLEGA,
                         "--recursivo", "--hoje", "2026-09-20"])
        conferir("a mesma pasta com --recursivo le as tres e sai 0",
                 (r_funda.returncode,
                  len(ler_csv_ou_vazio(saida_funda / "mensagens.csv"))),
                 (0, 3))

        # O arquivo de subpasta chega ate o entregavel: sem decisao escrita
        # para cada um, o indice nao e gravado.
        trab_rasa = base / "trabalho-rasa"
        trab_rasa.mkdir()
        cls_rasa = trab_rasa / "classes.csv"
        escrever(cls_rasa, classes_de(ler_csv_ou_vazio(
            saida_rasa / "threads.csv")))
        meia_dec = trab_rasa / "decisoes-meia.csv"
        escrever(meia_dec, "arquivo;decisao\n"
                 "setembro/outro.eml;rebaixada, pedido ja atendido\n")
        cmd_rasa = ["--rastro", str(saida_rasa), "--classes", str(cls_rasa),
                    "--saida", str(trab_rasa), "--data", "2026-09-18",
                    "--validacao", "nao validada"]
        r_meia = rodar(cmd_rasa + ["--decisoes", str(meia_dec)], INDICE)
        conferir("indice recusado enquanto falta decisao para a subpasta",
                 r_meia.returncode, 3)
        conferir_contem("e a recusa nomeia o arquivo pelo caminho",
                        r_meia.stderr, "setembro/prazo.eml")
        dec_rasa = trab_rasa / "decisoes.csv"
        escrever(dec_rasa, "arquivo;decisao\n"
                 "setembro/outro.eml;rebaixada, pedido ja atendido\n"
                 "setembro/prazo.eml;relida na rodada com --recursivo\n")
        r_ind_rasa = rodar(cmd_rasa + ["--decisoes", str(dec_rasa)], INDICE)
        conferir("com as duas decisoes o indice e gravado",
                 r_ind_rasa.returncode, 2)
        md_rasa = ler_texto_ou_vazio(trab_rasa / "indice-triado-2026-09-18.md")
        conferir_contem("o fechamento do indice declara a subpasta", md_rasa,
                        "em subpasta, rodada sem --recursivo")

        # -------------------------------------------------------------
        # Defeito proprio: entrada que a varredura nao alcanca saindo sem
        # linha nenhuma. Link simbolico para pasta nao e percorrido, link
        # quebrado nao e arquivo, e pasta sem permissao nao lista. Os tres
        # sumiam em silencio antes de virarem linha de nao-lidos.csv.
        # -------------------------------------------------------------
        alcance = base / "alcance"
        (alcance / "lado-de-fora").mkdir(parents=True)
        (alcance / "raiz.eml").write_bytes(eml([
            ("From", "Alguem <alguem@fornecedor.com.br>"),
            ("To", MEU),
            ("Subject", "Mensagem que a rodada alcanca"),
            ("Date", "Fri, 18 Sep 2026 08:00:00 -0300"),
            ("Content-Type", "text/plain; charset=utf-8"),
        ], "Corpo qualquer."))
        esperados = []
        try:
            (alcance / "link-pasta").symlink_to(alcance / "lado-de-fora",
                                                target_is_directory=True)
            (alcance / "link-quebrado.eml").symlink_to(
                alcance / "nao-existe.eml")
            esperados += ["link-pasta", "link-quebrado.eml"]
        except (OSError, NotImplementedError):
            pass  # Sem privilegio de link simbolico: o caso nao se aplica.
        sem_permissao = alcance / "sem-permissao"
        sem_permissao.mkdir()
        (sem_permissao / "dentro.eml").write_bytes(b"x")
        try:
            sem_permissao.chmod(0o000)
            bloqueada = not os.access(str(sem_permissao), os.R_OK)
        except OSError:
            bloqueada = False
        if bloqueada:
            esperados.append("sem-permissao")

        if esperados:
            saida_alc = base / "rastro-alcance"
            r_alc = rodar(["--pasta", str(alcance), "--saida", str(saida_alc),
                           "--meus-enderecos", MEU, "--colegas", COLEGA,
                           "--recursivo", "--hoje", "2026-09-20"])
            try:
                sem_permissao.chmod(0o755)
            except OSError:
                pass
            conferir("entrada fora do alcance da leitura nao sai 0",
                     r_alc.returncode, 1)
            conferir_nao_contem("e o fechamento continua fechando",
                                r_alc.stdout, "NAO FECHA")
            nl_alc = ler_csv_ou_vazio(saida_alc / "nao-lidos.csv")
            conferir("cada entrada fora do alcance vira linha nomeada",
                     sorted(l["arquivo"] for l in nl_alc), sorted(esperados))
        else:
            try:
                sem_permissao.chmod(0o755)
            except OSError:
                pass

        # -------------------------------------------------------------
        # Defeito proprio: pasta vazia e pasta so com arquivo de sistema.
        # -------------------------------------------------------------
        so_sistema = base / "so-sistema"
        so_sistema.mkdir()
        (so_sistema / ".DS_Store").write_bytes(b"\x00")
        r_sis = rodar(["--pasta", str(so_sistema), "--saida", str(base / "xs"),
                       "--meus-enderecos", MEU])
        conferir("pasta sem arquivo para ler sai 3, nao 4", r_sis.returncode, 3)
        conferir_nao_contem("e nao fala em recorte de data", r_sis.stderr,
                            "recorte")

        # -------------------------------------------------------------
        # Defeito: pasta so com .msg saindo com mensagem de recorte.
        # -------------------------------------------------------------
        so_msg = base / "so-msg"
        so_msg.mkdir()
        for nome in ("um.msg", "dois.msg"):
            (so_msg / nome).write_bytes(b"\xd0\xcf\x11\xe0" + b"\x00" * 20)
        saida_msg = base / "rastro-so-msg"
        r_msg = rodar(["--pasta", str(so_msg), "--saida", str(saida_msg),
                       "--meus-enderecos", MEU])
        conferir("pasta so com .msg sai 1, nao 4", r_msg.returncode, 1)
        conferir_contem("e diz que nao havia .eml", r_msg.stderr,
                        "Nenhum .eml na pasta")
        conferir("rodada vazia ainda escreve a nota de leitura",
                 (saida_msg / "nota-de-leitura.md").is_file(), True)
        conferir("rodada vazia escreve os quatro arquivos",
                 sorted(p.name for p in saida_msg.iterdir()),
                 ["mensagens.csv", "nao-lidos.csv", "nota-de-leitura.md",
                  "threads.csv"])

        r_vazio = rodar(["--pasta", str(pasta), "--saida", str(base / "xv"),
                         "--meus-enderecos", MEU, "--desde", "2030-01-01"])
        conferir("recorte que esvazia tudo sai 4", r_vazio.returncode, 4)
        conferir_contem("e o 4 fala do recorte", r_vazio.stderr,
                        "recorte de data nao deixou")

        # -------------------------------------------------------------
        # Erros de entrada.
        # -------------------------------------------------------------
        conferir("diretorio existente sem --forcar sai 3",
                 rodar(["--pasta", str(pasta), "--saida", str(saida),
                        "--meus-enderecos", MEU]).returncode, 3)
        conferir("sem endereco meu sai 3",
                 rodar(["--pasta", str(pasta), "--saida", str(base / "x5"),
                        "--meus-enderecos", ""]).returncode, 3)
        conferir("pasta inexistente sai 3",
                 rodar(["--pasta", str(base / "nao-existe"),
                        "--saida", str(base / "x6"),
                        "--meus-enderecos", MEU]).returncode, 3)
        conferir("data em formato errado sai 3",
                 rodar(["--pasta", str(pasta), "--saida", str(base / "x8"),
                        "--meus-enderecos", MEU,
                        "--desde", "18/09/2026"]).returncode, 3)
        conferir("desde posterior a ate sai 3",
                 rodar(["--pasta", str(pasta), "--saida", str(base / "x8b"),
                        "--meus-enderecos", MEU, "--desde", "2026-09-19",
                        "--ate", "2026-09-18"]).returncode, 3)

        limpa = base / "emails-limpos"
        limpa.mkdir()
        for nome in ("t1a.eml", "t1b.eml", "t1c.eml"):
            shutil.copy(pasta / nome, limpa / nome)
        conferir("pasta sem arquivo nao lido sai 0",
                 rodar(["--pasta", str(limpa), "--saida", str(base / "x9"),
                        "--meus-enderecos", MEU,
                        "--colegas", COLEGA]).returncode, 0)

        # -------------------------------------------------------------
        # montar-indice.py: o passo que produz o entregavel.
        # -------------------------------------------------------------
        trab = base / "trabalho"
        trab.mkdir()
        classes = trab / "classes.csv"
        decisoes = trab / "decisoes.csv"
        escrever(decisoes, "arquivo;decisao\n"
                 "arrastado.msg;rebaixado, mensagem ja tratada por telefone\n"
                 "vazio.eml;rebaixado, arquivo salvo em branco\n")

        ajustes = {
            t1["thread_id"]: ("respondida_por_outro", "", "Conferir se o "
                              "laudo da Maria cobriu o pedido", ""),
            t_nc["thread_id"]: ("cobranca_com_prazo", "2026-09-10",
                                "Responder a NC 4412", ""),
            t_abri["thread_id"]: ("exige_resposta_sua", "2026-09-30",
                                  "Dizer quem assina a liberacao do vao 4", ""),
            t_interno["thread_id"]: ("exige_resposta_sua", "",
                                     "Confirmar a data de entrega", ""),
        }
        escrever(classes, classes_de(threads, ajustes))

        base_cmd = ["--rastro", str(saida), "--classes", str(classes),
                    "--saida", str(trab), "--data", "2026-09-18"]

        # Thread faltando: recusa, e nada e gravado.
        parcial = trab / "classes-parcial.csv"
        escrever(parcial, classes_de(threads[:-1], ajustes))
        r_falta = rodar(["--rastro", str(saida), "--classes", str(parcial),
                         "--decisoes", str(decisoes), "--saida", str(trab),
                         "--data", "2026-09-18",
                         "--validacao", "nao validada"], INDICE)
        conferir("indice com thread faltando e recusado", r_falta.returncode, 3)
        conferir_contem("a recusa nomeia a thread que ficou de fora",
                        r_falta.stderr, threads[-1]["thread_id"])
        conferir("recusa nao grava arquivo nenhum",
                 list(trab.glob("indice-triado-*.md")), [])

        # Arquivo nao lido sem decisao: recusa.
        r_sem_dec = rodar(base_cmd + ["--validacao", "nao validada"], INDICE)
        conferir("indice sem decisao para nao lido e recusado",
                 r_sem_dec.returncode, 3)
        conferir_contem("a recusa nomeia o arquivo sem decisao",
                        r_sem_dec.stderr, "arrastado.msg")

        # Classe 3 sem sinal no rastro: recusa.
        errada = trab / "classes-errada.csv"
        ajuste_errado = dict(ajustes)
        ajuste_errado[t_interno["thread_id"]] = (
            "respondida_por_outro", "", "Conferir se a Maria cobriu", "")
        escrever(errada, classes_de(threads, ajuste_errado))
        r_c3 = rodar(["--rastro", str(saida), "--classes", str(errada),
                      "--decisoes", str(decisoes), "--saida", str(trab),
                      "--data", "2026-09-18",
                      "--validacao", "nao validada"], INDICE)
        conferir("colega de mensagem unica recusado na classe 3",
                 r_c3.returncode, 3)
        conferir_contem("a recusa cita colega_respondeu_anterior",
                        r_c3.stderr, "colega_respondeu_anterior")

        # Classe inexistente, prazo malformado, motivo faltando.
        for rotulo, ajuste in (
                ("classe fora das seis e recusada",
                 ("urgente", "", "x", "")),
                ("prazo fora de AAAA-MM-DD e recusado",
                 ("cobranca_com_prazo", "25/09", "x", "")),
                ("ruido sem evidencia escrita e recusado",
                 ("ruido", "", "", "")),
                ("exige_resposta_sua sem o pedido e recusado",
                 ("exige_resposta_sua", "", "", ""))):
            arq = trab / "classes-teste.csv"
            a = dict(ajustes)
            a[threads[3]["thread_id"]] = ajuste
            escrever(arq, classes_de(threads, a))
            saiu = rodar(["--rastro", str(saida), "--classes", str(arq),
                          "--decisoes", str(decisoes), "--saida", str(trab),
                          "--data", "2026-09-18",
                          "--validacao", "nao validada"], INDICE)
            conferir(rotulo, saiu.returncode, 3)

        vazio_cls = trab / "classes-vazio.csv"
        escrever(vazio_cls, "thread_id;classe;vence;o_que_e_pedido;motivo\n")
        r_vz = rodar(["--rastro", str(saida), "--classes", str(vazio_cls),
                      "--decisoes", str(decisoes), "--saida", str(trab),
                      "--data", "2026-09-18",
                      "--validacao", "nao validada"], INDICE)
        conferir("classes.csv vazio e recusado, nao estoura", r_vz.returncode, 3)
        conferir_contem("e a recusa diz o que escrever", r_vz.stderr,
                        "thread_id;classe;vence")

        misturado = base / "rastro-misturado"
        shutil.copytree(saida, misturado)
        shutil.copy(saida2 / "threads.csv", misturado / "threads.csv")
        r_mix = rodar(["--rastro", str(misturado), "--classes", str(classes),
                       "--decisoes", str(decisoes), "--saida", str(trab),
                       "--data", "2026-09-18",
                       "--validacao", "nao validada"], INDICE)
        conferir("rastro de duas rodadas diferentes e recusado",
                 r_mix.returncode, 3)
        conferir_contem("e a recusa aponta a divergencia", r_mix.stderr,
                        "rodadas diferentes")

        conferir("validacao fora da forma e recusada",
                 rodar(["--rastro", str(saida), "--classes", str(classes),
                        "--decisoes", str(decisoes), "--saida", str(trab),
                        "--data", "2026-09-18",
                        "--validacao", "ja conferi"], INDICE).returncode, 3)

        # Rodada boa, ainda sem gabarito.
        r_nv = rodar(base_cmd + ["--decisoes", str(decisoes),
                                 "--validacao", "nao validada"], INDICE)
        conferir("indice sem gabarito sai 2, nao 0", r_nv.returncode, 2)
        md = ler_texto_ou_vazio(trab / "indice-triado-2026-09-18.md")
        conferir_contem("o indice diz que nao foi validado", md,
                        "não foi validada")

        # Rodada boa, com gabarito.
        r_ok = rodar(base_cmd + [
            "--decisoes", str(decisoes),
            "--validacao", "2026-09-15, 34 threads comparadas, "
                           "erro que importa 0"], INDICE)
        conferir("indice validado sai 0", r_ok.returncode, 0)
        if r_ok.returncode != 0:
            falhas.append("montar-indice recusou a rodada boa\n    %s"
                          % r_ok.stderr.strip()[:400])
        md = ler_texto_ou_vazio(trab / "indice-triado-2026-09-18.md")
        linhas_csv = ler_csv_ou_vazio(trab / "triagem-2026-09-18.csv")

        conferir("o indice tem uma linha por thread do rastro",
                 len(linhas_csv), len(threads))
        conferir_contem("o fechamento do indice fecha", md,
                        "itens_no_indice = threads no rastro")
        conferir_nao_contem("nenhuma identidade do indice quebrada", md,
                            "NAO FECHA")
        conferir_contem("a validacao vai para o cabecalho", md,
                        "34 threads comparadas")
        conferir_contem("a ressalva do telefone esta no indice", md,
                        "resolvido por telefone")
        conferir_contem("o rodape esta no indice", md,
                        "Não substitui responsabilidade técnica")
        bruto_csv = ler_texto_ou_vazio(trab / "triagem-2026-09-18.csv")
        conferir_nao_contem("o CSV do entregavel nao tem rodape como linha",
                            bruto_csv, "# Gerado com apoio")

        conferir("prazo vencido vem antes de prazo futuro",
                 [l["thread_id"] for l in linhas_csv][:2],
                 [t_nc["thread_id"], t_abri["thread_id"]])
        conferir("a thread do colega entra no bloco 2",
                 por_chave(linhas_csv, "thread_id",
                           t1["thread_id"]).get("bloco"),
                 "2. Já respondido por outro na thread")
        conferir_contem("thread juntada por assunto vai para conferencia",
                        md, "%s: thread montada por assunto" % t2["thread_id"])
        conferir_contem("marca de prazo sem prazo no indice vai para "
                        "conferencia", md, "e o indice saiu sem prazo")
        conferir_contem("o arquivo nao lido aparece com a decisao", md,
                        "rebaixado, mensagem ja tratada por telefone")

        # -------------------------------------------------------------
        # Documentos: as arestas que o roteador e a classificacao leem.
        # -------------------------------------------------------------
        skill_md = (SKILL / "SKILL.md").read_text(encoding="utf-8")
        classif = (SKILL / "references" / "classificacao.md").read_text(
            encoding="utf-8")
        descricao = skill_md.split("description: >", 1)[1].split("\n---", 1)[0]

        conferir_contem("a description remete a comparativo-de-cotacoes",
                        descricao, "comparativo-de-cotacoes")
        conferir_contem("a description fala caixa de entrada",
                        descricao, "caixa de entrada")
        conferir_contem("a description fala responder hoje",
                        descricao, "responder hoje")
        conferir("a description cabe no limite",
                 len(" ".join(l.strip()
                              for l in descricao.strip().splitlines())) <= 1400,
                 True)

        vizinha = (SKILLS / "comparativo-de-cotacoes" / "SKILL.md").read_text(
            encoding="utf-8")
        conferir_contem("a skill vizinha remete de volta a triagem",
                        vizinha.split("description: >", 1)[1].split("\n---", 1)[0],
                        "triagem-de-caixa-de-email")

        conferir_contem("classificacao.md cobre meu_papel_maximo",
                        classif, "meu_papel_maximo")
        conferir_contem("classificacao.md cobre nao_aparece",
                        classif, "nao_aparece")
        conferir_contem("classificacao.md exige colega_respondeu_anterior",
                        classif, "colega_respondeu_anterior")
        conferir_contem("classificacao.md corrige eu_ja_respondi",
                        classif, "respondi_depois_da_ultima_externa")
        conferir_nao_contem("classificacao.md nao cita coluna inexistente",
                            classif, "`meu_papel = ")
        conferir_contem("o passo que grava o indice existe na SKILL",
                        skill_md, "## Passo 6: classificar e gravar o índice")
        conferir_contem("a SKILL cita o montar-indice.py",
                        skill_md, "montar-indice.py")

    finally:
        shutil.rmtree(base, ignore_errors=True)

    print("casos que passaram: %d" % len(passou))
    if falhas:
        print("")
        print("FALHARAM: %d" % len(falhas))
        for f in falhas:
            print("  - " + f)
        return 1
    print("nenhuma falha")
    return 0


if __name__ == "__main__":
    sys.exit(main())
