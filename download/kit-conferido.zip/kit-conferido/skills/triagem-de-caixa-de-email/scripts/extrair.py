#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extrair.py, leitura em lote de e-mails salvos em pasta local.

Le uma pasta de arquivos .eml salvos do Outlook ou do webmail, agrupa as
mensagens em threads, e escreve quatro arquivos no diretorio de --saida:
mensagens.csv (uma linha por mensagem), threads.csv (uma linha por thread, que e
a unidade da triagem), nao-lidos.csv (todo arquivo que ficou fora da leitura) e
nota-de-leitura.md (contagens, fechamento e limites declarados).

O script NAO classifica. Ele extrai remetente, assunto, data, papel de quem
recebeu, tamanho, anexos, sinais de mensagem automatica, marcas de prazo e um
trecho do corpo. A classificacao e do modelo, sobre o CSV, com as regras de
references/classificacao.md.

Depois da instalacao o script fica em
~/.claude/skills/triagem-de-caixa-de-email/scripts/extrair.py, e a rodada
acontece na pasta dos arquivos de trabalho. Chame o script pelo caminho completo:
caminho relativo como scripts/extrair.py so funciona dentro da pasta da skill.

DEPENDENCIA DECLARADA: biblioteca padrao do Python 3.8 ou superior, e nada mais.
Modulos usados: argparse, csv, email, html, re, sys, unicodedata, datetime,
pathlib. Nao instala pacote, nao acessa rede, nao conecta em caixa de e-mail, nao
le .msg, nao le anexo, e nao escreve nos arquivos de entrada (abre tudo em modo
leitura binaria).

O conteudo das mensagens nunca vai para a saida padrao. O terminal recebe apenas
contagens, o bloco de fechamento e o caminho do diretorio gerado, para que a tela
possa ser copiada sem vazar dado.

A data de cada mensagem e convertida para o fuso da maquina que roda, que e a
hora que a pessoa ve no cliente de e-mail. E contra essa hora que --desde e
--ate sao comparados.

A varredura e sempre da arvore inteira, com ou sem --recursivo. Sem --recursivo
o arquivo de subpasta nao e lido, mas entra em nao-lidos.csv com o motivo e
derruba a rodada para o codigo 1. Varredura rasa escondia o arquivo da propria
contagem: as identidades fechavam e a mensagem sumia numa rodada de codigo 0.

Codigos de saida: 0 todos os arquivos da pasta foram lidos, 1 sobrou arquivo nao
lido e a rodada esta incompleta ate alguem responder por ele (inclui a pasta sem
nenhum .eml, a pasta em que todo .eml falhou e o arquivo de subpasta numa rodada
sem --recursivo), 3 erro de entrada, pasta sem arquivo para ler ou fechamento
que nao fecha, 4 havia .eml na pasta mas o recorte de data nao deixou nenhuma
mensagem.

Os quatro arquivos sao rastro, nao o entregavel. O entregavel sai do
montar-indice.py, que le threads.csv mais a classificacao e grava o indice.
"""

import argparse
import csv
import html
import os
import re
import sys
import unicodedata
from datetime import datetime
from email import policy
from email.parser import BytesParser
from email.utils import getaddresses, parsedate_to_datetime
from pathlib import Path

VERSAO = "1.2"

RODAPE = ("Gerado com apoio de IA a partir de e-mails salvos em pasta local. "
          "Revisar antes de assinar. Não substitui responsabilidade "
          "técnica.")

# ---------------------------------------------------------------------------
# 1. Constantes
# ---------------------------------------------------------------------------

# Prefixos de resposta e encaminhamento, em portugues e em ingles. Aplicados em
# laco: "Re: Enc: Re: assunto" perde os tres.
PREFIXOS = re.compile(
    r"^\s*(re|res|rsp|resp|enc|encaminhada|encaminhado|fw|fwd|em resposta a)"
    r"\s*(\[\d+\]|\(\d+\))?\s*:\s*",
    re.IGNORECASE,
)

# Marcadores que o servidor da empresa cola no assunto antes de entregar.
MARCADORES = re.compile(
    r"^\s*\[\s*(externo|external|spam|suspeito|aviso|nao confiavel|caution)"
    r"[^\]]*\]\s*",
    re.IGNORECASE,
)

# Assuntos genericos demais para juntar thread por assunto. Comparados contra a
# chave inteira, nunca como pedaco: "pedido 45231" nao esta nesta lista.
ASSUNTOS_GENERICOS = {
    "", "sem assunto", "pedido", "pedidos", "nota fiscal", "notas fiscais",
    "bom dia", "boa tarde", "boa noite", "urgente", "informacao", "informacoes",
    "documento", "documentos", "contato", "orcamento", "cotacao", "reuniao",
    "follow up", "followup", "duvida", "duvidas", "obrigado", "obrigada",
    "ok", "segue", "segue anexo", "em anexo", "confirmacao", "aviso",
}

MIN_ASSUNTO_PARA_JUNTAR = 8

# Arquivo que o sistema operacional cria sozinho na pasta. Nao e mensagem
# perdida e nao entra em nao-lidos.csv: entra na contagem de ignorados, que a
# nota declara. Descarte declarado, nunca silencioso.
OCULTOS = {".ds_store", "thumbs.db", "desktop.ini", ".localized"}


def e_arquivo_de_sistema(nome_relativo):
    for parte in nome_relativo.split("/"):
        if parte.lower() in OCULTOS:
            return True
        if parte.startswith("._") or parte.startswith("~$"):
            return True
        if parte.startswith(".") and not parte.lower().endswith(".eml"):
            return True
    return False

# Cabecalhos que denunciam mensagem de lista, de sistema ou de robo.
CABECALHOS_AUTOMATICOS = (
    "list-unsubscribe", "list-id", "list-post", "precedence",
    "auto-submitted", "x-auto-response-suppress", "x-autoreply",
    "x-mailer-daemon", "x-campaign", "x-mailgun-tag",
)

ASSUNTOS_DE_AUSENCIA = re.compile(
    r"^\s*(automatic reply|auto\s*reply|out of office|resposta automatica|"
    r"ausencia temporaria|ausente do escritorio|fora do escritorio)",
    re.IGNORECASE,
)

# Marcas de prazo. Sinal para ordenar e para o modelo olhar, nunca decisao: o
# prazo so entra no indice quando esta escrito na mensagem.
MARCAS_DE_PRAZO = (
    re.compile(r"\b\d{1,2}/\d{1,2}(?:/\d{2,4})?\b"),
    re.compile(r"\b\d{1,2}\s+de\s+(janeiro|fevereiro|marco|abril|maio|junho|"
               r"julho|agosto|setembro|outubro|novembro|dezembro)\b",
               re.IGNORECASE),
    re.compile(r"\b(hoje|amanha|ainda hoje|fim do dia|final do dia)\b",
               re.IGNORECASE),
    re.compile(r"\b(segunda|terca|quarta|quinta|sexta|sabado|domingo)"
               r"(\s*-?\s*feira)?\b", re.IGNORECASE),
    re.compile(r"\b(prazo|vencimento|vence|venceu|improrrogavel|impreterivel|"
               r"limite|urgente|urgencia)\b", re.IGNORECASE),
    re.compile(r"\b(ate|retorno ate|responder ate|devolver ate)\s+"
               r"(o\s+dia\s+)?\d{1,2}[/ ]", re.IGNORECASE),
    re.compile(r"\b\d{1,3}\s*(dias?|horas?)\s*(uteis|corridos)?\b",
               re.IGNORECASE),
)

MAX_MARCAS = 5

# A coluna de marcas tem teto. Quando o teto corta, a propria coluna diz que
# cortou: marca que some sem aviso faz a linha parecer completa.
CORTE_DE_MARCAS = "corte em %d marcas, pode haver mais" % MAX_MARCAS

# Inicio de citacao. O corpo e cortado aqui: o que vem depois e a mensagem
# anterior da thread, nao o pedido novo.
# A linha de atribuicao do Gmail e do Outlook na web traz nome e endereco do
# remetente e passa de 80 caracteres. O que a identifica nao e o comprimento, e
# a data no meio: por isso o padrao exige um digito entre o "em" e o
# "escreveu:", e nao limita o miolo a um numero curto.
MARCO_DE_CITACAO = re.compile(
    r"^\s*(>|de:\s|from:\s|enviad[oa]?\s+em:|sent:|assunto original:|"
    r"em\s[^\n]{0,240}\d[^\n]{0,240}escreveu:|"
    r"on\s[^\n]{0,240}\d[^\n]{0,240}wrote:|"
    r"-{2,}\s*(mensagem original|original message|"
    r"mensagem encaminhada|forwarded message)\s*-{2,})",
    re.IGNORECASE,
)

FIM_DE_ASSINATURA = re.compile(r"^\s*(--\s*|__+|-{4,})\s*$")

# Tags que separam linha no corpo em HTML. O Gmail e o Outlook na web poem
# cada paragrafo dentro de <div>, e sem quebrar nessas tags o corpo inteiro
# vira uma linha so: o corte de citacao, que trabalha linha a linha, nunca
# dispara e o historico entra no trecho como se fosse pedido novo.
BLOCOS_HTML = re.compile(
    r"(?i)</?(div|p|br|tr|li|h[1-6]|table|blockquote|hr)[^>]*>")

# Em e-mail, <blockquote> e a citacao. Equivale ao ">" do texto puro.
CITACAO_HTML = re.compile(r"(?is)<blockquote[^>]*>.*?</blockquote>")

COLUNAS_MENSAGENS = [
    "id", "arquivo", "data_iso", "data_cabecalho", "de_nome", "de_email",
    "para", "copia", "n_destinatarios", "meu_papel", "assunto",
    "assunto_normalizado", "thread_id", "posicao_na_thread", "message_id",
    "in_reply_to", "n_anexos", "tamanho_bytes", "sinal_automatico",
    "resposta_automatica", "marcas_de_prazo", "trecho_corpo",
]

COLUNAS_THREADS = [
    "thread_id", "metodo_da_thread", "assunto", "assunto_normalizado",
    "n_mensagens", "primeira_data", "ultima_data", "dias_desde_a_ultima",
    "ultimo_remetente", "ultimo_remetente_email", "ultimo_e_meu",
    "ultimo_e_colega", "colega_respondeu_anterior",
    "tenho_mensagem_na_thread", "respondi_depois_da_ultima_externa",
    "meu_papel_maximo", "n_remetentes_externos", "n_anexos",
    "sinal_automatico", "resposta_automatica", "marcas_de_prazo", "arquivos",
    "trecho_da_ultima",
]

COLUNAS_NAO_LIDOS = ["arquivo", "extensao", "tamanho_bytes", "motivo"]

# Bloco `chave: valor` no topo de nota-de-leitura.md. E o que o montar-indice.py
# le para montar o cabecalho do indice sem ninguem redigitar nada.
CHAVES_DA_RODADA = [
    "versao_extrair", "pasta", "recursivo", "fuso", "desde", "ate",
    "meus_enderecos", "colegas", "trecho", "sem_corpo", "arquivos_vistos",
    "ignorados", "em_subpasta", "fora_de_alcance", "eml", "mensagens_no_csv",
    "fora_do_recorte", "sem_data", "threads", "nao_lidos",
]


# ---------------------------------------------------------------------------
# 2. Texto
# ---------------------------------------------------------------------------

def dobrar_acento(texto):
    """Remove acento e cedilha, preservando a letra."""
    if not texto:
        return ""
    decomposto = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in decomposto if not unicodedata.combining(c))


def limpar_espaco(texto):
    return re.sub(r"\s+", " ", texto or "").strip()


def normalizar_assunto(assunto):
    """Chave de assunto: sem acento, minuscula, sem prefixo de resposta e sem
    marcador colado pelo servidor."""
    chave = dobrar_acento(assunto or "").lower()
    chave = limpar_espaco(chave)
    anterior = None
    while anterior != chave:
        anterior = chave
        chave = MARCADORES.sub("", chave)
        chave = PREFIXOS.sub("", chave)
        chave = chave.strip()
    chave = re.sub(r"[^\w\s/\-\.]", " ", chave)
    return limpar_espaco(chave)


def assunto_serve_para_juntar(chave):
    if chave in ASSUNTOS_GENERICOS:
        return False
    # "NC 4412", "OS 7712", "RNC 118" tem menos de oito caracteres e sao o
    # nome padrao de assunto no chao de fabrica. Numero de tres digitos ou
    # mais e identificador, e identificador junta thread mesmo em assunto
    # curto: sem isso a reiteracao racha em duas linhas do indice.
    if re.search(r"\d{3,}", chave):
        return True
    if len(chave) < MIN_ASSUNTO_PARA_JUNTAR:
        return False
    return True


def achar_marcas_de_prazo(texto):
    achados = []
    for padrao in MARCAS_DE_PRAZO:
        for encontrado in padrao.finditer(texto or ""):
            fragmento = limpar_espaco(encontrado.group(0))
            if fragmento and fragmento.lower() not in [a.lower() for a in achados]:
                achados.append(fragmento)
            if len(achados) >= MAX_MARCAS:
                return "; ".join(achados + [CORTE_DE_MARCAS])
    return "; ".join(achados)


def tirar_html(bruto):
    texto = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", bruto)
    # Tira a citacao em <blockquote>, mas so se sobrar texto novo. Corpo que
    # ficaria vazio volta inteiro: cortar tudo seria descarte em silencio.
    sem_citacao = CITACAO_HTML.sub("\n", texto)
    if limpar_espaco(re.sub(r"(?s)<[^>]+>", " ", sem_citacao)):
        texto = sem_citacao
    texto = BLOCOS_HTML.sub("\n", texto)
    texto = re.sub(r"(?s)<[^>]+>", " ", texto)
    return html.unescape(texto)


def cortar_no_inicio_da_citacao(texto):
    linhas = []
    for linha in texto.splitlines():
        if MARCO_DE_CITACAO.match(linha):
            break
        if FIM_DE_ASSINATURA.match(linha):
            break
        linhas.append(linha)
    return "\n".join(linhas)


# ---------------------------------------------------------------------------
# 3. Enderecos
# ---------------------------------------------------------------------------

def carregar_lista_de_enderecos(bruto):
    """Aceita endereco completo e dominio inteiro na forma @empresa.com.br."""
    enderecos = set()
    dominios = set()
    for item in (bruto or "").split(","):
        item = item.strip().lower()
        if not item:
            continue
        if item.startswith("@"):
            dominios.add(item[1:])
        else:
            enderecos.add(item)
    return enderecos, dominios


def pertence(endereco, enderecos, dominios):
    endereco = (endereco or "").strip().lower()
    if not endereco:
        return False
    if endereco in enderecos:
        return True
    if "@" in endereco and endereco.split("@", 1)[1] in dominios:
        return True
    return False


def enderecos_do_cabecalho(msg, nome_do_campo):
    bruto = msg.get_all(nome_do_campo, [])
    saida = []
    for nome, endereco in getaddresses([str(v) for v in bruto]):
        endereco = (endereco or "").strip().lower()
        if endereco:
            saida.append((limpar_espaco(nome), endereco))
    return saida


# ---------------------------------------------------------------------------
# 4. Leitura de uma mensagem
# ---------------------------------------------------------------------------

class Mensagem(object):
    __slots__ = ("arquivo", "tamanho", "data", "data_cabecalho", "de_nome",
                 "de_email", "para", "copia", "assunto", "assunto_chave",
                 "message_id", "referencias", "n_anexos", "sinal_automatico",
                 "resposta_automatica", "trecho", "marcas", "meu_papel",
                 "de_mim", "thread_id", "posicao")


def ler_data(msg):
    bruto = msg.get("Date")
    if not bruto:
        return None, ""
    try:
        quando = parsedate_to_datetime(str(bruto))
    except Exception:
        return None, limpar_espaco(str(bruto))
    if quando is None:
        return None, limpar_espaco(str(bruto))
    if quando.tzinfo is not None:
        # Fuso da maquina que roda, nao UTC. E a hora que a pessoa ve no
        # cliente de e-mail, e e contra ela que --desde e --ate sao lidos.
        # Convertendo para UTC, toda mensagem recebida depois das 21h em
        # Brasilia cai no dia seguinte e some do recorte sem aviso.
        quando = quando.astimezone().replace(tzinfo=None)
    return quando, limpar_espaco(str(bruto))


def extrair_corpo(msg, limite):
    if limite <= 0:
        return ""
    bruto = ""
    try:
        parte = msg.get_body(preferencelist=("plain", "html"))
    except Exception:
        parte = None
    if parte is not None:
        try:
            bruto = parte.get_content()
        except Exception:
            carga = parte.get_payload(decode=True)
            if isinstance(carga, bytes):
                bruto = carga.decode("utf-8", "replace")
            else:
                bruto = str(carga or "")
        if (parte.get_content_type() or "").endswith("html"):
            bruto = tirar_html(bruto)
    else:
        carga = msg.get_payload(decode=True)
        if isinstance(carga, bytes):
            bruto = carga.decode("utf-8", "replace")
    bruto = cortar_no_inicio_da_citacao(bruto or "")
    return limpar_espaco(bruto)[:limite]


def contar_anexos(msg):
    total = 0
    try:
        partes = list(msg.walk())
    except Exception:
        return 0
    for parte in partes:
        if parte.get_content_maintype() == "multipart":
            continue
        if parte.get_content_disposition() == "attachment":
            total += 1
        elif parte.get_filename():
            total += 1
    return total


def sinais_automaticos(msg):
    achados = []
    for nome in CABECALHOS_AUTOMATICOS:
        valor = msg.get(nome)
        if valor is None:
            continue
        texto = limpar_espaco(str(valor)).lower()
        if nome == "auto-submitted" and texto in ("no", ""):
            continue
        if nome == "precedence" and texto not in ("bulk", "list", "junk"):
            continue
        achados.append(nome)
    if limpar_espaco(str(msg.get("Return-Path") or "")) == "<>":
        achados.append("return-path-vazio")
    return "; ".join(achados)


def ler_mensagem(caminho, nome_relativo, limite_corpo, meus, meus_dom):
    with caminho.open("rb") as fh:
        bruto = fh.read()
    msg = BytesParser(policy=policy.default).parsebytes(bruto)

    assunto = limpar_espaco(str(msg.get("Subject") or ""))
    remetentes = enderecos_do_cabecalho(msg, "From")
    quando, data_cabecalho = ler_data(msg)

    if not assunto and not remetentes and quando is None:
        return None

    item = Mensagem()
    # Caminho relativo a pasta lida, nunca so o nome. Em --recursivo dois
    # arquivos de mesmo nome em subpastas diferentes dariam a mesma chave de
    # thread e seriam fundidos em silencio, alem de a pessoa nao achar o
    # arquivo pelo indice.
    item.arquivo = nome_relativo
    item.tamanho = len(bruto)
    item.data = quando
    item.data_cabecalho = data_cabecalho
    item.de_nome = remetentes[0][0] if remetentes else ""
    item.de_email = remetentes[0][1] if remetentes else ""
    item.para = enderecos_do_cabecalho(msg, "To")
    item.copia = enderecos_do_cabecalho(msg, "Cc")
    item.assunto = assunto
    item.assunto_chave = normalizar_assunto(assunto)
    item.message_id = limpar_espaco(str(msg.get("Message-ID") or "")).lower()

    referencias = []
    for nome in ("In-Reply-To", "References"):
        valor = msg.get(nome)
        if valor:
            referencias.extend(re.findall(r"<[^>]+>", str(valor)))
    item.referencias = [r.lower() for r in referencias]

    item.n_anexos = contar_anexos(msg)
    item.sinal_automatico = sinais_automaticos(msg)
    auto_enviado = limpar_espaco(str(msg.get("Auto-Submitted") or "")).lower()
    item.resposta_automatica = (
        "sim" if (auto_enviado.startswith("auto-replied")
                  or ASSUNTOS_DE_AUSENCIA.match(assunto)) else "nao")
    item.trecho = extrair_corpo(msg, limite_corpo)
    item.marcas = achar_marcas_de_prazo(assunto + " " + item.trecho)

    item.de_mim = pertence(item.de_email, meus, meus_dom)
    if item.de_mim:
        item.meu_papel = "de_mim"
    elif any(pertence(e, meus, meus_dom) for _, e in item.para):
        item.meu_papel = "para"
    elif any(pertence(e, meus, meus_dom) for _, e in item.copia):
        item.meu_papel = "copia"
    else:
        item.meu_papel = "nao_aparece"

    item.thread_id = ""
    item.posicao = 0
    return item


# ---------------------------------------------------------------------------
# 5. Threads
# ---------------------------------------------------------------------------

class Conjuntos(object):
    """Union-find simples, sem dependencia."""

    def __init__(self):
        self.pai = {}
        self.por_assunto = set()

    def achar(self, no):
        self.pai.setdefault(no, no)
        raiz = no
        while self.pai[raiz] != raiz:
            raiz = self.pai[raiz]
        while self.pai[no] != raiz:
            self.pai[no], no = raiz, self.pai[no]
        return raiz

    def unir(self, a, b, por_assunto=False):
        ra, rb = self.achar(a), self.achar(b)
        if ra == rb:
            return False
        self.pai[rb] = ra
        if por_assunto or rb in self.por_assunto:
            self.por_assunto.add(ra)
        self.por_assunto.discard(rb)
        return True


def agrupar_em_threads(mensagens):
    conj = Conjuntos()
    no_da_mensagem = []
    for i, item in enumerate(mensagens):
        no = item.message_id or ("arquivo:" + item.arquivo)
        no_da_mensagem.append(no)
        conj.achar(no)

    # Primeira passada: cabecalho. Referencia a mensagem ausente tambem une,
    # porque duas respostas ao mesmo pai que nao foi salvo sao a mesma thread.
    for i, item in enumerate(mensagens):
        for referencia in item.referencias:
            conj.unir(no_da_mensagem[i], referencia, por_assunto=False)

    # Segunda passada: assunto, so quando o assunto e especifico o bastante.
    primeiro_por_assunto = {}
    for i, item in enumerate(mensagens):
        chave = item.assunto_chave
        if not assunto_serve_para_juntar(chave):
            continue
        if chave in primeiro_por_assunto:
            conj.unir(primeiro_por_assunto[chave], no_da_mensagem[i],
                      por_assunto=True)
        else:
            primeiro_por_assunto[chave] = no_da_mensagem[i]

    grupos = {}
    for i, item in enumerate(mensagens):
        raiz = conj.achar(no_da_mensagem[i])
        grupos.setdefault(raiz, []).append(item)

    def chave_de_ordem(par):
        itens = par[1]
        datas = [m.data for m in itens if m.data is not None]
        return (0, min(datas)) if datas else (1, datetime.max)

    ordenados = sorted(grupos.items(), key=chave_de_ordem)
    threads = []
    for n, (raiz, itens) in enumerate(ordenados, start=1):
        identificador = "t%03d" % n
        itens.sort(key=lambda m: (m.data is None,
                                  m.data or datetime.max, m.arquivo))
        for posicao, item in enumerate(itens, start=1):
            item.thread_id = identificador
            item.posicao = posicao
        if len(itens) == 1:
            metodo = "isolada"
        elif raiz in conj.por_assunto:
            metodo = "assunto"
        else:
            metodo = "cabecalho"
        threads.append((identificador, metodo, itens))
    return threads


# ---------------------------------------------------------------------------
# 6. Escrita
# ---------------------------------------------------------------------------

def escrever_csv(caminho, colunas, linhas):
    with caminho.open("w", encoding="utf-8-sig", newline="") as fh:
        escritor = csv.writer(fh, delimiter=";", quoting=csv.QUOTE_MINIMAL,
                              lineterminator="\n")
        escritor.writerow(colunas)
        for linha in linhas:
            escritor.writerow(linha)


def texto_da_data(quando):
    return quando.strftime("%Y-%m-%d %H:%M") if quando else ""


def linha_de_mensagem(n, item, sem_corpo):
    if sem_corpo:
        para = "%d destinatarios" % len(item.para)
        copia = "%d em copia" % len(item.copia)
        trecho = ""
    else:
        para = "; ".join(e for _, e in item.para)
        copia = "; ".join(e for _, e in item.copia)
        trecho = item.trecho
    return [
        n, item.arquivo, texto_da_data(item.data), item.data_cabecalho,
        item.de_nome, item.de_email, para, copia,
        len(item.para) + len(item.copia), item.meu_papel, item.assunto,
        item.assunto_chave, item.thread_id, item.posicao, item.message_id,
        "; ".join(item.referencias[:3]), item.n_anexos, item.tamanho,
        item.sinal_automatico, item.resposta_automatica, item.marcas, trecho,
    ]


def linha_de_thread(identificador, metodo, itens, hoje, meus, meus_dom,
                    colegas, colegas_dom, tem_colegas, sem_corpo):
    datas = [m.data for m in itens if m.data is not None]
    primeira = min(datas) if datas else None
    ultima = max(datas) if datas else None
    ultimo = itens[-1]
    ultimo_e_meu = "sim" if ultimo.de_mim else "nao"
    if not tem_colegas:
        ultimo_e_colega = "desconhecido"
    elif ultimo.de_mim:
        ultimo_e_colega = "nao"
    else:
        ultimo_e_colega = ("sim" if pertence(ultimo.de_email, colegas,
                                             colegas_dom) else "nao")
    # Classe 3 de classificacao.md: colega so "responde por voce" quando havia
    # mensagem anterior de outra pessoa para responder. Thread de mensagem
    # unica, e thread em que o colega apenas repete a propria mensagem, nunca
    # entram na classe, por mais que ultimo_e_colega seja sim.
    sem_data_na_thread = any(m.data is None for m in itens)
    if ultimo_e_colega == "desconhecido":
        colega_respondeu_anterior = "desconhecido"
    elif ultimo_e_colega == "nao":
        colega_respondeu_anterior = "nao"
    elif sem_data_na_thread:
        colega_respondeu_anterior = "indeterminado"
    else:
        colega_respondeu_anterior = (
            "sim" if any(not m.de_mim and m.de_email != ultimo.de_email
                         for m in itens[:-1]) else "nao")

    # Ter mensagem minha na thread nao quer dizer que o ultimo pedido foi
    # atendido: eu posso ter aberto o assunto e o outro lado ter respondido
    # com pergunta nova. O que decide e se existe mensagem minha depois da
    # ultima mensagem externa, isto e, de quem nao sou eu nem colega.
    def e_externo(m):
        if m.de_mim:
            return False
        if tem_colegas and pertence(m.de_email, colegas, colegas_dom):
            return False
        return True

    externas = [m for m in itens if e_externo(m)]
    if not externas:
        respondi_depois = "sem_externa"
    elif sem_data_na_thread:
        respondi_depois = "indeterminado"
    else:
        ultima_externa = max(m.data for m in externas)
        respondi_depois = ("sim" if any(m.de_mim and m.data > ultima_externa
                                        for m in itens) else "nao")

    ordem_do_papel = {"para": 3, "copia": 2, "nao_aparece": 1, "de_mim": 0}
    recebidas = [m.meu_papel for m in itens if not m.de_mim]
    papel_maximo = max(recebidas, key=lambda p: ordem_do_papel[p]) \
        if recebidas else "nao_aparece"
    externos = set(m.de_email for m in itens
                   if m.de_email and not pertence(m.de_email, meus, meus_dom))
    marcas = []
    marcas_cortadas = False
    for m in itens:
        for fragmento in (m.marcas or "").split("; "):
            if fragmento == CORTE_DE_MARCAS:
                marcas_cortadas = True
                continue
            if fragmento and fragmento not in marcas:
                marcas.append(fragmento)
    if len(marcas) > MAX_MARCAS:
        marcas_cortadas = True
    texto_das_marcas = "; ".join(marcas[:MAX_MARCAS])
    if marcas_cortadas:
        texto_das_marcas = "; ".join(
            p for p in (texto_das_marcas, CORTE_DE_MARCAS) if p)
    sinais = []
    for m in itens:
        for fragmento in (m.sinal_automatico or "").split("; "):
            if fragmento and fragmento not in sinais:
                sinais.append(fragmento)
    # Contado por data de calendario, nao por hora: a pergunta e ha quantos
    # dias a thread esta parada, e a hora do dia nao muda a resposta.
    dias = ""
    if ultima is not None:
        dias = (hoje.date() - ultima.date()).days
    return [
        identificador, metodo, ultimo.assunto, itens[0].assunto_chave,
        len(itens),
        texto_da_data(primeira), texto_da_data(ultima), dias,
        ultimo.de_nome, ultimo.de_email, ultimo_e_meu, ultimo_e_colega,
        colega_respondeu_anterior,
        "sim" if any(m.de_mim for m in itens) else "nao",
        respondi_depois,
        papel_maximo, len(externos), sum(m.n_anexos for m in itens),
        "; ".join(sinais),
        "sim" if any(m.resposta_automatica == "sim" for m in itens) else "nao",
        texto_das_marcas, "; ".join(m.arquivo for m in itens),
        "" if sem_corpo else ultimo.trecho,
    ]


def escrever_nota(caminho, dados):
    L = []
    L.append("# Nota de leitura da pasta de e-mails")
    L.append("")
    L.append("status: %s" % dados["status"])
    L.append("")
    L.append("Gerado por `extrair.py` versao %s em %s." %
             (VERSAO, dados["agora"]))
    L.append("")
    L.append("## Rodada")
    L.append("")
    L.append("Bloco lido pelo `montar-indice.py`. Uma chave por linha.")
    L.append("")
    L.append("```")
    for chave in CHAVES_DA_RODADA:
        L.append("%s: %s" % (chave, dados["rodada"][chave]))
    L.append("```")
    L.append("")
    if dados["rodada"]["em_subpasta"]:
        L.append("%s arquivo(s) estao em subpasta e nao foram lidos: a rodada "
                 "nao usou `--recursivo`. Cada um esta nomeado em "
                 "`nao-lidos.csv` e a rodada saiu com codigo 1. Para ler a "
                 "arvore inteira, repita com `--recursivo`."
                 % dados["rodada"]["em_subpasta"])
        L.append("")
    if dados["rodada"]["fora_de_alcance"]:
        L.append("%s entrada(s) ficaram fora do alcance da leitura: pasta que "
                 "o sistema nao deixou listar, link simbolico para pasta, que "
                 "nao e percorrido, ou arquivo sem acesso. Estao nomeadas em "
                 "`nao-lidos.csv` com o motivo."
                 % dados["rodada"]["fora_de_alcance"])
        L.append("")
    if dados["rodada"]["ignorados"]:
        L.append("Arquivos de sistema ignorados nao entram em "
                 "`nao-lidos.csv`: nao sao mensagem perdida. Eles estao "
                 "declarados na contagem `ignorados` e no fechamento.")
        L.append("")
    if dados["rodada"]["colegas"] == 0:
        L.append("`--colegas` nao foi declarado: `ultimo_e_colega` e "
                 "`colega_respondeu_anterior` saem como `desconhecido` e "
                 "nenhuma thread pode ser classificada como respondida por "
                 "outro.")
        L.append("")
    L.append("## Threads")
    L.append("")
    L.append("- Threads formadas: %d" % dados["threads"])
    L.append("- Por cabecalho (In-Reply-To ou References): %d" %
             dados["por_cabecalho"])
    L.append("- Por assunto, sem cabecalho de resposta: %d" %
             dados["por_assunto"])
    L.append("- Isoladas, uma unica mensagem: %d" % dados["isoladas"])
    L.append("")
    if dados["por_assunto"]:
        L.append("Thread formada por assunto e a que mais erra: dois pedidos "
                 "diferentes com o mesmo assunto viram uma thread so. Confira "
                 "as %d marcadas como `assunto` antes de aceitar o "
                 "agrupamento." % dados["por_assunto"])
        L.append("")
    L.append("## Sinais encontrados")
    L.append("")
    L.append("- Mensagens com sinal de lista ou robo: %d" % dados["automaticas"])
    L.append("- Respostas automaticas de ausencia: %d" % dados["ausencias"])
    L.append("- Mensagens com marca de prazo no assunto ou no trecho: %d" %
             dados["com_marca_de_prazo"])
    L.append("- Mensagens em que voce aparece so em copia: %d" % dados["em_copia"])
    L.append("- Mensagens em que voce nao aparece no cabecalho: %d" %
             dados["nao_aparece"])
    L.append("")
    L.append("Marca de prazo e sinal para olhar, nao prazo. O prazo so entra "
             "no indice quando esta escrito na mensagem.")
    L.append("")
    if dados["rodada"]["sem_corpo"] == "sim":
        L.append("Rodada com `--sem-corpo`: a marca de prazo so pode vir do "
                 "assunto, e prazo escrito no corpo nao aparece aqui. Nesta "
                 "rodada a ordem do indice vale menos, e cada thread de "
                 "cobranca precisa ser aberta no cliente de e-mail antes de "
                 "fixar a ordem.")
        L.append("")
    if dados["rodada"]["sem_data"]:
        L.append("%d mensagem(ns) sem data no cabecalho. Elas entraram no "
                 "recorte porque descartar mensagem sem data seria omissao "
                 "silenciosa, e as colunas de ordem da thread saem como "
                 "`indeterminado`." % dados["rodada"]["sem_data"])
        L.append("")
    L.append("## Fechamento")
    L.append("")
    L.append("```")
    for linha in dados["identidades"]:
        L.append(linha)
    L.append("```")
    L.append("")
    L.append("## Limite declarado")
    L.append("")
    L.append("Este script nao conecta em caixa de e-mail, nao le arquivo .msg, "
             "nao abre anexo e nao apaga, move nem responde mensagem. Ele le "
             "arquivos .eml da pasta indicada, em modo leitura, e escreve os "
             "quatro arquivos deste diretorio.")
    L.append("")
    L.append(RODAPE)
    L.append("")
    caminho.write_text("\n".join(L), encoding="utf-8")


# ---------------------------------------------------------------------------
# 7. Principal
# ---------------------------------------------------------------------------

def montar_argumentos():
    p = argparse.ArgumentParser(
        description="Le uma pasta de e-mails .eml salvos e escreve o CSV que a "
                    "triagem classifica. Nao conecta em caixa de e-mail.")
    p.add_argument("--pasta", required=True,
                   help="Pasta com os arquivos .eml salvos.")
    p.add_argument("--saida", required=True,
                   help="Diretorio a criar com os quatro arquivos de saida.")
    p.add_argument("--meus-enderecos", required=True, dest="meus",
                   help="Seus enderecos, separados por virgula. Aceita "
                        "@dominio para a caixa inteira. Sem isso nao existe "
                        "'exige resposta sua'.")
    p.add_argument("--colegas", default="",
                   help="Enderecos ou @dominio de quem responde do seu lado. "
                        "Sem isso a coluna ultimo_e_colega sai como "
                        "desconhecido.")
    p.add_argument("--trecho", type=int, default=300,
                   help="Caracteres do corpo por mensagem. Padrao 300.")
    p.add_argument("--sem-corpo", action="store_true", dest="sem_corpo",
                   help="Nao extrai corpo e troca as listas de destinatario "
                        "por contagem. Modo de dado sensivel.")
    p.add_argument("--desde", default="", help="Data AAAA-MM-DD inclusive.")
    p.add_argument("--ate", default="", help="Data AAAA-MM-DD inclusive.")
    p.add_argument("--hoje", default="",
                   help="Data AAAA-MM-DD usada para contar dias parados. "
                        "Padrao: a data do sistema. Numa conferencia de "
                        "rodada antiga, passe a data daquele dia, senao "
                        "dias_desde_a_ultima muda a cada execucao.")
    p.add_argument("--recursivo", action="store_true",
                   help="Le tambem as subpastas. Sem esta opcao a arvore e "
                        "varrida do mesmo jeito e cada arquivo de subpasta "
                        "entra em nao-lidos.csv, com a rodada saindo em 1.")
    p.add_argument("--forcar", action="store_true",
                   help="Sobrescreve um diretorio de saida que ja existe.")
    return p


def ler_data_de_opcao(bruto, nome):
    if not bruto:
        return None
    try:
        return datetime.strptime(bruto.strip(), "%Y-%m-%d")
    except ValueError:
        sys.stderr.write("ERRO: %s espera AAAA-MM-DD, recebeu %r.\n"
                         % (nome, bruto))
        sys.exit(3)


def varrer_arvore(pasta):
    """Percorre a arvore inteira e devolve (arquivos, barrados).

    A varredura nunca para no primeiro nivel, com ou sem --recursivo. Quem
    decide o que e lido e o --recursivo, no laco de leitura, e o que nao for
    lido vira linha em nao-lidos.csv. Varredura rasa escondia o arquivo de
    subpasta da propria contagem: as identidades fechavam, a rodada saia com
    codigo 0 e a mensagem sumia sem deixar linha. Era este o defeito.

    `barrados` sao as entradas que nao entregam arquivo para ler: pasta que o
    sistema nao deixa listar, link simbolico para pasta, que o os.walk nao
    percorre, e entrada que nao e arquivo comum, como link quebrado. Cada uma
    sai nomeada em nao-lidos.csv. Nenhuma e descartada em silencio.
    """
    arquivos = []
    barrados = []

    def relativo(alvo):
        try:
            return Path(alvo).relative_to(pasta).as_posix()
        except (TypeError, ValueError):
            return str(alvo or "(caminho desconhecido)")

    def anotar_erro(erro):
        barrados.append([relativo(getattr(erro, "filename", "")), "pasta", 0,
                         "pasta nao pode ser listada: %s. O que estiver "
                         "dentro dela nao foi lido"
                         % type(erro).__name__])

    for raiz, subpastas, nomes in os.walk(pasta, onerror=anotar_erro,
                                          followlinks=False):
        raiz = Path(raiz)
        restantes = []
        for nome in sorted(subpastas):
            alvo = raiz / nome
            if alvo.is_symlink():
                barrados.append([relativo(alvo), "link para pasta", 0,
                                 "link simbolico para pasta, nao percorrido. "
                                 "Copie os .eml para dentro da pasta lida"])
            else:
                restantes.append(nome)
        subpastas[:] = restantes
        for nome in sorted(nomes):
            alvo = raiz / nome
            if alvo.is_file():
                arquivos.append(alvo)
            else:
                barrados.append([relativo(alvo), "nao e arquivo", 0,
                                 "entrada que nao e arquivo comum: link "
                                 "quebrado, dispositivo ou soquete"])
    arquivos.sort(key=lambda c: c.as_posix())
    barrados.sort(key=lambda linha: linha[0])
    return arquivos, barrados


def main(argv=None):
    args = montar_argumentos().parse_args(argv)

    pasta = Path(args.pasta).expanduser()
    if not pasta.is_dir():
        sys.stderr.write("ERRO: pasta nao encontrada: %s\n" % pasta)
        return 3

    saida = Path(args.saida).expanduser()
    if saida.exists() and not args.forcar:
        sys.stderr.write("ERRO: o diretorio de saida ja existe: %s\n"
                         "Use --forcar para sobrescrever.\n" % saida)
        return 3
    saida.mkdir(parents=True, exist_ok=True)

    meus, meus_dom = carregar_lista_de_enderecos(args.meus)
    if not meus and not meus_dom:
        sys.stderr.write("ERRO: --meus-enderecos veio vazio. Sem saber quais "
                         "enderecos sao seus nao da para dizer o que exige "
                         "resposta sua.\n")
        return 3
    colegas, colegas_dom = carregar_lista_de_enderecos(args.colegas)
    tem_colegas = bool(colegas or colegas_dom)
    if not tem_colegas:
        sys.stderr.write(
            "AVISO: --colegas veio vazio. A coluna ultimo_e_colega sai como "
            "desconhecido e nenhuma thread pode ser classificada como "
            "respondida por outro. No PowerShell o valor vai entre aspas: "
            "--colegas \"@empresa.com.br\".\n")

    desde = ler_data_de_opcao(args.desde, "--desde")
    ate = ler_data_de_opcao(args.ate, "--ate")
    if ate is not None:
        ate = ate.replace(hour=23, minute=59, second=59)
    if desde is not None and ate is not None and desde > ate:
        sys.stderr.write("ERRO: --desde %s e posterior a --ate %s. O recorte "
                         "e vazio por construcao.\n" % (args.desde, args.ate))
        return 3
    hoje = ler_data_de_opcao(args.hoje, "--hoje") or datetime.now()

    limite_corpo = 0 if args.sem_corpo else max(0, args.trecho)

    arquivos, barrados = varrer_arvore(pasta)
    vistos = len(arquivos) + len(barrados)

    mensagens = []
    nao_lidos = list(barrados)
    fora_do_recorte = 0
    eml_candidatos = 0
    eml_com_falha = 0
    ignorados = 0
    em_subpasta = 0
    outros_formatos = 0
    fora_de_alcance = len(barrados)

    for caminho in arquivos:
        rel = caminho.relative_to(pasta).as_posix()
        if e_arquivo_de_sistema(rel):
            ignorados += 1
            continue
        extensao = caminho.suffix.lower()
        try:
            tamanho = caminho.stat().st_size
        except OSError as erro:
            fora_de_alcance += 1
            nao_lidos.append([rel, extensao or "sem extensao", 0,
                              "arquivo nao pode ser aberto: %s"
                              % type(erro).__name__])
            continue
        # Sem --recursivo o arquivo de subpasta nao e lido, mas e nomeado: ele
        # some da leitura, nunca da contagem, e a rodada nao pode sair com 0.
        if "/" in rel and not args.recursivo:
            em_subpasta += 1
            nao_lidos.append([rel, extensao or "sem extensao", tamanho,
                              "arquivo em subpasta e a rodada nao usou "
                              "--recursivo: repita com --recursivo para ler "
                              "a arvore inteira"])
            continue
        if extensao != ".eml":
            outros_formatos += 1
            if extensao == ".msg":
                motivo = ("formato .msg, que este script nao le. Baixe a "
                          "mesma mensagem como .eml pelo webmail")
            else:
                motivo = "extensao fora da leitura, so .eml e lido"
            nao_lidos.append([rel, extensao or "sem extensao",
                              tamanho, motivo])
            continue
        eml_candidatos += 1
        try:
            item = ler_mensagem(caminho, rel, limite_corpo, meus, meus_dom)
        except Exception as erro:
            eml_com_falha += 1
            nao_lidos.append([rel, extensao, tamanho,
                              "falha de leitura: %s" % type(erro).__name__])
            continue
        if item is None:
            eml_com_falha += 1
            nao_lidos.append([rel, extensao, tamanho,
                              "sem remetente, sem assunto e sem data: nao ha "
                              "o que triar"])
            continue
        if item.data is not None:
            if desde is not None and item.data < desde:
                fora_do_recorte += 1
                continue
            if ate is not None and item.data > ate:
                fora_do_recorte += 1
                continue
        mensagens.append(item)

    mensagens_lidas = eml_candidatos - eml_com_falha
    uteis = vistos - ignorados
    threads = agrupar_em_threads(mensagens) if mensagens else []

    por_cabecalho = sum(1 for _, m, _ in threads if m == "cabecalho")
    por_assunto = sum(1 for _, m, _ in threads if m == "assunto")
    isoladas = sum(1 for _, m, _ in threads if m == "isolada")
    soma_em_threads = sum(len(i) for _, _, i in threads)

    identidades = []
    tudo_fecha = True

    def conferir(rotulo, esquerda, direita):
        nonlocal tudo_fecha
        ok = esquerda == direita
        if not ok:
            tudo_fecha = False
        identidades.append("%-60s %6d = %-6d %s"
                           % (rotulo, esquerda, direita,
                              "fecha" if ok else "NAO FECHA"))

    # Cada contagem abaixo e somada no laco, nunca derivada do total. Contagem
    # derivada fecha sempre, inclusive quando falta arquivo.
    conferir("arquivos_vistos = eml + outros + subpasta + fora + ignorados",
             vistos, eml_candidatos + outros_formatos + em_subpasta
             + fora_de_alcance + ignorados)
    conferir("eml = lidas + com falha",
             eml_candidatos, mensagens_lidas + eml_com_falha)
    conferir("lidas = no csv + fora do recorte",
             mensagens_lidas, len(mensagens) + fora_do_recorte)
    conferir("mensagens no csv = soma nas threads",
             len(mensagens), soma_em_threads)
    conferir("threads = cabecalho + assunto + isoladas",
             len(threads), por_cabecalho + por_assunto + isoladas)
    conferir("linhas em nao-lidos = outros + subpasta + fora + com falha",
             len(nao_lidos),
             outros_formatos + em_subpasta + fora_de_alcance + eml_com_falha)

    fuso = datetime.now().astimezone().strftime("%z") or "sem fuso"
    dados = {
        "status": "completo" if tudo_fecha else "invalido, nao fecha",
        "agora": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "threads": len(threads), "por_cabecalho": por_cabecalho,
        "por_assunto": por_assunto, "isoladas": isoladas,
        "automaticas": sum(1 for m in mensagens if m.sinal_automatico),
        "ausencias": sum(1 for m in mensagens
                         if m.resposta_automatica == "sim"),
        "com_marca_de_prazo": sum(1 for m in mensagens if m.marcas),
        "em_copia": sum(1 for m in mensagens if m.meu_papel == "copia"),
        "nao_aparece": sum(1 for m in mensagens
                           if m.meu_papel == "nao_aparece"),
        "identidades": identidades,
        "rodada": {
            "versao_extrair": VERSAO,
            "pasta": str(pasta),
            "recursivo": "sim" if args.recursivo else "nao",
            "fuso": fuso,
            "desde": args.desde or "sem limite",
            "ate": args.ate or "sem limite",
            "meus_enderecos": len(meus) + len(meus_dom),
            "colegas": len(colegas) + len(colegas_dom),
            "trecho": ("0, rodada com --sem-corpo" if args.sem_corpo
                       else limite_corpo),
            "sem_corpo": "sim" if args.sem_corpo else "nao",
            "arquivos_vistos": vistos,
            "ignorados": ignorados,
            "em_subpasta": em_subpasta,
            "fora_de_alcance": fora_de_alcance,
            "eml": eml_candidatos,
            "mensagens_no_csv": len(mensagens),
            "fora_do_recorte": fora_do_recorte,
            "sem_data": sum(1 for m in mensagens if m.data is None),
            "threads": len(threads),
            "nao_lidos": len(nao_lidos),
        },
    }

    # Nenhuma mensagem sobrou. Os quatro arquivos saem do mesmo jeito: o
    # diagnostico de uma rodada vazia esta na nota, e rodada que nao escreve
    # nota nao deixa rastro do que foi descartado.
    if not mensagens:
        escrever_csv(saida / "mensagens.csv", COLUNAS_MENSAGENS, [])
        escrever_csv(saida / "threads.csv", COLUNAS_THREADS, [])
        escrever_csv(saida / "nao-lidos.csv", COLUNAS_NAO_LIDOS, nao_lidos)
        escrever_nota(saida / "nota-de-leitura.md", dados)
        print("Saida: %s" % saida)
        if uteis == 0:
            sys.stderr.write(
                "ERRO: a pasta nao tem arquivo para ler. Vistos %d, todos "
                "arquivos de sistema ou nenhum.\n" % vistos)
            return 3
        if eml_candidatos == 0:
            if em_subpasta:
                sys.stderr.write(
                    "Nenhum .eml no primeiro nivel da pasta, e %d arquivo(s) "
                    "estao em subpasta. A rodada nao usou --recursivo: eles "
                    "estao nomeados em nao-lidos.csv e nao foram lidos. "
                    "Repita com --recursivo para ler a arvore inteira.\n"
                    % em_subpasta)
                return 1
            sys.stderr.write(
                "Nenhum .eml na pasta. Os %d arquivos vistos estao em "
                "nao-lidos.csv, e a rodada nao produziu indice. No Outlook "
                "classico o arrasto grava .msg: baixe as mesmas mensagens "
                "pelo webmail.\n" % uteis)
            return 1
        if fora_do_recorte > 0:
            sys.stderr.write(
                "Havia .eml na pasta, mas o recorte de data nao deixou "
                "nenhuma mensagem. .eml candidatos: %d, fora do recorte: "
                "%d.\n" % (eml_candidatos, fora_do_recorte))
            if nao_lidos:
                sys.stderr.write(
                    "Alem disso sobraram %d arquivo(s) nao lidos, nomeados "
                    "em nao-lidos.csv.\n" % len(nao_lidos))
            return 4
        sys.stderr.write(
            "Nenhum .eml foi lido: %d candidatos, todos com falha. Os "
            "motivos estao em nao-lidos.csv.\n" % eml_candidatos)
        return 1

    linhas_mensagens = []
    for n, item in enumerate(sorted(mensagens,
                                    key=lambda m: (m.thread_id, m.posicao)),
                             start=1):
        linhas_mensagens.append(linha_de_mensagem(n, item, args.sem_corpo))
    escrever_csv(saida / "mensagens.csv", COLUNAS_MENSAGENS, linhas_mensagens)

    linhas_threads = []
    for identificador, metodo, itens in threads:
        linhas_threads.append(
            linha_de_thread(identificador, metodo, itens, hoje, meus, meus_dom,
                            colegas, colegas_dom, tem_colegas, args.sem_corpo))
    escrever_csv(saida / "threads.csv", COLUNAS_THREADS, linhas_threads)
    escrever_csv(saida / "nao-lidos.csv", COLUNAS_NAO_LIDOS, nao_lidos)
    escrever_nota(saida / "nota-de-leitura.md", dados)

    print("Pasta lida: %s" % pasta)
    print("Arquivos vistos: %d, mensagens lidas: %d, nao lidos: %d, "
          "ignorados: %d"
          % (vistos, len(mensagens), len(nao_lidos), ignorados))
    if em_subpasta:
        print("Em subpasta, nao lidos por falta de --recursivo: %d"
              % em_subpasta)
    if fora_de_alcance:
        print("Fora do alcance da leitura (pasta, link ou arquivo sem "
              "acesso): %d" % fora_de_alcance)
    if fora_do_recorte:
        print("Lidos e descartados pelo recorte de data: %d"
              % fora_do_recorte)
    print("Threads: %d (cabecalho %d, assunto %d, isoladas %d)"
          % (len(threads), por_cabecalho, por_assunto, isoladas))
    print("")
    print("FECHAMENTO")
    for linha in identidades:
        print("  " + linha)
    print("")
    print("Saida: %s" % saida)
    for nome in ("mensagens.csv", "threads.csv", "nao-lidos.csv",
                 "nota-de-leitura.md"):
        print("  " + str(saida / nome))
    print("")
    print("Proximo passo: classificar threads.csv e rodar montar-indice.py. "
          "Os quatro arquivos acima sao rastro, nao o entregavel.")

    if not tudo_fecha:
        sys.stderr.write("ERRO: o fechamento nao fecha. A saida nao vale.\n")
        return 3
    if nao_lidos:
        print("")
        if em_subpasta:
            print("%d arquivo(s) estao em subpasta e nao foram lidos: a "
                  "rodada nao usou --recursivo. Repita com --recursivo para "
                  "ler a arvore inteira." % em_subpasta)
        print("Sobrou arquivo nao lido. A rodada so fecha depois que alguem "
              "responder por cada linha de nao-lidos.csv.")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
