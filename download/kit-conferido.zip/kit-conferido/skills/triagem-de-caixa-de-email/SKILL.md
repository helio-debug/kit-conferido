---
name: triagem-de-caixa-de-email
description: >
  Lê uma pasta de e-mails salvos no computador (.eml) e devolve o índice triado: o que exige
  resposta sua, o que é cobrança com prazo, o que é só ciência, o que já foi respondido por
  outro na thread e o que é ruído. Cada item com remetente, assunto, data, o que está sendo
  pedido em uma linha e o prazo quando houver, ordenado pelo que vence primeiro. Trabalha
  sobre arquivo salvo, nunca conecta na caixa corporativa, e não apaga, arquiva nem responde
  nada. Classifica e indexa: não escreve a resposta. Use SEMPRE que aparecer: "tria minha
  caixa de e-mail", "o que desses e-mails precisa de resposta minha", "monta o índice da
  minha caixa", "organiza minha caixa de entrada", "o que eu preciso responder hoje",
  "estou com mil e-mails sem ler", "me diz o que é urgente nesses e-mails", "separa o que
  é só cópia", "quais desses têm prazo", "o que já foi respondido pelo pessoal", "baixei
  os e-mails do Outlook numa pasta", "salvei os e-mails numa pasta, organiza isso", "toda
  manhã eu gasto uma hora abrindo e-mail". NÃO use para escrever, rascunhar ou revisar
  resposta de e-mail, nem para conectar na caixa corporativa. NÃO use para extrair dado de
  dentro de anexo (extracao-de-documento-para-tabela), para comparar duas planilhas
  (conferencia-entre-duas-fontes) nem para comparar cotações ou propostas recebidas por
  e-mail (comparativo-de-cotacoes).
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que esta skill
ocupe o lugar das outras.

| Caso | Skill | Relação com esta |
|---|---|---|
| Ler o que está dentro do anexo e virar tabela | `extracao-de-documento-para-tabela` (construída) | Aqui o anexo é contado, nunca aberto. Rode a extração depois, sobre o anexo que a triagem apontou |
| Comparar duas listas que deveriam bater | `conferencia-entre-duas-fontes` (construída) | O índice desta skill não é fonte de conferência |
| Comparar propostas recebidas por e-mail | `comparativo-de-cotacoes` (construída) | A triagem aponta quais threads trazem proposta. A comparação é lá |
| Registrar o desvio que apareceu na thread | `registro-de-anomalia` | O item do índice é insumo do registro, não o registro |
| Descrever a área uma vez para as outras skills lerem | `ficha-da-area` | Rode-a antes: ela escreve `~/.kit-industrial/ficha-da-area.md`, que o passo 1 desta lê |
| Medir quanto tempo a triagem manual custa hoje | `linha-de-base-antes-de-automatizar` | Anote o relógio nas três primeiras rodadas à mão, antes de usar esta skill |

---

# Triagem de caixa de e-mail

A pessoa abre a caixa de manhã com centenas de mensagens não lidas. Rola a lista de cima
para baixo, abre as que parecem importantes, perde as que não pareciam, e descobre a
cobrança no dia em que ela vira problema. Faz isso todo dia e nunca sabe o que deixou para
trás.

Esta skill termina em arquivo. A saída é um índice triado gravado em disco, com o caminho
dito na última linha. Resposta em prosa dizendo "os mais importantes parecem ser estes" é
falha de execução.

**Esta skill não conecta na caixa corporativa.** Ela lê e-mails que a pessoa salvou numa
pasta do computador. Conector depende da TI, e enquanto ele não existe a triagem não
acontece. Pasta local acontece hoje. Diga isso na cara antes de começar.

---

## Leis de ferro

1. **Ataca a triagem, não a redação.** Esta skill classifica e indexa. Ela não escreve nem
   rascunha resposta. O motivo está na origem do kit: para redigir resposta não há gabarito
   nem acesso ao dado, e por isso a geração de resposta é o pior primeiro caso que existe.
   Separar o que chegou e apontar o que exige resposta sua, ao contrário, se confere no mesmo
   dia: basta abrir a caixa. Pedido de rascunho é recusado, e o motivo é dito.
2. **Pasta local, em modo leitura.** Nada é apagado, arquivado, movido, marcado como lido
   nem respondido. A skill lê os arquivos e escreve o índice, e mais nada.
3. **A unidade é a thread, não a mensagem.** Uma linha por assunto, com o histórico
   considerado. Classificar mensagem por mensagem faz a pessoa responder o mesmo pedido três
   vezes.
4. **O prazo só entra se estiver escrito na mensagem.** Prazo inferido da urgência aparente
   sai como `sem prazo declarado`. Prazo inventado destrói a ordem do índice, que é a única
   coisa que o índice entrega.
5. **Dúvida vai para `não classificado`, nunca para ruído.** Sobrar mensagem no índice custa
   quinze segundos de leitura. Mandar um pedido com prazo para o ruído custa o prazo.
6. **E-mail com dado sensível entra só por remetente, assunto e data.** O corpo não entra no
   índice, e a linha do pedido sai como `conteúdo não lido, classificação pelo cabeçalho`.
7. **Gabarito antes do uso real.** A pessoa roda sobre três dias que ela já triou na mão e
   compara item a item contra o que de fato respondeu. Só usa no trabalho real depois de três
   comparações sem erro que importe. O passo 7 diz como.
8. **Contagem que não fecha invalida a rodada.** Todo arquivo da árvore da pasta aparece em
   algum bloco do índice ou na lista de não lidos, inclusive o que está em subpasta. As
   identidades do passo 8 são obrigatórias.
9. **Thread sem classe não vira índice.** O `montar-indice.py` recusa a rodada e não grava
   arquivo nenhum quando falta classe para alguma thread do rastro, ou quando falta decisão
   registrada para alguma linha de `nao-lidos.csv`. Índice incompleto é pior do que índice
   nenhum, porque parece completo. Não existe opção de forçar.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Se existir, use o vocabulário da área, os sistemas
em uso e as reuniões de rotina para reconhecer o que é pedido real e o que é comunicado de
sistema. Se não existir, declare em voz alta "rodando sem ficha da área" e siga normalmente.

A skill que escreve essa ficha é a `ficha-da-area`, nesta versão do kit. Rodar sem ela não
degrada a triagem: só obriga a perguntar no passo 3 quais sistemas mandam mensagem
automática para a caixa.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi carregada ou se a
triagem está rodando sem ficha e, carregada, repete o status gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir arquivo

Três perguntas, nesta ordem:

1. **O dado é sensível?** Nome de pessoa em avaliação, folha de pagamento, salário ou
   remuneração individual, preço de fornecedor identificado, dado de cliente identificado,
   projeto sob sigilo. Folha, salário e remuneração individual não entram em nenhum modo:
   peça que essas mensagens fiquem fora da pasta. Se sim, ou se a pessoa não souber, vá para
   o **modo de dado sensível** e não leia o corpo. Ofereça sempre o modo derivado, que aqui é
   triar só por remetente, assunto e data.
2. **Essa triagem se repete?** Diária ou semanal. Se sim, rode pelo script mesmo que caiba na
   leitura: o valor está em repetir igual, e leitura não repete igual.
3. **Quantos arquivos tem a pasta?** Define leitura ou script pela tabela do passo 5.

**Critério de conclusão:** as três respostas estão registradas e a escolha entre leitura e
script está feita antes de qualquer arquivo ser aberto.

---

## Passo 3: montar a pasta local e declarar o recorte

**Como salvar os e-mails.** No Outlook na web ou no Outlook novo, selecione a mensagem, abra
o menu de três pontos e clique em Baixar: sai um arquivo `.eml`, e arrastar a mensagem para
uma pasta do Explorador também grava `.eml`. No Outlook clássico de computador, arrastar
grava `.msg`, que o script não lê: baixe as mesmas mensagens pelo webmail da mesma conta.

Depois disso, três declarações:

- **Quais endereços são seus**, incluindo apelidos e caixas compartilhadas que você atende.
  Sem isso não existe "exige resposta sua", e a triagem não roda.
- **Quem responde do seu lado.** Endereços ou o domínio inteiro dos colegas. Sem isso a
  classe `já respondido por outro na thread` não pode ser afirmada, só suspeitada.
- **O recorte.** Qual pasta e qual período. Triagem de acervo antigo inteiro não é triagem, é
  arqueologia: comece por um dia.

Se a pasta tiver subpastas, a rodada precisa de `--recursivo`. Sem a opção o script vê os
arquivos de subpasta, não os lê e os lista em `nao-lidos.csv`, e a rodada sai com código 1.

**Critério de conclusão:** a pasta existe com arquivos `.eml` dentro, os endereços seus estão
nomeados, e o período está declarado em uma frase.

---

## Passo 4: ler `references/classificacao.md`

Percorra as seis classes, os sinais de cada uma e as quatorze confusões. A classificação sai
dessas regras, não do bom senso da rodada.

**Critério de conclusão:** as seis classes estão nomeadas na resposta antes da primeira
mensagem ser classificada.

---

## Passo 5: rodar

| Arquivos na pasta | Como rodar |
|---|---|
| Até 40 | Leitura em contexto, com fechamento obrigatório |
| 41 a 120 | Leitura em contexto em modo contado: reemitir a lista completa de arquivos e fechar as contagens. Custa quase o mesmo que rodar o script |
| Acima de 120 | Script obrigatório, sem exceção |
| Qualquer volume, se o dado é sensível | Script obrigatório com `--sem-corpo`, exceto no nível 1 do modo de dado sensível, em que nada roda e a pessoa cola só os cabeçalhos |
| Qualquer volume, se a triagem se repete | Script obrigatório |

**Por que 120 e não um número maior.** O caso que originou esta skill é uma caixa que recebe
centenas de mensagens por dia. O limite não é a janela de contexto, são três coisas que a
leitura não resolve:

- **Omissão silenciosa.** Pular um arquivo na leitura não gera erro. O índice fica com cara
  de completo e a cobrança com prazo some. É a falha que esta skill existe para eliminar.
- **Não reprodutibilidade.** Duas leituras da mesma pasta podem devolver listas diferentes, e
  amanhã ninguém repete o resultado.
- **Ausência de rastro.** Leitura não deixa linha de comando que alguém rode de novo.

O teste que decide: se não for possível reemitir a lista completa de nomes de arquivo da
pasta e fechar as contagens, aquilo foi amostragem. Nesse caso diga que foi amostragem e rode
o script.

**Como rodar o script.** Dependência declarada: Python 3.8 ou superior, biblioteca padrão
apenas (`argparse`, `csv`, `email`, `html`, `re`, `sys`, `unicodedata`, `datetime`,
`pathlib`). Sem instalação, sem rede, sem conexão com caixa de e-mail, sem escrita nos
arquivos de entrada.

**Onde o script está depois de instalado.** A instalação copia a pasta da skill para
`~/.claude/skills/triagem-de-caixa-de-email/`, e o script fica em
`~/.claude/skills/triagem-de-caixa-de-email/scripts/extrair.py`. A rodada acontece na pasta
dos arquivos de trabalho, não na pasta da skill, e por isso o script é sempre chamado pelo
caminho completo. Caminho relativo como `scripts/extrair.py` só funciona de dentro da pasta
da skill: fora dela o Python responde `can't open file`.

No macOS e no Linux:

```
python3 ~/.claude/skills/triagem-de-caixa-de-email/scripts/extrair.py \
    --pasta ./emails-2026-09-18 \
    --saida rastro-2026-09-18 \
    --meus-enderecos "joao.silva@empresa.com.br,engenharia@empresa.com.br" \
    --colegas "@empresa.com.br" \
    --trecho 300
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho vai entre aspas
com `$env:USERPROFILE` no lugar do `~`, e a linha continua com acento grave no lugar da barra
invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\triagem-de-caixa-de-email\scripts\extrair.py" `
    --pasta .\emails-2026-09-18 `
    --saida rastro-2026-09-18 `
    --meus-enderecos "joao.silva@empresa.com.br,engenharia@empresa.com.br" `
    --colegas "@empresa.com.br" `
    --trecho 300
```

No PowerShell os dois valores vão entre aspas. Arroba sem aspas é sintaxe de splatting da
própria linguagem, e a vírgula monta arranjo: sem as aspas, `--colegas` chega vazio, a
coluna `ultimo_e_colega` sai como `desconhecido` e nenhuma thread pode ser classificada
como respondida por outro. O script avisa no terminal quando isso acontece.

O diretório de `--saida` é o rastro, não o entregável. Por isso ele se chama
`rastro-<AAAA-MM-DD>`: o entregável `triagem-<AAAA-MM-DD>.csv` é gravado no diretório de
trabalho e os dois não podem disputar o mesmo nome.

`--meus-enderecos` é obrigatório e derruba a rodada com código 3 quando vem vazio, porque
sair com 0 sem saber quais endereços são seus seria entregar um índice em que ninguém precisa
responder nada. `--colegas` aceita o domínio inteiro na forma `@empresa.com.br`. Sem ele a
coluna `ultimo_e_colega` sai como `desconhecido`, e nenhuma thread pode ser classificada como
já respondida por outro.

`--hoje AAAA-MM-DD` fixa a data usada para contar dias parados. Numa conferência de rodada
antiga, passe a data daquele dia: sem isso `dias_desde_a_ultima` muda a cada execução e a
rodada deixa de ser reproduzível.

**`--recursivo` lê também as subpastas.** A varredura é sempre da árvore inteira, com a opção
ou sem ela. A opção decide o que é lido, não o que é visto: sem ela, cada arquivo de subpasta
entra em `nao-lidos.csv` com o motivo escrito e a rodada sai com código 1. Nenhum arquivo
some da contagem por falta da opção. Caixa organizada em pastas por mês ou por cliente é o
caso normal, e a rodada que esquece a opção é reprovada no terminal, não aceita em silêncio.

Três entradas que a leitura não alcança também viram linha nomeada em `nao-lidos.csv`: pasta
que o sistema não deixa listar, link simbólico para pasta, que não é percorrido, e entrada
que não é arquivo comum. Aponte `--pasta` para uma pasta só de e-mails salvos: tudo o que
estiver na árvore é contado, e pasta de trabalho com outros arquivos dentro enche
`nao-lidos.csv` sem necessidade.

**A data usada é a do fuso da máquina que roda**, que é a hora que a pessoa vê no cliente de
e-mail, e é contra ela que `--desde` e `--ate` são comparados. A nota de leitura registra o
fuso usado.

O script **não classifica**. Ele extrai remetente, assunto, data, papel de quem recebeu,
anexos, sinais de mensagem automática, marcas de prazo e um trecho do corpo, e escreve
`threads.csv`, que é o que a classificação lê.

### Ler a nota antes de classificar

O script escreve `nota-de-leitura.md` com as contagens e dois avisos que mudam a rodada:

- **Threads formadas por assunto.** Quando `metodo_da_thread` sai como `assunto`, o
  agrupamento veio do texto do assunto, não do cabeçalho de resposta. Dois pedidos diferentes
  com o mesmo assunto viram uma thread só. Confira essas antes de aceitar.
- **Arquivos não lidos.** `.msg` arrastado do Outlook clássico, `.eml` sem remetente, sem
  assunto e sem data, arquivo em subpasta numa rodada sem `--recursivo`, e entrada que a
  leitura não alcança. Cada linha de `nao-lidos.csv` precisa de uma decisão registrada: ou a
  mensagem é rebaixada por escrito, ou ela volta em `.eml`.

| Código de saída | Significado |
|---|---|
| 0 | Todos os arquivos da pasta foram lidos |
| 1 | Sobrou arquivo não lido, e a rodada está incompleta até alguém responder por ele. Inclui a pasta sem nenhum `.eml`, que é o caso de quem arrastou do Outlook clássico e levou `.msg`, e o arquivo em subpasta numa rodada sem `--recursivo` |
| 3 | Erro de entrada, pasta sem arquivo para ler, ou fechamento que não fecha |
| 4 | Havia `.eml` na pasta, mas o recorte de data não deixou nenhuma mensagem |

O código 1 é intencional. Numa rodada repetida, 0 é lido como "a pasta inteira entrou no
índice": só pode sair quando nenhum arquivo ficou de fora. Arquivo que o sistema operacional
cria sozinho (`.DS_Store`, `Thumbs.db`, `desktop.ini`) não conta como arquivo não lido: ele
entra na contagem `ignorados` da nota, declarado, e não derruba a rodada para 1.

Os quatro arquivos são escritos mesmo quando nenhuma mensagem sobra, porque rodada que não
escreve nota não deixa rastro do que foi descartado.

**Critério de conclusão:** o diretório de `--saida` tem os quatro arquivos, o bloco de
fechamento impresso no terminal tem `fecha` em todas as linhas, e cada linha de
`nao-lidos.csv` tem uma decisão registrada.

---

## Passo 6: classificar e gravar o índice

É aqui que sai o entregável. O passo 5 produziu rastro, não índice.

**6.1. Classifique.** Abra `threads.csv`. Para cada linha, aplique as seis classes de
`references/classificacao.md` nesta ordem de teste: `ruido` com evidência positiva,
`respondida_por_outro`, `cobranca_com_prazo`, `exige_resposta_sua`, `so_ciencia`, e o resto
em `nao_classificada`. Nenhuma thread fica sem classe. Dúvida é `nao_classificada` com o
motivo escrito, nunca linha em branco.

**6.2. Escreva `classes.csv`** no diretório de trabalho, separador ponto e vírgula, uma
linha por thread:

```
thread_id;classe;vence;o_que_e_pedido;motivo
t001;cobranca_com_prazo;2026-09-25;Responder a NC 4412 com o laudo da qualidade;
t002;nao_classificada;;;Corpo só diz "segue anexo" e o anexo não é aberto
```

- `vence` só com prazo escrito na mensagem, em AAAA-MM-DD, pela tabela do prazo de
  `classificacao.md`. Prazo derivado sai como `2026-09-25 (derivado de "até sexta")`. Sem
  prazo, deixe vazio.
- `o_que_e_pedido` é obrigatório nas classes que exigem ação: uma linha, no imperativo, com
  o verbo do pedido.
- `motivo` é obrigatório em `ruido`, onde ele é a evidência positiva, e em
  `nao_classificada`, onde ele é a dúvida em uma linha.

**6.3. Escreva `decisoes.csv`** quando `nao-lidos.csv` tiver linha, com `arquivo;decisao`.
A decisão é uma das duas: a mensagem é rebaixada por escrito com o motivo, ou ela volta em
`.eml` e o passo 5 é refeito.

**6.4. Rode o `montar-indice.py`.**

```
python3 ~/.claude/skills/triagem-de-caixa-de-email/scripts/montar-indice.py \
    --rastro rastro-2026-09-18 \
    --classes classes.csv \
    --decisoes decisoes.csv \
    --validacao "nao validada" \
    --data 2026-09-18
```

Ele ordena, conta, formata, fecha e grava `indice-triado-<AAAA-MM-DD>.md` e
`triagem-<AAAA-MM-DD>.csv` no diretório de trabalho. Nada disso é feito à mão: é onde a
triagem manual perde linha.

O script **recusa a rodada e não grava arquivo nenhum** quando falta thread em
`classes.csv`, quando sobra id que não existe, quando a classe não é uma das seis, quando
falta `o_que_e_pedido` ou `motivo` onde eles são obrigatórios, quando `vence` não está em
AAAA-MM-DD, quando uma thread foi posta em `respondida_por_outro` sem que o rastro diga
`colega_respondeu_anterior = sim`, e quando alguma linha de `nao-lidos.csv` está sem
decisão. Não existe opção de forçar. Leia a recusa, corrija o CSV, rode de novo.

O que ele não recusa, ele marca no bloco **O que precisa de olho humano**, thread a thread:
marca de prazo no rastro que não virou prazo no índice, prazo no índice sem marca no rastro,
prazo derivado, thread montada por assunto, thread sem data, thread com anexo e corpo mudo,
`ruido` sem sinal automático, bloco `nao_classificada` vazio ou acima de um quinto.

| Código de saída | Significado |
|---|---|
| 0 | Índice gravado, com validação declarada |
| 2 | Índice gravado com `validacao: nao validada`. Não serve para trabalho real |
| 3 | Recusa. Nada foi gravado, e o motivo está no terminal |

**Critério de conclusão:** os dois arquivos existem em disco, o fechamento do índice tem
`fecha` nas duas linhas, `itens_no_indice` é igual ao número de threads do rastro, e o
caminho dos dois está na última linha da resposta.

---

## Passo 7: teste do gabarito, uma vez, antes do primeiro uso real

**Este passo roda três vezes no começo e uma vez por semana depois. Ele não se repete a
cada rodada diária.** Se a pessoa pedir a triagem de hoje e o gabarito ainda não foi feito,
entregue o índice de hoje com `--validacao "nao validada"` e marque o gabarito para depois.
O índice sai com o aviso escrito no cabeçalho.

**O gabarito da triagem é a pasta de Enviados.** O que você de fato respondeu naquele dia
está gravado, e é contra isso que a classificação se mede. Por isso a triagem é verificável
no mesmo dia.

Escolha um dia já passado, rode os passos 3 a 6 sobre a pasta daquele dia, e compare item a
item com o que você enviou naquele dia e no seguinte. Duas perguntas, e elas não têm o mesmo
peso:

- **Erro que importa:** alguma thread que você respondeu saiu como `só ciência`, `ruído` ou
  `já respondido por outro`? Cada ocorrência é falha da triagem. Precisa ser zero.
- **Erro que não importa tanto:** alguma thread marcada como `exige resposta sua` você não
  respondeu? Pode ser excesso da triagem, e pode ser um pedido que você de fato deixou passar.
  Decida qual dos dois foi, caso a caso, e anote.

Repita em três dias diferentes. A partir da terceira comparação com erro que importa igual a
zero, as rodadas de trabalho real passam a rodar com o `--validacao` preenchido:

```
--validacao "2026-09-15, 34 threads comparadas, erro que importa 0"
```

Esse texto vai para o cabeçalho do índice e é o que permite a alguém, semanas depois, saber
se aquele arquivo foi feito por uma skill validada ou não.

Se a pessoa não tiver acesso aos Enviados daquele período, o caminho derivado é triar um dia
à mão primeiro, por escrito, antes de rodar a skill, e comparar depois. Rodar a skill antes e
conferir depois não serve: a lista da skill contamina a memória de quem confere.

**Critério de conclusão:** está dito qual dia foi usado, quantas threads entraram na
comparação, e quantos erros de cada tipo apareceram.

---

## Passo 8: fechamento

O `extrair.py` imprime seis identidades e o `montar-indice.py` imprime duas. São estas, com
o nome exato que sai no terminal. Todas devem fechar:

```
extrair.py
  arquivos_vistos = eml + outros + subpasta + fora + ignorados
  eml = lidas + com falha
  lidas = no csv + fora do recorte
  mensagens no csv = soma nas threads
  threads = cabecalho + assunto + isoladas
  linhas em nao-lidos = outros + subpasta + fora + com falha

montar-indice.py
  itens_no_indice = threads no rastro
  threads = soma das seis classes
```

`subpasta` é o arquivo que ficou fora por a rodada não ter usado `--recursivo`, e `fora` é a
entrada que a leitura não alcança. As duas contagens existem porque a varredura enxerga a
árvore inteira: arquivo que a rodada não lê aparece na conta e em `nao-lidos.csv`, nunca
sumido. Cada parcela é somada no laço de leitura, nunca derivada do total, senão a identidade
fecharia sozinha mesmo com arquivo faltando.

As identidades provam que nenhuma mensagem sumiu no caminho, não que a classificação está
certa. O que pode falhar de fato está no bloco **O que precisa de olho humano** do índice, e
cada linha dele exige uma decisão registrada.

Bloco `nao_classificada` vazio em toda rodada é sinal de que a triagem está adivinhando.
Bloco `nao_classificada` acima de um quinto das threads é sinal de que faltou declaração no
passo 3, quase sempre a lista de colegas. O script marca os dois casos sozinho.

**Critério de conclusão:** as oito identidades saíram com `fecha`, cada linha do bloco de
conferência foi lida e respondida, e o caminho dos dois arquivos do entregável está na última
linha da resposta. Se uma identidade quebrar, a entrega para e o motivo é dito.

---

## Contrato de saída

O artefato é gravado no diretório de trabalho, e o caminho é dito na última linha da
resposta.

### `indice-triado-<AAAA-MM-DD>.md`

Gravado pelo `montar-indice.py`. Cabeçalho em tabela, com: pasta lida, período, fuso usado
para datar, endereços declarados como seus, endereços de colegas, se o corpo foi lido,
**validação**, quantas threads em cada classe e o total. Depois a ressalva de que a caixa não
sabe o que já foi resolvido por telefone ou por mensagem instantânea.

O campo de validação é obrigatório e tem duas formas, e só essas duas:

```
validacao: 2026-09-15, 34 threads comparadas, erro que importa 0
validacao: nao validada
```

Com `nao validada` o índice sai com o aviso em destaque logo abaixo do cabeçalho e o script
devolve código 2. Sem o campo o script recusa: não existe índice sem estado de validação
declarado.

Depois, cinco blocos, nesta ordem. Uma tabela por bloco, sempre com as mesmas colunas.

| Bloco | O que entra |
|---|---|
| 1. Exige ação sua | `cobranca_com_prazo` e `exige_resposta_sua`, numa tabela só, ordenada pelo que vence primeiro |
| 2. Já respondido por outro na thread | Com quem respondeu e quando. A ação é conferir se cobriu |
| 3. Só ciência | Sem prazo, sem ação |
| 4. Ruído | Só o que tem evidência positiva, com a evidência nomeada |
| 5. Não classificado | Com o motivo da dúvida em uma linha |

Colunas de cada tabela:

| Coluna | Conteúdo |
|---|---|
| `vence` | Data em AAAA-MM-DD, ou `sem prazo declarado`. Prazo derivado sai marcado |
| `remetente` | Nome e endereço de quem mandou a última mensagem |
| `assunto` | Como está na mensagem |
| `data` | Data da última mensagem da thread |
| `o_que_e_pedido` | Uma linha, no imperativo, com o verbo do pedido |
| `classe` | Uma das seis |
| `thread` | Número de mensagens, e o método quando for `assunto` |
| `arquivo` | Nome do arquivo `.eml`, para a pessoa achar a mensagem |

O fim do arquivo traz o fechamento do passo 8, o bloco **O que precisa de olho humano** com
uma linha por thread marcada, e a tabela dos arquivos não lidos com a decisão de cada um.

### `triagem-<AAAA-MM-DD>.csv`

O mesmo conteúdo, uma linha por thread, para filtrar e ordenar na planilha. Separador ponto e
vírgula, codificação UTF-8 com BOM. Traz ainda `bloco`, `prazo_derivado`, `motivo`,
`thread_id` e `conferir`, esta última com as marcações daquela thread. Nenhum CSV da skill
tem linha de rodapé: rodapé como linha de dados sobe junto ao ordenar a planilha.

### Quando o script rodou

Ficam também, no diretório de `--saida` do `extrair.py`: `mensagens.csv`, `threads.csv`,
`nao-lidos.csv` e `nota-de-leitura.md`. Eles são o rastro da rodada, não o entregável, e por
isso o diretório se chama `rastro-<AAAA-MM-DD>`. No diretório de trabalho ficam ainda o
`classes.csv` e o `decisoes.csv` que a rodada usou: eles são a prova de que cada thread e
cada arquivo não lido receberam uma decisão.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de e-mails salvos em pasta local. Revisar antes de assinar.
Não substitui responsabilidade técnica.
```

---

## Modo de dado sensível

Ofereça os três níveis antes de pedir a pasta. O padrão, quando a pessoa não decide, é o
nível 2.

**Nível 1, só o cabeçalho.** A pessoa cola apenas remetente, assunto e data de cada mensagem,
sem corpo. A triagem sai com a classificação pelo cabeçalho, e cada linha do índice diz
`conteúdo não lido`. A taxa de `não classificado` sobe, e isso é o esperado.

**Nível 2, script local (padrão).** A pessoa roda o script na máquina dela com `--sem-corpo`.
O corpo não é extraído e as listas de destinatário viram contagem. Depois ela cola só a
`nota-de-leitura.md`, que por construção não contém conteúdo de mensagem: só contagens, nomes
de coluna e o caminho da pasta. Nome de pasta costuma identificar o setor ou o projeto: se
for o caso, renomeie antes de rodar. O modelo confere as decisões e o fechamento e diz se a
rodada é válida.

Com `--sem-corpo` a marca de prazo só pode vir do assunto, e prazo escrito no corpo não
aparece. Nesse modo a ordem do índice vale menos, e cada thread de cobrança precisa ser
aberta na máquina da pessoa antes de a ordem ser aceita. Diga isso antes de rodar. O script
repete o aviso na nota de leitura e no cabeçalho do índice.

**Nível 3, nada sai.** O modelo entrega a linha de comando e a explicação de como ler o
`threads.csv` e classificar à mão, com as regras de `references/classificacao.md` na tela. A
pessoa responde apenas "fechou" ou "não fechou".

Regra que não se quebra: quando o dado é sensível, leitura e filtragem são locais. Nunca peça
o corpo das mensagens colado para resumir.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**Pedido de escrever a resposta.** Recusa, com o motivo: para redigir não há gabarito nem
acesso ao dado, e a resposta gerada só seria verificável depois de alguém que sabe o assunto
ler inteiro, o que custa mais do que escrever. A triagem, ao contrário, se confere abrindo a
caixa no mesmo dia. Ofereça em troca o índice e, se a pessoa insistir, diga que quem assina
escreve.

**Pedido de conectar na caixa.** Recusa. A skill não tem conector e não vai ter enquanto
depender da TI. O caminho é a pasta local, e ele funciona hoje.

**Pedido de apagar, arquivar, mover ou marcar como lido.** Recusa. A skill lê e escreve o
índice. Mudança na caixa é da pessoa, no cliente de e-mail dela.

**Arquivo `.msg`.** O script é biblioteca padrão e não lê o formato do Outlook clássico. Os
`.msg` são contados, nomeados em `nao-lidos.csv` e ficam fora do índice. A saída é baixar as
mesmas mensagens pelo webmail, que entrega `.eml`. Índice entregue com `.msg` na pasta e sem
essa decisão registrada está incompleto.

**Pedido dentro de anexo.** O anexo não é aberto. Thread cujo corpo só diz "segue anexo" vai
para `não classificado`, com o motivo escrito, e não para ciência.

**Caixa sem os Enviados do período.** O gabarito do passo 7 some. O caminho derivado está no
próprio passo 7: triar um dia à mão antes de rodar. Se nem isso for possível, rode com
`--validacao "nao validada"`: o índice sai, com o aviso em destaque no cabeçalho e código de
saída 2.

---

## Referência

A pasta da skill fica em `~/.claude/skills/triagem-de-caixa-de-email/` depois de instalada.
Os arquivos de referência são lidos por esse caminho, e os scripts são chamados pelo caminho
completo.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/triagem-de-caixa-de-email/references/classificacao.md` | As seis classes com os sinais que decidem cada uma, as quatorze confusões que derrubam a triagem, como o prazo entra no índice e a ordem dos itens. Leia antes de classificar a primeira mensagem. |
| `~/.claude/skills/triagem-de-caixa-de-email/scripts/extrair.py` | Leitura em lote de `.eml`, agrupamento em threads e escrita do CSV que a classificação lê. Python de biblioteca padrão. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/triagem-de-caixa-de-email/scripts/montar-indice.py` | Escrita do entregável a partir do rastro mais `classes.csv` e `decisoes.csv`: ordem, contagem, formato, fechamento e as recusas que impedem índice incompleto. Python de biblioteca padrão. |
| `~/.claude/skills/triagem-de-caixa-de-email/scripts/testar.py` | Teste de regressão dos dois scripts, biblioteca padrão apenas. Gera os `.eml` em diretório temporário, roda e compara. Cada caso é nomeado pelo defeito que prova, não pelo tema: mensagem das 22h30 que sumia do recorte do próprio dia por conversão para UTC; linha de citação do Gmail em português que não era cortada e fabricava prazo da mensagem antiga; thread `NC 4412` que rachava em duas linhas por o assunto ter menos de oito caracteres; colega de mensagem única classificado como tendo respondido alguém; `.DS_Store` derrubando toda rodada para o código 1; pasta só com `.msg` saindo com mensagem de recorte de data; arquivos de mesmo nome em subpastas sendo fundidos numa thread só; mensagem em subpasta sumindo sem linha numa rodada sem `--recursivo`, com as identidades fechando e código 0, caso que roda de propósito sem a opção; link para pasta, link quebrado e pasta sem permissão saindo sem linha; rodapé gravado como linha de dados no CSV; índice gravado com thread faltando; arquivo não lido sem decisão. Mais os casos de sempre: thread por cabeçalho e por assunto, assunto genérico, lista, ausência, prazo, cópia, mensagem minha, HTML, iso-8859-1, `.eml` vazio, `--sem-corpo` e os erros de entrada. Rode `python3 ~/.claude/skills/triagem-de-caixa-de-email/scripts/testar.py` depois de qualquer mudança, ou `py -3 "$env:USERPROFILE\.claude\skills\triagem-de-caixa-de-email\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
