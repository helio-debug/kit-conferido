# Regras de classificação da triagem

Este arquivo é lido antes de classificar qualquer mensagem. Ele define as seis classes, os
sinais que decidem cada uma, as confusões que derrubam a triagem, e como o prazo entra no
índice.

**As colunas citadas aqui são as de `threads.csv`**, que é o arquivo que a
classificação lê. `meu_papel`, uma linha por mensagem, está em `mensagens.csv`,
e em `threads.csv` ele aparece consolidado como `meu_papel_maximo`. Coluna que
você não achar em `threads.csv` está no arquivo errado: não classifique no olho.

**A unidade é a thread, não a mensagem.** A classe é da thread inteira e é decidida pela
última mensagem recebida, olhando o histórico. Classificar mensagem por mensagem produz o
mesmo pedido em três linhas do índice, e a pessoa responde três vezes.

**Dúvida vai para `nao_classificada`, nunca para `ruido`.** Os dois erros da triagem não
custam a mesma coisa. Mandar para o índice uma mensagem que não precisava estar lá custa
quinze segundos de leitura. Mandar para o ruído um pedido com prazo custa o prazo.

---

## As seis classes

### 1. `exige_resposta_sua`

Alguém pede alguma coisa de você, e ninguém do seu lado respondeu ainda.

*Sinais a favor:* pergunta direta no corpo; verbo de pedido dirigido a você (confirma,
envia, aprova, informa, valida, assina, libera); seu endereço em
`meu_papel_maximo = para`; a thread termina em mensagem externa;
`respondi_depois_da_ultima_externa = nao`.

*Sinais contra:* a última mensagem da thread é sua; o corpo só agradece ou confirma
recebimento.

*Não use `tenho_mensagem_na_thread` como sinal.* Ela só diz que existe mensagem sua em
algum ponto da thread, e isso acontece justamente quando foi você quem abriu o assunto.
O que decide é `respondi_depois_da_ultima_externa`. Quando essa coluna sai como
`indeterminado`, falta data em alguma mensagem: a thread vai para `nao_classificada`.

*Quando `meu_papel_maximo = nao_aparece`*, a mensagem chegou por lista de distribuição
ou por cópia oculta e o cabeçalho não decide nada. Procure o seu nome, o seu cargo ou o
nome da sua área dentro do corpo: achou com verbo de pedido, é `exige_resposta_sua`; não
achou, é `so_ciencia`; corpo vazio ou só anexo, é `nao_classificada`. Se `nao_aparece`
passar de um quinto das threads, falta declarar um apelido ou uma caixa compartilhada no
passo 3.

### 2. `cobranca_com_prazo`

É `exige_resposta_sua` com uma das duas coisas: prazo escrito na mensagem, ou reiteração,
que é o mesmo pedido chegando de novo do mesmo remetente sem resposta sua no meio.

Sai como classe própria porque é o que ordena o índice e o que gera consequência fora da
sua área. No índice ela aparece no mesmo bloco de `exige_resposta_sua`, no topo.

*Sinais a favor:* `marcas_de_prazo` preenchida e confirmada no corpo; `n_mensagens` maior
que um com todos os remetentes externos e `respondi_depois_da_ultima_externa = nao`;
assunto repetindo com `Re:` acumulado; palavras de reiteração (reiterando, segue
pendente, sem retorno, reenviando, aguardo posição desde).

*Sinais contra:* `marcas_de_prazo` que vem de data citada dentro de texto antigo. Confira no
corpo antes de aceitar.

### 3. `respondida_por_outro`

A última mensagem da thread é de alguém do seu lado que não é você.

*Sinal obrigatório:* `colega_respondeu_anterior = sim`. A coluna só sai `sim` quando o
colega respondeu alguma mensagem anterior de outra pessoa que não você. Sem ela a classe
não pode ser afirmada, e o `montar-indice.py` recusa a rodada.

*Sinais a favor:* `ultimo_e_colega = sim` e `ultimo_e_meu = nao`.

**Thread de uma única mensagem nunca entra nesta classe**, por mais que
`ultimo_e_colega = sim`: colega só responde o que alguém perguntou antes. Notificação do
sistema interno esperando a sua aprovação, colega encaminhando pedido de cliente e área
vizinha fazendo pergunta direta são todas mensagem única de remetente interno, e nenhuma
é resposta de ninguém. Thread interna de mensagem única com verbo de pedido dirigido a
você é `exige_resposta_sua`; sem verbo de pedido é `so_ciencia`; em dúvida,
`nao_classificada`.

*O que fazer com ela:* conferir se a resposta cobre o que foi pedido, não responder de novo.
É a classe que mais devolve tempo e a que mais esconde erro: leia a confusão 4.

*Quando `colega_respondeu_anterior` sai como `desconhecido`*, a lista de colegas não foi
declarada. Quando sai como `indeterminado`, falta data em alguma mensagem e a ordem da
thread não vale. Nos dois casos a thread vai para `nao_classificada`.

### 4. `so_ciencia`

Ninguém pede nada de você, e a thread não tem pergunta dirigida a você.

*Sinais a favor:* `meu_papel_maximo = copia`; corpo informativo sem interrogação e sem verbo de
pedido; comunicado de área; ata; encaminhamento de documento já resolvido.

*Sinais contra:* qualquer um dos sinais das classes 1 e 2. Estar em cópia não decide nada
sozinho: leia a confusão 2.

### 5. `ruido`

Mensagem que não pede nada de ninguém no seu contexto e não informa nada que você precise
saber. **Exige evidência positiva.**

*Evidência aceita:* `sinal_automatico` com `list-unsubscribe` ou `list-id`;
`resposta_automatica = sim`; confirmação de leitura; boletim, propaganda, convite de evento
comercial não solicitado; notificação de sistema em massa sem ação pendente sua.

*Não é evidência:* remetente desconhecido; assunto curto; mensagem em inglês; ausência de
anexo.

### 6. `nao_classificada`

Tudo que não reuniu evidência suficiente. Entra no índice, no último bloco, com o motivo da
dúvida em uma linha. Este bloco vazio em toda rodada é sinal de que a triagem está
adivinhando, não classificando.

---

## Quatorze confusões que derrubam a triagem

1. **"Para conhecimento" que termina em pergunta.** A abertura diz ciência e o último
   parágrafo pede confirmação. Leia o fim do corpo, não só o começo.
2. **Estar em cópia não é só ciência.** A pergunta pode estar no meio do corpo, dirigida a
   você pelo nome ou pelo cargo. Procure o seu nome dentro do texto antes de mandar para
   ciência.
3. **Estar em "Para" não é pedido.** Lista de distribuição interna joga a área inteira no
   campo Para. O que decide é o corpo.
4. **A resposta do colega pode não cobrir tudo.** Ele respondeu o preço e ninguém respondeu
   o prazo. `respondida_por_outro` não encerra a thread: ela troca "responder" por
   "conferir se cobriu".
5. **Notificação de sistema com ação pendente não é ruído.** Requisição esperando sua
   aprovação em fila chega com cara de robô e tem prazo. O sinal é o verbo de aprovação com
   você nomeado como aprovador.
6. **Encaminhamento sem texto novo.** Chega `Enc:` com corpo vazio e o pedido está na
   mensagem antiga. O corpo novo não diz o que se quer, então vai para `nao_classificada`,
   não para ruído.
7. **Thread montada por assunto pode juntar dois pedidos distintos.** Quando
   `metodo_da_thread = assunto`, confirme que é o mesmo caso antes de tratar como um item só.
8. **A ordem por data pode estar errada.** Mensagem sem cabeçalho de data, ou com data de
   servidor desajustado, cai no fim da thread sem ser a última. Confira quando a última
   mensagem não fizer sentido como resposta da anterior.
9. **Agradecimento encerra.** "Obrigado, recebido" é ciência e fecha a thread, mesmo que a
   thread inteira antes fosse um pedido.
10. **Prazo do remetente não é prazo seu.** "Preciso até sexta" de quem não manda no seu
    trabalho continua sendo prazo declarado. Entra no índice com o autor nomeado, e a
    decisão de atender é de quem lê.
11. **Resposta automática de ausência não é resposta.** O seu pedido continua aberto. A
    thread volta para `exige_resposta_sua`, com a data de retorno anotada.
12. **A caixa não sabe o que foi resolvido por telefone ou por mensagem instantânea.** Toda
    cobrança sai com essa ressalva escrita no índice, uma vez, no cabeçalho do bloco.
13. **Thread que você abriu não está respondida.** Mensagem sua no meio da thread não quer
    dizer que o último pedido foi atendido. O caso comum de cobrança na indústria é você
    pedir, o outro lado responder com uma pergunta nova, e a pergunta ficar parada. O que
    decide é `respondi_depois_da_ultima_externa`, nunca `tenho_mensagem_na_thread`.
14. **Você não aparecer no cabeçalho não é ciência.** Lista de distribuição e cópia oculta
    entregam a mensagem com `meu_papel_maximo = nao_aparece`, e é assim que chega a maior
    parte do comunicado interno. O cabeçalho não decide: o que decide é o seu nome, o seu
    cargo ou o nome da sua área dentro do corpo.

---

## O prazo

**Só entra o que está escrito na mensagem.** Prazo inferido do assunto, do remetente ou da
urgência aparente sai como `sem prazo declarado`.

| Como aparece | Como entra no índice |
|---|---|
| Data completa (`25/09`, `25/09/2026`, `25 de setembro`) | Data em AAAA-MM-DD |
| Dia da semana (`até sexta`) | Data em AAAA-MM-DD, calculada a partir da data da própria mensagem, marcada com `(derivado de "até sexta")` |
| `hoje`, `amanhã`, `fim do dia` | Data em AAAA-MM-DD, calculada a partir da data da mensagem, marcada como derivado |
| `em 5 dias úteis` | Data em AAAA-MM-DD, com o critério de dia útil declarado uma vez no cabeçalho do índice |
| `urgente`, `com brevidade`, `assim que possível` | `sem prazo declarado`, e a palavra usada entre aspas na coluna do pedido |
| Nada | `sem prazo declarado` |

Data ambígua entre dia e mês (`05/09` contra `09/05`) não é resolvida no chute: escreva a
forma literal entre aspas e marque a thread como `nao_classificada` se o prazo for o que
decide a ordem.

---

## Ordem do índice

1. Prazo declarado já vencido, do mais antigo para o mais novo.
2. Prazo declarado hoje.
3. Prazo declarado futuro, por data.
4. Sem prazo declarado, pelo maior `dias_desde_a_ultima`.
5. Sem prazo declarado e recente.

Dentro do mesmo grupo, `cobranca_com_prazo` vem antes de `exige_resposta_sua`.

---

## O que estas regras não classificam

**Anexo.** O pedido que está dentro da planilha ou do PDF anexo não é lido. A coluna
`n_anexos` diz que existe anexo, e nada mais. Thread cujo corpo só diz "segue anexo" e nada
mais vai para `nao_classificada`, com o motivo escrito.

**Imagem colada no corpo.** Pedido em captura de tela não é texto e não é lido.

**Idioma fora de português e inglês.** Os sinais de pedido e de prazo deste arquivo estão
nesses dois idiomas. Mensagem em outro idioma vai para `nao_classificada`.
