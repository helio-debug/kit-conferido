---
name: linha-de-base-antes-de-automatizar
description: >
  Recebe "vamos automatizar X" e devolve a ficha do antes: o valor medido da
  tarefa hoje, com a data das observações, o método de medição, o esforço em
  horas para medir, o validador nomeado e a conferência contra um número que
  alguém já tinha, mais o gabarito de dez a trinta casos já feitos à mão com o
  resultado da época. Separa o que foi medido do que foi dito: fala de gestor
  entra carimbada como estimativa declarada, com quem disse e quando, e não
  entra em conta nenhuma. Faltando um desses seis requisitos, a ficha não é
  emitida, e a skill diz qual é o projeto de verdade: medir. Use SEMPRE que
  aparecer: "vamos automatizar isso", "dá para automatizar essa tarefa",
  "quanto tempo isso toma hoje", "como eu provo que melhorou", "não temos
  indicador disso", "me disseram que são tantas horas por semana", "qual é o
  ganho desse projeto", "preciso do antes e do depois", "monta a linha de
  base", "quero medir esse processo antes de mexer", "o piloto funcionou?",
  "confere a saída do sistema contra os casos antigos", "qual foi a taxa de
  acerto", "o robô errou nesses casos". NÃO use para decidir o que
  automatizar, para dimensionar prazo ou esforço de projeto, nem para escolher
  ferramenta: ela entrega o número do antes e para ali.
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que
esta skill ocupe o lugar das outras.

| Caso | Skill | Relação |
|---|---|---|
| Descrever a área uma vez, para as outras skills lerem | `ficha-da-area` | Rode antes. Ela dá o vocabulário, os sistemas e o que cada um exporta, que é onde o número do antes costuma já estar |
| Duas fontes que deveriam dizer a mesma coisa | `conferencia-entre-duas-fontes` | O registro que vai virar medição costuma precisar de conferência antes. Ela também é insumo: a contagem de divergências dela é uma linha de base pronta |
| Documento que precisa virar tabela antes de qualquer conta | `extracao-de-documento-para-tabela` | Folha de apontamento em papel vira o `observacoes.csv` desta skill por ela |
| Caixa de e-mail que precisa ser triada | `triagem-de-caixa-de-email` | O volume triado por ela é contagem, e contagem é meio caminho da linha de base |
| Cotações de fornecedores diferentes | `comparativo-de-cotacoes` | Quer medir quanto custa montar o quadro hoje? A medição é aqui, a montagem é lá |
| Relatório refeito todo mês do mesmo jeito | `relatorio-recorrente` | Ele é o candidato mais comum a chegar aqui com "vamos automatizar" |
| Registrar um desvio de processo | `registro-de-anomalia` | A contagem de registros dele vira indicador, e indicador com histórico dispensa metade desta skill |
| Procedimento conferido contra a norma | `padrao-conferido-contra-norma` | A contagem de furos dele é uma linha de base de conformidade |
| Achar o documento que ninguém acha | `indice-do-acervo-da-area` | Rode antes de concluir que o número do antes não existe. Ele costuma existir, numa pasta que ninguém abre |

---

# Linha de base antes de automatizar

Alguém diz "vamos automatizar X". A conversa vai direto para ferramenta, prazo e
tela. Seis meses depois ninguém consegue dizer se melhorou, porque ninguém
anotou como era antes. O projeto não fracassa, o que é pior: ele fica sem
veredito, e o próximo pedido começa da estaca zero.

Esta skill faz a pergunta que trava a conversa e destrava o projeto: **qual é o
número de hoje, medido por quem, quando, e como?**

Ela termina em arquivo. A saída é um conjunto de arquivos gravados em disco, com
o caminho informado. Resposta em prosa dizendo que a tarefa toma mais ou menos
tanto tempo é exatamente o que esta skill existe para substituir.

**Ela não acessa ERP, não acessa ponto eletrônico e não acessa servidor de
arquivos.** As observações são anotadas ou exportadas antes, num arquivo local.
Ela diz isso na cara antes de começar.

---

## Leis de ferro

1. **Fala nunca vira valor medido.** "Isso toma um dia por semana" entra na
   ficha carimbado: quem disse, quando disse, e a palavra estimativa colada.
   Fica fora de toda média, soma e comparação. Não é desprezo pela fala: é ela
   que aponta onde medir. É o uso dela como número que quebra o projeto depois,
   quando alguém compara o depois medido contra um antes que ninguém mediu.
2. **A ficha não sai sem os seis:** valor medido, data das observações, método
   reconhecido, esforço em horas, validador nomeado e a conferência contra o
   gabarito da lei declarada. Os seis juntos. Faltando um, a skill escreve o
   plano de medição e diz a frase inteira: o projeto de verdade, agora, é medir.
   `--conferida-contra-gabarito nao-conferida` é resposta válida: ela não trava
   a ficha, carimba o topo dela.
3. **A ficha diz o antes e para ali.** Ela não diz o que automatizar, em quanto
   tempo nem por quanto. A fronteira está na seção de falha honesta, e é
   deliberada.
4. **O gabarito é a segunda metade, não um anexo.** A ficha prova o antes. Sem
   gabarito, nada prova o depois, e o projeto volta a depender de opinião.
5. **Na dúvida entre descartar e reportar, reporte.** Nenhuma observação sai da
   conta em silêncio. O que não entrou sai num arquivo próprio, com a causa.
6. **Divergência contra o gabarito é classificada por pessoa**, em erro do motor
   e erro do gabarito. Enquanto houver uma indeterminada, a rodada não fecha:
   as duas conclusões levam a ações opostas.
7. **Contagem que não fecha invalida a rodada.** As identidades da seção
   Fechamento são obrigatórias.

---

## Esta skill tem dois gabaritos, e confundi-los estraga os dois

**O gabarito da lei do kit**, que vale para todas as dez skills: antes de usar
no trabalho real, a pessoa roda a skill sobre um caso que ela já fez à mão e
compara. Aqui isso é o passo 8.

**O gabarito que esta skill entrega**, que é metade do produto: de dez a trinta
casos da tarefa, já feitos à mão, com o resultado da época, guardados para
conferir o motor candidato depois. É o passo 7.

O primeiro valida a skill. O segundo valida o que vier a ser construído. Os dois
usam a palavra gabarito e não são a mesma coisa. No texto adiante, o segundo
aparece sempre como **gabarito de casos**.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Existindo, use o vocabulário da área,
os sistemas em uso e o que cada um exporta: é ali que o número do antes costuma
já estar, gravado por um sistema e nunca extraído. Não existindo, declare em voz
alta "rodando sem ficha da área" e siga normalmente.

Rodar sem ficha não degrada a medição. Só obriga a perguntar à pessoa quais
sistemas carimbam data nessa tarefa, que é parte do passo 5.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi
carregada ou se a rodada está sem ficha e, carregada, repete o status
gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir o arquivo

Quatro perguntas, nesta ordem:

1. **O dado é sensível?** As cinco classes: nome de pessoa; folha de pagamento,
   salário e remuneração individual; preço de fornecedor identificado; dado de
   cliente identificado; projeto sob sigilo. Folha, salário e remuneração
   individual não entram em nenhum modo, e aqui a advertência é literal: uma
   planilha que liga nome a tempo gasto é insumo de avaliação de desempenho, e
   basta parecer isso para a área parar de anotar. **Nesta skill a resposta é
   quase sempre sim**, porque o livro-caixa nomeia quem fez e quem observou.
   Ofereça sempre o modo derivado, que aqui é `--anonimizar-pessoa` mais o
   script local.
2. **Essa medição vai se repetir?** Havendo um depois, rode pelo script desde a
   primeira rodada: o valor está em repetir igual, e leitura não repete igual.
   Antes e depois medidos por métodos diferentes não se comparam.
3. **Quantas observações existem hoje?** Define leitura ou script pela tabela do
   passo 6.
4. **Existe alguma tarefa da área já medida, para servir de gabarito da skill?**
   É o passo 8. Não existindo, ele diz o que fazer.

**Critério de conclusão:** as quatro respostas estão registradas, e a escolha
entre leitura e script está feita antes de qualquer arquivo ser aberto.

---

## Passo 3: nomear a tarefa, o caso e a unidade

Três frases curtas, e as três vão para a ficha:

- **A tarefa.** Uma frase com sujeito e verbo. "Conferir a lista contra o
  desenho" é tarefa. "Melhorar o processo" não é.
- **O caso.** Onde começa e onde termina. Comece quando chega o quê, termine
  quando sai o quê. Duas pessoas que discordam disso produzem números
  diferentes e ninguém descobre por quê.
- **A unidade.** Minutos por caso, casos por dia, reprovas por mil, horas por
  semana. Escolha uma.

Querendo o total por janela (por semana, por mês), declare também o volume de
casos da janela. O volume que vem de contagem entra com `--volume-medido`. O
volume que vem de fala entra sem essa opção, e a ficha carimba o total derivado
como derivado de volume declarado. Contar o volume costuma ser mais barato que
medir a duração, e é o primeiro atalho a tentar.

**Critério de conclusão:** as três frases estão escritas e a pessoa concordou
com a fronteira do caso.

---

## Passo 4: separar o que foi medido do que foi dito

Toda linha que vai para o `observacoes.csv` carrega a coluna `origem`, com dois
valores possíveis: `medido` ou `declarado`.

| Origem | O que é | Para onde vai |
|---|---|---|
| `medido` | Alguém observou, anotou ou o sistema carimbou | Entra na conta, com data, observador e duração |
| `declarado` | Alguém disse | Sai carimbado, com quem disse e quando, fora de toda conta |

Qualquer outro valor na coluna é reportado como origem não reconhecida e fica
fora da conta. Tratar o que não se entende como medido é o caminho mais curto
para uma fala virar número.

**Três colunas são obrigatórias:** `caso`, `quem` e `origem`. `quem` é quem
executou, e ela é obrigatória porque a representatividade se mede sobre quem faz,
não sobre quem anotou. Onde o registro não diz quem executou, escreva `nao
identificado`: a ficha sai com a representatividade marcada como não demonstrada,
que é o que aconteceu de fato. Os nomes usuais de folha de apontamento são
reconhecidos sem renomear coluna: `OP`, `Operador`, `Tempo (min)`, `Quem
observou`.

O formato do arquivo:

```
caso;data;quem;origem;metodo;inicio;fim;duracao_min;resultado;observador;canto;obs
OP-1001;2026-03-02;Ana;medido;cronometragem;09:00;09:22;;ok;Bruno;nao;
OP-1002;2026-03-02;Ana;medido;cronometragem;;;35;ok;Bruno;nao;
MEM-01;2026-03-06;Gerente de area;declarado;;;;600;;;;disse que toma um dia
```

Duração entra por `duracao_min` ou pelo par `inicio` e `fim`. Vindo os dois e
discordando em mais de um minuto, a linha fica fora da conta com a divergência
escrita: escolher uma das duas em silêncio é escolher o número da linha de base
no chute.

Os formatos que a folha carrega de verdade entram e a conversão fica escrita na
linha do livro: `1h10`, `0:50`, `30 min`, `1,5 h`. Dois não entram, e a causa é
dita: duração aproximada (`aprox 40`, `cerca de 40`) é fala e não medição, e a
linha deve virar `origem declarado`; e valor com separador de milhar (`1.000`) é
ambíguo, porque pode ser mil e pode ser um.

**Critério de conclusão:** toda linha do arquivo tem `origem` preenchida, e a
pessoa viu a lista do que foi classificado como fala.

---

## Passo 5: escolher o método e declarar o esforço de medir

Leia `references/metodos-de-medicao.md` e escolha um dos cinco:
`cronometragem`, `autoapontamento`, `contagem-de-registro`,
`reconstrucao-de-rastro`, `sondagem-aleatoria`.

Declare junto o esforço em horas para medir. Ele é parte da ficha porque é o que
transforma "vamos medir" em decisão: medição que custa mais que o problema não
acontece, e é melhor descobrir isso agora.

**Antes de escolher, procure o número que já existe.** Registro que o sistema
grava e ninguém exporta, planilha de controle da área, relatório antigo que
trazia o indicador. A ordem de custo está na referência. Achando, a medição vira
conferência e custa uma tarde.

**Nomeie o validador.** Uma pessoa, com nome, que confere o número e responde
por ele. Não é formalidade: número sem dono não é contestado, e número que
ninguém contesta é o que trava a conversa quando o depois chegar.

**Critério de conclusão:** método, esforço em horas e validador nomeado estão
escritos, e a pessoa confirmou que procurou o registro já existente.

---

## Passo 6: rodar o livro-caixa

| Observações | Como rodar |
|---|---|
| Até 40 | Leitura em contexto, com fechamento obrigatório |
| Acima de 40 | Script obrigatório |
| Qualquer número, se o dado é sensível | Script obrigatório |
| Qualquer número, se vai haver um depois | Script obrigatório |

O limite é baixo de propósito, e o motivo é o mesmo das skills irmãs: leitura
omite linha sem gerar erro, não repete igual na semana seguinte e não deixa
rastro para alguém refazer a rodada. Numa linha de base isso é fatal, porque o
valor inteiro do artefato está em ele ser repetível daqui a seis meses.

**Dependência:** Python 3.8 ou superior, biblioteca padrão apenas. Sem
instalação, sem rede, sem escrita no arquivo de entrada.

A instalação copia a pasta da skill para
`~/.claude/skills/linha-de-base-antes-de-automatizar/`. A rodada acontece na
pasta dos arquivos de trabalho, e por isso o script é sempre chamado pelo
caminho completo.

No macOS e no Linux:

```
python3 ~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/livro-caixa.py \
    --observacoes observacoes.csv \
    --tarefa "Conferir a lista contra o desenho" \
    --unidade "minutos por caso" \
    --janela semana --volume-janela 40 \
    --metodo cronometragem --esforco-horas 6 \
    --validador "Nome de quem responde pelo numero" \
    --conferida-contra-gabarito tres-casos-a-mao --numero-da-pessoa 24 \
    --saida linha-de-base-2026-09-20
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho
vai entre aspas com `$env:USERPROFILE` no lugar do `~`, e a linha continua com
acento grave no lugar da barra invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\linha-de-base-antes-de-automatizar\scripts\livro-caixa.py" `
    --observacoes observacoes.csv `
    --tarefa "Conferir a lista contra o desenho" `
    --unidade "minutos por caso" `
    --metodo cronometragem --esforco-horas 6 `
    --validador "Nome de quem responde pelo numero" `
    --conferida-contra-gabarito tres-casos-a-mao --numero-da-pessoa 24 `
    --saida linha-de-base-2026-09-20
```

Antes de emitir a ficha, rode com `--so-plano`. Ele lê, classifica, escreve o
plano de medição e o que ficou fora, e não emite ficha. Serve para a pessoa
aprovar a classificação antes de ver um número. **A rodada de aprovação usa
diretório próprio**, senão a emissão seguinte para com "o diretório já existe":

```
... --so-plano --saida linha-de-base-2026-09-20-plano
... --saida linha-de-base-2026-09-20
```

Gravar por cima do mesmo diretório é possível e é declarado, com `--forcar`.

As opções que mudam o resultado, e todas aparecem no artefato:

| Opção | O que faz |
|---|---|
| `--conferida-contra-gabarito` | `medicao-anterior`, `tres-casos-a-mao` ou `nao-conferida`. Obrigatória para emitir a ficha |
| `--numero-da-pessoa` | O número que a pessoa já tinha. Obrigatório nos dois primeiros caminhos, e a ficha imprime os dois lado a lado com a diferença |
| `--linha-de-total` | Tira da conta o caso declarado como linha de total, e só ele |
| `--virada-de-dia` | Aceita fim menor que início como virada de dia |
| `--campo-multilinha` | Declara que o arquivo tem quebra de linha dentro de célula de texto |
| `--anonimizar-pessoa` | Nome de pessoa vira pseudônimo em todo artefato |
| `--forcar` | Grava por cima de diretório existente |
| `--so-plano` | Escreve o plano e não emite ficha |
| `--estrito` | Qualquer pendência derruba a rodada com 2 |

| Código de saída | Significado |
|---|---|
| 0 | Ficha emitida, representatividade demonstrada, nada perdido |
| 1 | Ficha emitida com pendência declarada: representatividade, ou conferência contra o gabarito fora do critério |
| 2 | `--estrito` e existe pendência |
| 3 | Erro de entrada, leitura que perdeu linha, fechamento que não fecha, zero observação medida, ou falta um dos seis requisitos: valor medido, data das observações, método reconhecido, esforço em horas, validador nomeado, conferência declarada. A ficha não é emitida |
| 4 | Rodada `--so-plano` |
| 5 | Ficha emitida, mas ficou observação fora da conta, ou entrou na conta sob suspeita não confirmada |

O código 3 para "zero observação medida" é o coração da skill: um arquivo cheio
de falas de gestor não é uma medição, e sair com 0 ali seria emitir uma ficha
que prova o contrário do que parece provar.

**Suspeita de linha de total.** Caso cujo código contém `TOTAL`, `SOMA`,
`GERAL`, `SUBTOTAL`, `ACUMULADO` ou `MEDIA` **continua na conta** e sai
reportado. A skill não apaga linha por palavra encontrada no código: item
legítimo com `GERAL` no código já foi apagado como linha de total em outra
rodada, em silêncio, com código 0. Sendo total mesmo, declare em
`--linha-de-total` e ela sai da conta declaradamente. É a diferença entre não
contar de propósito e não contar por descuido.

**Representatividade.** Menos de cinco observações, ou todas do mesmo dia, ou
todas executadas pela mesma pessoa, e a ficha sai com `representatividade: nao
demonstrada`. Ela sai mesmo assim, marcada: serve para conversar e não serve para
comparar contra um depois. A contagem é de **quem executou**, não de quem
observou: três observadores acompanhando a mesma pessoa não cobrem variação de
quem faz, e a ficha imprime as duas contagens em linhas próprias.

**Duas coisas derrubam a rodada com código 3 mesmo com tudo fechando.** Registro
que ocupou mais de uma linha física do arquivo, que é o sintoma de aspa dupla não
fechada: o leitor de CSV engole o resto do arquivo dentro de uma célula de texto
e a conta sai de um terço das observações. Sendo quebra de linha de propósito,
declare `--campo-multilinha`. E identidade de fechamento que não fecha.

**Duplicata exata** de observação, mesmo caso com a mesma data, a mesma pessoa e
a mesma duração, fica fora da conta e vai para o arquivo do que ficou fora:
copiar e colar linha em planilha de apontamento é o erro mais comum do insumo. O
mesmo caso com duração diferente continua na conta, com alerta, porque são duas
execuções.

**Critério de conclusão:** o diretório tem os quatro arquivos, o bloco de
fechamento tem `fecha` em todas as linhas, e cada linha do bloco de verificações
foi lida e respondida. Código 5 não é falha da rodada: é a rodada dizendo que o
número só vale depois de alguém responder pelo que ficou fora.

---

## Passo 7: montar o gabarito de casos

É a metade que quase ninguém empacota, e é o que separa um projeto que termina
de um que fica em suspenso.

**Quantos.** Dez casos para autorizar um piloto, trinta para autorizar
produção.

**Quais.** Casos reais, já feitos à mão, com o resultado da época e a fonte de
onde ele saiu. Não invente caso e não refaça agora: o valor está em o resultado
ter sido produzido antes de existir motor nenhum, por alguém que não sabia que
ia ser conferido.

**Casos de canto, de propósito.** O catálogo está na referência: campo vazio,
valor fora do padrão, registro duplicado, unidade diferente, texto ilegível,
exceção que a área conhece de cor, caso do limite, e o caso em que a pessoa
errou na época. O último é o mais valioso e o mais esquecido: sem ele não dá
para distinguir erro do motor de erro do gabarito depois.

**Piso de cobertura:** um caso de canto a cada cinco, no mínimo dois, e ao menos
duas classes distintas. O script recusa autorizar o estágio quando não bate.

O formato:

```
caso;canto;entrada;resultado_da_epoca;quem_fez;data;fonte
OP-1001;nao;lista-1001.pdf;42 itens conferidos, 3 divergencias;Ana;2026-03-02;pasta da area
OP-1042;campo vazio;lista-1042.pdf;sem peso na linha 7, devolvido;Ana;2026-03-09;pasta da area
```

**Critério de conclusão:** o `gabarito.csv` existe, tem o número de casos do
estágio pretendido, e `divergencia.py --so-cobertura` devolve todas as checagens
como atende.

---

## Passo 8: a lei do gabarito, aplicada a esta skill

Antes de usar no trabalho real, rode sobre uma tarefa da área **cuja duração já
tenha sido medida à mão por alguém**, e compare o número que sai com o número
que essa pessoa tinha.

**A declaração é por opção, e ela é obrigatória para emitir a ficha.** Três
valores, em ordem de preferência:

1. `--conferida-contra-gabarito medicao-anterior --numero-da-pessoa <valor>`.
   **Existe medição anterior:** um estudo de tempos antigo, uma planilha de
   apontamento de um mês fechado, um indicador que a área acompanhava. Monte o
   `observacoes.csv` com as observações daquela época e passe o número que foi
   entregue na época.
2. `--conferida-contra-gabarito tres-casos-a-mao --numero-da-pessoa <valor>`.
   **Não existe, mas dá para produzir em uma tarde:** cronometre três casos à
   mão, anote em papel, calcule a média de cabeça e passe esse número. Depois
   rode a skill sobre as mesmas três observações. É um teste pequeno, e ele pega
   a maioria dos erros de fronteira do caso e de unidade.
3. `--conferida-contra-gabarito nao-conferida`. **Não existe nada.** A ficha sai
   com `NAO CONFERIDA CONTRA GABARITO` escrito no topo dela, e a segunda rodada,
   com a medição já feita, é que vira a ficha de referência. Ela não trava, e a
   ressalva fica no artefato, não na conversa.

Nos caminhos 1 e 2 a ficha imprime os dois números lado a lado com a diferença
percentual. **Diferença acima de 20%, que é o critério desta skill, vira
pendência declarada e a rodada devolve código 1.** Na quase totalidade dos casos
a causa é uma de três: a fronteira do caso do passo 3 está diferente da que a
pessoa usou, a unidade está diferente, ou a pessoa citou a média e a skill citou
a mediana. Descubra qual antes de mexer no número.

**Critério de conclusão:** a ficha traz a linha `Conferida contra gabarito` com o
caminho usado, e nos caminhos 1 e 2 a seção com os dois números e a diferença.

---

## Passo 9: rodar a conta da divergência

Este passo acontece depois, quando existir um motor candidato. Ele fecha o ciclo
que a ficha abriu.

```
python3 ~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/divergencia.py \
    --gabarito gabarito.csv --motor saida-do-motor.csv \
    --estagio piloto --classificacao classificacao.csv \
    --saida gabarito-2026-09-20
```

No PowerShell, as mesmas três diferenças do passo 6.

A saída do motor é um CSV com `caso;resultado`. O que o script faz com cada
caso:

| Situação | O que significa |
|---|---|
| `diferente` | Os dois lados responderam e não bateram. Precisa de classificação |
| `caso_nao_processado_pelo_motor` | O motor não produziu saída para um caso do gabarito. Isso é resultado, não ausência de dado |
| `caso_fora_do_gabarito` | O motor respondeu um caso que o gabarito não cobre. Não se sabe se acertou |
| `resultado_vazio_no_gabarito` ou `no_motor` | Vazio não é igual. Fica fora da comparação, contado |
| `caso_repetido_divergente_no_gabarito` | O mesmo caso aparece duas vezes no gabarito com resultados diferentes. Não dá para parear |

**Linha que não chega à comparação tem arquivo próprio**, o
`linhas-fora-da-comparacao.csv`, com o lado, o tipo, a causa e o conteúdo da
linha. São quatro tipos: linha vazia, linha descartada na leitura por contagem de
coluna diferente, linha sem código de caso, e duplicata exata colapsada. As três
últimas viram checagem de cobertura dos dois lados.

**Linha descartada na leitura derruba a rodada com código 3.** Enquanto ela
existe, a frase "o motor não produziu saída para este caso" pode ser apenas a
linha do motor que não foi lida, e a pessoa é mandada depurar um motor que
respondeu certo. O caso mais comum é resultado com ponto e vírgula dentro, como
`42 itens conferidos; 3 divergencias`, num arquivo separado por ponto e vírgula.

**A classificação da divergência é a parte que exige pessoa.** Duas classes, e
só duas:

| Classe | O que quer dizer | O que se faz |
|---|---|---|
| `erro-do-motor` | O gabarito está certo e o motor errou | Corrige o motor |
| `erro-do-gabarito` | O motor está certo e o resultado da época estava errado | Corrige o gabarito, e registra que a tarefa manual errava ali |

A segunda é a descoberta que paga a rodada, e é a que some quando ninguém
classifica. Enquanto houver divergência `indeterminado`, a rodada não fecha:
"70% de acerto" sem essa separação pode ser um motor ruim ou um gabarito errado,
e as duas conclusões levam a ações opostas.

**Normalização declarada antes do resultado.** Espaço em excesso é sempre
colapsado. Caixa e acento só com `--ignorar-caixa`. Tolerância numérica só com
`--tolerancia`, e ela aparece no relatório. Sem tolerância declarada, `10` e
`10,0` são resultados diferentes e aparecem na lista: igualar formato em
silêncio esconde, em outro campo, diferença de valor.

| Código de saída | Significado |
|---|---|
| 0 | Tudo processado, tudo bateu, a cobertura autoriza o estágio |
| 1 | Há divergência de resultado |
| 2 | `--estrito` e há divergência sem classificação |
| 3 | Erro de entrada, coluna obrigatória ausente, fechamento que não fecha, linha descartada na leitura em qualquer um dos dois lados, ou nenhum caso pareado |
| 4 | Rodada `--so-cobertura` |
| 5 | Nada divergiu, mas ficou caso fora da comparação, ou a cobertura não autoriza o estágio |

A rodada `--so-cobertura` também usa diretório próprio, ou repete o comando com
`--forcar`.

**O mesmo caso classificado duas vezes com classes opostas é reportado**, e a
rodada não fecha: a segunda linha sobrescrevia a primeira em silêncio, e erro do
motor virava erro do gabarito sem ninguém saber.

**Critério de conclusão:** o fechamento fecha, nenhuma divergência está
`indeterminado`, nenhuma linha ficou fora da comparação, e o bloco de cobertura
devolve atende em todas as checagens para o estágio pretendido.

---

## Passo 10: fechamento

As identidades abaixo saem impressas e vão para os artefatos. Todas devem
fechar. Elas provam que a contabilidade da rodada é consistente, não que a
rodada prestou: o que pode falhar de fato vem no bloco de verificações logo
depois.

No livro-caixa:

```
linhas_lidas = vazias + descartadas_leitura + aspa_nao_fechada + sem_caso
             + total_declarada + origem_desconhecida + estimativas + incompletas
             + duracao_invalida + duplicadas + na_conta
linhas_fisicas_do_arquivo = linhas_ate_o_cabecalho + linhas consumidas pelos registros
registros_lidos_no_arquivo = linhas_lidas
linhas em observacoes-fora-da-conta.csv = tudo que nao entrou na conta
linhas em livro-caixa.csv = na_conta
n da conta = observacoes com duracao valida
```

A segunda identidade é a que compara o leitor de CSV com o **arquivo**, contando
as linhas físicas do texto bruto. Ela existe porque a identidade que compara a
contagem do leitor com a contagem do laço que consome o mesmo leitor está
comparando o leitor com ele mesmo: ela fecha com nove observações engolidas por
uma aspa não fechada.

Na conta da divergência:

```
linhas_gabarito = vazias + descartadas + caso_vazio + distintos + nao_pareaveis
                + extras_iguais + extras_divergentes
linhas_motor    = mesma identidade, do outro lado
linhas em linhas-fora-da-comparacao.csv = vazias + descartadas + caso_vazio
                                        + extras_iguais, dos dois lados
casos_distintos_gabarito = pareados + so_no_gabarito
casos_distintos_motor    = pareados + so_no_motor
pareados   = iguais + diferentes + nao_comparaveis
diferentes = erro_do_motor + erro_do_gabarito + indeterminado
linhas em divergencias-contra-gabarito.csv = tudo que nao e igual
```

Nenhum desses contadores é obtido por subtração, e a regra está escrita no
cabeçalho dos dois scripts. Identidade derivada por subtração fecha sozinha
mesmo com dado faltando, e foi assim que outras rodadas saíram com sucesso
depois de perder linha.

**Critério de conclusão:** as identidades foram impressas com os números e todas
fecham, e cada linha do bloco de verificações foi lida e respondida. Quebrando
uma, a entrega para e o motivo é dito.

---

## Contrato de saída

### Rodada do livro-caixa, quatro arquivos

**1. `plano-de-medicao.md`, primeiro, sempre.** Escrito antes de qualquer
número. Abre com `status: incompleto` e só vira `completo` na última gravação.
Os valores possíveis são `incompleto, sem ficha`, `so-plano, sem ficha`,
`completo` e `invalido, nao fecha`. Traz a fonte, o que a ficha ainda exige, o
método, o esforço, quantas observações faltam para cinco e para dez, as
pendências de representatividade, as estimativas declaradas, as suspeitas de
linha de total e o fechamento.

**2. `livro-caixa.csv`.** Uma linha por observação que entrou na conta, com a
duração normalizada, a situação, o alerta quando houver e o número da linha de
origem.

**3. `observacoes-fora-da-conta.csv`.** Uma linha por observação que não entrou,
com `tipo`, `causa`, `o_que_falta` e o conteúdo da linha. É o arquivo que
impede o descarte silencioso, e o total dele entra no fechamento. Os tipos:
`linha vazia`, `descartada na leitura`, `aspa nao fechada`, `linha sem caso`,
`linha de total declarada`, `origem nao reconhecida`, `estimativa declarada`,
`incompleta`, `duracao invalida`, `duracao aproximada`, `duracao ambigua`,
`duracao nao reconhecida`, `duplicata exata`.

**4. `ficha-do-antes.md`**, e só quando os seis requisitos estão atendidos. O
número com n, mediana, média, mínimo, máximo, amplitude, dias, pessoas que
executaram e observadores distintos; o total por janela quando houver, carimbado e
na unidade da janela; método, esforço, validador e data; a conferência contra o
gabarito da lei, com os dois números lado a lado; a representatividade; as
estimativas declaradas em seção própria; a chamada para montar o gabarito de
casos, com o piso do estágio pretendido; o fechamento; e o limite declarado.

### Rodada da divergência, três arquivos

**5. `cobertura-do-gabarito.md`.** A normalização declarada antes do resultado,
as checagens de cobertura com atende ou não atende, as classes de canto
presentes, as linhas que não chegaram à comparação itemizadas por lado e tipo, a
conta da divergência com as três classes, e o fechamento.

**6. `divergencias-contra-gabarito.csv`.** Tudo o que não é igual, ordenado pelo
que mais preocupa: primeiro os casos que o motor não processou, depois os
repetidos divergentes, os vazios, os que estão fora do gabarito, e por último as
divergências de resultado.

**7. `linhas-fora-da-comparacao.csv`.** Uma linha por linha que não chegou à
comparação, com `caso`, `linha`, `lado`, `tipo`, `causa` e o conteúdo da linha. É
o equivalente do arquivo do que ficou fora na rodada do livro-caixa, e o total
dele entra no fechamento.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de <fonte>. Revisar antes de assinar. Não
substitui responsabilidade técnica.
```

---

## Modo de dado sensível

Ofereça os três níveis antes de pedir o arquivo. O padrão, quando a pessoa não
decide, é o nível 2.

**Nível 1, só o cabeçalho.** A pessoa cola a linha de cabeçalho e duas ou três
linhas com os valores trocados por exemplos inventados que preservem o formato.
Dá para escolher o método, montar o arquivo e devolver a linha de comando
pronta. Nenhum valor real é lido.

**Nível 2, script local (padrão).** A pessoa roda na máquina dela com
`--anonimizar-pessoa`. Nome de pessoa vira `pessoa-1`, `pessoa-2`, o texto livre
da coluna `obs` é suprimido, e o de-para é gravado **fora** do diretório de
saída, porque o diretório é o que se compartilha. Uma exceção declarada: o nome
do validador continua inteiro na `ficha-do-antes.md`, porque ficha sem validador
nomeado não é ficha. No `plano-de-medicao.md` ele nem aparece. A segunda exceção é
declarada na tela: linha em que as colunas não alinham com o cabeçalho sai para o
arquivo do que ficou fora com o texto como está, porque a rodada não sabe qual
campo é texto livre. Leia essas linhas antes de compartilhar o diretório.

**Nível 3, nada sai.** O modelo entrega a linha de comando e a explicação de
como ler os arquivos. A pessoa responde só "fechou" ou "não fechou".

**A regra que não se quebra nesta skill.** Planilha que liga nome de pessoa a
tempo gasto é, na prática, insumo de avaliação de desempenho. Duas providências,
e as duas são do próprio interesse de quem mede: a ficha mede a tarefa e não a
pessoa, e o texto diz isso; e a área é avisada de que os nomes saem
pseudonimizados antes de qualquer anotação começar. Medição que a área suspeita
estar sendo usada contra ela para de acontecer no terceiro dia.

---

## Falha honesta

### Onde esta skill para, e é de propósito

Ela entrega o número do antes. **Ela não diz o que automatizar, em quanto tempo
nem por quanto.** Não é limitação técnica, é escopo:

- **O que automatizar** depende de comparar candidatos entre si, e a comparação
  exige o número de vários, não de um.
- **Em quanto tempo** depende de quem vai construir, do que já existe pronto e
  do que o TI libera. Nada disso está no arquivo de observações.
- **Por quanto** é decisão de quem paga, com informação que esta skill não vê e
  não deve ver.

A ficha carrega essa frase escrita, e ela fica no artefato. Sai do escopo quem
usa o número de uma tarefa medida para projetar ganho em tarefas que ninguém
mediu.

### Os outros limites

**Só existe fala.** É o caso mais comum e não é fracasso da rodada: é o
diagnóstico. A skill escreve o plano de medição, diz quantas observações faltam,
qual o método mais barato e quanto custa, e para. A ficha não sai.

**A tarefa acontece uma vez por mês.** Dez observações levariam dez meses.
Nesse caso o caminho é contagem de registro ou reconstrução de rastro sobre o
histórico, descritos na referência, e a ficha sai com o método carimbado e
confiança menor. Cronometrar não é opção.

**Ninguém consegue definir onde o caso começa.** Para no passo 3. Medir com
fronteira indefinida produz um número que a própria área vai desautorizar na
primeira reunião.

**A tarefa mudou no meio da janela medida.** Observações de antes e de depois da
mudança não formam uma linha de base. Separe em duas rodadas e diga qual vale.

**Não existe gabarito de casos e não dá para montar.** Acontece quando o
resultado da época não foi guardado em lugar nenhum. A ficha sai, marcada:
prova o antes e não vai poder provar o depois. Antes de aceitar isso, rode
`indice-do-acervo-da-area` na pasta da área. O resultado da época costuma estar
lá.

**Arquivo .xlsx binário.** O script é biblioteca padrão e não lê xlsx. Salve
como CSV. Ao converter, formate a coluna de código do caso como Texto antes de
salvar, senão zero à esquerda some e código longo vira notação científica, de
forma irreversível.

**Pedido para estimar o depois.** "Com a automação isso cai para quanto?" não é
desta skill e não é de skill nenhuma do kit. Responder isso sem motor construído
é a fala de gestor que a lei de ferro 1 recusa, agora dita pelo modelo.

---

## Referência

A pasta da skill fica em `~/.claude/skills/linha-de-base-antes-de-automatizar/`
depois de instalada. Os arquivos de referência são lidos por esse caminho, e os
scripts são chamados pelo caminho completo.

| Arquivo | Cobre |
|---|---|
| `references/metodos-de-medicao.md` | As três definições que não podem ficar implícitas, os cinco métodos com custo, erro típico e validação de cada um, o efeito de ser observado, o piso de observações por estágio, o catálogo das oito classes de caso de canto, e a ordem de busca do número que já existe. Leia antes do passo 5 e antes do passo 7. |
| `~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/livro-caixa.py` | O livro-caixa da medição em Python de biblioteca padrão. Lê o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/divergencia.py` | A conta da divergência contra o gabarito de casos, com a classificação em erro do motor e erro do gabarito. |
| `~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/testar.py` | Teste de regressão dos dois scripts, biblioteca padrão apenas. Oitenta e sete casos, um por defeito conhecido, e todos escritos a partir de uma pergunta só: existe caminho em que isso sai com sucesso tendo perdido dado? Os principais: aspa dupla não fechada engolindo nove observações com tudo fechando e código 0; duplicata exata de observação entrando na conta uma vez por cópia; representatividade contada sobre quem observou no lugar de quem executou; linha do motor descartada na leitura virando a afirmação de que o motor não processou o caso; total por janela impresso na unidade por caso; duração `1h10` recusada como duração ausente; `1.000` entrando como um minuto; linha medida sem código de caso entrando na conta; caso cujo código contém `GERAL` apagado como linha de total; arquivo só com fala de gestor emitindo ficha; fala entrando na média; origem não reconhecida tratada como medida; fim menor que início virando duração sozinho; nenhum caso pareado com a saída dizendo que bate; resultado vazio contado como igual; divergência indeterminada fechando a rodada; o mesmo caso classificado duas vezes com classes opostas; duplicata exata no gabarito colapsada em silêncio; gabarito abaixo do mínimo autorizando o estágio; e nome real sobrevivendo no diretório com a anonimização ligada, conferido por varredura da pasta inteira e não de um arquivo só. Rode `python3 ~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/testar.py` depois de qualquer mudança, ou `py -3 "$env:USERPROFILE\.claude\skills\linha-de-base-antes-de-automatizar\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
