#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
livro-caixa.py, o livro-caixa da medicao da linha de base.

Le o arquivo de observacoes da tarefa, separa o que foi medido do que foi dito,
faz a conta so sobre o que foi medido e emite a ficha do antes. Falta valor
medido, data das observacoes, metodo reconhecido, esforco de medicao, validador
nomeado ou a conferencia contra o gabarito da lei declarada, a ficha nao sai:
sai o plano de medicao, que e o projeto de verdade.

Biblioteca padrao apenas, Python 3.8 ou superior. Sem rede. Nao escreve no
arquivo de entrada.

Depois de instalado:

    python3 ~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/livro-caixa.py \\
        --observacoes observacoes.csv \\
        --tarefa "Conferencia da lista do PCP contra o desenho" \\
        --unidade "minutos por caso" \\
        --metodo cronometragem \\
        --esforco-horas 6 \\
        --validador "Nome do validador" \\
        --conferida-contra-gabarito tres-casos-a-mao --numero-da-pessoa 24 \\
        --saida linha-de-base-2026-09-20

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\linha-de-base-antes-de-automatizar\\scripts\\livro-caixa.py" `
        --observacoes observacoes.csv `
        --tarefa "Conferencia da lista do PCP contra o desenho" `
        --unidade "minutos por caso" `
        --metodo cronometragem `
        --esforco-horas 6 `
        --validador "Nome do validador" `
        --conferida-contra-gabarito tres-casos-a-mao --numero-da-pessoa 24 `
        --saida linha-de-base-2026-09-20

Codigos de saida:

    0  Ficha emitida, representatividade demonstrada, nada perdido
    1  Ficha emitida com pendencia declarada (representatividade nao demonstrada,
       ou conferencia contra o gabarito da lei fora do criterio)
    2  --estrito e existe pendencia
    3  Erro de entrada, leitura que perdeu linha, fechamento que nao fecha, zero
       observacao medida, ou falta um dos seis requisitos da ficha: valor
       medido, data das observacoes, metodo reconhecido, esforco em horas,
       validador nomeado, conferencia contra o gabarito da lei declarada.
       A ficha nao e emitida
    4  Rodada --so-plano, nenhuma ficha foi emitida
    5  Ficha emitida, mas ficou observacao fora da conta que nao e estimativa
       declarada, ou entrou na conta sob suspeita nao confirmada

REGRA DE CONSTRUCAO DESTE ARQUIVO, e ela vale para quem for mexer nele:
nenhum contador desta rodada e obtido por subtracao. Cada balde e incrementado
dentro do laco, na linha em que a decisao e tomada, e o fechamento compara os
baldes com o total lido, que tambem foi contado no laco. Identidade derivada por
subtracao fecha sozinha mesmo com dado faltando, e foi assim que outras rodadas
sairam com codigo 0 depois de perder linha.
"""

import argparse
import csv
import io
import os
import re
import statistics
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

VERSAO = "1.0"

RODAPE = ("Gerado com apoio de IA a partir de {fonte}. Revisar antes de assinar. "
          "Nao substitui responsabilidade tecnica.")

LIMITE_DECLARADO = (
    "Esta ficha diz o numero do antes. Ela nao diz o que automatizar, em quanto "
    "tempo nem por quanto. Quem decide isso e a pessoa, com este numero na mao.")

# Marcadores que costumam indicar linha de total num apontamento. A deteccao
# NUNCA descarta: ela reporta. Caso real com codigo contendo GERAL ja foi
# apagado como linha de total em outra rodada, e a rodada saiu com sucesso.
MARCADORES_DE_TOTAL = ("TOTAL", "SUBTOTAL", "SOMA", "GERAL", "ACUMULADO", "MEDIA")

METODOS = ("cronometragem", "autoapontamento", "contagem-de-registro",
           "reconstrucao-de-rastro", "sondagem-aleatoria")

# Dicionario de cabecalho. Os nomes usuais de folha de apontamento entram aqui
# de proposito: a primeira rodada com o cabecalho real de uma folha de fabrica
# (OP, Operador, Tempo (min), Quem observou) parava com coluna obrigatoria
# ausente, e a mensagem nao dizia o que fazer.
COLUNAS_CONHECIDAS = {
    "caso": "caso",
    "op": "caso",
    "ordem": "caso",
    "of": "caso",
    "codigo": "caso",
    "codigo do caso": "caso",
    "data": "data",
    "dia": "data",
    "quem": "quem",
    "quem fez": "quem",
    "operador": "quem",
    "executante": "quem",
    "executou": "quem",
    "origem": "origem",
    "metodo": "metodo",
    "inicio": "inicio",
    "hora inicio": "inicio",
    "fim": "fim",
    "hora fim": "fim",
    "duracao_min": "duracao_min",
    "duracao": "duracao_min",
    "duracao (min)": "duracao_min",
    "duracao minutos": "duracao_min",
    "minutos": "duracao_min",
    "tempo": "duracao_min",
    "tempo (min)": "duracao_min",
    "tempo gasto": "duracao_min",
    "resultado": "resultado",
    "observador": "observador",
    "quem observou": "observador",
    "canto": "canto",
    "obs": "obs",
    "observacao": "obs",
}

OBRIGATORIAS = ("caso", "quem", "origem")

# Valores de preenchimento: a celula esta escrita e mesmo assim nao ha dado
# atras dela. O passo 4 da skill manda escrever "nao identificado" na coluna de
# quem executou quando o registro nao diz quem foi, e o buraco renomeado estava
# sendo contado como uma SEGUNDA pessoa: o criterio de mais de uma pessoa
# executando a tarefa passava com um campo em branco, e a ficha saia com
# representatividade demonstrada e codigo 0. A comparacao ignora acento, caixa,
# espaco repetido e hifen ligando palavra.
PREENCHIMENTO = (
    "nao identificado", "nao identificada", "nao identificados",
    "nao informado", "nao informada", "nao declarado", "nao declarada",
    "nao consta", "(nao consta)", "sem identificacao", "sem identificar",
    "desconhecido", "desconhecida", "n/a", "n.a.", "(vazio)", "(em branco)",
    "-", "--", "---", "?", "??", "???",
)

# Marcas de aproximacao numa celula de duracao. Texto aproximado e fala, nao
# medicao: ele sai da conta com essa causa escrita, nao como duracao ausente.
MARCAS_DE_APROXIMACAO = ("aprox", "cerca de", "mais ou menos", "em torno de",
                         "por volta", "media de", "~", "+/-", "mais o menos")

# 1.000 pode ser mil ou pode ser um: depende de quem exportou a planilha.
# Adivinhar aqui troca mil minutos por um minuto em silencio.
AMBIGUO_MILHAR = re.compile(r"^\d{1,3}([.,]\d{3})+$")

UNIDADES_DE_DURACAO = {
    "min": 1.0, "mins": 1.0, "minuto": 1.0, "minutos": 1.0, "m": 1.0,
    "h": 60.0, "hr": 60.0, "hrs": 60.0, "hora": 60.0, "horas": 60.0,
}

CONFERIDA_CONTRA_GABARITO = ("medicao-anterior", "tres-casos-a-mao",
                             "nao-conferida")

# Criterio desta skill, nao requisito externo: acima disso a fronteira do caso
# ou a unidade estao diferentes da que a pessoa usou.
LIMITE_DIVERGENCIA_GABARITO = 20.0

CABECALHO_LIVRO = ["caso", "data", "quem", "observador", "origem", "metodo",
                   "inicio", "fim", "duracao_min", "resultado", "canto",
                   "situacao", "alerta", "linha", "obs"]

CABECALHO_FORA = ["caso", "linha", "tipo", "causa", "o_que_falta",
                  "conteudo_da_linha"]


# ---------------------------------------------------------------- utilidades

def sem_acento(texto):
    if texto is None:
        return ""
    normal = unicodedata.normalize("NFKD", str(texto))
    return "".join(c for c in normal if not unicodedata.combining(c))


def chave(texto):
    return " ".join(sem_acento(texto).strip().lower().split())


def eh_preenchimento(texto):
    """Diz se a celula esta escrita e mesmo assim nao carrega dado.

    Celula vazia nao entra aqui: ela ja tem tratamento proprio, que e dizer o
    que falta preencher. O que esta funcao pega e o caso oposto, que passava
    inteiro: a celula preenchida com a palavra combinada para o buraco. Contar
    isso como valor distinto satisfaz um criterio de representatividade com um
    campo em branco renomeado.
    """
    k = chave(texto)
    if not k:
        return False
    if k in PREENCHIMENTO:
        return True
    achatado = " ".join(k.replace("-", " ").replace("_", " ").split())
    return bool(achatado) and achatado in PREENCHIMENTO


def abrir_texto(caminho):
    dados = Path(caminho).read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return dados.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return dados.decode("latin-1", "replace"), "latin-1 com substituicao"


def detectar_delimitador(primeira_linha):
    contagem = {}
    for d in (";", "\t", ","):
        contagem[d] = primeira_linha.count(d)
    melhor = max(contagem, key=lambda d: contagem[d])
    if contagem[melhor] == 0:
        return ";", "nenhum separador no cabecalho, assumido ponto e virgula"
    nome = {";": "ponto e virgula", "\t": "tabulacao", ",": "virgula"}[melhor]
    return melhor, "maior contagem no cabecalho (%s)" % nome


def ler_tabela(caminho):
    """Devolve (cabecalho, registros, info).

    registros e uma lista de (linha_fisica, lista_de_campos, linhas_consumidas).
    Nada e filtrado aqui: quem decide o que entra na conta e o laco de
    classificacao, uma vez so, e cada decisao vira um balde contado.

    linhas_consumidas e quantas linhas FISICAS do arquivo aquele registro comeu.
    Uma aspa dupla que ninguem fechou faz o leitor de CSV engolir todo o resto
    do arquivo dentro de um campo de texto: um registro com linhas_consumidas
    maior que um. Sem esse numero nao ha como saber que aconteceu, porque
    comparar a contagem do leitor com a contagem do laco que consome o mesmo
    leitor e comparar o leitor com ele mesmo.
    """
    texto, enc = abrir_texto(caminho)
    primeira = ""
    for linha in texto.splitlines():
        if linha.strip():
            primeira = linha
            break
    delim, motivo_delim = detectar_delimitador(primeira)
    leitor = csv.reader(io.StringIO(texto), delimiter=delim)
    cabecalho = None
    linha_cabecalho = 0
    registros = []
    anterior = 0
    for campos in leitor:
        numero = leitor.line_num
        consumidas = numero - anterior
        anterior = numero
        if cabecalho is None:
            if not any(c.strip() for c in campos):
                continue
            cabecalho = [c.strip() for c in campos]
            linha_cabecalho = numero
            continue
        registros.append((numero, campos, consumidas))
    if cabecalho is None:
        cabecalho = []
    caminho_p = Path(caminho)
    info = {
        "arquivo": caminho_p.name,
        "bytes": caminho_p.stat().st_size,
        "modificado": datetime.fromtimestamp(
            caminho_p.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
        "encoding": enc,
        "delimitador": motivo_delim,
        "linha_do_cabecalho": linha_cabecalho,
        "registros_lidos": len(registros),
        "linhas_fisicas": len(texto.splitlines()),
        "linhas_ate_cabecalho": linha_cabecalho,
        "linhas_consumidas_pelos_registros": sum(r[2] for r in registros),
    }
    return cabecalho, registros, info


def mapear_colunas(cabecalho):
    mapa = {}
    desconhecidas = []
    for i, nome in enumerate(cabecalho):
        k = chave(nome).replace("-", "_")
        alvo = COLUNAS_CONHECIDAS.get(k)
        if alvo is None:
            alvo = COLUNAS_CONHECIDAS.get(k.replace("_", " "))
        if alvo is None:
            desconhecidas.append(nome)
            continue
        if alvo not in mapa:
            mapa[alvo] = i
    return mapa, desconhecidas


def numero(texto):
    """Le 12, 12,5 e 12.5. Devolve None quando nao e numero."""
    bruto = (texto or "").strip()
    if not bruto:
        return None
    limpo = bruto.replace(" ", "")
    if "," in limpo and "." in limpo:
        limpo = limpo.replace(".", "").replace(",", ".")
    else:
        limpo = limpo.replace(",", ".")
    try:
        return float(limpo)
    except ValueError:
        return None


def hora_em_minutos(texto):
    bruto = (texto or "").strip()
    if not bruto:
        return None
    partes = bruto.replace("h", ":").replace(".", ":").split(":")
    partes = [p for p in partes if p != ""]
    if not partes or len(partes) > 3:
        return None
    try:
        valores = [int(p) for p in partes]
    except ValueError:
        return None
    if len(valores) == 1:
        return valores[0] * 60.0
    h, m = valores[0], valores[1]
    s = valores[2] if len(valores) == 3 else 0
    if not (0 <= h <= 47 and 0 <= m <= 59 and 0 <= s <= 59):
        return None
    return h * 60.0 + m + s / 60.0


def duracao_declarada(texto):
    """Le a celula de duracao como a folha de apontamento a carrega de verdade.

    Devolve (minutos, como_foi_lido, recusa). recusa e (tipo, causa, o_que_falta)
    quando a celula TEM valor e ainda assim nao pode entrar na conta: dizer que
    falta duracao nesse caso manda a pessoa preencher o que ja esta preenchido.
    """
    bruto = (texto or "").strip()
    if not bruto:
        return None, "", None

    k = chave(bruto)
    for marca in MARCAS_DE_APROXIMACAO:
        if marca in k:
            return None, "", (
                "duracao aproximada",
                "a celula diz '%s': aproximacao e fala, nao medicao" % bruto,
                "medir esse caso, ou mover a linha para origem declarado")

    limpo = k.replace(" ", "")
    if AMBIGUO_MILHAR.match(limpo):
        return None, "", (
            "duracao ambigua",
            "'%s' pode ser mil e pode ser um, depende de quem exportou a "
            "planilha" % bruto,
            "escrever o valor sem separador de milhar")

    direto = numero(bruto)
    if direto is not None:
        return direto, "", None

    casado = re.match(r"^([0-9]+(?:[.,][0-9]+)?)\s*([a-z]+)$", k)
    if casado and casado.group(2) in UNIDADES_DE_DURACAO:
        valor = numero(casado.group(1))
        if valor is not None:
            fator = UNIDADES_DE_DURACAO[casado.group(2)]
            return valor * fator, "'%s' lido como %s minutos" % (
                bruto, formatar(valor * fator)), None

    if ":" in k or "h" in k:
        valor = hora_em_minutos(k)
        if valor is not None:
            return valor, "'%s' lido como %s minutos" % (
                bruto, formatar(valor)), None

    return None, "", (
        "duracao nao reconhecida",
        "duracao lida: %s" % bruto,
        "escrever a duracao em minutos, ou no formato 1h10")


def ler_data(texto):
    bruto = (texto or "").strip()
    if not bruto:
        return None
    for formato in ("%Y-%m-%d", "%d/%m/%Y", "%d/%m/%y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(bruto, formato).date()
        except ValueError:
            continue
    return None


def parece_total(caso):
    alvo = sem_acento(caso).upper()
    for marcador in MARCADORES_DE_TOTAL:
        if marcador in alvo:
            return marcador
    return None


def formatar(valor, casas=1):
    if valor is None:
        return ""
    texto = ("%." + str(casas) + "f") % valor
    if texto.endswith(".0") and casas == 1:
        texto = texto[:-2]
    return texto


def unidade_da_janela(unidade, janela):
    """Devolve (unidade_do_total, motivo_da_recusa).

    Mediana vezes volume da janela NAO esta na unidade por caso: minutos por
    caso vezes casos por semana da minutos por semana. Imprimir o total com o
    rotulo por caso foi o defeito: o numero citado em reuniao vinha com a
    unidade errada colada.
    """
    k = chave(unidade)
    if k.endswith(" por caso"):
        base = k[: -len(" por caso")].strip()
        return "%s por %s" % (base, chave(janela)), ""
    return None, ("A derivacao so existe quando a unidade base e por caso, "
                  "porque o volume da janela e contado em casos.")


class Mascarador:
    """Troca nome de pessoa por pseudonimo estavel em TODO artefato do
    diretorio. O nome do validador e a unica excecao, e ela e declarada: uma
    ficha sem validador nomeado nao e uma ficha. Por isso o nome do validador
    entra por um marcador, depois da mascara ter sido aplicada."""

    def __init__(self, ativo):
        self.ativo = ativo
        self.mapa = {}

    def registrar(self, nome):
        limpo = (nome or "").strip()
        if not limpo:
            return
        # Valor de preenchimento nao e nome de pessoa. Registrar o buraco aqui
        # o transformava em pessoa-N nos artefatos e no de-para, e ai nem o
        # leitor da ficha nem quem abre o de-para consegue ver que aquilo e
        # buraco no registro.
        if eh_preenchimento(limpo):
            return
        k = chave(limpo)
        if k not in self.mapa:
            self.mapa[k] = ("pessoa-%d" % (len(self.mapa) + 1), limpo)

    def mascarar(self, texto):
        if not self.ativo or texto is None:
            return texto
        saida = str(texto)
        alvos = sorted(self.mapa.values(), key=lambda p: -len(p[1]))
        for pseudo, real in alvos:
            if not real:
                continue
            saida = substituir_sem_caixa(saida, real, pseudo)
        return saida


def substituir_sem_caixa(texto, alvo, troca):
    if not alvo:
        return texto
    base = sem_acento(texto).lower()
    agulha = sem_acento(alvo).lower()
    if agulha not in base:
        return texto
    saida = []
    i = 0
    while i < len(texto):
        if base.startswith(agulha, i):
            saida.append(troca)
            i += len(agulha)
        else:
            saida.append(texto[i])
            i += 1
    return "".join(saida)


# ------------------------------------------------------------------- rodada

def main(argv=None):
    p = argparse.ArgumentParser(
        description="Livro-caixa da medicao da linha de base.")
    p.add_argument("--observacoes", required=True,
                   help="CSV com uma linha por observacao.")
    p.add_argument("--tarefa", required=True,
                   help="A tarefa medida, em uma frase.")
    p.add_argument("--unidade", default="minutos por caso",
                   help="Unidade do numero (padrao: minutos por caso).")
    p.add_argument("--janela", default="",
                   help="Janela de referencia, por exemplo: semana.")
    p.add_argument("--volume-janela", default="",
                   help="Quantos casos acontecem por janela.")
    p.add_argument("--volume-medido", action="store_true",
                   help="O volume por janela veio de contagem, nao de fala.")
    p.add_argument("--metodo", default="",
                   help="Metodo de medicao: " + ", ".join(METODOS) + ".")
    p.add_argument("--esforco-horas", default="",
                   help="Horas gastas para medir.")
    p.add_argument("--validador", default="",
                   help="Nome de quem valida o numero.")
    p.add_argument("--data-validacao", default="",
                   help="Data em que o validador conferiu.")
    p.add_argument("--conferida-contra-gabarito", default="",
                   choices=("",) + CONFERIDA_CONTRA_GABARITO,
                   help="Como esta rodada foi conferida contra um numero que "
                        "alguem ja tinha: medicao-anterior, tres-casos-a-mao "
                        "ou nao-conferida. Sem esta declaracao a ficha nao "
                        "sai. nao-conferida e resposta valida e custa carimbo.")
    p.add_argument("--numero-da-pessoa", default="",
                   help="O numero que a pessoa tinha antes desta rodada, na "
                        "mesma unidade. Obrigatorio quando a conferencia foi "
                        "medicao-anterior ou tres-casos-a-mao.")
    p.add_argument("--saida", required=True, help="Diretorio de saida.")
    p.add_argument("--linha-de-total", default="",
                   help="Casos que sao linha de total, separados por virgula. "
                        "So sai da conta o que for declarado aqui.")
    p.add_argument("--virada-de-dia", action="store_true",
                   help="Aceita fim menor que inicio como virada de dia.")
    p.add_argument("--campo-multilinha", action="store_true",
                   help="Declara que o arquivo tem campo de texto com quebra "
                        "de linha dentro. Sem isso, registro que ocupa mais de "
                        "uma linha fisica derruba a rodada: e o sintoma de "
                        "aspa nao fechada, que engole o resto do arquivo.")
    p.add_argument("--anonimizar-pessoa", action="store_true",
                   help="Troca nome de pessoa por pseudonimo nos artefatos.")
    p.add_argument("--so-plano", action="store_true",
                   help="Escreve o plano de medicao e nao emite ficha.")
    p.add_argument("--estrito", action="store_true",
                   help="Qualquer pendencia derruba a rodada com codigo 2.")
    p.add_argument("--forcar", action="store_true",
                   help="Grava por cima de diretorio ja existente.")
    args = p.parse_args(argv)

    caminho = Path(args.observacoes)
    if not caminho.is_file():
        print("ERRO: arquivo de observacoes nao encontrado: %s" % caminho,
              file=sys.stderr)
        return 3

    destino = Path(args.saida)
    if destino.exists() and not args.forcar:
        print("ERRO: o diretorio %s ja existe. Use --forcar para gravar por "
              "cima." % destino, file=sys.stderr)
        return 3
    destino.mkdir(parents=True, exist_ok=True)

    cabecalho, registros, info = ler_tabela(caminho)
    mapa, desconhecidas = mapear_colunas(cabecalho)

    faltando = [c for c in OBRIGATORIAS if c not in mapa]
    if faltando:
        print("ERRO: coluna obrigatoria ausente: %s" % ", ".join(faltando),
              file=sys.stderr)
        print("Colunas encontradas no arquivo: %s"
              % (", ".join(cabecalho) if cabecalho else "nenhuma"),
              file=sys.stderr)
        if mapa:
            print("Mapeamento que esta rodada conseguiu fazer: %s"
                  % ", ".join("%s -> %s" % (cabecalho[i], alvo)
                              for alvo, i in sorted(mapa.items(),
                                                    key=lambda p: p[1])),
                  file=sys.stderr)
        if "caso" in faltando and cabecalho:
            print("A coluna do caso provavelmente e a primeira do arquivo (%s): "
                  "renomeie para caso." % cabecalho[0], file=sys.stderr)
        if "quem" in faltando:
            print("A coluna de quem executou e obrigatoria: sem ela a ficha nao "
                  "sabe se o numero cobre uma pessoa ou varias. Nomes usuais "
                  "aceitos: quem, quem fez, operador, executante.",
                  file=sys.stderr)
        if "origem" in faltando:
            print("Crie a coluna origem e escreva medido ou declarado em cada "
                  "linha: e o passo 4 da skill, e e o que separa medicao de "
                  "fala.", file=sys.stderr)
        print("Sair com 0 aqui seria dizer que a tarefa foi medida sem ter "
              "lido observacao nenhuma.", file=sys.stderr)
        return 3

    declarados_total = [chave(c) for c in args.linha_de_total.split(",")
                        if c.strip()]

    mascarador = Mascarador(args.anonimizar_pessoa)
    if args.anonimizar_pessoa:
        for _, campos, _c in registros:
            for coluna in ("quem", "observador"):
                idx = mapa.get(coluna)
                if idx is not None and idx < len(campos):
                    mascarador.registrar(campos[idx])

    # ---- baldes. Cada um e incrementado dentro do laco, na decisao. Nenhum
    # ---- e calculado por diferenca.
    n_vazias = 0
    n_descartadas_leitura = 0
    n_multilinha = 0
    n_caso_vazio = 0
    n_total_declarada = 0
    n_origem_desconhecida = 0
    n_estimativas = 0
    n_incompletas = 0
    n_duracao_invalida = 0
    n_duplicadas = 0
    n_na_conta = 0
    n_lidas = 0
    n_multilinha_declarada = 0

    # Contadores de buraco preenchido. Eles NAO sao baldes do fechamento: a
    # linha entrou na conta, a duracao dela e medicao de verdade. O que falta e
    # a identidade de quem executou, de quem observou ou do caso, e e isso que
    # a ficha precisa dizer em vez de contar o buraco como valor distinto.
    n_sem_executante = 0
    n_sem_observador_identificado = 0
    n_sem_caso_identificado = 0

    linhas_livro = []
    linhas_fora = []
    estimativas = []
    suspeitas_na_conta = []
    suspeitas_fora = []
    duracoes = []
    dias = set()
    executantes = set()
    observadores = set()
    casos_na_conta = set()
    vistas = {}

    def pega(campos, nome):
        idx = mapa.get(nome)
        if idx is None or idx >= len(campos):
            return ""
        return (campos[idx] or "").strip()

    def fora(caso, numero_linha, tipo, causa, falta, conteudo, marcador=None):
        """Grava a linha que ficou fora e, havendo suspeita de linha de total,
        registra que ela ficou FORA. Anotar a suspeita antes das recusas fazia a
        rodada afirmar que a linha estava na conta quando ela nao estava."""
        linhas_fora.append([caso, numero_linha, tipo, causa, falta, conteudo])
        if marcador:
            suspeitas_fora.append((caso, numero_linha, marcador, tipo))

    for numero_linha, campos, consumidas in registros:
        n_lidas += 1
        conteudo_bruto = ";".join(campos)

        # Registro que ocupou mais de uma linha fisica. Sem declaracao, e aspa
        # nao fechada: o leitor de CSV engoliu o resto do arquivo dentro de um
        # campo de texto e a rodada seguiria com um terco das observacoes.
        if consumidas > 1:
            if not args.campo_multilinha:
                n_multilinha += 1
                fora(pega(campos, "caso"), numero_linha, "aspa nao fechada",
                     "este registro ocupou %d linhas fisicas do arquivo, da "
                     "linha %d a %d" % (consumidas,
                                        numero_linha - consumidas + 1,
                                        numero_linha),
                     "fechar a aspa dessa celula, ou declarar "
                     "--campo-multilinha se a quebra de linha for de proposito",
                     conteudo_bruto)
                continue
            n_multilinha_declarada += 1

        if not any((c or "").strip() for c in campos):
            n_vazias += 1
            fora("", numero_linha, "linha vazia",
                 "linha sem nenhum campo preenchido", "", conteudo_bruto)
            continue

        if len(campos) != len(cabecalho):
            n_descartadas_leitura += 1
            fora("", numero_linha, "descartada na leitura",
                 "a linha tem %d campos e o cabecalho tem %d"
                 % (len(campos), len(cabecalho)),
                 "conferir o separador ou a aspa dessa linha", conteudo_bruto)
            continue

        caso = pega(campos, "caso")
        data_txt = pega(campos, "data")
        quem = pega(campos, "quem")
        observador = pega(campos, "observador")
        origem_txt = pega(campos, "origem")
        metodo_linha = pega(campos, "metodo")
        inicio = pega(campos, "inicio")
        fim = pega(campos, "fim")
        duracao_txt = pega(campos, "duracao_min")
        resultado = pega(campos, "resultado")
        canto = pega(campos, "canto")
        obs = pega(campos, "obs")
        if args.anonimizar_pessoa and obs:
            obs = "(texto livre suprimido pela anonimizacao)"

        # O arquivo do que ficou fora leva a linha inteira. Com a anonimizacao
        # ligada, o texto livre da coluna obs e suprimido aqui tambem: suprimir
        # so na linha que entrou na conta deixava o texto sair pela linha que
        # ficou fora, no mesmo diretorio.
        campos_saida = list(campos)
        idx_obs = mapa.get("obs")
        if (args.anonimizar_pessoa and idx_obs is not None
                and idx_obs < len(campos_saida)
                and (campos_saida[idx_obs] or "").strip()):
            campos_saida[idx_obs] = "(texto livre suprimido pela anonimizacao)"
        conteudo = ";".join(campos_saida)
        alertas = []
        marcador = parece_total(caso)

        if not caso:
            n_caso_vazio += 1
            fora("", numero_linha, "linha sem caso",
                 "a linha tem conteudo e nao tem codigo de caso",
                 "preencher a coluna caso nessa linha", conteudo)
            continue

        if chave(caso) in declarados_total:
            n_total_declarada += 1
            fora(caso, numero_linha, "linha de total declarada",
                 "declarada em --linha-de-total", "", conteudo)
            continue

        origem = chave(origem_txt)
        if origem in ("medido", "medida", "medicao"):
            origem = "medido"
        elif origem in ("declarado", "declarada", "estimativa",
                        "estimativa declarada", "fala"):
            origem = "declarado"
        else:
            n_origem_desconhecida += 1
            fora(caso, numero_linha, "origem nao reconhecida",
                 "origem lida: %s" % (origem_txt or "(vazia)"),
                 "escreva medido ou declarado nessa linha", conteudo, marcador)
            continue

        if origem == "declarado":
            n_estimativas += 1
            falta = []
            if not quem:
                falta.append("quem disse")
            if ler_data(data_txt) is None:
                falta.append("data da fala")
            valor, _como, _recusa = duracao_declarada(duracao_txt)
            estimativas.append({
                "caso": caso, "quem": quem, "data": data_txt,
                "valor": valor, "texto": duracao_txt or resultado,
                "linha": numero_linha, "falta": ", ".join(falta),
            })
            fora(caso, numero_linha, "estimativa declarada",
                 "fala de %s em %s" % (quem or "(quem nao consta)",
                                       data_txt or "(data nao consta)"),
                 ", ".join(falta), conteudo)
            continue

        # A partir daqui, origem == medido.
        falta = []
        if ler_data(data_txt) is None:
            falta.append("data")
        if not quem:
            falta.append("quem executou")
        minutos, como_lida, recusa = duracao_declarada(duracao_txt)
        if recusa is not None:
            n_duracao_invalida += 1
            fora(caso, numero_linha, recusa[0], recusa[1], recusa[2], conteudo,
                 marcador)
            continue
        m_inicio = hora_em_minutos(inicio)
        m_fim = hora_em_minutos(fim)
        derivada = None
        if m_inicio is not None and m_fim is not None:
            derivada = m_fim - m_inicio
            if derivada < 0:
                if args.virada_de_dia:
                    derivada += 1440.0
                else:
                    n_duracao_invalida += 1
                    fora(caso, numero_linha, "duracao invalida",
                         "fim (%s) e menor que inicio (%s)" % (fim, inicio),
                         "confirme a virada de dia e rode com --virada-de-dia",
                         conteudo, marcador)
                    continue
        if minutos is None and derivada is None:
            falta.append("duracao")
        if falta:
            n_incompletas += 1
            fora(caso, numero_linha, "incompleta",
                 "observacao medida sem %s" % ", ".join(falta),
                 "preencher %s nessa linha" % ", ".join(falta), conteudo,
                 marcador)
            continue

        if minutos is not None and derivada is not None:
            if abs(minutos - derivada) > 1.0:
                n_duracao_invalida += 1
                fora(caso, numero_linha, "duracao invalida",
                     "duracao_min diz %s e inicio/fim dao %s"
                     % (formatar(minutos), formatar(derivada)),
                     "decidir qual das duas vale e apagar a outra", conteudo,
                     marcador)
                continue
        final = minutos if minutos is not None else derivada
        if final is None or final <= 0:
            n_duracao_invalida += 1
            fora(caso, numero_linha, "duracao invalida",
                 "duracao lida: %s" % (duracao_txt or "(vazia)"),
                 "duracao tem que ser maior que zero", conteudo, marcador)
            continue

        # Copiar e colar linha em planilha de apontamento e o erro mais comum do
        # insumo. Duas copias identicas contam a mesma observacao duas vezes e
        # movem a mediana sem deixar rastro.
        dia_lido = ler_data(data_txt)
        impressao = (chave(caso),
                     dia_lido.isoformat() if dia_lido else chave(data_txt),
                     chave(quem), chave(observador), round(final, 3))
        if impressao in vistas:
            n_duplicadas += 1
            fora(caso, numero_linha, "duplicata exata",
                 "identica a linha %d em caso, data, quem, observador e "
                 "duracao" % vistas[impressao],
                 "apagar a copia, ou corrigir a linha que deveria ser outra "
                 "observacao", conteudo, marcador)
            continue
        vistas[impressao] = numero_linha

        # Buraco preenchido. O passo 4 manda escrever a palavra combinada
        # quando o registro nao diz quem executou, e a palavra estava entrando
        # como executante distinto.
        quem_e_buraco = eh_preenchimento(quem)
        observador_e_buraco = eh_preenchimento(observador)
        caso_e_buraco = eh_preenchimento(caso)

        if not caso_e_buraco and chave(caso) in casos_na_conta:
            alertas.append("o mesmo caso ja entrou na conta com outra duracao: "
                           "sendo duas execucoes, esta certo")
        if como_lida:
            alertas.append(como_lida)
        if marcador:
            alertas.append("parece linha de total pelo marcador %s, confirme "
                           "antes de tirar da conta" % marcador)
            suspeitas_na_conta.append((caso, numero_linha, marcador))
        if quem_e_buraco:
            alertas.append("quem executou diz '%s': isso e buraco no registro e "
                           "nao pessoa, e nao conta como executante distinto"
                           % quem)
        if observador_e_buraco:
            alertas.append("o observador diz '%s': isso e buraco no registro e "
                           "nao pessoa, e nao conta como observador distinto"
                           % observador)
        if caso_e_buraco:
            alertas.append("o codigo do caso diz '%s': esta linha nao entra na "
                           "contagem de casos distintos" % caso)
        if not observador or observador_e_buraco:
            alertas.append("sem observador declarado: a duracao foi anotada por "
                           "quem executou")

        n_na_conta += 1
        duracoes.append(final)
        if caso_e_buraco:
            n_sem_caso_identificado += 1
        else:
            casos_na_conta.add(chave(caso))
        d = ler_data(data_txt)
        if d is not None:
            dias.add(d.isoformat())
        # Representatividade se mede sobre quem FAZ. Um observador acompanhando
        # tres executantes nao e tres executantes, e tres observadores olhando a
        # mesma pessoa nao cobrem variacao de quem faz. E buraco no registro nao
        # e nenhum dos dois: ele e contado a parte e sai dito na ficha.
        if quem_e_buraco:
            n_sem_executante += 1
        elif quem:
            executantes.add(chave(quem))
        if observador_e_buraco:
            n_sem_observador_identificado += 1
        elif observador:
            observadores.add(chave(observador))
        linhas_livro.append([caso, data_txt, quem, observador, "medido",
                             metodo_linha, inicio, fim, formatar(final),
                             resultado, canto, "na conta", "; ".join(alertas),
                             numero_linha, obs])

    # ------------------------------------------------------------ fechamento
    soma_baldes = (n_vazias + n_descartadas_leitura + n_multilinha
                   + n_caso_vazio + n_total_declarada + n_origem_desconhecida
                   + n_estimativas + n_incompletas + n_duracao_invalida
                   + n_duplicadas + n_na_conta)
    fora_esperado = (n_vazias + n_descartadas_leitura + n_multilinha
                     + n_caso_vazio + n_total_declarada + n_origem_desconhecida
                     + n_estimativas + n_incompletas + n_duracao_invalida
                     + n_duplicadas)

    identidades = [
        ("linhas_lidas = vazias + descartadas_leitura + aspa_nao_fechada + "
         "sem_caso + total_declarada + origem_desconhecida + estimativas + "
         "incompletas + duracao_invalida + duplicadas + na_conta",
         n_lidas, soma_baldes),
        # Esta identidade compara o leitor de CSV com o ARQUIVO, contando as
        # linhas fisicas do texto bruto. A antiga comparava a contagem do leitor
        # com a contagem do laco que consome o mesmo leitor, o que e comparar o
        # leitor com ele mesmo: ela fechava com nove observacoes engolidas.
        ("linhas_fisicas_do_arquivo = linhas_ate_o_cabecalho + linhas "
         "consumidas pelos registros",
         info["linhas_fisicas"],
         info["linhas_ate_cabecalho"]
         + info["linhas_consumidas_pelos_registros"]),
        ("registros_lidos_no_arquivo = linhas_lidas",
         info["registros_lidos"], n_lidas),
        ("linhas em observacoes-fora-da-conta.csv = tudo que nao entrou",
         len(linhas_fora), fora_esperado),
        ("linhas em livro-caixa.csv = na_conta", len(linhas_livro), n_na_conta),
        ("n da conta = observacoes com duracao valida",
         len(duracoes), n_na_conta),
    ]
    fechamento_ok = all(a == b for _, a, b in identidades)

    # ------------------------------------------------------------ estatistica
    estat = {}
    if duracoes:
        ordenadas = sorted(duracoes)
        estat = {
            "n": len(ordenadas),
            "soma": sum(ordenadas),
            "media": statistics.mean(ordenadas),
            "mediana": statistics.median(ordenadas),
            "minimo": ordenadas[0],
            "maximo": ordenadas[-1],
            "dias": len(dias),
            "executantes": len(executantes),
            "observadores": len(observadores),
            "casos": len(casos_na_conta),
            "sem_executante": n_sem_executante,
            "sem_observador_identificado": n_sem_observador_identificado,
            "sem_caso_identificado": n_sem_caso_identificado,
        }
        estat["amplitude"] = estat["maximo"] - estat["minimo"]

    pendencias = []
    if estat:
        if estat["n"] < 5:
            pendencias.append(
                "so %d observacao(oes) medida(s): abaixo de cinco o numero nao "
                "tem dispersao para ser defendido" % estat["n"])
        if estat["dias"] <= 1:
            pendencias.append(
                "todas as observacoes sao do mesmo dia: o numero nao cobre "
                "variacao de dia")
        # Esta pendencia vem antes da contagem de executantes de proposito: com
        # buraco no registro, a contagem de executantes distintos ja nao e a
        # pergunta. A pergunta e quantas observacoes nao dizem quem executou.
        if n_sem_executante:
            pendencias.append(
                "%d de %d observacao(oes) na conta nao dizem quem executou: a "
                "celula carrega valor de preenchimento, que e buraco no "
                "registro e nao pessoa. Buraco nao conta como executante "
                "distinto, e o criterio de mais de uma pessoa executando a "
                "tarefa nao pode ser satisfeito por ele"
                % (n_sem_executante, estat["n"]))
        if estat["executantes"] == 0:
            pendencias.append(
                "nenhuma observacao na conta tem executante identificado: o "
                "numero nao cobre variacao de quem faz, e nao se sabe sequer "
                "de quantas pessoas ele fala")
        elif estat["executantes"] <= 1:
            pendencias.append(
                "todas as observacoes sao de quem executa uma unica pessoa "
                "(%d executante distinto): o numero nao cobre variacao de quem "
                "faz. Observador diferente nao supre isso" % estat["executantes"])

    # ---- conferencia contra o gabarito da lei do kit. Ela e declarada por
    # ---- opcao e impressa na ficha, senao a lei do passo 8 vive so na conversa.
    conferencia = args.conferida_contra_gabarito.strip()
    numero_pessoa = numero(args.numero_da_pessoa)
    divergencia_gabarito = None
    # Lista propria. Somar isto as pendencias de representatividade fazia a ficha
    # dizer "representatividade: nao demonstrada" quando a representatividade
    # estava demonstrada e o que nao batia era a conferencia.
    pendencias_conferencia = []
    if conferencia in ("medicao-anterior", "tres-casos-a-mao") and estat:
        if numero_pessoa is not None and numero_pessoa > 0:
            divergencia_gabarito = abs(
                estat["mediana"] - numero_pessoa) / numero_pessoa * 100.0
            if divergencia_gabarito > LIMITE_DIVERGENCIA_GABARITO:
                pendencias_conferencia.append(
                    "conferencia contra o gabarito da lei: a mediana desta "
                    "rodada (%s) esta %s%% longe do numero que a pessoa tinha "
                    "(%s), acima do criterio de %s%% desta skill. Refaca a "
                    "fronteira do caso do passo 3 antes de usar o numero"
                    % (formatar(estat["mediana"]),
                       formatar(divergencia_gabarito),
                       formatar(numero_pessoa),
                       formatar(LIMITE_DIVERGENCIA_GABARITO)))

    faltam_para_ficha = []
    if not estat:
        faltam_para_ficha.append("valor medido (nenhuma observacao entrou na conta)")
    if estat and not dias:
        faltam_para_ficha.append("data das observacoes")
    if not args.metodo.strip():
        faltam_para_ficha.append("metodo de medicao (--metodo)")
    elif chave(args.metodo) not in [chave(m) for m in METODOS]:
        faltam_para_ficha.append(
            "metodo de medicao reconhecido (--metodo, um entre %s)"
            % ", ".join(METODOS))
    if numero(args.esforco_horas) is None:
        faltam_para_ficha.append("esforco em horas para medir (--esforco-horas)")
    if not args.validador.strip():
        faltam_para_ficha.append("validador nomeado (--validador)")
    if not conferencia:
        faltam_para_ficha.append(
            "conferencia contra o gabarito da lei declarada "
            "(--conferida-contra-gabarito, um entre %s). nao-conferida e "
            "resposta valida e custa carimbo na ficha"
            % ", ".join(CONFERIDA_CONTRA_GABARITO))
    elif (conferencia in ("medicao-anterior", "tres-casos-a-mao")
            and numero_pessoa is None):
        faltam_para_ficha.append(
            "o numero que a pessoa tinha (--numero-da-pessoa), para a ficha "
            "imprimir os dois lado a lado")

    emite_ficha = ((not faltam_para_ficha) and fechamento_ok
                   and not n_multilinha and not args.so_plano)

    # ------------------------------------------------------------- artefatos
    fonte = info["arquivo"]
    if not fechamento_ok:
        status = "invalido, nao fecha"
    elif n_multilinha:
        status = "invalido, a leitura perdeu linha"
    elif args.so_plano:
        status = "so-plano, sem ficha"
    elif emite_ficha:
        status = "completo"
    else:
        status = "incompleto, sem ficha"

    escrever_csv(destino / "livro-caixa.csv", CABECALHO_LIVRO,
                 linhas_livro, mascarador, fonte)
    escrever_csv(destino / "observacoes-fora-da-conta.csv", CABECALHO_FORA,
                 linhas_fora, mascarador, fonte)

    plano = montar_plano(args, info, estat, faltam_para_ficha,
                         pendencias + pendencias_conferencia,
                         estimativas, identidades, fechamento_ok, status,
                         suspeitas_na_conta, suspeitas_fora, desconhecidas,
                         n_na_conta)
    texto_plano = mascarador.mascarar("\n".join(plano))
    # O nome do validador so entra inteiro na ficha, e essa excecao e
    # declarada. No plano, com a anonimizacao ligada, ele nao entra.
    texto_plano = texto_plano.replace(
        "@@VALIDADOR@@",
        (args.validador.strip() or "(nao nomeado)") if not args.anonimizar_pessoa
        else "(nomeado no comando, fora dos artefatos anonimizados)")
    (destino / "plano-de-medicao.md").write_text(texto_plano, encoding="utf-8")

    caminho_ficha = destino / "ficha-do-antes.md"
    if emite_ficha:
        ficha = montar_ficha(args, info, estat, pendencias, estimativas,
                             identidades, suspeitas_na_conta, suspeitas_fora,
                             dias, conferencia, numero_pessoa,
                             divergencia_gabarito)
        texto_ficha = mascarador.mascarar("\n".join(ficha))
        texto_ficha = texto_ficha.replace("@@VALIDADOR@@", args.validador.strip())
        caminho_ficha.write_text(texto_ficha, encoding="utf-8")
    elif caminho_ficha.exists():
        caminho_ficha.unlink()

    if args.anonimizar_pessoa and mascarador.mapa:
        de_para = destino.parent / (destino.name + "-de-para-pessoa.csv")
        with open(str(de_para), "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";", lineterminator="\n")
            w.writerow(["pseudonimo", "nome_real"])
            for pseudo, real in sorted(mascarador.mapa.values()):
                w.writerow([pseudo, real])
            w.writerow(["# de-para gravado FORA do diretorio de saida de "
                        "proposito: o diretorio e o que se compartilha", ""])

    # ------------------------------------------------------------- terminal
    print("")
    print("FECHAMENTO")
    for texto, a, b in identidades:
        print("  %-92s %6s %6s  %s"
              % (texto[:92], a, b, "fecha" if a == b else "NAO FECHA"))

    print("")
    print("VERIFICACOES QUE PODEM FALHAR DE FATO")
    print("  observacoes medidas na conta ........... %d" % n_na_conta)
    print("  executantes distintos .................. %d" % len(executantes))
    print("  sem executante identificado ............ %d" % n_sem_executante)
    print("  observadores distintos ................. %d" % len(observadores))
    print("  sem observador identificado ............ %d"
          % n_sem_observador_identificado)
    print("  sem caso identificado .................. %d"
          % n_sem_caso_identificado)
    print("  estimativas declaradas, fora da conta .. %d" % n_estimativas)
    print("  observacoes incompletas ................ %d" % n_incompletas)
    print("  duracoes invalidas ..................... %d" % n_duracao_invalida)
    print("  duplicatas exatas ...................... %d" % n_duplicadas)
    print("  origem nao reconhecida ................. %d" % n_origem_desconhecida)
    print("  linhas descartadas na leitura .......... %d" % n_descartadas_leitura)
    print("  linhas com aspa nao fechada ............ %d" % n_multilinha)
    print("  linhas sem caso ........................ %d" % n_caso_vazio)
    print("  linhas vazias .......................... %d" % n_vazias)
    print("  linhas de total declaradas ............. %d" % n_total_declarada)
    if n_multilinha_declarada:
        print("  registros com campo multilinha declarado ...... %d"
              % n_multilinha_declarada)
    print("  suspeitas de linha de total NA CONTA ........... %d"
          % len(suspeitas_na_conta))
    for caso, linha, marcador in suspeitas_na_conta:
        print("      linha %s, caso %s, marcador %s: esta NA CONTA. Confirme, "
              "e sendo total declare em --linha-de-total"
              % (linha, mascarador.mascarar(caso), marcador))
    print("  suspeitas de linha de total JA FORA DA CONTA ... %d"
          % len(suspeitas_fora))
    for caso, linha, marcador, tipo in suspeitas_fora:
        print("      linha %s, caso %s, marcador %s: ja esta FORA da conta "
              "como %s. Declarar em --linha-de-total nao muda o numero"
              % (linha, mascarador.mascarar(caso), marcador, tipo))
    if desconhecidas:
        print("  colunas do arquivo que a rodada nao usa: %s"
              % ", ".join(desconhecidas))
    nao_alinhadas = n_multilinha + n_descartadas_leitura
    if args.anonimizar_pessoa and nao_alinhadas:
        print("")
        print("EXCECAO DECLARADA DA ANONIMIZACAO: %d linha(s) sairam para "
              "observacoes-fora-da-conta.csv com o texto como esta no arquivo, "
              "porque nelas as colunas nao alinham com o cabecalho e a rodada "
              "nao sabe qual campo e texto livre. Nome de pessoa conhecido "
              "continua pseudonimizado. Leia essas linhas antes de compartilhar "
              "o diretorio." % nao_alinhadas)

    if not fechamento_ok:
        print("")
        print("RODADA INVALIDA: uma identidade de fechamento nao fecha. A "
              "ficha nao foi emitida.", file=sys.stderr)
        return 3

    if n_multilinha:
        print("")
        print("RODADA INVALIDA: %d registro(s) ocuparam mais de uma linha "
              "fisica do arquivo. O sintoma classico e aspa dupla que ninguem "
              "fechou: o leitor de CSV engole o resto do arquivo dentro de um "
              "campo de texto e a conta sai de um terco das observacoes, com "
              "tudo fechando. Leia observacoes-fora-da-conta.csv, feche a aspa, "
              "ou declare --campo-multilinha se a quebra de linha for de "
              "proposito. A ficha nao foi emitida." % n_multilinha,
              file=sys.stderr)
        return 3

    if args.so_plano:
        print("")
        print("Rodada --so-plano. Plano em %s. Nenhuma ficha foi emitida."
              % (destino / "plano-de-medicao.md"))
        return 4

    if faltam_para_ficha:
        print("")
        print("A FICHA NAO FOI EMITIDA. Falta: %s." % "; ".join(faltam_para_ficha))
        print("O projeto de verdade, agora, e medir. O que fazer esta em %s."
              % (destino / "plano-de-medicao.md"))
        return 3

    print("")
    print("Ficha emitida em %s" % caminho_ficha)
    print("  n = %d, mediana = %s, media = %s, minimo = %s, maximo = %s (%s)"
          % (estat["n"], formatar(estat["mediana"]), formatar(estat["media"]),
             formatar(estat["minimo"]), formatar(estat["maximo"]),
             args.unidade))

    sobrou = (n_incompletas + n_duracao_invalida + n_origem_desconhecida
              + n_descartadas_leitura + n_caso_vazio + n_duplicadas
              + len(suspeitas_na_conta))

    # As pendencias sao impressas antes de escolher o codigo de saida. Impressas
    # dentro do ramo delas, elas sumiam da tela toda vez que sobrava linha fora
    # da conta, porque o ramo de sobrou devolvia 5 primeiro: a ficha dizia
    # representatividade nao demonstrada e o terminal nao dizia nada.
    if pendencias or pendencias_conferencia:
        print("")
        for pend in pendencias:
            print("Representatividade nao demonstrada: %s" % pend)
        for pend in pendencias_conferencia:
            print("Pendencia declarada: %s" % pend)

    if args.estrito and (sobrou or pendencias or pendencias_conferencia):
        print("")
        print("--estrito: existe pendencia. Rodada devolvida com 2.",
              file=sys.stderr)
        return 2
    if sobrou:
        print("")
        print("Ficou dado fora da conta, ou na conta sob suspeita nao "
              "confirmada. Leia observacoes-fora-da-conta.csv antes de usar o "
              "numero.")
        return 5
    if pendencias or pendencias_conferencia:
        return 1
    return 0


def escrever_csv(caminho, cabecalho, linhas, mascarador, fonte):
    with open(str(caminho), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";", lineterminator="\n")
        w.writerow(cabecalho)
        for linha in linhas:
            w.writerow([mascarador.mascarar(c) for c in linha])
        rodape = ["# " + RODAPE.format(fonte=fonte)]
        rodape += [""] * (len(cabecalho) - 1)
        w.writerow(rodape)


def bloco_estimativas(estimativas):
    linhas = []
    if not estimativas:
        linhas.append("Nenhuma estimativa declarada entrou no arquivo.")
        return linhas
    linhas.append("Estas linhas NAO entram em conta nenhuma. Elas ficam aqui "
                  "carimbadas com quem disse e quando disse.")
    linhas.append("")
    linhas.append("| Caso | Quem disse | Quando disse | O que disse | Linha | Falta |")
    linhas.append("|---|---|---|---|---|---|")
    for e in estimativas:
        linhas.append("| %s | %s | %s | %s | %s | %s |" % (
            e["caso"], e["quem"] or "(nao consta)",
            e["data"] or "(nao consta)", e["texto"] or "(nao consta)",
            e["linha"], e["falta"] or "nada"))
    return linhas


def bloco_fechamento(identidades):
    linhas = ["| Identidade | Esquerda | Direita | |", "|---|---|---|---|"]
    for texto, a, b in identidades:
        linhas.append("| `%s` | %s | %s | %s |"
                      % (texto, a, b, "fecha" if a == b else "NAO FECHA"))
    return linhas


def montar_plano(args, info, estat, faltam, pendencias, estimativas,
                 identidades, fechamento_ok, status, suspeitas, suspeitas_fora,
                 desconhecidas, n_na_conta):
    L = []
    A = L.append
    A("# Plano de medicao da linha de base")
    A("")
    A("status: %s" % status)
    A("")
    A("**Tarefa.** %s" % args.tarefa)
    A("")
    A("**Unidade do numero.** %s" % args.unidade)
    A("")
    A("## Fonte")
    A("")
    A("| Arquivo | Bytes | Modificado | Encoding | Delimitador | Registros |")
    A("|---|---|---|---|---|---|")
    A("| %s | %s | %s | %s | %s | %s |" % (
        info["arquivo"], info["bytes"], info["modificado"], info["encoding"],
        info["delimitador"], info["registros_lidos"]))
    if desconhecidas:
        A("")
        A("Colunas do arquivo que a rodada nao usa: %s." % ", ".join(desconhecidas))
    A("")
    A("## O que a ficha do antes ainda exige")
    A("")
    if not faltam:
        A("Nada. Os seis requisitos estao atendidos: valor medido, data das "
          "observacoes, metodo reconhecido, esforco em horas, validador nomeado "
          "e conferencia contra o gabarito da lei declarada.")
    else:
        A("A ficha do antes nao e emitida enquanto faltar qualquer item desta "
          "lista. Nao e rigor de formulario: numero sem metodo e sem validador "
          "nao sustenta comparacao depois.")
        A("")
        for item in faltam:
            A("- Falta: %s" % item)
        A("")
        A("**O projeto de verdade, agora, e medir.** O passo seguinte nao e "
          "automatizar: e produzir as observacoes que faltam.")
    A("")
    A("## Como medir a partir daqui")
    A("")
    A("| Item | Valor |")
    A("|---|---|")
    A("| Metodo escolhido | %s |" % (args.metodo or "(nao escolhido)"))
    A("| Esforco declarado para medir, em horas | %s |"
      % (args.esforco_horas or "(nao declarado)"))
    A("| Validador nomeado | @@VALIDADOR@@ |")
    A("| Observacoes ja na conta | %d |" % n_na_conta)
    A("| Observacoes que faltam para chegar a cinco | %d |"
      % max(0, 5 - n_na_conta))
    A("| Observacoes que faltam para chegar a dez | %d |"
      % max(0, 10 - n_na_conta))
    A("")
    A("Dez observacoes sustentam um piloto. Trinta sustentam producao. O numero "
      "de observacoes nao substitui a cobertura: dia diferente, pessoa "
      "diferente e caso de canto valem mais que repeticao do mesmo caso facil.")
    A("")
    if pendencias:
        A("### Pendencias declaradas")
        A("")
        for pend in pendencias:
            A("- %s" % pend)
        A("")
    A("## Estimativas declaradas")
    A("")
    for linha in bloco_estimativas(estimativas):
        A(linha)
    A("")
    if suspeitas:
        A("## Suspeitas de linha de total que estao NA CONTA")
        A("")
        A("Estas linhas continuam NA CONTA. A rodada nao apaga linha por "
          "palavra encontrada no codigo do caso: codigo de item legitimo ja "
          "continha um desses marcadores e foi apagado em silencio em outra "
          "rodada.")
        A("")
        A("| Caso | Linha | Marcador |")
        A("|---|---|---|")
        for caso, linha, marcador in suspeitas:
            A("| %s | %s | %s |" % (caso, linha, marcador))
        A("")
    if suspeitas_fora:
        A("## Suspeitas de linha de total que JA ESTAO FORA da conta")
        A("")
        A("Estas nao entraram na conta, e o motivo esta na coluna. Declarar "
          "qualquer uma em `--linha-de-total` nao muda numero nenhum.")
        A("")
        A("| Caso | Linha | Marcador | Ficou fora como |")
        A("|---|---|---|---|")
        for caso, linha, marcador, tipo in suspeitas_fora:
            A("| %s | %s | %s | %s |" % (caso, linha, marcador, tipo))
        A("")
    A("## Fechamento")
    A("")
    for linha in bloco_fechamento(identidades):
        A(linha)
    A("")
    if not fechamento_ok:
        A("Uma identidade nao fecha. A saida desta rodada nao vale.")
        A("")
    A("---")
    A("")
    A(RODAPE.format(fonte=info["arquivo"]))
    return L


def montar_ficha(args, info, estat, pendencias, estimativas, identidades,
                 suspeitas, suspeitas_fora, dias, conferencia, numero_pessoa,
                 divergencia_gabarito):
    L = []
    A = L.append
    A("# Ficha do antes")
    A("")
    A("status: completo")
    A("")
    if conferencia == "nao-conferida":
        A("**NAO CONFERIDA CONTRA GABARITO.** Nenhum numero anterior foi "
          "comparado com o desta rodada. A ficha vale como primeira medicao e "
          "nao como referencia: a segunda rodada, com a conferencia feita, e "
          "que vira a ficha de referencia.")
        A("")
    A("**Tarefa medida.** %s" % args.tarefa)
    A("")
    A("**O que e um caso.** Uma execucao da tarefa acima, do inicio ao fim, "
      "por uma pessoa. A contagem de casos distintos desta ficha e %d, sobre "
      "%d observacoes medidas."
      % (estat["casos"], estat["n"]))
    if estat["sem_caso_identificado"]:
        A("")
        A("Dessas, %d nao tem codigo de caso identificado: a celula carrega "
          "valor de preenchimento. Elas continuam na conta da duracao e ficam "
          "fora da contagem de casos distintos, porque buraco no registro nao e "
          "caso." % estat["sem_caso_identificado"])
    if estat["casos"] < estat["n"] - estat["sem_caso_identificado"]:
        A("")
        A("Ha caso que aparece mais de uma vez com duracao diferente. Sendo "
          "duas execucoes do mesmo caso, esta certo. Sendo a mesma execucao "
          "anotada duas vezes, o numero desta ficha esta inflado: confira as "
          "linhas com alerta no `livro-caixa.csv`.")
    A("")
    A("## O numero do antes")
    A("")
    A("| Medida | Valor | Unidade |")
    A("|---|---|---|")
    A("| n, observacoes medidas | %d | observacoes |" % estat["n"])
    A("| mediana | %s | %s |" % (formatar(estat["mediana"]), args.unidade))
    A("| media | %s | %s |" % (formatar(estat["media"]), args.unidade))
    A("| minimo | %s | %s |" % (formatar(estat["minimo"]), args.unidade))
    A("| maximo | %s | %s |" % (formatar(estat["maximo"]), args.unidade))
    A("| amplitude | %s | %s |" % (formatar(estat["amplitude"]), args.unidade))
    A("| soma das observacoes | %s | %s |" % (formatar(estat["soma"]),
                                              args.unidade))
    A("| dias distintos | %d | dias |" % estat["dias"])
    A("| pessoas que executaram | %d | pessoas |" % estat["executantes"])
    A("| observacoes sem executante identificado | %d | observacoes |"
      % estat["sem_executante"])
    A("| observadores distintos | %d | pessoas |" % estat["observadores"])
    A("| observacoes sem observador identificado | %d | observacoes |"
      % estat["sem_observador_identificado"])
    A("")
    A("A representatividade desta ficha se mede pela linha de quem executou. "
      "Observador e quem anotou, e tres observadores olhando a mesma pessoa nao "
      "cobrem variacao de quem faz.")
    A("")
    if estat["sem_executante"]:
        A("As %d observacao(oes) sem executante identificado continuam na "
          "conta, porque a duracao delas foi medida de verdade. Elas nao entram "
          "na linha de pessoas que executaram: valor de preenchimento e buraco "
          "no registro, e contar buraco como pessoa satisfaz o criterio de mais "
          "de uma pessoa executando a tarefa sem nenhuma segunda pessoa existir."
          % estat["sem_executante"])
        A("")
    A("A mediana e o numero a citar quando a amplitude e larga. A media sozinha "
      "esconde o caso raro e demorado, que costuma ser o que mais incomoda.")
    A("")
    vol = numero(args.volume_janela)
    if vol is not None and args.janela:
        unidade_total, motivo = unidade_da_janela(args.unidade, args.janela)
        A("### Total por janela, derivado")
        A("")
        if unidade_total is None:
            A("Nao derivado. A unidade declarada e `%s`, e ela nao e por caso: "
              "multiplicar por volume de casos da janela nao produz grandeza "
              "nenhuma. %s" % (args.unidade, motivo))
            A("")
        else:
            total = estat["mediana"] * vol
            carimbo = ("volume medido" if args.volume_medido
                       else "volume DECLARADO, nao medido")
            A("| Janela | Volume por janela | Origem do volume | Total derivado |")
            A("|---|---|---|---|")
            A("| %s | %s | %s | %s %s |" % (args.janela, formatar(vol), carimbo,
                                            formatar(total), unidade_total))
            A("")
            A("O total acima esta em %s, e nao em %s. Sao grandezas diferentes, "
              "e e o total que vai ser citado em reuniao."
              % (unidade_total, args.unidade))
            A("")
            if not args.volume_medido:
                A("O total acima e derivado de um volume que ninguem contou. Ele "
                  "vale como ordem de grandeza e nao como valor medido. Contar o "
                  "volume costuma ser mais barato que medir a duracao.")
                A("")
    A("## Como foi medido")
    A("")
    A("| Item | Valor |")
    A("|---|---|")
    A("| Metodo de medicao | %s |" % args.metodo)
    A("| Esforco para medir, em horas | %s |" % args.esforco_horas)
    A("| Janela das observacoes | %s a %s |"
      % (min(dias) if dias else "", max(dias) if dias else ""))
    A("| Validador | @@VALIDADOR@@ |")
    A("| Data da validacao | %s |"
      % (args.data_validacao or "(a preencher na assinatura)"))
    A("| Conferida contra gabarito | %s |" % conferencia)
    A("| Arquivo de observacoes | %s |" % info["arquivo"])
    A("")
    A("O validador e nomeado de proposito. Numero sem dono nao e contestado, e "
      "numero que ninguem contesta e o que trava a conversa depois.")
    A("")
    A("## Conferencia contra o gabarito da lei")
    A("")
    if conferencia == "nao-conferida":
        A("**nao conferida contra gabarito.** Nao existia numero anterior nem "
          "foi produzido um a mao. Esta ficha nao foi comparada com nada, e "
          "isso esta dito no topo dela de proposito.")
    else:
        rotulo = {"medicao-anterior": "medicao anterior da area",
                  "tres-casos-a-mao": "tres casos cronometrados a mao"}
        A("| Caminho | Numero da pessoa | Mediana desta rodada | Diferenca |")
        A("|---|---|---|---|")
        A("| %s | %s %s | %s %s | %s |" % (
            rotulo.get(conferencia, conferencia),
            formatar(numero_pessoa), args.unidade,
            formatar(estat["mediana"]), args.unidade,
            ("%s%%" % formatar(divergencia_gabarito))
            if divergencia_gabarito is not None else "(nao calculada)"))
        A("")
        if (divergencia_gabarito is not None
                and divergencia_gabarito > LIMITE_DIVERGENCIA_GABARITO):
            A("**conferencia contra o gabarito: fora do criterio.** A mediana "
              "desta rodada esta %s%% longe do numero que a pessoa tinha, acima "
              "do criterio de %s%% desta skill. O numero desta ficha nao esta "
              "conferido: refaca a fronteira do caso do passo 3 antes de usar."
              % (formatar(divergencia_gabarito),
                 formatar(LIMITE_DIVERGENCIA_GABARITO)))
            A("")
        A("Pelo criterio desta skill, diferenca acima de %s%% quer dizer que a "
          "fronteira do caso ou a unidade estao diferentes da que a pessoa "
          "usou, e o passo 3 precisa ser refeito antes de usar o numero. As "
          "tres causas usuais, nessa ordem: fronteira do caso, unidade, e a "
          "pessoa citando a media contra a mediana desta ficha."
          % formatar(LIMITE_DIVERGENCIA_GABARITO))
    A("")
    A("## Representatividade")
    A("")
    if pendencias:
        A("**representatividade: nao demonstrada**")
        A("")
        for pend in pendencias:
            A("- %s" % pend)
        A("")
        A("A ficha sai assim mesmo, marcada. O numero serve para conversar e "
          "nao serve para comparar contra um depois.")
    else:
        A("**representatividade: demonstrada** pelos criterios desta skill: "
          "cinco ou mais observacoes, mais de um dia e mais de uma pessoa "
          "executando a tarefa.")
    A("")
    A("## Estimativas declaradas, fora da conta")
    A("")
    for linha in bloco_estimativas(estimativas):
        A(linha)
    A("")
    A("Fala de gestor nao e valor medido. Ela entra nesta ficha carimbada com "
      "quem disse e quando disse, e nao entra em nenhuma media, soma ou "
      "comparacao.")
    A("")
    if suspeitas:
        A("## Suspeitas de linha de total que estao NA CONTA")
        A("")
        A("| Caso | Linha | Marcador |")
        A("|---|---|---|")
        for caso, linha, marcador in suspeitas:
            A("| %s | %s | %s |" % (caso, linha, marcador))
        A("")
        A("Elas estao NA CONTA. Sendo linha de total mesmo, rode de novo com "
          "--linha-de-total e o numero muda.")
        A("")
    if suspeitas_fora:
        A("## Suspeitas de linha de total que JA ESTAO FORA da conta")
        A("")
        A("| Caso | Linha | Marcador | Ficou fora como |")
        A("|---|---|---|---|")
        for caso, linha, marcador, tipo in suspeitas_fora:
            A("| %s | %s | %s | %s |" % (caso, linha, marcador, tipo))
        A("")
        A("Estas nao entraram na conta. Declarar qualquer uma em "
          "--linha-de-total nao muda o numero desta ficha.")
        A("")
    A("## O gabarito do depois")
    A("")
    A("Esta ficha prova o antes. Ela nao prova o depois. Esta secao e a chamada "
      "para montar o gabarito de casos, com o piso do estagio pretendido: dez "
      "casos ja feitos a mao autorizam um piloto, trinta autorizam producao, "
      "com o resultado da epoca e casos de canto incluidos de proposito. Monte "
      "o `gabarito.csv` e confira com o `divergencia.py` desta mesma skill. "
      "Enquanto ele nao existir, esta ficha prova o antes e nao vai poder "
      "provar o depois.")
    A("")
    A("## Fechamento")
    A("")
    for linha in bloco_fechamento(identidades):
        A(linha)
    A("")
    A("## Limite declarado")
    A("")
    A(LIMITE_DECLARADO)
    A("")
    A("---")
    A("")
    A(RODAPE.format(fonte=info["arquivo"]))
    return L


if __name__ == "__main__":
    sys.exit(main())
