#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
divergencia.py, a conta da divergencia contra o gabarito.

Compara a saida de um motor candidato contra o gabarito de casos ja feitos a
mao, caso a caso, e devolve a lista de divergencias classificada em erro do
motor e erro do gabarito. Caso do gabarito que o motor nao processou e caso do
motor que nao esta no gabarito sao resultado, nunca descarte.

Biblioteca padrao apenas, Python 3.8 ou superior. Sem rede. Nao escreve nos
arquivos de entrada.

Depois de instalado:

    python3 ~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/divergencia.py \\
        --gabarito gabarito.csv --motor saida-do-motor.csv \\
        --estagio piloto --saida gabarito-2026-09-20

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\linha-de-base-antes-de-automatizar\\scripts\\divergencia.py" `
        --gabarito gabarito.csv --motor saida-do-motor.csv `
        --estagio piloto --saida gabarito-2026-09-20

Codigos de saida:

    0  Todos os casos do gabarito foram processados, todos bateram, a cobertura
       autoriza o estagio e nao sobrou caso fora da comparacao
    1  Ha divergencia de resultado
    2  --estrito e ha divergencia sem classificacao, ou classe nao reconhecida
    3  Erro de entrada, coluna obrigatoria ausente, fechamento que nao fecha,
       linha descartada na leitura em qualquer um dos dois lados, ou nenhum caso
       pareado. Sair com 0 sem parear nada seria dizer que o motor reproduz o
       gabarito
    4  Rodada --so-cobertura, nenhuma comparacao foi feita
    5  Nada divergiu, mas ficou caso fora da comparacao, ou a cobertura nao
       autoriza o estagio

REGRA DE CONSTRUCAO DESTE ARQUIVO: nenhum contador sai por subtracao. Cada
balde e incrementado na decisao, dentro do laco, e o fechamento compara baldes
com totais contados tambem no laco.
"""

import argparse
import csv
import io
import math
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

VERSAO = "1.0"

RODAPE = ("Gerado com apoio de IA a partir de {fonte}. Revisar antes de assinar. "
          "Nao substitui responsabilidade tecnica.")

MINIMO_POR_ESTAGIO = {"piloto": 10, "producao": 30}

CABECALHO_DIV = ["caso", "canto", "resultado_gabarito", "resultado_motor",
                 "situacao", "classe", "quem_classificou", "data_classificacao",
                 "linha_gabarito", "linha_motor", "observacao"]

CABECALHO_FORA = ["caso", "linha", "lado", "tipo", "causa", "conteudo_da_linha"]

# Cada tipo de linha que nao chega a comparacao, com a causa escrita. Sem este
# arquivo os baldes guardavam o conteudo da linha perdida e ninguem lia: a
# mensagem do codigo 5 mandava ler a lista de divergencias, que nao traz essas
# linhas.
TIPOS_FORA = {
    "vazias": ("linha vazia", "linha sem nenhum campo preenchido"),
    "descartadas": ("descartada na leitura",
                    "a linha tem contagem de coluna diferente do cabecalho: "
                    "confira o separador e a aspa dessa linha"),
    "caso_vazio": ("linha sem caso",
                   "a linha tem conteudo e nao tem codigo de caso"),
    "extras": ("duplicata exata colapsada",
               "o mesmo caso aparece de novo com o mesmo resultado: a linha foi "
               "colapsada, e arquivo remontado errado e a causa usual"),
}

COL_GABARITO = {
    "caso": "caso",
    "canto": "canto",
    "entrada": "entrada",
    "resultado_da_epoca": "resultado",
    "resultado da epoca": "resultado",
    "resultado": "resultado",
    "quem_fez": "quem_fez",
    "quem fez": "quem_fez",
    "data": "data",
    "fonte": "fonte",
}

COL_MOTOR = {
    "caso": "caso",
    "resultado": "resultado",
    "resultado_do_motor": "resultado",
    "saida": "resultado",
}

COL_CLASSIF = {
    "caso": "caso",
    "classe": "classe",
    "quem_classificou": "quem",
    "quem": "quem",
    "data": "data",
}


def sem_acento(texto):
    if texto is None:
        return ""
    normal = unicodedata.normalize("NFKD", str(texto))
    return "".join(c for c in normal if not unicodedata.combining(c))


def chave(texto):
    return " ".join(sem_acento(texto).strip().lower().split())


def abrir_texto(caminho):
    dados = Path(caminho).read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return dados.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return dados.decode("latin-1", "replace"), "latin-1 com substituicao"


def detectar_delimitador(primeira_linha):
    contagem = {}
    for d in (";", "\t", ","):
        contagem[d] = primeira_linha.count(d)
    melhor = max(contagem, key=lambda d: contagem[d])
    if contagem[melhor] == 0:
        return ";"
    return melhor


def ler_tabela(caminho, dicionario, obrigatorias):
    """Devolve (mapa, registros, info, faltando)."""
    texto, enc = abrir_texto(caminho)
    primeira = ""
    for linha in texto.splitlines():
        if linha.strip():
            primeira = linha
            break
    delim = detectar_delimitador(primeira)
    leitor = csv.reader(io.StringIO(texto), delimiter=delim)
    cabecalho = None
    registros = []
    for campos in leitor:
        numero = leitor.line_num
        if cabecalho is None:
            if not any(c.strip() for c in campos):
                continue
            cabecalho = [c.strip() for c in campos]
            continue
        registros.append((numero, campos))
    if cabecalho is None:
        cabecalho = []
    mapa = {}
    for i, nome in enumerate(cabecalho):
        k = chave(nome).replace("-", "_")
        alvo = dicionario.get(k) or dicionario.get(k.replace("_", " "))
        if alvo and alvo not in mapa:
            mapa[alvo] = i
    faltando = [c for c in obrigatorias if c not in mapa]
    caminho_p = Path(caminho)
    info = {
        "arquivo": caminho_p.name,
        "bytes": caminho_p.stat().st_size,
        "modificado": datetime.fromtimestamp(
            caminho_p.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
        "encoding": enc,
        "colunas": cabecalho,
        "registros_lidos": len(registros),
    }
    return mapa, registros, info, faltando


def numero(texto):
    bruto = (texto or "").strip()
    if not bruto:
        return None
    limpo = bruto.replace(" ", "")
    if "," in limpo and "." in limpo:
        limpo = limpo.replace(".", "").replace(",", ".")
    else:
        limpo = limpo.replace(",", ".")
    try:
        return float(limpo)
    except ValueError:
        return None


class Mascarador:
    def __init__(self, ativo):
        self.ativo = ativo
        self.mapa = {}

    def registrar(self, nome):
        limpo = (nome or "").strip()
        if not limpo:
            return
        k = chave(limpo)
        if k not in self.mapa:
            self.mapa[k] = ("pessoa-%d" % (len(self.mapa) + 1), limpo)

    def mascarar(self, texto):
        if not self.ativo or texto is None:
            return texto
        saida = str(texto)
        for pseudo, real in sorted(self.mapa.values(), key=lambda p: -len(p[1])):
            saida = substituir_sem_caixa(saida, real, pseudo)
        return saida


def substituir_sem_caixa(texto, alvo, troca):
    if not alvo:
        return texto
    base = sem_acento(texto).lower()
    agulha = sem_acento(alvo).lower()
    if agulha not in base:
        return texto
    saida = []
    i = 0
    while i < len(texto):
        if base.startswith(agulha, i):
            saida.append(troca)
            i += len(agulha)
        else:
            saida.append(texto[i])
            i += 1
    return "".join(saida)


def agrupar(registros, mapa, cabecalho_len, baldes, prefixo):
    """Agrupa por caso contando cada descarte no proprio laco.

    Devolve (por_caso, nao_pareaveis) onde por_caso mapeia chave do caso para
    (valor_exibido, resultado, linha) e nao_pareaveis lista os casos que
    repetem com resultado diferente.
    """
    bruto = {}
    ordem = []
    for numero_linha, campos in registros:
        baldes[prefixo + "lidas"] += 1
        if not any((c or "").strip() for c in campos):
            baldes[prefixo + "vazias"] += 1
            baldes[prefixo + "vazias_conteudo"].append(
                (numero_linha, ";".join(campos)))
            continue
        if len(campos) != cabecalho_len:
            baldes[prefixo + "descartadas"] += 1
            baldes[prefixo + "descartadas_conteudo"].append(
                (numero_linha, ";".join(campos)))
            continue
        idx_caso = mapa["caso"]
        idx_res = mapa["resultado"]
        caso = (campos[idx_caso] or "").strip()
        resultado = (campos[idx_res] or "").strip()
        extras = {}
        for nome, idx in mapa.items():
            if idx < len(campos):
                extras[nome] = (campos[idx] or "").strip()
        if not caso:
            baldes[prefixo + "caso_vazio"] += 1
            baldes[prefixo + "caso_vazio_conteudo"].append(
                (numero_linha, ";".join(campos)))
            continue
        k = chave(caso)
        if k not in bruto:
            bruto[k] = []
            ordem.append(k)
        bruto[k].append((numero_linha, caso, resultado, extras, ";".join(campos)))

    por_caso = {}
    nao_pareaveis = []
    for k in ordem:
        itens = bruto[k]
        resultados = set(i[2] for i in itens)
        if len(resultados) > 1:
            # Repeticao com resultado diferente: nao pareia, e a lista de
            # divergencia ja carrega o caso.
            baldes[prefixo + "extras_divergentes"] += len(itens) - 1
            baldes[prefixo + "nao_pareaveis"] += 1
            nao_pareaveis.append((k, itens))
            continue
        # Repeticao com resultado igual: a linha some colapsada. Antes ela
        # entrava so dentro da soma da identidade, sem checagem, sem linha no
        # relatorio e sem arquivo. Gabarito com linha repetida e sinal de
        # arquivo remontado errado.
        baldes[prefixo + "extras_iguais"] += len(itens) - 1
        for extra in itens[1:]:
            baldes[prefixo + "extras_conteudo"].append(
                (extra[0], extra[4], extra[1]))
        baldes[prefixo + "distintos"] += 1
        por_caso[k] = itens[0]
    return por_caso, nao_pareaveis


def novo_balde(prefixo):
    return {
        prefixo + "lidas": 0,
        prefixo + "vazias": 0,
        prefixo + "vazias_conteudo": [],
        prefixo + "descartadas": 0,
        prefixo + "descartadas_conteudo": [],
        prefixo + "caso_vazio": 0,
        prefixo + "caso_vazio_conteudo": [],
        prefixo + "extras_iguais": 0,
        prefixo + "extras_conteudo": [],
        prefixo + "extras_divergentes": 0,
        prefixo + "nao_pareaveis": 0,
        prefixo + "distintos": 0,
    }


def linhas_fora_da_comparacao(baldes):
    """Monta as linhas do arquivo do que ficou fora da comparacao.

    Le os baldes que ja guardavam o conteudo exato da linha perdida e nunca eram
    lidos em lugar nenhum.
    """
    linhas = []
    for prefixo, lado in (("g_", "gabarito"), ("m_", "motor")):
        for balde, (tipo, causa) in TIPOS_FORA.items():
            for item in baldes.get(prefixo + balde + "_conteudo", []):
                caso = item[2] if len(item) > 2 else ""
                linhas.append([caso, item[0], lado, tipo, causa, item[1]])
    return sorted(linhas, key=lambda l: (l[2], l[1]))


def total_fora_da_comparacao(baldes):
    total = 0
    for prefixo in ("g_", "m_"):
        total += (baldes.get(prefixo + "vazias", 0)
                  + baldes.get(prefixo + "descartadas", 0)
                  + baldes.get(prefixo + "caso_vazio", 0)
                  + baldes.get(prefixo + "extras_iguais", 0))
    return total


def escrever_fora(caminho, baldes, mascarador, fonte):
    linhas = linhas_fora_da_comparacao(baldes)
    with open(str(caminho), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";", lineterminator="\n")
        w.writerow(CABECALHO_FORA)
        for linha in linhas:
            w.writerow([mascarador.mascarar(c) for c in linha])
        w.writerow(["# " + RODAPE.format(fonte=fonte)]
                   + [""] * (len(CABECALHO_FORA) - 1))
    return len(linhas)


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Conta da divergencia contra o gabarito.")
    p.add_argument("--gabarito", required=True)
    p.add_argument("--motor", default="",
                   help="Saida do motor candidato. Sem ela, use --so-cobertura.")
    p.add_argument("--classificacao", default="",
                   help="CSV com caso;classe;quem_classificou;data.")
    p.add_argument("--saida", required=True)
    p.add_argument("--estagio", default="piloto",
                   choices=sorted(MINIMO_POR_ESTAGIO.keys()))
    p.add_argument("--ignorar-caixa", action="store_true")
    p.add_argument("--tolerancia", default="",
                   help="Diferenca numerica aceita como igual, declarada.")
    p.add_argument("--so-cobertura", action="store_true",
                   help="So confere a cobertura do gabarito, sem comparar.")
    p.add_argument("--anonimizar-pessoa", action="store_true")
    p.add_argument("--estrito", action="store_true")
    p.add_argument("--forcar", action="store_true")
    args = p.parse_args(argv)

    if not Path(args.gabarito).is_file():
        print("ERRO: gabarito nao encontrado: %s" % args.gabarito,
              file=sys.stderr)
        return 3
    if not args.so_cobertura and not args.motor:
        print("ERRO: sem --motor nao ha o que comparar. Use --so-cobertura "
              "para conferir so a cobertura do gabarito.", file=sys.stderr)
        return 3
    if args.motor and not Path(args.motor).is_file():
        print("ERRO: saida do motor nao encontrada: %s" % args.motor,
              file=sys.stderr)
        return 3

    destino = Path(args.saida)
    if destino.exists() and not args.forcar:
        print("ERRO: o diretorio %s ja existe. Use --forcar." % destino,
              file=sys.stderr)
        return 3
    destino.mkdir(parents=True, exist_ok=True)

    tolerancia = numero(args.tolerancia)
    if args.tolerancia.strip() and tolerancia is None:
        print("ERRO: --tolerancia nao e numero: %s" % args.tolerancia,
              file=sys.stderr)
        return 3

    mapa_g, reg_g, info_g, falta_g = ler_tabela(
        args.gabarito, COL_GABARITO, ("caso", "resultado"))
    if falta_g:
        print("ERRO: coluna obrigatoria ausente no gabarito: %s"
              % ", ".join(falta_g), file=sys.stderr)
        print("Colunas encontradas: %s"
              % (", ".join(info_g["colunas"]) or "nenhuma"), file=sys.stderr)
        return 3

    baldes = novo_balde("g_")
    por_caso_g, nao_par_g = agrupar(reg_g, mapa_g, len(info_g["colunas"]),
                                    baldes, "g_")

    mascarador = Mascarador(args.anonimizar_pessoa)
    if args.anonimizar_pessoa:
        # Registrar por TODAS as linhas lidas, e nao so pelas que entraram na
        # comparacao: o arquivo do que ficou fora leva o conteudo da linha
        # inteira, e nome de pessoa numa linha descartada tambem sai do
        # diretorio se ninguem o registrou aqui.
        idx_quem = mapa_g.get("quem_fez")
        for _linha, campos in reg_g:
            if idx_quem is not None and idx_quem < len(campos):
                mascarador.registrar(campos[idx_quem])
        for item in por_caso_g.values():
            mascarador.registrar(item[3].get("quem_fez", ""))

    # ------------------------------------------------------ cobertura
    cantos = {}
    for k, item in por_caso_g.items():
        valor = item[3].get("canto", "")
        vk = chave(valor)
        if vk in ("", "nao", "n", "0", "-"):
            continue
        cantos.setdefault(vk, []).append(item[1])

    n_gab = baldes["g_distintos"]
    minimo = MINIMO_POR_ESTAGIO[args.estagio]
    minimo_canto = max(2, int(math.ceil(n_gab / 5.0))) if n_gab else 2
    casos_de_canto = sum(len(v) for v in cantos.values())
    checagens = [
        ("casos no gabarito >= %d (estagio %s)" % (minimo, args.estagio),
         n_gab >= minimo, "%d" % n_gab),
        ("casos de canto >= %d (um a cada cinco, minimo dois)" % minimo_canto,
         casos_de_canto >= minimo_canto, "%d" % casos_de_canto),
        ("classes de canto distintas >= 2", len(cantos) >= 2,
         "%d" % len(cantos)),
        ("nenhum caso do gabarito repetido com resultado diferente",
         baldes["g_nao_pareaveis"] == 0, "%d" % baldes["g_nao_pareaveis"]),
        ("nenhuma linha do gabarito repetida com o mesmo resultado",
         baldes["g_extras_iguais"] == 0, "%d" % baldes["g_extras_iguais"]),
        ("nenhuma linha do gabarito sem codigo de caso",
         baldes["g_caso_vazio"] == 0, "%d" % baldes["g_caso_vazio"]),
        ("nenhuma linha do gabarito descartada na leitura",
         baldes["g_descartadas"] == 0, "%d" % baldes["g_descartadas"]),
    ]

    if args.so_cobertura:
        cobertura_autoriza = all(ok for _, ok, _ in checagens)
        n_fora = escrever_fora(destino / "linhas-fora-da-comparacao.csv",
                               baldes, mascarador, info_g["arquivo"])
        identidades_cobertura = [
            ("linhas em linhas-fora-da-comparacao.csv = vazias + descartadas "
             "+ caso_vazio + extras_iguais",
             n_fora, total_fora_da_comparacao(baldes)),
        ]
        texto = montar_cobertura(args, info_g, None, baldes, None, checagens,
                                 cantos, cobertura_autoriza,
                                 identidades_cobertura, {},
                                 "so-cobertura, sem comparacao", [], [], [])
        (destino / "cobertura-do-gabarito.md").write_text(
            mascarador.mascarar("\n".join(texto)), encoding="utf-8")
        imprimir_checagens(checagens)
        if any(a != b for _, a, b in identidades_cobertura):
            print("")
            print("RODADA INVALIDA: a identidade do que ficou fora da "
                  "comparacao nao fecha.", file=sys.stderr)
            return 3
        print("")
        print("Rodada --so-cobertura. Nenhuma comparacao foi feita. Relatorio "
              "em %s" % (destino / "cobertura-do-gabarito.md"))
        if n_fora:
            print("Ficou linha fora da comparacao: %d. Leia %s"
                  % (n_fora, destino / "linhas-fora-da-comparacao.csv"))
        return 4

    mapa_m, reg_m, info_m, falta_m = ler_tabela(
        args.motor, COL_MOTOR, ("caso", "resultado"))
    if falta_m:
        print("ERRO: coluna obrigatoria ausente na saida do motor: %s"
              % ", ".join(falta_m), file=sys.stderr)
        print("Colunas encontradas: %s"
              % (", ".join(info_m["colunas"]) or "nenhuma"), file=sys.stderr)
        return 3

    baldes.update(novo_balde("m_"))
    por_caso_m, nao_par_m = agrupar(reg_m, mapa_m, len(info_m["colunas"]),
                                    baldes, "m_")

    # A cobertura do lado do motor. Sem estas duas checagens, linha do motor
    # descartada na leitura saia como "o motor nao produziu saida para este
    # caso", que e o contrario do que aconteceu, com as cinco checagens em
    # atende e o fechamento fechando.
    checagens += [
        ("nenhuma linha do motor descartada na leitura",
         baldes["m_descartadas"] == 0, "%d" % baldes["m_descartadas"]),
        ("nenhuma linha do motor sem codigo de caso",
         baldes["m_caso_vazio"] == 0, "%d" % baldes["m_caso_vazio"]),
    ]
    cobertura_autoriza = all(ok for _, ok, _ in checagens)

    # ------------------------------------------------------ classificacao
    classificacao = {}
    classes_nao_reconhecidas = []
    classificacao_orfa = []
    # Duas pessoas classificando o mesmo caso com classes opostas: a segunda
    # linha sobrescrevia a primeira em silencio, e erro do motor virava erro do
    # gabarito sem ninguem saber. As duas conclusoes levam a acoes opostas.
    classificacao_conflitante = []
    if args.classificacao:
        if not Path(args.classificacao).is_file():
            print("ERRO: arquivo de classificacao nao encontrado: %s"
                  % args.classificacao, file=sys.stderr)
            return 3
        mapa_c, reg_c, info_c, falta_c = ler_tabela(
            args.classificacao, COL_CLASSIF, ("caso", "classe"))
        if falta_c:
            print("ERRO: coluna obrigatoria ausente na classificacao: %s"
                  % ", ".join(falta_c), file=sys.stderr)
            return 3
        for numero_linha, campos in reg_c:
            if not any((c or "").strip() for c in campos):
                continue
            if len(campos) != len(info_c["colunas"]):
                classes_nao_reconhecidas.append(
                    ("(linha %d)" % numero_linha,
                     "linha com contagem de coluna diferente do cabecalho"))
                continue
            caso = (campos[mapa_c["caso"]] or "").strip()
            classe_txt = (campos[mapa_c["classe"]] or "").strip()
            quem = ""
            data = ""
            if "quem" in mapa_c and mapa_c["quem"] < len(campos):
                quem = (campos[mapa_c["quem"]] or "").strip()
            if "data" in mapa_c and mapa_c["data"] < len(campos):
                data = (campos[mapa_c["data"]] or "").strip()
            k = chave(classe_txt)
            if k in ("erro do motor", "erro-do-motor", "motor"):
                classe = "erro-do-motor"
            elif k in ("erro do gabarito", "erro-do-gabarito", "gabarito"):
                classe = "erro-do-gabarito"
            else:
                classes_nao_reconhecidas.append((caso, classe_txt or "(vazia)"))
                classe = "indeterminado"
            anterior = classificacao.get(chave(caso))
            if anterior is not None and anterior[0] != classe:
                classificacao_conflitante.append(
                    (caso, anterior[0], classe, numero_linha))
            classificacao[chave(caso)] = (classe, quem, data)
            if args.anonimizar_pessoa:
                mascarador.registrar(quem)

    # ------------------------------------------------------ comparacao
    n_pareados = 0
    n_iguais = 0
    n_diferentes = 0
    n_nao_comparaveis = 0
    n_so_gabarito = 0
    n_so_motor = 0
    n_erro_motor = 0
    n_erro_gabarito = 0
    n_indeterminado = 0
    linhas_div = []

    def normalizar(valor):
        v = " ".join((valor or "").split())
        if args.ignorar_caixa:
            v = sem_acento(v).lower()
        return v

    for k in por_caso_g:
        item_g = por_caso_g[k]
        canto = item_g[3].get("canto", "")
        if k not in por_caso_m:
            n_so_gabarito += 1
            if baldes["m_descartadas"] or baldes["m_caso_vazio"]:
                nota = ("nao ha saida do motor para este caso, e ha linha do "
                        "motor que nao chegou a comparacao: ou o motor nao "
                        "processou, ou a linha dele foi descartada na leitura. "
                        "Leia linhas-fora-da-comparacao.csv antes de depurar o "
                        "motor")
            else:
                nota = ("o motor nao produziu saida para este caso. Isso e "
                        "resultado, nao ausencia de dado")
            linhas_div.append([item_g[1], canto, item_g[2], "",
                               "caso_nao_processado_pelo_motor", "", "", "",
                               item_g[0], "", nota])
            continue
        item_m = por_caso_m[k]
        n_pareados += 1
        rg = item_g[2]
        rm = item_m[2]
        if not rg.strip() or not rm.strip():
            n_nao_comparaveis += 1
            situacao = ("resultado_vazio_no_gabarito" if not rg.strip()
                        else "resultado_vazio_no_motor")
            linhas_div.append([item_g[1], canto, rg, rm, situacao, "", "", "",
                               item_g[0], item_m[0],
                               "vazio nao e igual: sem os dois lados nao ha "
                               "comparacao"])
            continue
        ng, nm = normalizar(rg), normalizar(rm)
        igual = ng == nm
        if not igual and tolerancia is not None:
            vg, vm = numero(rg), numero(rm)
            if vg is not None and vm is not None and abs(vg - vm) <= tolerancia:
                igual = True
        if igual:
            n_iguais += 1
            continue
        n_diferentes += 1
        classe, quem, data = classificacao.get(k, ("indeterminado", "", ""))
        if classe == "erro-do-motor":
            n_erro_motor += 1
        elif classe == "erro-do-gabarito":
            n_erro_gabarito += 1
        else:
            n_indeterminado += 1
        linhas_div.append([item_g[1], canto, rg, rm, "diferente", classe, quem,
                           data, item_g[0], item_m[0], ""])

    for k in por_caso_m:
        if k in por_caso_g:
            continue
        item_m = por_caso_m[k]
        n_so_motor += 1
        if baldes["g_descartadas"] or baldes["g_caso_vazio"]:
            nota = ("este caso nao foi encontrado no gabarito, e ha linha do "
                    "gabarito que nao chegou a comparacao: ou o gabarito nao "
                    "cobre o caso, ou a linha dele foi descartada na leitura. "
                    "Leia linhas-fora-da-comparacao.csv antes de concluir")
        else:
            nota = ("o motor produziu saida para um caso que o gabarito nao "
                    "cobre. Nao se sabe se acertou")
        linhas_div.append([item_m[1], "", "", item_m[2], "caso_fora_do_gabarito",
                           "", "", "", "", item_m[0], nota])

    for k, itens in nao_par_g:
        linhas_div.append([itens[0][1], "", " | ".join(i[2] for i in itens), "",
                           "caso_repetido_divergente_no_gabarito", "", "", "",
                           " ".join(str(i[0]) for i in itens), "",
                           "o mesmo caso aparece no gabarito com resultados "
                           "diferentes. Nao da para parear"])
    for k, itens in nao_par_m:
        linhas_div.append([itens[0][1], "", "", " | ".join(i[2] for i in itens),
                           "caso_repetido_divergente_no_motor", "", "", "",
                           "", " ".join(str(i[0]) for i in itens),
                           "o motor devolveu o mesmo caso com resultados "
                           "diferentes"])

    for caso in classificacao:
        achou = any(chave(l[0]) == caso and l[4] == "diferente"
                    for l in linhas_div)
        if not achou:
            classificacao_orfa.append(caso)

    # ------------------------------------------------------ fechamento
    n_fora = escrever_fora(destino / "linhas-fora-da-comparacao.csv", baldes,
                           mascarador, info_g["arquivo"])
    identidades = [
        ("linhas_gabarito = vazias + descartadas + caso_vazio + distintos + "
         "nao_pareaveis + extras_iguais + extras_divergentes",
         baldes["g_lidas"],
         baldes["g_vazias"] + baldes["g_descartadas"] + baldes["g_caso_vazio"]
         + baldes["g_distintos"] + baldes["g_nao_pareaveis"]
         + baldes["g_extras_iguais"] + baldes["g_extras_divergentes"]),
        ("linhas_motor = vazias + descartadas + caso_vazio + distintos + "
         "nao_pareaveis + extras_iguais + extras_divergentes",
         baldes["m_lidas"],
         baldes["m_vazias"] + baldes["m_descartadas"] + baldes["m_caso_vazio"]
         + baldes["m_distintos"] + baldes["m_nao_pareaveis"]
         + baldes["m_extras_iguais"] + baldes["m_extras_divergentes"]),
        ("linhas em linhas-fora-da-comparacao.csv = vazias + descartadas + "
         "caso_vazio + extras_iguais, dos dois lados",
         n_fora, total_fora_da_comparacao(baldes)),
        ("casos_distintos_gabarito = pareados + so_no_gabarito",
         baldes["g_distintos"], n_pareados + n_so_gabarito),
        ("casos_distintos_motor = pareados + so_no_motor",
         baldes["m_distintos"], n_pareados + n_so_motor),
        ("pareados = iguais + diferentes + nao_comparaveis",
         n_pareados, n_iguais + n_diferentes + n_nao_comparaveis),
        ("diferentes = erro_do_motor + erro_do_gabarito + indeterminado",
         n_diferentes, n_erro_motor + n_erro_gabarito + n_indeterminado),
        ("linhas em divergencias-contra-gabarito.csv = tudo que nao e igual",
         len(linhas_div),
         n_diferentes + n_nao_comparaveis + n_so_gabarito + n_so_motor
         + baldes["g_nao_pareaveis"] + baldes["m_nao_pareaveis"]),
    ]
    fechamento_ok = all(a == b for _, a, b in identidades)

    contagens = {
        "pareados": n_pareados, "iguais": n_iguais, "diferentes": n_diferentes,
        "nao_comparaveis": n_nao_comparaveis, "so_gabarito": n_so_gabarito,
        "so_motor": n_so_motor, "erro_motor": n_erro_motor,
        "erro_gabarito": n_erro_gabarito, "indeterminado": n_indeterminado,
    }

    status = ("invalido, nao fecha" if not fechamento_ok else "completo")
    texto = montar_cobertura(args, info_g, info_m, baldes, contagens,
                             checagens, cantos, cobertura_autoriza,
                             identidades, classificacao,
                             status, classes_nao_reconhecidas,
                             classificacao_orfa, classificacao_conflitante)
    (destino / "cobertura-do-gabarito.md").write_text(
        mascarador.mascarar("\n".join(texto)), encoding="utf-8")

    with open(str(destino / "divergencias-contra-gabarito.csv"), "w",
              encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";", lineterminator="\n")
        w.writerow(CABECALHO_DIV)
        ordem = {"caso_nao_processado_pelo_motor": 0,
                 "caso_repetido_divergente_no_gabarito": 1,
                 "caso_repetido_divergente_no_motor": 1,
                 "resultado_vazio_no_gabarito": 2,
                 "resultado_vazio_no_motor": 2,
                 "caso_fora_do_gabarito": 3,
                 "diferente": 4}
        for linha in sorted(linhas_div, key=lambda l: (ordem.get(l[4], 9),
                                                       chave(l[0]))):
            w.writerow([mascarador.mascarar(c) for c in linha])
        w.writerow(["# " + RODAPE.format(fonte=info_g["arquivo"])]
                   + [""] * (len(CABECALHO_DIV) - 1))

    # ------------------------------------------------------ terminal
    print("")
    print("FECHAMENTO")
    for t, a, b in identidades:
        print("  %-88s %6s %6s  %s" % (t[:88], a, b,
                                       "fecha" if a == b else "NAO FECHA"))
    print("")
    print("CONTAS DA RODADA")
    print("  casos no gabarito ...................... %d" % baldes["g_distintos"])
    print("  pareados ............................... %d" % n_pareados)
    print("  iguais ................................. %d" % n_iguais)
    print("  diferentes ............................. %d" % n_diferentes)
    print("      erro do motor ...................... %d" % n_erro_motor)
    print("      erro do gabarito ................... %d" % n_erro_gabarito)
    print("      indeterminado ...................... %d" % n_indeterminado)
    print("  nao comparaveis (um dos lados vazio) ... %d" % n_nao_comparaveis)
    print("  casos do gabarito nao processados ...... %d" % n_so_gabarito)
    print("  casos do motor fora do gabarito ........ %d" % n_so_motor)
    print("  linhas que nao chegaram a comparacao ... %d" % n_fora)
    for prefixo, lado in (("g_", "gabarito"), ("m_", "motor")):
        for balde, rotulo in (("vazias", "linha vazia"),
                              ("descartadas", "descartada na leitura"),
                              ("caso_vazio", "linha sem caso"),
                              ("extras_iguais", "duplicata exata colapsada")):
            quantas = baldes.get(prefixo + balde, 0)
            if quantas:
                print("      %s, %s: %d" % (lado, rotulo, quantas))
    imprimir_checagens(checagens)
    if classes_nao_reconhecidas:
        print("")
        print("  classes de divergencia nao reconhecidas: %d"
              % len(classes_nao_reconhecidas))
        for caso, valor in classes_nao_reconhecidas:
            print("      caso %s, classe lida: %s. Tratada como indeterminado"
                  % (mascarador.mascarar(caso), valor))
    if classificacao_orfa:
        print("")
        print("  classificacoes sem divergencia correspondente: %d"
              % len(classificacao_orfa))
    if classificacao_conflitante:
        print("")
        print("  casos classificados duas vezes com classes diferentes: %d"
              % len(classificacao_conflitante))
        for caso, antes, agora, linha in classificacao_conflitante:
            print("      caso %s: %s na primeira linha e %s na linha %d. A "
                  "segunda sobrescrevia a primeira em silencio"
                  % (mascarador.mascarar(caso), antes, agora, linha))

    if not fechamento_ok:
        print("")
        print("RODADA INVALIDA: uma identidade de fechamento nao fecha.",
              file=sys.stderr)
        return 3

    if n_pareados == 0:
        print("")
        print("RODADA INVALIDA: nenhum caso pareou entre o gabarito e a saida "
              "do motor. Sair com 0 aqui seria dizer que o motor reproduz o "
              "gabarito sem ter comparado nada.", file=sys.stderr)
        return 3

    if baldes["g_descartadas"] or baldes["m_descartadas"]:
        print("")
        print("RODADA INVALIDA: %d linha(s) do gabarito e %d linha(s) do motor "
              "foram descartadas na leitura, por contagem de coluna diferente "
              "do cabecalho. Seguir e classificar aqui faz a rodada afirmar "
              "que um caso nao foi processado quando a linha dele so nao foi "
              "lida. O conteudo esta em %s: corrija o separador ou a aspa e "
              "rode de novo."
              % (baldes["g_descartadas"], baldes["m_descartadas"],
                 destino / "linhas-fora-da-comparacao.csv"), file=sys.stderr)
        return 3

    pendencia_estrita = (n_indeterminado > 0 or classes_nao_reconhecidas
                         or classificacao_orfa or classificacao_conflitante)
    if args.estrito and (pendencia_estrita or n_diferentes
                         or not cobertura_autoriza):
        print("")
        print("--estrito: existe pendencia. Rodada devolvida com 2.",
              file=sys.stderr)
        return 2
    if n_diferentes:
        return 1
    sobrou = (n_so_gabarito + n_so_motor + n_nao_comparaveis
              + baldes["g_nao_pareaveis"] + baldes["m_nao_pareaveis"]
              + baldes["g_caso_vazio"] + baldes["m_caso_vazio"]
              + baldes["g_extras_iguais"] + baldes["m_extras_iguais"]
              + len(classes_nao_reconhecidas) + len(classificacao_orfa)
              + len(classificacao_conflitante))
    if sobrou or not cobertura_autoriza:
        print("")
        if not cobertura_autoriza:
            print("Nenhum resultado divergiu, mas a cobertura do gabarito NAO "
                  "autoriza o estagio %s." % args.estagio)
        if sobrou:
            print("Nenhum resultado divergiu, mas ficou caso fora da "
                  "comparacao. Caso pareado que nao bateu esta em %s. Linha que "
                  "nao chegou a comparacao esta em %s."
                  % (destino / "divergencias-contra-gabarito.csv",
                     destino / "linhas-fora-da-comparacao.csv"))
        return 5
    return 0


def imprimir_checagens(checagens):
    print("")
    print("COBERTURA DO GABARITO")
    for texto, ok, valor in checagens:
        print("  %-62s %6s  %s" % (texto[:62], valor,
                                   "atende" if ok else "NAO ATENDE"))


def montar_cobertura(args, info_g, info_m, baldes, contagens, checagens,
                     cantos, autoriza, identidades, classificacao, status,
                     classes_ruins, orfas, conflitantes=()):
    L = []
    A = L.append
    A("# Cobertura do gabarito e conta da divergencia")
    A("")
    A("status: %s" % status)
    A("")
    A("**Estagio pretendido.** %s, que exige %d casos."
      % (args.estagio, MINIMO_POR_ESTAGIO[args.estagio]))
    A("")
    A("## Fontes")
    A("")
    A("| Papel | Arquivo | Bytes | Modificado | Encoding | Linhas |")
    A("|---|---|---|---|---|---|")
    A("| gabarito | %s | %s | %s | %s | %s |"
      % (info_g["arquivo"], info_g["bytes"], info_g["modificado"],
         info_g["encoding"], info_g["registros_lidos"]))
    if info_m:
        A("| motor | %s | %s | %s | %s | %s |"
          % (info_m["arquivo"], info_m["bytes"], info_m["modificado"],
             info_m["encoding"], info_m["registros_lidos"]))
    A("")
    A("## Normalizacao da comparacao, declarada antes do resultado")
    A("")
    A("| Regra | Estado |")
    A("|---|---|")
    A("| espaco em excesso colapsado | sempre |")
    A("| caixa e acento ignorados | %s |"
      % ("sim, por --ignorar-caixa" if args.ignorar_caixa else "nao"))
    A("| tolerancia numerica | %s |"
      % (args.tolerancia if args.tolerancia.strip() else "nenhuma"))
    A("")
    A("Sem tolerancia declarada, `10` e `10,0` sao resultados diferentes e "
      "aparecem na lista. Igualar os dois em silencio esconderia diferenca de "
      "formato que, em outro campo, seria diferenca de valor.")
    A("")
    A("## Cobertura")
    A("")
    A("| Checagem | Valor | Situacao |")
    A("|---|---|---|")
    for texto, ok, valor in checagens:
        A("| %s | %s | %s |" % (texto, valor, "atende" if ok else "NAO ATENDE"))
    A("")
    A("**A cobertura %s o estagio %s.**"
      % ("autoriza" if autoriza else "NAO autoriza", args.estagio))
    A("")
    A("### Classes de canto presentes")
    A("")
    if cantos:
        A("| Classe de canto | Casos |")
        A("|---|---|")
        for k in sorted(cantos):
            A("| %s | %d |" % (k, len(cantos[k])))
    else:
        A("Nenhuma. Gabarito so com caso facil mede a parte facil. O caso de "
          "canto entra de proposito: campo vazio, valor fora do padrao, "
          "registro duplicado, unidade diferente, texto ilegivel, excecao que a "
          "area conhece de cor.")
    A("")
    A("## Linhas que nao chegaram a comparacao")
    A("")
    itens = []
    for prefixo, lado in (("g_", "gabarito"), ("m_", "motor")):
        if (prefixo + "lidas") not in baldes:
            continue
        for balde, rotulo in (("vazias", "linha vazia"),
                              ("descartadas", "descartada na leitura"),
                              ("caso_vazio", "linha sem caso"),
                              ("extras_iguais", "duplicata exata colapsada")):
            quantas = baldes.get(prefixo + balde, 0)
            if quantas:
                itens.append((lado, rotulo, quantas))
    if itens:
        A("| Lado | Tipo | Linhas |")
        A("|---|---|---|")
        for lado, rotulo, quantas in itens:
            A("| %s | %s | %d |" % (lado, rotulo, quantas))
        A("")
        A("Cada uma dessas linhas esta inteira em `linhas-fora-da-comparacao.csv`, "
          "com o lado, o tipo, a causa e o conteudo. Linha descartada na leitura "
          "derruba a rodada com codigo 3: enquanto ela existe, a afirmacao de "
          "que o motor nao processou um caso pode ser so a linha dele que nao "
          "foi lida.")
    else:
        A("Nenhuma. Todas as linhas dos dois lados chegaram a comparacao.")
    A("")
    if contagens:
        A("## Conta da divergencia")
        A("")
        A("| Conta | Casos |")
        A("|---|---|")
        A("| pareados | %d |" % contagens["pareados"])
        A("| iguais | %d |" % contagens["iguais"])
        A("| diferentes | %d |" % contagens["diferentes"])
        A("| diferentes, erro do motor | %d |" % contagens["erro_motor"])
        A("| diferentes, erro do gabarito | %d |" % contagens["erro_gabarito"])
        A("| diferentes, indeterminado | %d |" % contagens["indeterminado"])
        A("| nao comparaveis, um dos lados vazio | %d |"
          % contagens["nao_comparaveis"])
        A("| casos do gabarito que o motor nao processou | %d |"
          % contagens["so_gabarito"])
        A("| casos do motor fora do gabarito | %d |" % contagens["so_motor"])
        A("")
        A("A divergencia indeterminada nao e empate: e trabalho pendente. "
          "Enquanto houver uma, ninguem sabe se o motor errou ou se o gabarito "
          "estava errado desde o inicio, e as duas conclusoes levam a acoes "
          "opostas.")
        A("")
        if classes_ruins:
            A("### Classes nao reconhecidas")
            A("")
            A("| Caso | Classe lida |")
            A("|---|---|")
            for caso, valor in classes_ruins:
                A("| %s | %s |" % (caso, valor))
            A("")
            A("Foram tratadas como indeterminado. As duas classes aceitas sao "
              "`erro-do-motor` e `erro-do-gabarito`.")
            A("")
        if conflitantes:
            A("### Casos classificados duas vezes com classes diferentes")
            A("")
            A("| Caso | Primeira classe | Segunda classe | Linha |")
            A("|---|---|---|---|")
            for caso, antes, agora, linha in conflitantes:
                A("| %s | %s | %s | %s |" % (caso, antes, agora, linha))
            A("")
            A("A segunda linha sobrescreve a primeira. Erro do motor e erro do "
              "gabarito levam a acoes opostas, e a rodada nao fecha enquanto o "
              "mesmo caso tiver as duas.")
            A("")
        if orfas:
            A("### Classificacoes sem divergencia correspondente")
            A("")
            for caso in orfas:
                A("- %s" % caso)
            A("")
            A("Classificar um caso que nao divergiu costuma ser sinal de que a "
              "rodada classificada e outra.")
            A("")
    if identidades:
        A("## Fechamento")
        A("")
        A("| Identidade | Esquerda | Direita | |")
        A("|---|---|---|---|")
        for t, a, b in identidades:
            A("| `%s` | %s | %s | %s |" % (t, a, b,
                                           "fecha" if a == b else "NAO FECHA"))
        A("")
    A("## Limite declarado")
    A("")
    A("Esta conta diz o quanto o motor candidato reproduz o gabarito. Ela nao "
      "diz se vale a pena automatizar, nem em quanto tempo, nem por quanto.")
    A("")
    A("---")
    A("")
    A(RODAPE.format(fonte=info_g["arquivo"]))
    return L


if __name__ == "__main__":
    sys.exit(main())
