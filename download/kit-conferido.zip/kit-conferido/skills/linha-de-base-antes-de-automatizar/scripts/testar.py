#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do livro-caixa.py e do divergencia.py.

Biblioteca padrao apenas. Gera cada caso num diretorio temporario, roda o
script nele e compara o codigo de saida e trechos dos arquivos gerados com o
esperado. Um caso por defeito conhecido.

Cada caso deste arquivo foi escrito a partir de uma pergunta so: existe caminho
em que isso sai com sucesso tendo perdido dado? Nao foi escrito a partir da
funcionalidade. Os defeitos que custaram rodada nas skills irmas foram todos
desse tipo: script terminando com codigo 0 depois de nao processar, nao
comparar ou descartar dado em silencio.

Rode depois de qualquer mudanca nos scripts:

    python3 ~/.claude/skills/linha-de-base-antes-de-automatizar/scripts/testar.py

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\linha-de-base-antes-de-automatizar\\scripts\\testar.py"

Sai com 1 se algum caso falhar.
"""

import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
LIVRO = AQUI / "livro-caixa.py"
DIVERGENCIA = AQUI / "divergencia.py"
SKILL = AQUI.parent / "SKILL.md"

CAB_OBS = ("caso;data;quem;origem;metodo;inicio;fim;duracao_min;resultado;"
           "observador;canto;obs")

# Cinco observacoes medidas, tres dias, duas pessoas: o piso que a skill exige
# para dizer que a representatividade esta demonstrada.
OBS_OK = (
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Ana;nao;\n"
    "OP-2;2026-03-02;Bia;medido;cronometragem;;;22;ok;Bia;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Ana;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;Bia;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Ana;nao;\n")

COMPLETO = ["--metodo", "cronometragem", "--esforco-horas", "6",
            "--validador", "Validador Teste",
            "--conferida-contra-gabarito", "nao-conferida"]

CAB_GAB = "caso;canto;entrada;resultado_da_epoca;quem_fez;data;fonte"
CAB_MOTOR = "caso;resultado"

# Os dois sinais proibidos no kit entram aqui por escape, e nao escritos. Este
# arquivo e o que verifica a regra: escrito o sinal de verdade, o proprio
# verificador vira a violacao. Trocar por virgula ou dois pontos, que e o que a
# regra manda fazer com o sinal no texto, desligaria a checagem em silencio e
# deixaria o SKILL.md passar com travessao.
TRAVESSAO = "\u2014"
MEIA_RISCA = "\u2013"

falhas = []


def registrar(nome, erros):
    if erros:
        falhas.append((nome, erros))
        print("FALHOU  %s" % nome)
        for e in erros:
            print("        %s" % e)
    else:
        print("ok      %s" % nome)


def ler(caminho):
    try:
        return caminho.read_text(encoding="utf-8-sig")
    except (UnicodeDecodeError, OSError):
        try:
            return caminho.read_bytes().decode("latin-1", "replace")
        except OSError:
            return ""


def conferir(nome, r, saida, esperado_codigo, checagens, nomes_reais=(),
             excecoes=()):
    erros = []
    if r.returncode != esperado_codigo:
        erros.append("codigo de saida %s, esperado %s"
                     % (r.returncode, esperado_codigo))
    for arquivo, texto, deve in checagens:
        if arquivo == "stdout":
            conteudo = r.stdout
        elif arquivo == "stderr":
            conteudo = r.stderr
        else:
            alvo = (saida / arquivo).resolve()
            if not alvo.is_file():
                if deve:
                    erros.append("arquivo ausente: %s" % arquivo)
                continue
            conteudo = ler(alvo)
        presente = texto in conteudo
        if presente != deve:
            erros.append("%s em %s: esperado %s"
                         % (repr(texto[:70]), arquivo,
                            "presente" if deve else "ausente"))
    # Varredura do diretorio inteiro: conferir um arquivo so nao prova
    # anonimizacao, porque o que se compartilha e a pasta.
    if nomes_reais and saida.is_dir():
        for arquivo in sorted(saida.iterdir()):
            if not arquivo.is_file() or arquivo.name in excecoes:
                continue
            conteudo = ler(arquivo)
            for real in nomes_reais:
                if real in conteudo:
                    erros.append("nome real %s sobreviveu em %s"
                                 % (repr(real), arquivo.name))
    registrar(nome, erros)


def rodar_livro(nome, observacoes, esperado_codigo, checagens, extra=(),
                completo=True, cabecalho=CAB_OBS, criar_saida=False,
                nomes_reais=(), excecoes=()):
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        arq = base / "observacoes.csv"
        corpo = cabecalho + "\n" + observacoes if cabecalho else observacoes
        arq.write_text(corpo, encoding="utf-8")
        saida = base / "saida"
        if criar_saida:
            saida.mkdir()
        cmd = [sys.executable, str(LIVRO), "--observacoes", str(arq),
               "--tarefa", "Tarefa de teste", "--unidade", "minutos por caso",
               "--saida", str(saida)]
        if completo:
            cmd += COMPLETO
        cmd += list(extra)
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           universal_newlines=True)
        conferir(nome, r, saida, esperado_codigo, checagens, nomes_reais,
                 excecoes)


def rodar_div(nome, gabarito, motor, esperado_codigo, checagens, extra=(),
              classificacao=None, cab_gab=CAB_GAB, cab_motor=CAB_MOTOR,
              nomes_reais=(), excecoes=()):
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        arq_g = base / "gabarito.csv"
        arq_g.write_text(cab_gab + "\n" + gabarito, encoding="utf-8")
        saida = base / "saida"
        cmd = [sys.executable, str(DIVERGENCIA), "--gabarito", str(arq_g),
               "--saida", str(saida)]
        if motor is not None:
            arq_m = base / "motor.csv"
            arq_m.write_text(cab_motor + "\n" + motor, encoding="utf-8")
            cmd += ["--motor", str(arq_m)]
        if classificacao is not None:
            arq_c = base / "classificacao.csv"
            arq_c.write_text("caso;classe;quem_classificou;data\n"
                             + classificacao, encoding="utf-8")
            cmd += ["--classificacao", str(arq_c)]
        cmd += list(extra)
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           universal_newlines=True)
        conferir(nome, r, saida, esperado_codigo, checagens, nomes_reais,
                 excecoes)


def gabarito_de(n, cantos=()):
    """n casos, com as posicoes de cantos recebendo classe de canto."""
    linhas = []
    for i in range(1, n + 1):
        canto = "nao"
        for pos, classe in cantos:
            if pos == i:
                canto = classe
        linhas.append("C-%d;%s;e%d;R%d;Ana;2026-03-01;pasta"
                      % (i, canto, i, i))
    return "\n".join(linhas) + "\n"


def motor_de(n, trocas=None):
    trocas = trocas or {}
    linhas = []
    for i in range(1, n + 1):
        linhas.append("C-%d;%s" % (i, trocas.get(i, "R%d" % i)))
    return "\n".join(linhas) + "\n"


CANTOS_PADRAO = ((9, "campo vazio"), (10, "registro duplicado"))


print("")
print("== livro-caixa.py ==")
print("")

# 1. O caso feliz existe, e ele e a unica porta para o codigo 0.
rodar_livro(
    "rodada completa emite a ficha e fecha",
    OBS_OK, 0,
    [("ficha-do-antes.md", "status: completo", True),
     ("ficha-do-antes.md", "representatividade: demonstrada", True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 5 |", True),
     ("stdout", "NAO FECHA", False),
     ("stdout", "fecha", True)])

# 2. O defeito literal das skills irmas, trazido para ca: item real cujo codigo
#    contem GERAL sendo apagado como linha de total, em silencio, com codigo 0.
rodar_livro(
    "caso cujo codigo contem GERAL nao e apagado como linha de total",
    OBS_OK + "OP-GERAL-7;2026-03-04;Bia;medido;cronometragem;;;30;ok;Bia;nao;\n",
    5,
    [("livro-caixa.csv", "OP-GERAL-7", True),
     ("stdout", "esta NA CONTA", True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 6 |", True),
     ("observacoes-fora-da-conta.csv", "OP-GERAL-7", False)])

# 3. Nao contar de proposito e diferente de nao contar por descuido.
rodar_livro(
    "linha de total declarada sai da conta e aparece no arquivo de fora",
    OBS_OK + "TOTAL-SEMANA;2026-03-04;Bia;medido;cronometragem;;;132;ok;Bia;nao;\n",
    0,
    [("observacoes-fora-da-conta.csv", "linha de total declarada", True),
     ("observacoes-fora-da-conta.csv", "TOTAL-SEMANA", True),
     ("livro-caixa.csv", "TOTAL-SEMANA", False),
     ("ficha-do-antes.md", "| n, observacoes medidas | 5 |", True)],
    extra=["--linha-de-total", "TOTAL-SEMANA"])

# 4. Lei de ferro 2: so fala de gestor nao emite ficha nenhuma.
rodar_livro(
    "arquivo so com estimativa declarada nao emite ficha e manda medir",
    "OP-9;2026-03-06;Gerente;declarado;;;;600;;;;toma um dia inteiro\n",
    3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "O projeto de verdade, agora, e medir", True),
     ("plano-de-medicao.md", "valor medido", True),
     ("stdout", "A FICHA NAO FOI EMITIDA", True)])

# 5. Lei de ferro 1: a fala nao entra em media nenhuma. Com uma medida de 10 e
#    uma fala de 600, a media tem que ser 10.
rodar_livro(
    "fala de gestor nao entra na media, so no carimbo",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;10;ok;Ana;nao;\n"
    "OP-9;2026-03-06;Gerente;declarado;;;;600;;;;toma um dia inteiro\n",
    1,
    [("ficha-do-antes.md", "| media | 10 | minutos por caso |", True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 1 |", True),
     ("ficha-do-antes.md", "Estimativas declaradas, fora da conta", True),
     ("ficha-do-antes.md", "| OP-9 | Gerente | 2026-03-06 | 600 |", True),
     ("ficha-do-antes.md", "representatividade: nao demonstrada", True)])

# 6. Linha com conteudo perdida na leitura por contagem de coluna. Ela some do
#    arquivo e a media continua saindo redonda.
rodar_livro(
    "linha com contagem de coluna diferente aparece com o conteudo",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;;;33\n",
    5,
    [("observacoes-fora-da-conta.csv", "descartada na leitura", True),
     ("observacoes-fora-da-conta.csv", "OP-6;2026-03-05", True),
     ("stdout", "linhas descartadas na leitura .......... 1", True)])

# 7. Origem escrita de um jeito que a rodada nao conhece. Tratar como medido
#    seria deixar uma fala virar numero.
rodar_livro(
    "origem nao reconhecida fica fora da conta e derruba o codigo 0",
    OBS_OK + "OP-6;2026-03-05;Ana;estimado;cronometragem;;;33;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "origem nao reconhecida", True),
     ("observacoes-fora-da-conta.csv", "origem lida: estimado", True),
     ("livro-caixa.csv", "OP-6", False)])

# 8. Caixa e espaco na origem sao erro de digitacao, nao decisao.
rodar_livro(
    "origem com caixa e espaco continua sendo medido",
    "OP-1;2026-03-02;Ana; Medido ;cronometragem;;;20;ok;Ana;nao;\n"
    "OP-2;2026-03-02;Bia;MEDIDO;cronometragem;;;22;ok;Bia;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Ana;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;Bia;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Ana;nao;\n",
    0,
    [("ficha-do-antes.md", "| n, observacoes medidas | 5 |", True)])

# 9. Fim menor que inicio: ou virou o dia, ou alguem digitou errado. Assumir a
#    virada em silencio inventa 24 horas de trabalho.
rodar_livro(
    "fim menor que inicio nao vira duracao sozinho",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;23:40;00:10;;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "duracao invalida", True),
     ("observacoes-fora-da-conta.csv", "confirme a virada de dia", True)])

rodar_livro(
    "com --virada-de-dia declarada a mesma linha entra",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;23:40;00:10;;ok;Ana;nao;\n",
    0,
    [("ficha-do-antes.md", "| n, observacoes medidas | 6 |", True),
     ("livro-caixa.csv", "OP-6", True)],
    extra=["--virada-de-dia"])

# 10. Duas fontes de duracao na mesma linha discordando. Escolher uma em
#     silencio e escolher o numero da linha de base no chute.
rodar_livro(
    "duracao declarada que diverge de inicio e fim nao entra",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;09:00;09:20;45;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "duracao_min diz 45 e inicio/fim dao 20",
      True)])

# 11 a 14. Os quatro requisitos da lei de ferro 2, um por caso.
rodar_livro(
    "sem validador nomeado a ficha nao sai",
    OBS_OK, 3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "validador nomeado (--validador)", True)],
    completo=False,
    extra=["--metodo", "cronometragem", "--esforco-horas", "6",
           "--conferida-contra-gabarito", "nao-conferida"])

rodar_livro(
    "sem esforco de medicao a ficha nao sai",
    OBS_OK, 3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "esforco em horas para medir", True)],
    completo=False,
    extra=["--metodo", "cronometragem", "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "nao-conferida"])

rodar_livro(
    "sem metodo de medicao a ficha nao sai",
    OBS_OK, 3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "metodo de medicao (--metodo)", True)],
    completo=False,
    extra=["--esforco-horas", "6", "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "nao-conferida"])

rodar_livro(
    "metodo que nao esta na lista nao passa por metodo",
    OBS_OK, 3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "metodo de medicao reconhecido", True)],
    completo=False,
    extra=["--metodo", "achismo", "--esforco-horas", "6",
           "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "nao-conferida"])

# 15. --so-plano nao pode devolver 0, que significa ficha emitida e fechada.
rodar_livro(
    "--so-plano devolve 4 e nao escreve ficha",
    OBS_OK, 4,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "status: so-plano, sem ficha", True),
     ("livro-caixa.csv", "OP-1", True)],
    extra=["--so-plano"])

# 16. Tres observacoes do mesmo dia e da mesma pessoa produzem um numero
#     redondo que nao aguenta comparacao. A ficha sai marcada, nunca limpa.
rodar_livro(
    "mesma pessoa e mesmo dia derrubam a representatividade",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Ana;nao;\n"
    "OP-2;2026-03-02;Ana;medido;cronometragem;;;22;ok;Ana;nao;\n"
    "OP-3;2026-03-02;Ana;medido;cronometragem;;;24;ok;Ana;nao;\n",
    1,
    [("ficha-do-antes.md", "representatividade: nao demonstrada", True),
     ("ficha-do-antes.md", "mesmo dia", True),
     ("ficha-do-antes.md", "mesma pessoa", True),
     ("stdout", "Representatividade nao demonstrada", True)])

# 17. Diretorio ja existente: erro de entrada, nao rodada valida.
rodar_livro(
    "diretorio de saida ja existente para a rodada",
    OBS_OK, 3, [("stderr", "ja existe", True)], criar_saida=True)

# 18. Anonimizacao conferida no diretorio inteiro, com a excecao declarada.
rodar_livro(
    "anonimizacao nao deixa nome real no diretorio, exceto o validador",
    "OP-1;2026-03-02;Ana Souza;medido;cronometragem;;;20;ok;Ana Souza;nao;"
    "combinado com Ana Souza\n"
    "OP-2;2026-03-02;Bia Lima;medido;cronometragem;;;22;ok;Bia Lima;nao;\n"
    "OP-3;2026-03-03;Ana Souza;medido;cronometragem;;;24;ok;Ana Souza;nao;\n"
    "OP-4;2026-03-03;Bia Lima;medido;cronometragem;;;26;ok;Bia Lima;nao;\n"
    "OP-5;2026-03-04;Ana Souza;medido;cronometragem;;;28;ok;Ana Souza;nao;\n",
    0,
    [("livro-caixa.csv", "pessoa-1", True),
     ("livro-caixa.csv", "texto livre suprimido", True),
     ("ficha-do-antes.md", "Marina Validadora", True),
     ("../saida-de-para-pessoa.csv", "Ana Souza", True),
     ("../saida-de-para-pessoa.csv", "FORA do diretorio", True)],
    completo=False,
    extra=["--metodo", "cronometragem", "--esforco-horas", "6",
           "--validador", "Marina Validadora", "--anonimizar-pessoa",
           "--conferida-contra-gabarito", "nao-conferida"],
    nomes_reais=("Ana Souza", "Bia Lima", "Marina Validadora"),
    excecoes=("ficha-do-antes.md",))

# 18b. O texto livre saia do diretorio pela linha que ficou FORA da conta: a
#      supressao valia so para a linha que entrou, e as duas ficam na mesma
#      pasta, que e o que se compartilha.
rodar_livro(
    "anonimizacao suprime o texto livre tambem na linha que ficou fora da conta",
    "OP-1;2026-03-02;Ana Souza;medido;cronometragem;;;20;ok;Ana Souza;nao;\n"
    "OP-2;2026-03-02;Bia Lima;medido;cronometragem;;;22;ok;Bia Lima;nao;\n"
    "OP-3;2026-03-03;Ana Souza;medido;cronometragem;;;24;ok;Ana Souza;nao;\n"
    "OP-4;2026-03-03;Bia Lima;medido;cronometragem;;;26;ok;Bia Lima;nao;\n"
    "OP-5;2026-03-04;Ana Souza;medido;cronometragem;;;28;ok;Ana Souza;nao;\n"
    "OP-6;;Ana Souza;medido;cronometragem;;;33;ok;Ana Souza;nao;"
    "queixa do operador sobre o supervisor\n",
    5,
    [("observacoes-fora-da-conta.csv", "texto livre suprimido", True),
     ("observacoes-fora-da-conta.csv", "queixa do operador", False)],
    completo=False,
    extra=["--metodo", "cronometragem", "--esforco-horas", "6",
           "--validador", "Marina Validadora", "--anonimizar-pessoa",
           "--conferida-contra-gabarito", "nao-conferida"],
    nomes_reais=("Ana Souza", "Bia Lima"),
    excecoes=("ficha-do-antes.md",))

# 19. Coluna obrigatoria ausente: sair com 0 aqui seria dizer que a tarefa foi
#     medida sem ter lido observacao nenhuma.
rodar_livro(
    "coluna obrigatoria ausente lista as colunas encontradas",
    "2026-03-02;Ana;medido;20\n", 3,
    [("stderr", "coluna obrigatoria ausente: caso", True),
     ("stderr", "Colunas encontradas", True)],
    cabecalho="data;quem;origem;duracao_min")

# 20. Arquivo so com cabecalho.
rodar_livro(
    "arquivo sem nenhuma observacao nao emite ficha",
    "", 3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "nenhuma observacao entrou na conta", True)])

# 21. A fronteira do produto, escrita no artefato.
rodar_livro(
    "a ficha declara que nao diz o que automatizar",
    OBS_OK, 0,
    [("ficha-do-antes.md", "nao diz o que automatizar, em quanto tempo nem por "
      "quanto", True)])

# 22. Rodape em todo artefato, os quatro.
rodar_livro(
    "rodape em todo artefato",
    OBS_OK, 0,
    [("ficha-do-antes.md", "Gerado com apoio de IA", True),
     ("plano-de-medicao.md", "Gerado com apoio de IA", True),
     ("livro-caixa.csv", "Gerado com apoio de IA", True),
     ("observacoes-fora-da-conta.csv", "Gerado com apoio de IA", True),
     ("ficha-do-antes.md", "Nao substitui responsabilidade tecnica", True)])

# 23. --estrito nao aceita pendencia.
rodar_livro(
    "--estrito devolve 2 quando existe pendencia",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Ana;nao;\n"
    "OP-2;2026-03-02;Ana;medido;cronometragem;;;22;ok;Ana;nao;\n"
    "OP-3;2026-03-02;Ana;medido;cronometragem;;;24;ok;Ana;nao;\n",
    2, [("stderr", "existe pendencia", True)], extra=["--estrito"])

# 24 e 25. Observacao medida sem data e sem duracao.
rodar_livro(
    "observacao medida sem data fica incompleta",
    OBS_OK + "OP-6;;Ana;medido;cronometragem;;;33;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "observacao medida sem data", True)])

rodar_livro(
    "observacao medida sem duracao e sem inicio e fim fica incompleta",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;;;;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "observacao medida sem duracao", True)])

# 26 e 27. O total por janela e derivado. Volume que ninguem contou sai
#          carimbado, senao a ficha exporta uma fala travestida de medicao.
rodar_livro(
    "volume por janela nao medido sai carimbado",
    OBS_OK, 0,
    [("ficha-do-antes.md", "volume DECLARADO, nao medido", True),
     ("ficha-do-antes.md", "Total por janela, derivado", True)],
    extra=["--janela", "semana", "--volume-janela", "40"])

rodar_livro(
    "volume por janela medido sai como medido",
    OBS_OK, 0,
    [("ficha-do-antes.md", "| semana | 40 | volume medido |", True),
     ("ficha-do-antes.md", "volume DECLARADO", False)],
    extra=["--janela", "semana", "--volume-janela", "40", "--volume-medido"])

# 28. Linha vazia no meio do arquivo continua contada, e o fechamento fecha.
rodar_livro(
    "linha vazia no meio do arquivo e contada, nao ignorada",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Ana;nao;\n"
    "\n"
    "OP-2;2026-03-02;Bia;medido;cronometragem;;;22;ok;Bia;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Ana;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;Bia;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Ana;nao;\n",
    0,
    [("stdout", "linhas vazias .......................... 1", True),
     ("stdout", "NAO FECHA", False),
     ("observacoes-fora-da-conta.csv", "linha vazia", True)])

# 29. Duracao zero ou negativa declarada direto na coluna.
rodar_livro(
    "duracao zero nao entra na conta",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;;;0;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "duracao tem que ser maior que zero",
      True)])

# 30. Aspa dupla que ninguem fechou. O leitor de CSV engole todas as linhas
#     seguintes dentro de um campo de texto: a rodada saia com codigo 0, ficha
#     completa, representatividade demonstrada, arquivo de fora vazio e as cinco
#     identidades imprimindo fecha, com nove observacoes engolidas. As linhas
#     engolidas eram justamente as de retrabalho: a mediana verdadeira era o
#     dobro da que saiu.
ASPA_ABERTA = (
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Ana;nao;\n"
    "OP-2;2026-03-02;Bia;medido;cronometragem;;;22;ok;Bia;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Ana;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;Bia;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Ana;nao;"
    "\"peca especial\n"
    "OP-6;2026-03-04;Bia;medido;cronometragem;;;110;retrabalho;Bia;nao;\n"
    "OP-7;2026-03-05;Ana;medido;cronometragem;;;130;retrabalho;Ana;nao;\n"
    "OP-8;2026-03-05;Bia;medido;cronometragem;;;150;retrabalho;Bia;nao;\n")

rodar_livro(
    "aspa nao fechada engolindo o resto do arquivo derruba a rodada",
    ASPA_ABERTA, 3,
    [("ficha-do-antes.md", "", False),
     ("observacoes-fora-da-conta.csv", "aspa nao fechada", True),
     ("observacoes-fora-da-conta.csv", "OP-8", True),
     ("stdout", "linhas com aspa nao fechada ............ 1", True),
     ("stderr", "engole o resto do arquivo", True),
     ("plano-de-medicao.md", "status: invalido, a leitura perdeu linha", True)])

# 31. A identidade que nao podia detectar o caso acima: ela comparava a saida do
#     leitor de CSV com a contagem do laco que consome a mesma saida. A nova
#     compara o leitor com as linhas fisicas do arquivo.
rodar_livro(
    "o fechamento conta linha fisica do arquivo, nao so o que o leitor devolveu",
    OBS_OK, 0,
    [("stdout", "linhas_fisicas_do_arquivo", True),
     ("ficha-do-antes.md", "linhas_fisicas_do_arquivo", True),
     ("stdout", "NAO FECHA", False)])

# 32. Campo multilinha existe de verdade em planilha exportada do Excel. Com a
#     opcao declarada, a linha entra e o registro e contado como multilinha.
rodar_livro(
    "com --campo-multilinha declarado a quebra de linha na coluna obs entra",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Ana;nao;"
    "\"peca especial\ncom duas linhas\"\n"
    "OP-2;2026-03-02;Bia;medido;cronometragem;;;22;ok;Bia;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Ana;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;Bia;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Ana;nao;\n",
    0,
    [("ficha-do-antes.md", "| n, observacoes medidas | 5 |", True),
     ("stdout", "registros com campo multilinha declarado ...... 1", True),
     ("stdout", "NAO FECHA", False)],
    extra=["--campo-multilinha"])

# 33. Copiar e colar linha em planilha de apontamento e o erro mais comum do
#     insumo. Tres copias identicas de uma observacao de 120 entravam na conta
#     uma vez por copia, sem alerta, sem linha no arquivo de fora e sem efeito
#     no codigo de saida: a media saia de 64,6 no lugar de 47,5.
rodar_livro(
    "duplicata exata de observacao fica fora da conta e reportada",
    OBS_OK
    + "OP-9;2026-03-05;Ana;medido;cronometragem;;;120;ok;Ana;nao;\n"
    + "OP-9;2026-03-05;Ana;medido;cronometragem;;;120;ok;Ana;nao;\n"
    + "OP-9;2026-03-05;Ana;medido;cronometragem;;;120;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "duplicata exata", True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 6 |", True),
     ("stdout", "duplicatas exatas ...................... 2", True),
     ("stdout", "NAO FECHA", False)])

# 34. Repeticao do mesmo caso com duracao diferente e observacao legitima: duas
#     execucoes do mesmo caso. Ela continua na conta, com alerta.
rodar_livro(
    "mesmo caso com duracao diferente continua na conta, com alerta",
    OBS_OK + "OP-1;2026-03-05;Ana;medido;cronometragem;;;33;ok;Ana;nao;\n",
    0,
    [("livro-caixa.csv", "o mesmo caso ja entrou na conta com outra duracao",
      True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 6 |", True),
     ("observacoes-fora-da-conta.csv", "duplicata exata", False)])

# 35. A representatividade se mede sobre quem FAZ. Cinco observacoes de uma
#     unica executante, com tres observadores diferentes, saiam com codigo 0 e a
#     ficha afirmando por escrito que o numero cobre mais de uma pessoa.
rodar_livro(
    "tres observadores para uma unica executante nao demonstram "
    "representatividade",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Bruno;nao;\n"
    "OP-2;2026-03-02;Ana;medido;cronometragem;;;22;ok;Carla;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Bruno;nao;\n"
    "OP-4;2026-03-03;Ana;medido;cronometragem;;;26;ok;Dora;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Carla;nao;\n",
    1,
    [("ficha-do-antes.md", "representatividade: nao demonstrada", True),
     ("ficha-do-antes.md", "| pessoas que executaram | 1 | pessoas |", True),
     ("ficha-do-antes.md", "| observadores distintos | 3 | pessoas |", True),
     ("stdout", "executantes distintos .................. 1", True)])

# 36. O erro na direcao inversa: um observador unico acompanhando duas
#     executantes derrubava a representatividade sem motivo.
rodar_livro(
    "um observador unico para duas executantes nao derruba a representatividade",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;Bruno;nao;\n"
    "OP-2;2026-03-02;Bia;medido;cronometragem;;;22;ok;Bruno;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Bruno;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;Bruno;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Bruno;nao;\n",
    0,
    [("ficha-do-antes.md", "representatividade: demonstrada", True),
     ("ficha-do-antes.md", "| pessoas que executaram | 2 | pessoas |", True),
     ("ficha-do-antes.md", "| observadores distintos | 1 | pessoas |", True)])

# 37. Observacao medida sem quem executou nao entra na conta, do mesmo jeito que
#     a que nao tem data.
rodar_livro(
    "observacao medida sem quem executou fica incompleta",
    OBS_OK + "OP-6;2026-03-05;;medido;cronometragem;;;33;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "observacao medida sem quem executou",
      True),
     ("livro-caixa.csv", "OP-6", False)])

# 38. O total por janela e outra grandeza. Ele saia rotulado com a unidade por
#     caso: 960 minutos por semana impresso como 960 minutos por caso.
rodar_livro(
    "o total por janela sai na unidade da janela, nao na unidade por caso",
    OBS_OK, 0,
    [("ficha-do-antes.md", "| semana | 40 | volume medido | 960 minutos por "
      "semana |", True),
     ("ficha-do-antes.md", "minutos por semana, e nao em minutos por caso",
      True)],
    extra=["--janela", "semana", "--volume-janela", "40", "--volume-medido"])

rodar_livro(
    "unidade que nao e por caso recusa a derivacao do total por janela",
    OBS_OK, 0,
    [("ficha-do-antes.md", "Nao derivado", True),
     ("ficha-do-antes.md", "ela nao e por caso", True)],
    completo=False,
    extra=["--unidade", "casos por dia", "--janela", "semana",
           "--volume-janela", "40", "--metodo", "contagem-de-registro",
           "--esforco-horas", "4", "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "nao-conferida"])

# 39. A lei do gabarito do kit, agora verificavel. Sem a declaracao a ficha nao
#     sai, e a marca de nao conferida existe no artefato em vez de viver na
#     conversa, que acaba.
rodar_livro(
    "sem declarar a conferencia contra o gabarito da lei a ficha nao sai",
    OBS_OK, 3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "conferencia contra o gabarito da lei declarada",
      True),
     ("stdout", "A FICHA NAO FOI EMITIDA", True)],
    completo=False,
    extra=["--metodo", "cronometragem", "--esforco-horas", "6",
           "--validador", "Validador Teste"])

rodar_livro(
    "conferencia nao-conferida carimba a ficha no topo",
    OBS_OK, 0,
    [("ficha-do-antes.md", "NAO CONFERIDA CONTRA GABARITO", True),
     ("ficha-do-antes.md", "| Conferida contra gabarito | nao-conferida |",
      True)])

rodar_livro(
    "conferencia contra medicao anterior imprime os dois numeros e a diferenca",
    OBS_OK, 0,
    [("ficha-do-antes.md", "| medicao anterior da area | 24 minutos por caso | "
      "24 minutos por caso | 0% |", True),
     ("ficha-do-antes.md", "NAO CONFERIDA CONTRA GABARITO", False)],
    completo=False,
    extra=["--metodo", "cronometragem", "--esforco-horas", "6",
           "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "medicao-anterior",
           "--numero-da-pessoa", "24"])

rodar_livro(
    "diferenca acima do criterio contra o numero da pessoa vira pendencia",
    OBS_OK, 1,
    [("ficha-do-antes.md", "representatividade: demonstrada", True),
     ("ficha-do-antes.md", "conferencia contra o gabarito: fora do criterio",
      True),
     ("ficha-do-antes.md", "60% longe do numero que a pessoa tinha", True),
     ("stdout", "Pendencia declarada: conferencia contra o gabarito da lei",
      True),
     ("stdout", "Representatividade nao demonstrada", False)],
    completo=False,
    extra=["--metodo", "cronometragem", "--esforco-horas", "6",
           "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "tres-casos-a-mao",
           "--numero-da-pessoa", "15"])

rodar_livro(
    "conferencia declarada sem o numero da pessoa nao emite ficha",
    OBS_OK, 3,
    [("ficha-do-antes.md", "", False),
     ("plano-de-medicao.md", "o numero que a pessoa tinha", True)],
    completo=False,
    extra=["--metodo", "cronometragem", "--esforco-horas", "6",
           "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "medicao-anterior"])

# 40. A suspeita de linha de total era registrada antes das recusas: linha que
#     acabou FORA da conta saia afirmada como estando NA CONTA, no terminal, no
#     plano e na ficha assinada, e ainda inflava o codigo 5.
rodar_livro(
    "suspeita de total que ficou fora da conta nao e afirmada como estando nela",
    OBS_OK + "TOTAL SEMANA;;Ana;medido;cronometragem;;;132;ok;Ana;nao;\n",
    5,
    [("stdout", "ja esta FORA da conta como incompleta", True),
     ("stdout", "suspeitas de linha de total NA CONTA ........... 0", True),
     ("ficha-do-antes.md", "JA ESTAO FORA da conta", True),
     ("ficha-do-antes.md", "Elas estao NA CONTA", False),
     ("plano-de-medicao.md", "Estas linhas continuam NA CONTA", False)])

# 41. Os formatos que a folha de apontamento carrega de verdade. Eles saiam como
#     "observacao medida sem duracao", e a correcao sugerida era preencher a
#     duracao que ja estava preenchida.
rodar_livro(
    "1h10, 30 min e 0:50 entram na conta com a conversao escrita",
    "OP-1;2026-03-02;Ana;medido;autoapontamento;;;1h10;ok;Ana;nao;\n"
    "OP-2;2026-03-02;Bia;medido;autoapontamento;;;30 min;ok;Bia;nao;\n"
    "OP-3;2026-03-03;Ana;medido;autoapontamento;;;0:50;ok;Ana;nao;\n"
    "OP-4;2026-03-03;Bia;medido;autoapontamento;;;1,5 h;ok;Bia;nao;\n"
    "OP-5;2026-03-04;Ana;medido;autoapontamento;;;45;ok;Ana;nao;\n",
    0,
    [("livro-caixa.csv", "'1h10' lido como 70 minutos", True),
     ("livro-caixa.csv", "'1,5 h' lido como 90 minutos", True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 5 |", True),
     ("observacoes-fora-da-conta.csv", "sem duracao", False)],
    completo=False,
    extra=["--metodo", "autoapontamento", "--esforco-horas", "6",
           "--validador", "Validador Teste",
           "--conferida-contra-gabarito", "nao-conferida"])

rodar_livro(
    "duracao aproximada sai da conta com a causa certa escrita",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;;;aprox 40;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "duracao aproximada", True),
     ("observacoes-fora-da-conta.csv", "aproximacao e fala, nao medicao", True),
     ("observacoes-fora-da-conta.csv", "origem declarado", True),
     ("observacoes-fora-da-conta.csv", "observacao medida sem duracao", False)])

# 42. Procurado por conta propria, atras da mesma doenca: 1.000 na celula de
#     duracao entrava como 1,0 minuto. Mil minutos viravam um minuto, e a rodada
#     seguia. O valor e ambiguo de fato, e adivinhar aqui e escolher o numero da
#     linha de base no chute.
rodar_livro(
    "duracao com separador de milhar e ambigua e nao entra como um minuto",
    OBS_OK + "OP-6;2026-03-05;Ana;medido;cronometragem;;;1.000;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "duracao ambigua", True),
     ("observacoes-fora-da-conta.csv", "pode ser mil e pode ser um", True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 5 |", True),
     ("livro-caixa.csv", "OP-6", False)])

# 43. Procurado por conta propria: linha com conteudo e sem codigo de caso
#     entrava na conta, e o caso vazio virava um caso distinto na ficha.
rodar_livro(
    "linha medida sem codigo de caso nao entra na conta",
    OBS_OK + ";2026-03-05;Ana;medido;cronometragem;;;33;ok;Ana;nao;\n",
    5,
    [("observacoes-fora-da-conta.csv", "linha sem caso", True),
     ("stdout", "linhas sem caso ........................ 1", True),
     ("ficha-do-antes.md", "| n, observacoes medidas | 5 |", True),
     ("stdout", "NAO FECHA", False)])

# 44. O cabecalho que a folha de apontamento tem de verdade. A primeira rodada
#     parava com coluna obrigatoria ausente e a mensagem nao dizia o que fazer.
rodar_livro(
    "cabecalho real de folha de apontamento e reconhecido, menos a origem",
    "OP-1;2026-03-02;Ana;;;20;ok;Bruno;\n", 3,
    [("stderr", "coluna obrigatoria ausente: origem", True),
     ("stderr", "OP -> caso", True),
     ("stderr", "Operador -> quem", True),
     ("stderr", "Tempo (min) -> duracao_min", True),
     ("stderr", "Quem observou -> observador", True),
     ("stderr", "e o passo 4 da skill", True)],
    cabecalho="OP;Data;Operador;Inicio;Fim;Tempo (min);Resultado;"
              "Quem observou;Obs")

# 45. O buraco no registro contado como pessoa. O passo 4 da SKILL.md manda
#     escrever "nao identificado" em quem executou quando o registro nao diz
#     quem foi, e promete que a ficha sai com a representatividade nao
#     demonstrada. O script nao implementava isso: a palavra entrava como
#     executante DISTINTO. Tres observacoes sem executante mais duas da mesma
#     pessoa saiam com "pessoas que executaram | 2", representatividade
#     demonstrada e codigo 0, e a ficha-do-antes.md e o documento que vai para a
#     reuniao sustentar a decisao de automatizar. O criterio de mais de uma
#     pessoa executando estava sendo satisfeito por um campo em branco
#     renomeado.
rodar_livro(
    "quem executou nao identificado nao conta como executante distinto",
    "OP-1;2026-03-02;nao identificado;medido;cronometragem;;;20;ok;Bruno;nao;\n"
    "OP-2;2026-03-02;nao identificado;medido;cronometragem;;;22;ok;Bruno;nao;\n"
    "OP-3;2026-03-03;nao identificado;medido;cronometragem;;;24;ok;Bruno;nao;\n"
    "OP-4;2026-03-03;Ana;medido;cronometragem;;;26;ok;Bruno;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Bruno;nao;\n",
    1,
    [("ficha-do-antes.md", "representatividade: nao demonstrada", True),
     ("ficha-do-antes.md", "representatividade: demonstrada", False),
     ("ficha-do-antes.md", "| pessoas que executaram | 1 | pessoas |", True),
     ("ficha-do-antes.md",
      "| observacoes sem executante identificado | 3 | observacoes |", True),
     ("ficha-do-antes.md", "3 de 5 observacao(oes) na conta nao dizem quem "
      "executou", True),
     ("livro-caixa.csv", "buraco no registro e nao pessoa", True),
     ("stdout", "sem executante identificado ............ 3", True),
     ("stdout", "executantes distintos .................. 1", True)])

# 46. Acento e caixa sao digitacao, nao decisao. Escrito "Nao Identificado" ou
#     "nao-identificado", o buraco e o mesmo buraco.
rodar_livro(
    "acento, caixa e hifen no valor de preenchimento nao criam executante",
    "OP-1;2026-03-02;Não Identificado;medido;cronometragem;;;20;ok;B;nao;\n"
    "OP-2;2026-03-02;NAO IDENTIFICADO;medido;cronometragem;;;22;ok;B;nao;\n"
    "OP-3;2026-03-03;nao-identificado;medido;cronometragem;;;24;ok;B;nao;\n"
    "OP-4;2026-03-03;Ana;medido;cronometragem;;;26;ok;B;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;B;nao;\n",
    1,
    [("ficha-do-antes.md", "representatividade: nao demonstrada", True),
     ("ficha-do-antes.md", "| pessoas que executaram | 1 | pessoas |", True),
     ("stdout", "sem executante identificado ............ 3", True)])

# 47. O caso extremo: nenhuma observacao diz quem executou. A contagem de
#     executantes cai para zero, e a frase de "uma unica pessoa" nao serve mais
#     para descrever isso.
rodar_livro(
    "nenhum executante identificado sai dito, e nao como uma unica pessoa",
    "OP-1;2026-03-02;nao identificado;medido;cronometragem;;;20;ok;B;nao;\n"
    "OP-2;2026-03-02;nao informado;medido;cronometragem;;;22;ok;B;nao;\n"
    "OP-3;2026-03-03;desconhecido;medido;cronometragem;;;24;ok;B;nao;\n"
    "OP-4;2026-03-03;n/a;medido;cronometragem;;;26;ok;B;nao;\n"
    "OP-5;2026-03-04;-;medido;cronometragem;;;28;ok;B;nao;\n",
    1,
    [("ficha-do-antes.md", "| pessoas que executaram | 0 | pessoas |", True),
     ("ficha-do-antes.md",
      "| observacoes sem executante identificado | 5 | observacoes |", True),
     ("ficha-do-antes.md", "nenhuma observacao na conta tem executante "
      "identificado", True),
     ("ficha-do-antes.md", "uma unica pessoa", False)])

# 48. O nome de verdade continua contando. Um remedio que derruba toda rodada
#     nao e remedio: seria trocar um falso positivo por outro.
rodar_livro(
    "nome de pessoa de verdade continua contando como executante",
    OBS_OK, 0,
    [("ficha-do-antes.md", "representatividade: demonstrada", True),
     ("ficha-do-antes.md", "| pessoas que executaram | 2 | pessoas |", True),
     ("ficha-do-antes.md",
      "| observacoes sem executante identificado | 0 | observacoes |", True),
     ("stdout", "sem executante identificado ............ 0", True)])

# 49. Procurado por conta propria, atras da mesma doenca no resto da ficha: o
#     observador preenchido com a palavra do buraco saia contado como observador
#     distinto, e a ficha imprimia duas pessoas anotando onde havia uma.
rodar_livro(
    "observador nao identificado nao conta como observador distinto",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;nao identificado;nao;\n"
    "OP-2;2026-03-02;Bia;medido;cronometragem;;;22;ok;Bruno;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;Bruno;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;Bruno;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;Bruno;nao;\n",
    0,
    [("ficha-do-antes.md", "| observadores distintos | 1 | pessoas |", True),
     ("ficha-do-antes.md",
      "| observacoes sem observador identificado | 1 | observacoes |", True),
     ("livro-caixa.csv", "sem observador declarado", True),
     ("stdout", "sem observador identificado ............ 1", True)])

# 50. Mesma doenca no codigo do caso: duas linhas com o codigo preenchido pela
#     palavra do buraco saiam contadas como dois casos distintos, e a segunda
#     ainda ganhava o alerta de que o mesmo caso entrou duas vezes, afirmando
#     que sao duas execucoes da mesma coisa. Nao sao: sao dois buracos.
rodar_livro(
    "codigo de caso nao identificado nao conta como caso distinto",
    "nao identificado;2026-03-02;Ana;medido;cronometragem;;;20;ok;B;nao;\n"
    "nao identificado;2026-03-02;Bia;medido;cronometragem;;;22;ok;B;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;B;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;B;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;B;nao;\n",
    0,
    [("ficha-do-antes.md", "contagem de casos distintos desta ficha e 3", True),
     ("ficha-do-antes.md", "2 nao tem codigo de caso identificado", True),
     ("ficha-do-antes.md", "Ha caso que aparece mais de uma vez", False),
     ("livro-caixa.csv", "o mesmo caso ja entrou na conta", False),
     ("stdout", "sem caso identificado .................. 2", True)])

# 51. Procurado por conta propria nos outros criterios da representatividade,
#     para saber se a doenca esta neles tambem. Dia preenchido com a palavra do
#     buraco nao vira dia distinto: a linha nao passa pela leitura da data e sai
#     da conta como incompleta. O caso fica aqui para que continue assim.
rodar_livro(
    "dia nao identificado nao vira dia distinto",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;20;ok;B;nao;\n"
    "OP-2;nao identificado;Bia;medido;cronometragem;;;22;ok;B;nao;\n"
    "OP-3;2026-03-02;Ana;medido;cronometragem;;;24;ok;B;nao;\n"
    "OP-4;2026-03-02;Bia;medido;cronometragem;;;26;ok;B;nao;\n"
    "OP-5;2026-03-02;Ana;medido;cronometragem;;;28;ok;B;nao;\n",
    5,
    [("ficha-do-antes.md", "| dias distintos | 1 | dias |", True),
     ("ficha-do-antes.md", "representatividade: nao demonstrada", True),
     ("observacoes-fora-da-conta.csv", "observacao medida sem data", True),
     ("stdout", "todas as observacoes sao do mesmo dia", True)])

# 52. Mesma pergunta na duracao: a palavra do buraco na celula de duracao nao
#     vira observacao medida. Ela sai da conta com a causa escrita, e o n cai
#     abaixo de cinco em vez de subir.
rodar_livro(
    "duracao nao identificada nao vira observacao medida",
    "OP-1;2026-03-02;Ana;medido;cronometragem;;;nao identificado;ok;B;nao;\n"
    "OP-2;2026-03-02;Bia;medido;cronometragem;;;22;ok;B;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;B;nao;\n"
    "OP-4;2026-03-03;Bia;medido;cronometragem;;;26;ok;B;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;B;nao;\n",
    5,
    [("ficha-do-antes.md", "| n, observacoes medidas | 4 | observacoes |", True),
     ("ficha-do-antes.md", "representatividade: nao demonstrada", True),
     ("observacoes-fora-da-conta.csv", "duracao nao reconhecida", True)])

# 53. A pendencia de representatividade sumia da tela toda vez que sobrava linha
#     fora da conta: o ramo de sobrou devolvia 5 antes de imprimir. A ficha
#     dizia nao demonstrada e o terminal, que e o que a pessoa le primeiro, nao
#     dizia nada.
rodar_livro(
    "a pendencia de representatividade e impressa mesmo sobrando linha fora",
    "OP-1;2026-03-02;nao identificado;medido;cronometragem;;;20;ok;B;nao;\n"
    "OP-2;2026-03-02;nao identificado;medido;cronometragem;;;22;ok;B;nao;\n"
    "OP-3;2026-03-03;Ana;medido;cronometragem;;;24;ok;B;nao;\n"
    "OP-4;2026-03-03;Ana;medido;cronometragem;;;26;ok;B;nao;\n"
    "OP-5;2026-03-04;Ana;medido;cronometragem;;;28;ok;B;nao;\n"
    "OP-6;2026-03-04;Ana;medido;cronometragem;;;;ok;B;nao;\n",
    5,
    [("stdout", "Representatividade nao demonstrada", True),
     ("stdout", "nao dizem quem executou", True),
     ("stdout", "Ficou dado fora da conta", True)])

# 54. Os scripts do kit tambem obedecem a regra do travessao. O verificador do
#     SKILL.md carregava os dois sinais escritos no proprio corpo, e trocar cada
#     um por virgula, que e o que a regra manda fazer no texto, desligaria a
#     checagem em silencio: por isso eles entram por escape.
def conferir_sinais_nos_scripts():
    erros = []
    for arquivo in (LIVRO, DIVERGENCIA, Path(__file__).resolve()):
        if not arquivo.is_file():
            erros.append("script ausente: %s" % arquivo.name)
            continue
        texto = arquivo.read_text(encoding="utf-8")
        for numero, linha in enumerate(texto.split("\n"), 1):
            if TRAVESSAO in linha or MEIA_RISCA in linha:
                erros.append("travessao ou meia-risca em %s, linha %d"
                             % (arquivo.name, numero))
    registrar("scripts sem travessao e sem meia-risca", erros)


conferir_sinais_nos_scripts()

print("")
print("== divergencia.py ==")
print("")

# 30. O defeito central da conta: nenhum caso pareado e a saida dizendo que
#     bate. Aqui o gabarito e o motor usam codigos diferentes.
rodar_div(
    "nenhum caso pareado derruba a rodada em vez de dizer que bate",
    gabarito_de(10, CANTOS_PADRAO),
    "X-1;R1\nX-2;R2\n", 3,
    [("stderr", "nenhum caso pareou", True),
     ("stderr", "sem ter comparado nada", True)])

# 31. Caso do gabarito que o motor nunca viu. E o equivalente da mensagem em
#     subpasta que nunca foi lida com tudo fechando.
rodar_div(
    "caso do gabarito nao processado pelo motor e resultado, nao ausencia",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(9), 5,
    [("divergencias-contra-gabarito.csv", "caso_nao_processado_pelo_motor",
      True),
     ("divergencias-contra-gabarito.csv", "C-10", True),
     ("stdout", "casos do gabarito nao processados ...... 1", True)])

# 32. Caso que o motor produziu e o gabarito nao cobre.
rodar_div(
    "caso do motor fora do gabarito aparece na lista",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(10) + "C-99;R99\n", 5,
    [("divergencias-contra-gabarito.csv", "caso_fora_do_gabarito", True),
     ("divergencias-contra-gabarito.csv", "C-99", True)])

# 33. Gabarito pequeno demais. Bater dez de dez e facil com quatro casos.
rodar_div(
    "gabarito abaixo do minimo nao autoriza o estagio",
    gabarito_de(4, ((3, "campo vazio"), (4, "registro duplicado"))),
    motor_de(4), 5,
    [("stdout", "NAO ATENDE", True),
     ("cobertura-do-gabarito.md", "NAO autoriza o estagio piloto", True)])

rodar_div(
    "trinta casos sao exigidos para producao",
    gabarito_de(10, CANTOS_PADRAO), motor_de(10), 5,
    [("cobertura-do-gabarito.md", "casos no gabarito >= 30", True),
     ("cobertura-do-gabarito.md", "NAO autoriza o estagio producao", True)],
    extra=["--estagio", "producao"])

# 34. Divergencia sem ninguem ter dito de quem e o erro.
rodar_div(
    "divergencia sem classificacao fica indeterminada",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(10, {3: "RX"}), 1,
    [("divergencias-contra-gabarito.csv", "diferente;indeterminado", True),
     ("cobertura-do-gabarito.md", "nao e empate", True)])

rodar_div(
    "--estrito nao aceita divergencia indeterminada",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(10, {3: "RX"}), 2,
    [("stderr", "existe pendencia", True)], extra=["--estrito"])

# 35. Classe escrita fora do vocabulario. Aceitar em silencio seria fechar a
#     conta com uma classificacao que ninguem entende.
rodar_div(
    "classe nao reconhecida vira indeterminado e aparece nomeada",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(10, {3: "RX"}), 1,
    [("stdout", "classes de divergencia nao reconhecidas", True),
     ("cobertura-do-gabarito.md", "| C-3 | erro de digitacao |", True),
     ("divergencias-contra-gabarito.csv", "diferente;indeterminado", True)],
    classificacao="C-3;erro de digitacao;Ana;2026-03-10\n")

rodar_div(
    "classificacao reconhecida fecha a identidade das tres classes",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(10, {3: "RX", 4: "RY"}), 1,
    [("divergencias-contra-gabarito.csv", "diferente;erro-do-motor", True),
     ("divergencias-contra-gabarito.csv", "diferente;erro-do-gabarito", True),
     ("stdout", "diferentes = erro_do_motor + erro_do_gabarito + "
      "indeterminado", True),
     ("stdout", "NAO FECHA", False)],
    classificacao="C-3;erro-do-motor;Ana;2026-03-10\n"
                  "C-4;erro do gabarito;Bia;2026-03-10\n")

# 36. Classificacao de um caso que nao divergiu costuma ser rodada trocada.
rodar_div(
    "classificacao sem divergencia correspondente e reportada",
    gabarito_de(10, CANTOS_PADRAO), motor_de(10), 5,
    [("stdout", "classificacoes sem divergencia correspondente", True),
     ("cobertura-do-gabarito.md", "rodada classificada e outra", True)],
    classificacao="C-2;erro-do-motor;Ana;2026-03-10\n")

# 37. Gabarito so com caso facil mede a parte facil.
rodar_div(
    "gabarito sem caso de canto nao autoriza o estagio",
    gabarito_de(10), motor_de(10), 5,
    [("cobertura-do-gabarito.md", "classes de canto distintas >= 2", True),
     ("cobertura-do-gabarito.md", "Nenhuma. Gabarito so com caso facil", True),
     ("stdout", "NAO ATENDE", True)])

rodar_div(
    "uma classe de canto so ainda nao autoriza",
    gabarito_de(10, ((9, "campo vazio"), (10, "campo vazio"))),
    motor_de(10), 5,
    [("cobertura-do-gabarito.md", "| classes de canto distintas >= 2 | 1 | "
      "NAO ATENDE |", True)])

# 38. Vazio nao e igual. Contar como igual e o caminho mais curto para 100%.
rodar_div(
    "resultado vazio no gabarito nao conta como igual",
    gabarito_de(9, CANTOS_PADRAO) + "C-10;registro duplicado;e10;;Ana;"
    "2026-03-10;pasta\n",
    motor_de(10), 5,
    [("divergencias-contra-gabarito.csv", "resultado_vazio_no_gabarito", True),
     ("stdout", "nao comparaveis (um dos lados vazio) ... 1", True),
     ("stdout", "iguais ................................. 9", True)])

rodar_div(
    "resultado vazio no motor nao conta como igual",
    gabarito_de(10, CANTOS_PADRAO), motor_de(9) + "C-10;\n", 5,
    [("divergencias-contra-gabarito.csv", "resultado_vazio_no_motor", True)])

# 39. Coluna obrigatoria ausente na saida do motor.
rodar_div(
    "coluna obrigatoria ausente na saida do motor derruba a rodada",
    gabarito_de(10, CANTOS_PADRAO), "C-1\nC-2\n", 3,
    [("stderr", "coluna obrigatoria ausente na saida do motor", True)],
    cab_motor="caso")

# 40. Caso repetido no gabarito com resultados diferentes.
rodar_div(
    "caso repetido no gabarito com resultados diferentes nao pareia em silencio",
    gabarito_de(10, CANTOS_PADRAO) + "C-3;nao;e3;OUTRO;Ana;2026-03-01;pasta\n",
    motor_de(10), 5,
    [("divergencias-contra-gabarito.csv",
      "caso_repetido_divergente_no_gabarito", True),
     ("cobertura-do-gabarito.md", "nenhum caso do gabarito repetido com "
      "resultado diferente | 1 | NAO ATENDE", True),
     ("stdout", "NAO FECHA", False)])

# 41. Diferenca de formato numerico: igualar em silencio esconde diferenca de
#     valor em outro campo. So iguala com tolerancia declarada.
rodar_div(
    "10 contra 10,0 e diferenca reportada sem tolerancia declarada",
    gabarito_de(9, CANTOS_PADRAO) + "C-10;registro duplicado;e10;10;Ana;"
    "2026-03-10;pasta\n",
    motor_de(9) + "C-10;10,0\n", 1,
    [("divergencias-contra-gabarito.csv", "C-10;registro duplicado;10;10,0;"
      "diferente", True),
     ("cobertura-do-gabarito.md", "| tolerancia numerica | nenhuma |", True)])

rodar_div(
    "com tolerancia declarada a mesma diferenca some, e a tolerancia fica no "
    "relatorio",
    gabarito_de(9, CANTOS_PADRAO) + "C-10;registro duplicado;e10;10;Ana;"
    "2026-03-10;pasta\n",
    motor_de(9) + "C-10;10,0\n", 0,
    [("cobertura-do-gabarito.md", "| tolerancia numerica | 0,5 |", True),
     ("stdout", "diferentes ............................. 0", True)],
    extra=["--tolerancia", "0,5"])

# 42. O caso feliz da conta, que e a unica porta para o codigo 0.
rodar_div(
    "gabarito de dez com dois cantos e motor identico devolve 0",
    gabarito_de(10, CANTOS_PADRAO), motor_de(10), 0,
    [("stdout", "NAO ATENDE", False),
     ("stdout", "NAO FECHA", False),
     ("cobertura-do-gabarito.md", "A cobertura autoriza o estagio piloto",
      True)])

# 43. --so-cobertura nao pode devolver 0.
rodar_div(
    "--so-cobertura devolve 4 e nao escreve lista de divergencia",
    gabarito_de(10, CANTOS_PADRAO), None, 4,
    [("divergencias-contra-gabarito.csv", "", False),
     ("cobertura-do-gabarito.md", "status: so-cobertura, sem comparacao",
      True)],
    extra=["--so-cobertura"])

# 44. Linha do gabarito perdida na leitura. Ela derruba a rodada com 3: enquanto
#     existe linha descartada, "o motor nao processou este caso" pode ser so a
#     linha do gabarito que nao foi lida.
rodar_div(
    "linha do gabarito com contagem de coluna diferente derruba a rodada",
    gabarito_de(10, CANTOS_PADRAO) + "C-11;nao;e11\n",
    motor_de(10), 3,
    [("cobertura-do-gabarito.md", "nenhuma linha do gabarito descartada na "
      "leitura | 1 | NAO ATENDE", True),
     ("linhas-fora-da-comparacao.csv", "descartada na leitura", True),
     ("linhas-fora-da-comparacao.csv", "C-11;nao;e11", True),
     ("stderr", "foram descartadas na leitura", True),
     ("stdout", "NAO FECHA", False)])

# 45. Caso sem codigo no gabarito.
rodar_div(
    "linha de gabarito sem caso e contada e o fechamento fecha",
    gabarito_de(10, CANTOS_PADRAO) + ";nao;e11;R11;Ana;2026-03-01;pasta\n",
    motor_de(10), 5,
    [("stdout", "NAO FECHA", False)])

# 46. Rodape nos dois artefatos da conta.
rodar_div(
    "rodape nos artefatos da conta",
    gabarito_de(10, CANTOS_PADRAO), motor_de(10), 0,
    [("cobertura-do-gabarito.md", "Gerado com apoio de IA", True),
     ("divergencias-contra-gabarito.csv", "Gerado com apoio de IA", True),
     ("cobertura-do-gabarito.md", "nao diz se vale a pena automatizar", True)])

# 47. Anonimizacao tambem na conta da divergencia.
rodar_div(
    "anonimizacao do gabarito nao deixa nome real no diretorio",
    gabarito_de(10, CANTOS_PADRAO).replace("Ana", "Ana Souza"),
    motor_de(10), 0, [("cobertura-do-gabarito.md", "Gerado com apoio de IA",
                       True)],
    extra=["--anonimizar-pessoa"],
    nomes_reais=("Ana Souza",))

# 47b. O arquivo do que ficou fora leva o conteudo da linha inteira. Nome de
#      pessoa numa linha que nao entrou na comparacao tambem tem que sair
#      pseudonimizado, senao o arquivo novo vaza o que os outros protegem.
rodar_div(
    "anonimizacao alcanca o conteudo da linha que ficou fora da comparacao",
    gabarito_de(10, CANTOS_PADRAO).replace("Ana", "Ana Souza")
    + "C-5;nao;e5;R5;Bia Lima;2026-03-01;pasta\n",
    motor_de(10), 5,
    [("linhas-fora-da-comparacao.csv", "duplicata exata colapsada", True),
     ("linhas-fora-da-comparacao.csv", "pessoa-", True)],
    extra=["--anonimizar-pessoa"],
    nomes_reais=("Ana Souza", "Bia Lima"))

# 48. Sem --motor e sem --so-cobertura nao ha o que comparar.
rodar_div(
    "sem saida do motor a rodada nao finge ter comparado",
    gabarito_de(10, CANTOS_PADRAO), None, 3,
    [("stderr", "sem --motor nao ha o que comparar", True)])

# 49. Linha do motor descartada na leitura virava afirmacao falsa e confiante
#     sobre o outro lado: "o motor nao produziu saida para este caso", com as
#     cinco checagens em atende e o fechamento fechando, mandando a pessoa
#     depurar um motor que respondeu certo. O resultado com ponto e virgula
#     dentro e o formato do exemplo do proprio passo 7.
rodar_div(
    "linha do motor descartada nao vira afirmacao de que o motor nao processou",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(9) + "C-10;42 itens conferidos; 3 divergencias\n", 3,
    [("cobertura-do-gabarito.md", "nenhuma linha do motor descartada na "
      "leitura | 1 | NAO ATENDE", True),
     ("linhas-fora-da-comparacao.csv", "motor;descartada na leitura", True),
     ("linhas-fora-da-comparacao.csv", "42 itens conferidos", True),
     ("divergencias-contra-gabarito.csv", "ou a linha dele foi descartada na "
      "leitura", True),
     ("divergencias-contra-gabarito.csv", "o motor nao produziu saida para este "
      "caso. Isso e resultado", False),
     ("stderr", "faz a rodada afirmar", True)])

# 50. Lei de ferro 5 na conta da divergencia: linha que nao chega a comparacao
#     tem arquivo proprio. Os baldes guardavam o conteudo exato da linha perdida
#     e nunca eram lidos em lugar nenhum, e a mensagem do codigo 5 mandava ler a
#     lista de divergencias, que nao traz essas linhas.
rodar_div(
    "linha de gabarito sem caso aparece no arquivo do que ficou fora",
    gabarito_de(10, CANTOS_PADRAO) + ";nao;e11;R11;Ana;2026-03-01;pasta\n",
    motor_de(10), 5,
    [("linhas-fora-da-comparacao.csv", "gabarito;linha sem caso", True),
     ("linhas-fora-da-comparacao.csv", "e11;R11", True),
     ("cobertura-do-gabarito.md", "nenhuma linha do gabarito sem codigo de "
      "caso | 1 | NAO ATENDE", True),
     ("cobertura-do-gabarito.md", "| gabarito | linha sem caso | 1 |", True),
     ("stdout", "linhas em linhas-fora-da-comparacao.csv", True),
     ("stdout", "NAO FECHA", False)])

GAB_COM_VAZIA = "\n".join(
    gabarito_de(10, CANTOS_PADRAO).strip().split("\n")[:5] + [""]
    + gabarito_de(10, CANTOS_PADRAO).strip().split("\n")[5:]) + "\n"

rodar_div(
    "linha vazia no meio do gabarito aparece no arquivo do que ficou fora",
    GAB_COM_VAZIA, motor_de(10), 0,
    [("linhas-fora-da-comparacao.csv", "gabarito;linha vazia", True),
     ("cobertura-do-gabarito.md", "| gabarito | linha vazia | 1 |", True),
     ("stdout", "gabarito, linha vazia: 1", True),
     ("stdout", "casos no gabarito ...................... 10", True),
     ("stdout", "NAO FECHA", False)])

# 51. Duplicata exata no gabarito era colapsada em silencio, com codigo 0 e a
#     cobertura autorizando o estagio. Gabarito com linha repetida e sinal de
#     arquivo remontado errado.
rodar_div(
    "duplicata exata no gabarito nao e colapsada em silencio",
    gabarito_de(10, CANTOS_PADRAO) + "C-5;nao;e5;R5;Ana;2026-03-01;pasta\n",
    motor_de(10), 5,
    [("cobertura-do-gabarito.md", "nenhuma linha do gabarito repetida com o "
      "mesmo resultado | 1 | NAO ATENDE", True),
     ("linhas-fora-da-comparacao.csv", "duplicata exata colapsada", True),
     ("linhas-fora-da-comparacao.csv", "C-5;12;gabarito", True),
     ("cobertura-do-gabarito.md", "NAO autoriza o estagio piloto", True),
     ("stdout", "NAO FECHA", False)])

# 52. Procurado por conta propria, atras da mesma doenca: o mesmo caso
#     classificado duas vezes com classes opostas. A segunda linha sobrescrevia a
#     primeira em silencio, e erro do motor virava erro do gabarito sem ninguem
#     saber. As duas conclusoes levam a acoes opostas.
rodar_div(
    "caso classificado duas vezes com classes opostas e reportado",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(10, {3: "RX"}), 1,
    [("stdout", "casos classificados duas vezes com classes diferentes: 1",
      True),
     ("cobertura-do-gabarito.md", "| C-3 | erro-do-motor | erro-do-gabarito | "
      "3 |", True),
     ("cobertura-do-gabarito.md", "levam a acoes opostas", True)],
    classificacao="C-3;erro-do-motor;Ana;2026-03-10\n"
                  "C-3;erro-do-gabarito;Bia;2026-03-11\n")

rodar_div(
    "--estrito nao aceita caso classificado duas vezes",
    gabarito_de(10, CANTOS_PADRAO),
    motor_de(10, {3: "RX"}), 2,
    [("stderr", "existe pendencia", True)],
    extra=["--estrito"],
    classificacao="C-3;erro-do-motor;Ana;2026-03-10\n"
                  "C-3;erro-do-gabarito;Bia;2026-03-11\n")

# 53. Rodape tambem no arquivo novo, e ele existe na rodada --so-cobertura.
rodar_div(
    "--so-cobertura tambem grava o arquivo do que ficou fora",
    gabarito_de(10, CANTOS_PADRAO) + "C-5;nao;e5;R5;Ana;2026-03-01;pasta\n",
    None, 4,
    [("linhas-fora-da-comparacao.csv", "duplicata exata colapsada", True),
     ("linhas-fora-da-comparacao.csv", "Gerado com apoio de IA", True),
     ("stdout", "Ficou linha fora da comparacao: 1", True)],
    extra=["--so-cobertura"])

# 54. A description da skill tem que caber no limite do kit.
def conferir_skill():
    erros = []
    if not SKILL.is_file():
        registrar("SKILL.md presente", ["SKILL.md nao encontrado"])
        return
    texto = SKILL.read_text(encoding="utf-8")
    linhas = texto.split("\n")
    if linhas[0].strip() != "---":
        erros.append("o arquivo nao abre com frontmatter")
    fim = None
    for i in range(1, len(linhas)):
        if linhas[i].strip() == "---":
            fim = i
            break
    if fim is None:
        erros.append("frontmatter sem fechamento")
    else:
        frontmatter = "\n".join(linhas[1:fim])
        if "name: linha-de-base-antes-de-automatizar" not in frontmatter:
            erros.append("name diferente do nome da pasta")
        pos = frontmatter.find("description:")
        if pos < 0:
            erros.append("frontmatter sem description")
        else:
            descricao = frontmatter[pos:]
            if len(descricao) > 1400:
                erros.append("description com %d caracteres, o limite e 1400"
                             % len(descricao))
    for trecho in ("O kit preve dez skills e esta versao traz dez.",
                   "O kit prevê dez skills e esta versão traz dez."):
        if trecho in texto:
            break
    else:
        erros.append("falta a frase de abertura de Skills vizinhas")
    for vizinha in ("conferencia-entre-duas-fontes",
                    "extracao-de-documento-para-tabela",
                    "triagem-de-caixa-de-email", "comparativo-de-cotacoes",
                    "ficha-da-area", "relatorio-recorrente",
                    "registro-de-anomalia", "padrao-conferido-contra-norma",
                    "indice-do-acervo-da-area"):
        if vizinha not in texto:
            erros.append("skill vizinha ausente: %s" % vizinha)
    if TRAVESSAO in texto or MEIA_RISCA in texto:
        erros.append("travessao ou meia-risca no SKILL.md")
    # Opcao que o texto manda usar e nao documenta e opcao que ninguem acha. A
    # sequencia do passo 6 morria porque o diretorio ja existia e --forcar nao
    # aparecia no SKILL.md nenhuma vez.
    for opcao in ("--forcar", "--conferida-contra-gabarito",
                  "--numero-da-pessoa", "--campo-multilinha"):
        if opcao not in texto:
            erros.append("opcao do script ausente do SKILL.md: %s" % opcao)
    if "linhas-fora-da-comparacao.csv" not in texto:
        erros.append("arquivo de saida ausente do contrato: "
                     "linhas-fora-da-comparacao.csv")
    for trecho in ("A ficha não sai sem os seis", "A ficha nao sai sem os seis"):
        if trecho in texto:
            break
    else:
        erros.append("a lei de ferro 2 nao enuncia os seis requisitos")
    registrar("SKILL.md dentro do padrao do kit", erros)


def conferir_estado_do_kit():
    """O estado da skill nos arquivos do kit, quando eles estao na arvore.

    Instalada, a skill nao carrega os arquivos do kit, e a checagem e pulada. Na
    arvore ela pega o caso em que o documento de entrada do kit diz que esta
    skill nao existe.
    """
    raiz = AQUI.parent.parent.parent.parent
    leia_me = raiz / "kit" / "00-LEIA-ME.md"
    espinha = raiz / "ESPINHA-DAS-DEZ.md"
    if not leia_me.is_file() and not espinha.is_file():
        registrar("estado do kit conferido (fora da arvore, pulado)", [])
        return
    erros = []
    nome = AQUI.parent.name
    if leia_me.is_file():
        texto = leia_me.read_text(encoding="utf-8")
        for linha in texto.split("\n"):
            if nome in linha and ("Prevista" in linha or "prevista" in linha):
                erros.append("o 00-LEIA-ME marca esta skill como prevista: %s"
                             % linha.strip()[:90])
        for trecho in ("quatro skills prontas", "para as quatro skills",
                       "As quatro skills", "as quatro skills fazem",
                       "Três das quatro", "Tres das quatro"):
            if trecho in texto:
                erros.append("o 00-LEIA-ME ainda conta quatro skills: %s"
                             % trecho)
    if espinha.is_file():
        texto = espinha.read_text(encoding="utf-8")
        bloco = texto.split(nome)
        if len(bloco) > 1 and "**Estado:** especificada" in bloco[1][:600]:
            erros.append("a espinha ainda marca esta secao como especificada")
    registrar("estado desta skill nos arquivos do kit", erros)


conferir_skill()
conferir_estado_do_kit()

print("")
if falhas:
    print("%d caso(s) falharam." % len(falhas))
    sys.exit(1)
print("Todos os casos passaram.")
sys.exit(0)
