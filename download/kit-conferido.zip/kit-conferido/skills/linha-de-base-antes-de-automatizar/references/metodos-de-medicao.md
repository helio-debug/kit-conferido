# Métodos de medição, casos de canto e tamanho de amostra

Referência da skill `linha-de-base-antes-de-automatizar`. Leia antes de escolher
o método do passo 5 e antes de montar o gabarito do passo 7.

---

## Antes do método: três definições que não podem ficar implícitas

**O caso.** Uma execução da tarefa, do início ao fim, por uma pessoa. Se duas
pessoas discordam sobre onde o caso começa, o número vai divergir e ninguém vai
saber por quê. Escreva a fronteira: começa quando chega o quê, termina quando
sai o quê.

**A unidade.** Minutos por caso, casos por dia, reprovas por mil peças, horas
por semana. Duas unidades diferentes da mesma tarefa não se comparam, e a
conversa depois vai comparar.

**A janela.** A semana típica não existe em todo lugar: fechamento de mês,
parada programada e pico sazonal mudam o número. Declare a janela medida e
declare se ela é típica ou não.

---

## Os cinco métodos

| Método | O que mede | Onde erra |
|---|---|---|
| Cronometragem | Duração real do caso, observada por alguém de fora | Efeito de ser observado, e amostra pequena demais |
| Autoapontamento | Duração anotada por quem faz | Arredondamento para cima e para números redondos, e esquecimento |
| Contagem de registro que já existe | Volume e, às vezes, duração, a partir de carimbo de data que o sistema já grava | Mede o registro, não o trabalho |
| Reconstrução de rastro | Duração inferida de data de arquivo, histórico de versão, horário de mensagem | Confunde tempo de espera com tempo de trabalho |
| Sondagem aleatória | Proporção do turno gasta na tarefa, por amostragem de instantes | Não dá duração por caso, dá fração de tempo |

### Cronometragem

**Como.** Alguém acompanha e anota início e fim de cada caso. De dez a trinta
casos, espalhados por dias e por pessoas diferentes.

**Custo.** O tempo de quem observa, mais o tempo do caso. É o método caro e o
mais defensável.

**Onde erra.** Ser observado muda o ritmo, quase sempre para mais rápido e mais
caprichado. O caso raro e demorado, que é o que mais incomoda, raramente cai na
janela de observação.

**Como se valida.** Duas pessoas cronometram os mesmos três casos em separado.
Pelo critério desta skill, diferença acima de 20% entre as duas quer dizer que a
fronteira do caso não está definida, e o passo 3 precisa ser refeito antes de
continuar. O número é convenção do kit, não requisito externo: calibre para a sua
casa e escreva qual valor usou.

**Não use** quando a tarefa acontece uma vez por semana: observar dez casos
levaria dez semanas. Aí é autoapontamento ou registro.

### Autoapontamento

**Como.** Quem faz anota início e fim numa folha ou numa planilha, por duas
semanas.

**Custo.** Baixo em horas de quem mede, alto em disciplina de quem anota.

**Onde erra.** O apontamento vira 30, 60 e 90 minutos. Quando a coluna inteira
só tem múltiplos de 15, o dado é estimativa com aparência de medição, e a ficha
tem que dizer isso.

**Como se valida.** Cronometre três casos por fora, sem avisar a data, e compare
com o que foi anotado naqueles dias.

**Não use** sozinho quando o número vai sustentar uma decisão contestada. Ele
não resiste a quem quer contestar.

### Contagem de registro que já existe

**Como.** O sistema já grava quando o documento foi criado, quando o e-mail foi
enviado, quando a ordem mudou de estado. Conte.

**Custo.** O mais barato dos cinco, e quase sempre o primeiro a tentar.

**Onde erra.** A diferença entre dois carimbos inclui almoço, fila, espera por
resposta e fim de semana. Isso é tempo de travessia, não tempo de trabalho, e os
dois são números legítimos e diferentes. A ficha tem que dizer qual dos dois ela
carrega.

**Como se valida.** Escolha cinco casos do registro e pergunte à pessoa quanto
tempo ela lembra de ter gasto neles. Não é prova, é detector de absurdo.

**Não use** para duração de trabalho sem dizer que é travessia.

### Reconstrução de rastro

**Como.** Data de modificação de arquivo, histórico de versão de planilha,
horário de mensagem. Serve quando ninguém mediu nada e ninguém vai medir agora.

**Custo.** Baixo, e é o único que produz número sobre o passado.

**Onde erra.** Tudo o que erra na contagem de registro, mais a chance de o
arquivo ter sido tocado por outro motivo.

**Como se valida.** Reconstrua um mês que alguém consiga conferir de memória com
o calendário na mão.

**Não use** como valor medido sem carimbo. Rastro reconstruído entra na ficha
como medição de confiança baixa, com o método nomeado.

### Sondagem aleatória

**Como.** Em instantes sorteados do turno, registre o que a pessoa está fazendo
naquele momento. A proporção de instantes na tarefa estima a proporção do tempo.

**Custo.** Baixo por observação, e precisa de muitas observações.

**Onde erra.** Não devolve duração por caso, devolve fração de tempo. Para
converter em duração por caso é preciso o volume de casos da janela, e esse
volume tem que ser contado, não estimado.

**Como se valida.** Duas rodadas em semanas diferentes têm que dar frações
próximas.

**Não use** quando a pergunta é quanto demora um caso.

---

## O efeito de ser observado

Ele existe nos cinco métodos, em graus diferentes, e não se elimina. O que se
faz é declarar. Duas providências baratas:

1. Descartar o primeiro dia de observação, e dizer na ficha que foi descartado.
2. Medir também uma semana em que ninguém sabia que estava sendo medido, quando
   o registro já existente permitir, e comparar as duas.

Diferença grande entre as duas não invalida a medição. Ela vira uma linha da
ficha, e quem for contestar o número depois já vai encontrar a ressalva escrita.

---

## Quantas observações

Os três pisos abaixo são critério desta skill, não requisito externo.

| Situação | Piso |
|---|---|
| Conversar internamente sobre a tarefa | 5 observações |
| Autorizar um piloto | 10 observações, em ao menos 3 dias e com 2 pessoas executando |
| Sustentar uma comparação de antes e depois | 30 observações, cobrindo a variação conhecida |

A contagem de pessoas é de quem executa a tarefa. Três observadores acompanhando
a mesma pessoa não cobrem variação de quem faz, e a ficha imprime as duas
contagens em linhas próprias.

Número de observações não substitui cobertura. Trinta repetições do mesmo caso
fácil medem a parte fácil. A regra prática: a amostra precisa conter o caso que
a área cita quando quer explicar por que a tarefa é chata.

**Amplitude larga muda a conta.** Pelo critério desta skill, quando o maior caso
é mais que o triplo do menor, a média sozinha engana. Cite a mediana, cite a amplitude, e diga quantos
casos ficaram acima do dobro da mediana. São eles que vão decidir se automatizar
vale.

---

## O catálogo de casos de canto do gabarito

O gabarito é a segunda metade da skill. Ele são de dez a trinta casos já feitos
à mão, com o resultado da época. Casos de canto entram de propósito, e esta
lista existe para que a escolha não fique na memória de quem monta.

| Classe de canto | Como ela aparece |
|---|---|
| Campo vazio | O documento veio sem o dado que sempre vem |
| Valor fora do padrão | Quantidade com três casas, código com letra onde só havia número |
| Registro duplicado | O mesmo caso entrou duas vezes, com diferença pequena |
| Unidade diferente | O mesmo item medido em outra unidade |
| Texto ilegível | Manuscrito ruim, digitalização torta, carimbo por cima |
| Exceção conhecida | Aquele item, aquele fornecedor, aquele turno que a área trata diferente e ninguém escreveu |
| Caso do limite | O maior, o menor, o mais antigo, o do dia de fechamento |
| Caso que deu errado | O caso em que a pessoa errou na época, e o gabarito registra o erro |

O último é o mais valioso e o mais esquecido. Gabarito montado só com caso em
que a pessoa acertou não permite distinguir erro do motor de erro do gabarito
depois.

**Piso de cobertura:** um caso de canto a cada cinco casos, no mínimo dois, e ao
menos duas classes distintas. O `divergencia.py` confere isso e recusa autorizar
o estágio quando não bate.

---

## Quando o número do antes já existe e ninguém sabe

Antes de medir, procure. Em ordem de custo:

1. Registro que o sistema já grava e ninguém exporta.
2. Planilha de controle que alguém da área mantém por conta própria.
3. Relatório mensal antigo que trazia o indicador e parou de trazer.
4. Contagem feita uma vez, para outro assunto, que serve de referência.

Achando, a medição vira conferência: rode o livro-caixa sobre o registro
existente e confira o resultado contra o número que a área cita de memória.
Baterem, a linha de base custou uma tarde. Não baterem, você achou um problema
maior que a automação.

---

Gerado com apoio de IA a partir do material de método do kit. Revisar antes de
assinar. Não substitui responsabilidade técnica.
