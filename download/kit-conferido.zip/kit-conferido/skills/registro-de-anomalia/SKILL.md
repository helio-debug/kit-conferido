---
name: registro-de-anomalia
description: >
  Recebe o desvio como a pessoa o descreve e devolve o registro no formato que a
  empresa dela já usa: lê o cabeçalho da planilha ou do formulário de registro em
  uso e emite a linha pronta para colar, em vez de propor formato novo. Separa o
  que só exige registro do que exige tratamento com causa, marca causa sem teste
  como hipótese, e não fecha registro de tratamento sem contramedida com dono
  nomeado e data. Varre o histórico entregue atrás do mesmo desvio e aponta as
  ocorrências anteriores, que é o que mostra anomalia repetida virando problema
  crônico. Use SEMPRE que aparecer: "abre uma não conformidade disso", "registra
  essa ocorrência", "preenche o RNC", "monta o registro desse desvio", "abre um
  desvio de processo", "isso já aconteceu antes?", "isso é reincidência?", "toda
  semana eu preencho essa planilha de NC", "escreve a descrição da não
  conformidade", "qual a causa disso para o registro". NÃO use para decidir a
  disposição do produto, liberar, retrabalhar ou sucatear, que é decisão de quem
  tem autoridade no procedimento. NÃO use para investigar causa no lugar do time:
  ela registra o que foi apurado e marca o que ainda é hipótese. NÃO use para
  conferir procedimento contra norma (padrao-conferido-contra-norma) nem para
  comparar duas listas (conferencia-entre-duas-fontes).
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que
esta skill ocupe o lugar das outras.

| Caso | Skill | Como se encadeia |
|---|---|---|
| Descrever a área uma vez para as outras skills lerem | `ficha-da-area` | Roda antes. Ela traz o vocabulário da casa, e é o que faz esta skill acertar o nome das coisas de primeira |
| A divergência entre duas fontes que virou o desvio | `conferencia-entre-duas-fontes` | Lá se acha a divergência, aqui ela vira registro. A divergência é insumo, não é o registro |
| O registro da empresa está em papel, em PDF ou em foto | `extracao-de-documento-para-tabela` | Extraia primeiro, com a taxa medida contra gabarito, e traga o CSV para cá |
| O histórico de registros está numa pasta que ninguém acha | `indice-do-acervo-da-area` | Ela indexa a pasta e devolve os caminhos que entram no `--historico` daqui |
| O relatório mensal da qualidade que consome esses registros | `relatorio-recorrente` | Ela consome a saída desta skill, e não a substitui |
| Conferir se o procedimento atende a cláusula da norma | `padrao-conferido-contra-norma` | Lá o objeto é o procedimento, aqui é o caso |
| Cotações de fornecedores diferentes | `comparativo-de-cotacoes` | Sem relação com registro de desvio |
| Caixa de e-mail que precisa ser triada | `triagem-de-caixa-de-email` | O e-mail que trouxe a reclamação entra aqui já triado |
| Medir quanto tempo o preenchimento manual custa hoje | `linha-de-base-antes-de-automatizar` | Rode antes de falar em automatizar o registro. Esta skill não mede nada |

---

# Registro de anomalia

O desvio aconteceu, alguém precisa registrar, e o registro é sempre o mesmo
ritual: abrir a planilha pesada, achar o próximo número, escrever a descrição
correndo, preencher causa com o primeiro palpite, deixar prazo em branco e
fechar. O que a casa recebe no fim do mês é uma lista que não responde nem a
pergunta mais simples, que é se aquilo já tinha acontecido.

Esta skill não propõe um formato novo. **Ela sai no formato que a sua empresa já
usa**, porque registro em formato novo é digitação a mais: alguém vai ter que
copiar de um lugar para o outro, e o ganho desaparece nessa cópia. Onde a casa
numera não conformidade em planilha com painel, o que sai daqui é a linha da
planilha, com as colunas dela, na ordem dela, pronta para colar.

O que ela acrescenta ao que você já faz é pequeno e é o que falta:

1. Separa o que só exige registro do que exige tratamento com causa.
2. Marca hipótese como hipótese, com o teste que a confirmaria.
3. Não deixa fechar registro de tratamento sem contramedida, dono nomeado e data.
4. Aponta quando o mesmo desvio já apareceu antes no histórico que você entregou.

**Ela não escreve no seu sistema.** Não abre o ERP, não numera o registro, não
lança no painel e não envia nada. Ela entrega a linha e o caminho do arquivo, e
diz isso na cara antes de começar.

Esta skill termina em arquivo. Resposta em prosa descrevendo a não conformidade é
falha de execução.

---

## Leis de ferro

1. **O formato é o da casa, lido do arquivo da casa.** A skill não entrega nada
   antes de ler o cabeçalho do registro que a empresa usa hoje. Sem o cabeçalho,
   não há saída: o que sairia seria um arquivo a mais para alguém redigitar.
2. **Causa declarada sem teste é hipótese.** Ela entra no registro marcada como
   hipótese, com o teste que a confirmaria escrito junto. Causa errada dentro de
   um registro fechado é pior do que campo vazio: ela encerra a investigação e
   sobrevive no histórico.
3. **Registro que exige tratamento não fecha sem contramedida, dono nomeado e
   data.** Dono que é setor não é dono. Prazo que não é data não é prazo.
4. **A skill não decide a disposição do produto.** Liberar, retrabalhar,
   reclassificar, devolver ou sucatear é decisão de quem tem autoridade no
   procedimento da casa. A skill registra a disposição que a pessoa informou.
5. **Reincidência é achado, não veredito.** A skill mostra as ocorrências
   anteriores com o número e a data de cada uma, conta e diz quando o padrão
   passa do limiar. Quem decide se é problema crônico é quem responde pelo
   processo.
6. **Na dúvida entre descartar e reportar, reporte.** Valor que não tem coluna,
   campo que não existe no modelo, registro do histórico que não pôde ser lido:
   tudo isso sai em arquivo, com a causa. A rodada nunca sai com sucesso tendo
   perdido dado em silêncio.
7. **Gabarito antes do uso real.** A primeira rodada refaz um registro que você
   já escreveu e fechou, o script compara coluna a coluna com o seu e a
   liberação fica registrada em
   `~/.kit-industrial/gabaritos-registro-de-anomalia.csv`, fora da conversa.
   Enquanto não bater, a skill não é usada em caso novo.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Existindo, use o vocabulário da área,
o código de equipamento e de item que a casa usa e os sistemas em que o registro
vive. Não existindo, declare em voz alta "rodando sem ficha da área" e siga.

Rodar sem ficha não degrada o registro: só obriga a confirmar o nome do
equipamento e do item com a pessoa, porque é por eles que a varredura de
reincidência procura.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi
carregada ou se a rodada está sem ficha e, carregada, repete o status
gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir o arquivo

Quatro perguntas, nesta ordem:

1. **O dado é sensível?** As cinco classes: nome de pessoa; folha de pagamento,
   salário e remuneração individual; preço de fornecedor identificado; dado de
   cliente identificado; projeto sob sigilo. Folha, salário e remuneração
   individual não entram em nenhum modo. **Nesta skill a resposta é quase sempre
   sim**: registro de desvio costuma trazer nome de operador na descrição, nome
   de cliente na reclamação e nome de fornecedor na causa. Ofereça sempre o modo
   derivado, que aqui é o script local mais `--sem-valores-no-mapa`.
2. **Esse preenchimento se repete?** Sendo semanal ou mensal, rode pelo script
   mesmo cabendo na leitura: o valor está em repetir igual, e leitura não repete
   igual.
3. **Quantos registros tem o histórico, e em quantos arquivos?** Define leitura
   ou script pela tabela do passo 7.
4. **Existe um registro já escrito e fechado para servir de gabarito?** Existindo,
   ele é o primeiro a rodar. Não existindo, o passo 8 diz o que fazer.

Sobre nome de pessoa: o campo de descrição não leva nome de operador. A descrição
registra o fato, não quem estava no posto. Quando o registro da casa tiver uma
coluna para isso, ela é preenchida pela pessoa, não pela skill.

**Critério de conclusão:** as quatro respostas estão registradas e a escolha
entre leitura e script está feita antes de qualquer arquivo ser aberto.

---

## Passo 3: pegar o registro que a empresa usa hoje e ler o cabeçalho dele

Este é o passo que define a skill. Pergunte, nesta ordem:

1. **Qual é o registro que vocês usam hoje?** O nome da casa: RNC, NC, ocorrência,
   desvio, apontamento, chamado. Use esse nome daqui para a frente, inclusive na
   conversa.
2. **Onde ele vive?** Planilha, formulário em papel, formulário no editor de
   texto, tela do ERP, sistema da qualidade.
3. **Me mande o arquivo, ou a lista dos campos.** Planilha vira CSV e entra em
   `--modelo`. Formulário em papel ou tela de sistema vira uma lista com um campo
   por linha, na ordem em que aparecem, e entra em `--modelo` com
   `--modelo-em-linhas`.
4. **Quais colunas são obrigatórias para o registro ser aceito na sua casa?**
   Entram em `--obrigatorias`. Coluna obrigatória sem valor impede o fechamento.
5. **Quem numera?** Quase sempre a numeração é da casa, sequencial. A skill não
   inventa número: ou a pessoa informa o próximo, ou a coluna sai pendente.

O cabeçalho lido é o contrato de saída. A ordem das colunas, o nome de cada uma,
o delimitador e o encoding do arquivo são preservados, para que a linha cole na
planilha sem ajuste.

Não havendo registro nenhum na empresa, a skill para aqui e diz o que falta. Ela
não cria o sistema de registro da casa, e um formato inventado por ela seria
exatamente o erro que ela existe para não cometer. A entrada mínima aceitável é a
lista dos campos digitada à mão pela pessoa, que já basta para
`--modelo-em-linhas`.

**Critério de conclusão:** o nome que a casa dá ao registro está escrito, o
arquivo do modelo está na mão, e o `mapa-de-campos.md` lista as colunas lidas na
ordem do arquivo.

---

## Passo 4: separar o que só exige registro do que exige tratamento

Leia `references/classes-de-registro.md`, seção 1. Aplique primeiro o critério do
procedimento da casa, quando houver. Não havendo, use o teste de cinco perguntas
da referência: uma resposta "sim" já joga o caso em tratamento com causa.

A classe entra em `kit.classe`, com um dos dois valores: `somente_registro` ou
`exige_tratamento`. Ela não é decoração: é o que liga a exigência de contramedida
com dono e data.

Registrar como `somente_registro` o desvio que foi corrigido na hora e não pede
análise de causa é legítimo e é o que mantém a fila de tratativas viva. O
critério que vale aqui é operacional: avaliar se o caso pede ação sobre a causa
é um passo próprio, e não um automatismo que dispara em todo desvio. O kit não
afirma o que a cláusula da sua norma exige.
Confira na edição vigente da sua empresa, e com a sua área da qualidade.

**Critério de conclusão:** a classe está declarada, com a pergunta que a decidiu
dita em uma frase, e a pessoa concordou.

---

## Passo 5: escrever a descrição e marcar hipótese como hipótese

A descrição sai como fato observável: o que foi encontrado, onde, em que etapa,
quanto, medido como. Sem opinião, sem culpa e sem nome de pessoa. A seção 4 da
referência traz a comparação entre descrição fraca e descrição utilizável.

A causa segue a lei de ferro 2:

- Causa apurada com teste feito: `kit.causa_status` vale `confirmada_por_teste` e
  `kit.teste_realizado` diz qual foi. A célula sai com a causa e o teste juntos.
- Causa sem teste: a célula sai com o prefixo de hipótese e o teste que a
  confirmaria. A seção 5 da referência traz a tabela de hipótese contra teste.
- Causa declarada como confirmada sem dizer qual teste confirmou: cai para
  hipótese e vira pendência. Não fecha.

A descrição é digitada uma vez só, em `kit.descricao_do_desvio`. Ela é o alvo da
varredura de reincidência e é o que entra na coluna de descrição do registro: o
destino é a coluna declarada em `kit.coluna_da_descricao` ou, não havendo
declaração, a única coluna do modelo cujo nome case com descrição, ocorrência,
relato ou constatação. Havendo duas candidatas, o script não escolhe: vira
pendência e você declara. Digitando também direto na coluna, os dois textos têm
que ser o mesmo: textos diferentes bloqueiam, porque o registro e a busca
contariam histórias diferentes.

**Critério de conclusão:** a descrição não contém nome de pessoa nem juízo, o
campo de causa do arquivo de saída está marcado como hipótese ou acompanhado do
teste que a confirmou, e a célula de descrição da linha emitida não está vazia.

---

## Passo 6: fechar o tratamento com contramedida, dono e data

Vale quando a classe é `exige_tratamento`. Três campos, e os três são
verificáveis:

- `kit.contramedida`: o que muda para o desvio não voltar. Correção feita na hora
  é ação imediata, e vai na coluna de ação imediata, não nesta.
- `kit.dono`: uma pessoa. Setor não é dono, e a skill recusa nome de setor.
- `kit.prazo`: uma data que o script consiga ler.

Quando o tratamento vive em outro arquivo da casa, o plano de ação por exemplo, a
contramedida não entra na linha do registro. Isso é decisão declarada, roda com
`--contramedida-fora-da-linha`, e o texto sai no mapa pronto para o outro
arquivo. Declarada é diferente de esquecida.

**Critério de conclusão:** sendo `exige_tratamento`, a saída tem contramedida,
dono nomeado e data lida como data, ou a rodada saiu com código 2 e a pendência
está escrita.

---

## Passo 7: rodar

| Situação | Como rodar |
|---|---|
| Histórico até 60 registros, num arquivo só | Leitura em contexto, em modo contado: reemitir a lista completa de números do histórico e fechar as contagens |
| Acima de 60 registros | Script obrigatório |
| Histórico em mais de um arquivo, ou em pasta | Script obrigatório |
| Qualquer tamanho, se o dado é sensível | Script obrigatório |
| Qualquer tamanho, se o preenchimento se repete | Script obrigatório |
| Registro com mais de 15 colunas | Script obrigatório |

**Por que 60, e não um número maior.** O limite não é a janela de contexto. A
varredura do histórico é uma passagem por todo registro, e a falha da leitura é
pular um. O registro pulado é justamente a reincidência que se queria achar, e a
saída fica com cara de certa: "nenhuma ocorrência anterior" é a frase mais fácil
de produzir e a mais cara de entregar errada. O teste que decide: não sendo
possível reemitir a lista completa de números do histórico e fechar as contagens,
aquilo foi amostragem. Nesse caso diga que foi amostragem e rode o script.

**Por que existe script nesta skill.** Ele resolve quatro coisas que o modelo
sozinho não resolve: volume, porque o histórico de não conformidade cresce sem
parar; repetibilidade, porque a linha precisa sair na mesma ordem de coluna toda
vez; dado que não deve sair da máquina, porque o registro traz nome de cliente e
de pessoa; e rastro, porque a rodada precisa poder ser refeita igual no mês
seguinte.

**Dependência declarada.** Python 3.8 ou superior, biblioteca padrão apenas
(`argparse`, `codecs`, `csv`, `io`, `os`, `re`, `sys`, `unicodedata`,
`datetime`, `pathlib`). Sem instalação, sem rede, sem escrita nos arquivos de entrada.

**Onde o script está depois de instalado.** A instalação copia a pasta da skill
para `~/.claude/skills/registro-de-anomalia/`, e o script fica em
`~/.claude/skills/registro-de-anomalia/scripts/registrar.py`. A rodada acontece
na pasta dos arquivos de trabalho, não na pasta da skill, e por isso o script é
sempre chamado pelo caminho completo.

Antes de emitir qualquer linha, rode `--so-mapa`: ele lê o cabeçalho, monta o
mapa de campos e não emite registro. Serve para a pessoa aprovar o formato antes
de olhar conteúdo.

No macOS e no Linux:

```
python3 ~/.claude/skills/registro-de-anomalia/scripts/registrar.py \
    --modelo registro-nc.csv --anomalia anomalia.csv \
    --historico historico-nc/ \
    --coluna-descricao "Descricao da ocorrencia" --coluna-data "Data" \
    --coluna-numero "No" --coluna-local "Equipamento" \
    --obrigatorias "No,Data,Setor,Descricao da ocorrencia" \
    --saida registro-2026-09-20
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho vai
entre aspas com `$env:USERPROFILE` no lugar do `~`, e a linha continua com acento
grave no lugar da barra invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\registro-de-anomalia\scripts\registrar.py" `
    --modelo registro-nc.csv --anomalia anomalia.csv `
    --historico historico-nc\ `
    --coluna-descricao "Descricao da ocorrencia" --coluna-data "Data" `
    --coluna-numero "No" --coluna-local "Equipamento" `
    --obrigatorias "No,Data,Setor,Descricao da ocorrencia" `
    --saida registro-2026-09-20
```

O `--historico` aponta para os registros anteriores, nunca para o arquivo do
`--modelo`: modelo tem cabeçalho e nenhum registro, e varrer um arquivo assim
compara zero registro.

O arquivo da anomalia é escrito pelo modelo, sempre com ponto e vírgula, uma
linha por campo. O nome do campo é ou uma coluna do modelo, ou um dos campos
governados pelo kit: `kit.classe`, `kit.descricao_do_desvio`, `kit.local`,
`kit.causa`, `kit.causa_status`, `kit.teste_que_confirmaria`,
`kit.teste_realizado`, `kit.contramedida`, `kit.dono`, `kit.prazo`, e as seis que
dizem em qual coluna do modelo cada um entra: `kit.coluna_da_descricao`,
`kit.coluna_da_causa`, `kit.coluna_da_contramedida`, `kit.coluna_do_dono`,
`kit.coluna_do_prazo` e `kit.coluna_do_local`. Nome de campo fora dessas duas
listas não é ignorado: vira pendência bloqueante, porque campo ignorado é dado
perdido.

As seis declarações de coluna são opcionais quando o nome da coluna do modelo já
diz o que ela recebe. Não sendo declaradas, o script procura no modelo uma única
coluna cujo nome case, e usa. Uma só: duas candidatas viram pendência, porque
escolher entre duas é decisão de quem conhece a planilha. Todo destino inferido
sai escrito no mapa e no terminal, coluna por coluna.

| Código de saída | Significado |
|---|---|
| 0 | Registro fechado, histórico varrido inteiro, nenhuma reincidência |
| 1 | Registro fechado, varredura completa, e há reincidência para ler |
| 2 | Registro não fechado: pendência bloqueante |
| 3 | Erro de entrada, cabeçalho não lido, ou identidade de fechamento que não fecha |
| 4 | Rodada `--so-mapa`, nenhum registro emitido |
| 5 | Registro fechado, sem reincidência, mas ficou coisa fora da varredura |
| 6 | Registro fechado, há reincidência, e ficou coisa fora da varredura |

O 5 e o 6 são o mesmo recado, e são os mais importantes da tabela: sobrou coisa
que a varredura não leu. Arquivo em formato que o script não abre, registro sem
coluna de descrição, linha com contagem de coluna diferente do cabeçalho, data
que não foi lida, coluna de apoio do histórico não encontrada, arquivo de
histórico sem registro nenhum, histórico declarado inexistente com
`--sem-historico`, ou zero registro comparado. Completude e reincidência são dois
eixos: o 6 existe porque o 1 sozinho escondia varredura incompleta. Numa rodada
agendada, 0 é lido como "esse desvio é novo", e essa frase só pode sair quando
todo registro do histórico entregue foi de fato comparado.

**Critério de conclusão:** o diretório tem os arquivos que o contrato de saída
prevê para o modo que você rodou, o bloco de fechamento impresso no terminal tem
`fecha` em todas as linhas, e o código de saída foi lido e respondido. Código 2
não é falha do script: é o registro dizendo que não fecha ainda.

---

## Passo 8: o gabarito

A primeira rodada desta skill em qualquer empresa é sobre um registro que a
pessoa já escreveu e já fechou. Não é formalidade: é o que separa a ferramenta do
chute bem formatado.

Como se faz:

1. Escolha um registro fechado do histórico, de preferência um que tenha exigido
   tratamento. Salve a linha dele num CSV no formato do modelo, com o cabeçalho
   e uma linha.
2. Peça a descrição bruta de como o caso chegou, do jeito que chegou na época, e
   rode a skill com ela, passando `--gabarito` com o arquivo do item 1.
3. O script compara coluna a coluna e grava `conferencia-do-gabarito.md` no
   diretório da rodada, com uma linha por coluna e o veredito de cada uma: igual,
   equivalente em palavras diferentes, divergente, vazia nas duas, ou coluna que
   não existe de um dos lados. Coluna obrigatória divergente é pendência
   bloqueante: a rodada sai com 2 e o registro não fecha. Equivalente em
   palavras diferentes só vale para texto corrido: em data, número e campo
   curto, ou é o mesmo valor ou divergiu.
4. Confira à mão três coisas que não são coluna: a classe bate com o que a casa
   deu ao caso; o que a pessoa escreveu como causa aparece marcado como hipótese
   quando não havia teste; e a varredura achou as ocorrências anteriores que a
   pessoa já sabe que existem.

A liberação não fica só dentro do diretório da rodada, que ninguém acha na
conversa seguinte. Cada rodada com `--gabarito` acrescenta uma linha em
`~/.kit-industrial/gabaritos-registro-de-anomalia.csv`, com data, arquivo do
modelo, arquivo do gabarito, quantas colunas divergiram, quais divergiram em
coluna obrigatória e o veredito. Outro caminho entra em `--livro-de-gabaritos`.

Enquanto houver coluna obrigatória divergente sem explicação escrita, a skill não
roda em caso novo.

**Critério de conclusão:** o livro em
`~/.kit-industrial/gabaritos-registro-de-anomalia.csv` tem uma linha com
veredito `libera` para o modelo desta empresa, e a resposta diz o caminho do
`conferencia-do-gabarito.md` da rodada que liberou. Antes de rodar um caso novo,
leia o livro: não existindo o arquivo, ou não havendo linha `libera` para este
modelo, diga que o gabarito ainda não foi feito e faça o gabarito primeiro.

---

## Passo 9: fechamento

Confira as identidades. Todas devem fechar, e os números vão no mapa:

```
campos_do_cabecalho_bruto = colunas_com_nome + colunas_sem_nome
colunas_do_modelo   = preenchidas + sem_valor + em_branco_declaradas
campos_da_anomalia  = casados + governados + sem_lugar_no_modelo
preenchidas         = casados + governados_em_coluna
registros_do_historico = varridos + nao_varridos
varridos            = sem_semelhanca + reincidencias
arquivos_encontrados = lidos + nao_lidos
registros gravados em campos-pendentes.csv = pendencias
registros gravados em reincidencia.csv = reincidencias
registros gravados em historico-nao-varrido.csv = nao_varridos +
    arquivos_nao_lidos + arquivos_sem_registro + colunas_de_apoio
```

São dez na rodada completa e oito em `--so-mapa`, onde os dois arquivos da
varredura não são escritos. As três últimas são conferidas contra as linhas
efetivamente gravadas em cada arquivo, não contra o contador que o script trazia
na memória, e nenhuma delas tem o resultado escrito no código. A primeira é a que
pega coluna do cabeçalho perdida no caminho: cabeçalho com campo sem nome mantém
a posição, e a linha emitida sai alinhada com a planilha da casa.

Todo contador é incrementado dentro do laço, no ponto da decisão. Nenhum deles é
obtido por subtração, e o motivo é prático: contador derivado por subtração fecha
sozinho mesmo quando some dado, e foi assim que uma varredura já saiu dizendo que
estava tudo certo com uma pasta inteira nunca aberta.

As identidades provam que a contabilidade da rodada é consistente, não que a
rodada prestou. O que pode falhar de fato sai no bloco de verificações: colunas
preenchidas contra colunas do modelo, pendências bloqueantes, células com quebra
de linha trocada, registros do histórico varridos contra encontrados, registros e
arquivos fora da varredura, e reincidências. Cada linha desse bloco exige uma
decisão registrada.

**Critério de conclusão:** as dez identidades saíram com os números e todas
fecham, oito em `--so-mapa`, e cada linha do bloco de verificações foi lida e
respondida. Quebrando uma identidade, a entrega para e o motivo é dito.

---

## Contrato de saída

Um diretório com a data da rodada. O número de arquivos depende do modo:

| Modo | Arquivos |
|---|---|
| Rodada completa, modelo em CSV | Sete: `mapa-de-campos.md`, `linha-para-colar.csv`, `linha-para-colar.txt`, `campos-pendentes.csv`, `reincidencia.csv`, `historico-nao-varrido.csv` e `procedencia.txt` |
| Com `--modelo-em-linhas` | Seis: os dois da linha viram um só `linha-para-colar.md` |
| Com `--so-mapa` | Três: `mapa-de-campos.md`, `campos-pendentes.csv` e `procedencia.txt` |
| Com `--gabarito` | Um a mais, `conferencia-do-gabarito.md`, e uma linha no livro de gabaritos, que fica fora do diretório |

Havendo pendência bloqueante, o arquivo da linha sai como
`rascunho-nao-fechado`, com a mesma extensão.

Ordem de escrita: o mapa sai antes de qualquer linha de registro, os arquivos de
resultado saem depois, e o mapa é reescrito por último, com o fechamento.

### 1. `mapa-de-campos.md`, primeiro, sempre

Abre com `status: incompleto` e só vira `status: completo` na última gravação.
Os quatro valores possíveis são `incompleto`, `so-mapa, sem registro emitido`,
`rascunho, nao fechado` e `completo`, mais `invalido, nao fecha` quando uma
identidade quebra.

Seções obrigatórias: o modelo lido, com arquivo, bytes, data de modificação,
encoding, delimitador, linha do cabeçalho e número de colunas; a tabela coluna a
coluna, com a origem do valor e o estado de cada uma; os campos governados pelo
kit e o efeito de cada um; a regra de causa aplicada; a classe e o fechamento; a
varredura do histórico com todas as contagens; as identidades; as pendências e os
avisos; e o limite declarado de que o script não escreve no sistema da empresa.

### 2. `linha-para-colar.csv`

Cabeçalho e uma linha, na ordem de coluna do modelo, com o delimitador e o
encoding do modelo. Existindo pendência bloqueante, este arquivo não é escrito:
sai `rascunho-nao-fechado.csv` no lugar, e o nome diz o que ele é.

Caractere que não cabe no encoding do modelo não é trocado em silêncio: o arquivo
sai em UTF-8 com BOM e o fato entra no mapa com o caractere nomeado.

### 3. `linha-para-colar.txt`

A mesma linha, só os valores, separados por tabulação, para colar direto na
linha da planilha aberta. Quebra de linha dentro de célula vira espaço, e a
substituição sai contada no mapa.

Com `--modelo-em-linhas` estes dois viram um só, `linha-para-colar.md`, com um
campo por linha na ordem do formulário.

### 4. `campos-pendentes.csv`

Colunas: `campo`, `tipo`, `bloqueia`, `detalhe`. Reúne o que impede o fechamento e
o que é só aviso. Os tipos que bloqueiam: `campo_sem_coluna_no_modelo`,
`campo_kit_desconhecido`, `coluna_com_dois_valores`, `classe_nao_declarada`,
`hipotese_sem_teste`, `confirmacao_sem_teste`, `tratamento_sem_contramedida`,
`tratamento_sem_dono`, `dono_generico`, `tratamento_sem_prazo`,
`prazo_nao_e_data`, `sem_coluna_no_modelo`, `coluna_declarada_nao_existe`,
`descricao_sem_coluna_no_modelo`, `descricao_divergente`, `gabarito_nao_lido`,
`gabarito_divergente_em_coluna_obrigatoria`, `coluna_sem_nome_no_cabecalho`
quando o campo sem nome está no meio do cabeçalho, e `coluna_sem_valor` quando a
coluna está em `--obrigatorias`.

Os que não bloqueiam, e que ainda assim exigem leitura:
`caractere_fora_do_encoding_do_modelo`, `descricao_digitada_duas_vezes`,
`local_sem_coluna_no_modelo`, `local_divergente`,
`livro_de_gabaritos_nao_gravado`, e `coluna_sem_nome_no_cabecalho` quando o campo
sem nome é o último, que é o ponto e vírgula sobrando do export.

### 5. `reincidencia.csv`

Uma linha por ocorrência anterior encontrada, com `arquivo`, `linha`,
`numero_do_registro`, `data`, `data_lida`, `motivo`, `escore`,
`termos_em_comum`, `local`, `descricao_do_historico` e `alerta`. O `motivo` é
`descricao_semelhante` ou `mesmo_local`. O escore e os termos em comum estão ali
para você julgar o achado, não para confiar nele: a seção 7 da referência traz o
critério do que é o mesmo desvio.

### 6. `historico-nao-varrido.csv`

Escrito em toda rodada que varre histórico, mesmo vazio. Uma linha por registro
ou arquivo que ficou fora da varredura, com `arquivo`, `linha`, `tipo`, `causa` e
`conteudo_da_linha`. Os tipos: `linha_vazia`, `sem_coluna_de_descricao`,
`contagem_de_colunas_diferente`, `descricao_vazia`, `arquivo_nao_lido`,
`historico_sem_registro` e `coluna_de_apoio_nao_encontrada`. É o arquivo que
impede a resposta falsa: enquanto ele tiver linha, "esse desvio é novo" é uma
frase que não se pode dizer.

### 7. `procedencia.txt`

O rodapé de procedência, a fonte e a lista dos arquivos da rodada. Ele existe
porque rodapé dentro de CSV vira linha de dado: aparece como registro a mais no
Excel, entra como registro na skill que consome esta saída, e desmente a
identidade que conta registros. Nos CSV desta pasta, toda linha é registro.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de <fonte>. Revisar antes de assinar. Não substitui responsabilidade técnica.
```

Ele sai nos `.md` e no `procedencia.txt`. Nos CSV, não.

---

## Modo de dado sensível

Ofereça os três níveis antes de pedir o arquivo. O padrão, quando a pessoa não
decide, é o nível 2.

**Nível 1, só o cabeçalho.** A pessoa cola apenas a linha de cabeçalho do
registro e, se quiser, uma linha antiga com os valores trocados por exemplos
inventados que preservem o formato. Com isso dá para montar o mapa de campos e
devolver a linha de comando pronta. Nenhum valor real é lido.

**Nível 2, script local (padrão).** A pessoa roda o script na máquina dela, com
`--sem-valores-no-mapa`, e o conteúdo das células não chega ao modelo. Depois ela
cola só o mapa, que nesse modo traz nome de coluna, nome de regra e contagem, sem
valor. Nome de arquivo em indústria costuma identificar o cliente ou o projeto:
sendo o caso, renomeie o arquivo antes de rodar.

**Nível 3, nada sai.** O modelo entrega a linha de comando e a explicação de como
ler os arquivos da rodada. A pessoa responde apenas "fechou" ou "não fechou" e, não
tendo fechado, qual pendência apareceu.

Regra que não se quebra: quando o dado é sensível, a leitura é local. Nunca peça
o `reincidencia.csv` colado para resumir.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**A empresa não tem registro nenhum hoje.** A skill não cria o sistema de
registro da casa. Ela para e diz o que trazer: um export do que existir, uma foto
do formulário, ou a lista dos campos digitada à mão. Inventar um formato aqui
seria o erro que ela existe para não cometer.

**Planilha .xlsx binária.** O script é biblioteca padrão e não lê xlsx. Converta
para CSV, e antes de salvar formate a coluna do número do registro como Texto:
número com zero à esquerda vira número sem zero, e código longo vira notação
científica, de forma irreversível. Depois de converter, abra o CSV num editor de
texto e confirme que os zeros continuam lá.

**Registro que vive só dentro do sistema, sem export.** A skill não acessa o
sistema. Com a lista dos campos da tela, na ordem da tela, ela entrega o conteúdo
campo a campo para a pessoa digitar, e diz que foi isso que fez.

**Histórico só em papel ou em PDF escaneado.** Não é registro, é extração. Use
`extracao-de-documento-para-tabela` primeiro, com a taxa de acerto medida contra
gabarito, e traga o CSV para cá. Varredura de reincidência sobre extração não
medida produz tanto achado falso quanto achado perdido.

**Causa que exige investigação do time.** A skill não investiga. Ela registra o
que foi apurado, marca o que é hipótese e escreve o teste que confirmaria. Análise
de causa com o time é reunião, não é preenchimento de campo.

**Disposição do produto.** Liberar, retrabalhar, reclassificar, devolver ou
sucatear não é decisão da skill nem da IA. Ela registra o que a pessoa com
autoridade decidiu.

**Numeração.** A skill não gera o próximo número. Ou a pessoa informa, ou a
coluna sai pendente.

---

## Referência

A pasta da skill fica em `~/.claude/skills/registro-de-anomalia/` depois de
instalada. Os arquivos de referência são lidos por esse caminho, e os scripts são
chamados pelo caminho completo.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/registro-de-anomalia/references/classes-de-registro.md` | A separação entre registro e tratamento com o teste de cinco perguntas, o vocabulário que as casas usam, o catálogo das colunas típicas, descrição fraca contra descrição utilizável, a tabela de hipótese contra teste, os três testes da contramedida, e o critério do que é o mesmo desvio. Leia antes de decidir a classe e antes de preencher causa. |
| `~/.claude/skills/registro-de-anomalia/scripts/registrar.py` | Implementação em Python de biblioteca padrão: lê o cabeçalho do modelo, emite a linha no formato dele e varre o histórico. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/registro-de-anomalia/scripts/testar.py` | Teste de regressão do `registrar.py`, biblioteca padrão apenas. Sessenta casos, cada um escrito a partir da pergunta que interessa: existe caminho em que esta rodada sai com sucesso tendo perdido, ignorado ou não processado dado? Os doze primeiros e os quinze últimos são as respostas: histórico sem coluna de descrição, histórico ausente sem declaração, `--sem-historico`, registro em subpasta, arquivo que o script não abre, campo sem coluna no modelo, caractere fora do encoding, quebra de linha dentro de célula, coluna sem nome no meio do cabeçalho e no fim, histórico existente e vazio, `--historico` apontado para o modelo, descrição sem coluna de destino, descrição divergente, coluna de apoio do histórico não encontrada, reincidência com varredura incompleta, título acima do cabeçalho do histórico, a saída da rodada dentro do histórico, e coluna declarada em `--obrigatorias` que não existe. Nenhum caso escreve na pasta do usuário. Rode `python3 ~/.claude/skills/registro-de-anomalia/scripts/testar.py` depois de qualquer mudança no script, ou `py -3 "$env:USERPROFILE\.claude\skills\registro-de-anomalia\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
