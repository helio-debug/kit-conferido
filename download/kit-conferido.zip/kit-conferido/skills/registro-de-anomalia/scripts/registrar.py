#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
registrar.py, emite o registro de anomalia no formato que a empresa ja usa.

Le o cabecalho do registro que a empresa mantem hoje (planilha exportada em CSV,
ou a lista de campos de um formulario), emite a linha pronta para colar naquele
formato, e varre o historico entregue atras do mesmo desvio.

Biblioteca padrao apenas, Python 3.8 ou superior. Sem rede. Nao escreve nos
arquivos de entrada e nao escreve em sistema nenhum.

Uso tipico. O --historico aponta para os registros anteriores, nunca para o
arquivo do --modelo: modelo com cabecalho e nenhum registro nao responde nada
sobre reincidencia.

    python3 ~/.claude/skills/registro-de-anomalia/scripts/registrar.py \\
        --modelo registro-nc.csv --anomalia anomalia.csv \\
        --historico historico-nc/ --coluna-descricao "Descricao" \\
        --coluna-data "Data" --coluna-numero "No" \\
        --obrigatorias "No,Data,Descricao,Setor" \\
        --saida registro-2026-09-20

Codigos de saida:

    0  registro fechado, historico varrido inteiro, nenhuma reincidencia
    1  registro fechado, varredura completa, e ha reincidencia para ler
    2  registro nao fechado: pendencia bloqueante
    3  erro de entrada, ou fechamento que nao fecha
    4  rodada --so-mapa, nenhum registro emitido
    5  registro fechado, sem reincidencia, mas ficou coisa fora da varredura
    6  registro fechado, ha reincidencia, e ficou coisa fora da varredura

O 0 e o 1 sao as duas unicas saidas que afirmam varredura completa. Zero
registro comparado nunca sai com 0 nem com 1.
"""

import argparse
import codecs
import csv
import io
import os
import re
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

RODAPE = ("Gerado com apoio de IA a partir de {fonte}. Revisar antes de assinar. "
          "Nao substitui responsabilidade tecnica.")

GOVERNADOS = [
    "kit.classe",
    "kit.descricao_do_desvio",
    "kit.causa",
    "kit.causa_status",
    "kit.teste_que_confirmaria",
    "kit.teste_realizado",
    "kit.contramedida",
    "kit.dono",
    "kit.prazo",
    "kit.local",
    "kit.coluna_da_descricao",
    "kit.coluna_da_causa",
    "kit.coluna_da_contramedida",
    "kit.coluna_do_dono",
    "kit.coluna_do_prazo",
    "kit.coluna_do_local",
]

CLASSES = ("somente_registro", "exige_tratamento")

CONFIRMADA = "confirmada por teste"  # comparada depois de normalizar

DONOS_GENERICOS = {
    "producao", "qualidade", "manutencao", "engenharia", "pcp", "suprimentos",
    "compras", "logistica", "almoxarifado", "seguranca", "rh", "ti", "time",
    "equipe", "todos", "setor", "area", "turno", "lideranca", "supervisao",
    "gerencia", "a definir", "adefinir", "responsavel", "quem for",
}

PALAVRAS_VAZIAS = {
    "de", "da", "do", "das", "dos", "e", "o", "a", "os", "as", "em", "no", "na",
    "nos", "nas", "um", "uma", "uns", "umas", "para", "por", "com", "sem", "que",
    "ao", "aos", "se", "foi", "sao", "esta", "este", "essa", "esse", "isso",
    "nao", "mais", "menos", "apos", "antes", "durante", "houve", "teve", "ficou",
    "sobre", "entre", "pelo", "pela", "ser", "estar", "muito", "quando", "onde",
}

CANDIDATAS_DESCRICAO = ("descric", "ocorrenc", "desvio", "relato", "problema",
                        "nao conformidade", "naoconformidade", "anomalia",
                        "constatac", "fato")

# Destino no modelo, quando a pessoa nao declara kit.coluna_*. Vale so quando
# uma unica coluna do modelo casa: duas candidatas viram pendencia, nunca
# escolha do script. Todo destino inferido sai escrito no mapa e no terminal.
CANDIDATAS_CAUSA = ("causa",)
CANDIDATAS_CONTRAMEDIDA = ("corretiva", "contramedida", "acao de bloqueio",
                           "acao definitiva")
CANDIDATAS_DONO = ("responsavel", "dono", "encarregad")
CANDIDATAS_PRAZO = ("prazo", "data prevista", "previsao", "data limite")
CANDIDATAS_LOCAL = ("equipamento", "maquina", "tag", "posto", "local",
                    "recurso")

EXTENSOES_LIDAS = (".csv", ".txt", ".tsv")

# Pendencias cujo detalhe carrega conteudo de celula. Com --sem-valores-no-mapa
# o mapa e o arquivo que a pessoa cola, e a skill promete que ele nao leva
# valor: nestes tipos o detalhe fica so no campos-pendentes.csv, na maquina dela.
TIPOS_COM_VALOR = {
    "descricao_divergente", "local_divergente", "dono_generico",
    "prazo_nao_e_data", "classe_invalida",
    "caractere_fora_do_encoding_do_modelo",
    "gabarito_divergente_em_coluna_obrigatoria",
}

LIVRO_PADRAO = "~/.kit-industrial/gabaritos-registro-de-anomalia.csv"


# ---------------------------------------------------------------- utilitarios

def normalizar(texto):
    if texto is None:
        return ""
    t = unicodedata.normalize("NFKD", str(texto))
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = t.lower()
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return t.strip()


def ler_texto(caminho):
    """Devolve (texto, encoding). Ordem declarada, sem adivinhacao silenciosa."""
    bruto = Path(caminho).read_bytes()
    ordem = ("utf-8-sig",) if bruto.startswith(codecs.BOM_UTF8) else ()
    for enc in ordem + ("utf-8", "cp1252", "latin-1"):
        try:
            return bruto.decode(enc), enc
        except UnicodeDecodeError:
            continue
    raise ValueError("nenhum encoding conhecido leu o arquivo")


def detectar_delimitador(linha):
    contagens = {d: linha.count(d) for d in (";", "\t", ",", "|")}
    melhor = max(contagens, key=lambda d: contagens[d])
    if contagens[melhor] == 0:
        return None
    return melhor


def ler_data(valor):
    v = (valor or "").strip()
    if not v:
        return None
    v = v.split(" ")[0]
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%y", "%d.%m.%Y"):
        try:
            return datetime.strptime(v, fmt).date()
        except ValueError:
            continue
    return None


def termos(texto):
    fora = normalizar(texto).split()
    saida = set()
    for p in fora:
        if p in PALAVRAS_VAZIAS:
            continue
        if len(p) >= 3 or (p.isdigit() and len(p) >= 2):
            saida.add(p)
    return saida


def limpar_celula(valor):
    """Tira quebra de linha e tabulacao de uma celula. Devolve (valor, mudou)."""
    v = valor or ""
    novo = v.replace("\r\n", " ").replace("\n", " ").replace("\r", " ")
    novo = novo.replace("\t", " ")
    novo = re.sub(r" {2,}", " ", novo).strip()
    return novo, novo != v


# ------------------------------------------------------------------- leituras

def ler_modelo(caminho, em_linhas, linha_cabecalho, permitir_repetida, erros):
    """Devolve (colunas, encoding, delimitador, info)."""
    texto, enc = ler_texto(caminho)
    info = {
        "arquivo": str(caminho),
        "bytes": Path(caminho).stat().st_size,
        "modificado": datetime.fromtimestamp(
            Path(caminho).stat().st_mtime).strftime("%d/%m/%Y %H:%M"),
        "encoding": enc,
    }
    if em_linhas:
        colunas = [l.strip() for l in texto.splitlines() if l.strip()]
        info["delimitador"] = "um campo por linha"
        info["linha_do_cabecalho"] = 1
        delim = None
    else:
        linhas = texto.splitlines()
        if not linhas:
            erros.append("o arquivo do modelo esta vazio")
            return [], enc, None, info
        idx = (linha_cabecalho or 1) - 1
        if idx < 0 or idx >= len(linhas):
            erros.append("--linha-do-cabecalho %s nao existe no arquivo"
                         % linha_cabecalho)
            return [], enc, None, info
        delim = detectar_delimitador(linhas[idx])
        if delim is None:
            erros.append(
                "a linha %d do modelo nao tem delimitador. Sendo planilha com "
                "titulo em cima, aponte a linha do cabecalho com "
                "--linha-do-cabecalho. Sendo formulario com um campo por linha, "
                "rode com --modelo-em-linhas" % (idx + 1))
            return [], enc, None, info
        leitor = csv.reader(io.StringIO(texto), delimiter=delim)
        todas = list(leitor)
        if idx >= len(todas):
            erros.append("--linha-do-cabecalho %s nao existe no arquivo"
                         % linha_cabecalho)
            return [], enc, delim, info
        colunas = [c.strip() for c in todas[idx]]
        if linha_cabecalho is None:
            cheias = len([c for c in colunas if c])
            adiante = max([len([c for c in l if c.strip()])
                           for l in todas[idx + 1:idx + 6]] or [0])
            if cheias < 2 and adiante >= 2:
                erros.append(
                    "a linha 1 tem %d celula preenchida e as seguintes tem ate "
                    "%d: parece titulo, nao cabecalho. Rode com "
                    "--linha-do-cabecalho apontando a linha do cabecalho"
                    % (cheias, adiante))
                return [], enc, delim, info
        info["delimitador"] = repr(delim)
        info["linha_do_cabecalho"] = idx + 1

    # Coluna sem nome no cabecalho nao e descartada. Descartar mudava a
    # contagem de colunas para a de depois do filtro, nenhuma identidade
    # acusava a perda, e a linha emitida saia deslocada uma coluna a esquerda
    # em relacao a planilha da casa. Aqui ela guarda a posicao, recebe um nome
    # de trabalho pela posicao e sai como celula vazia.
    info["campos_do_cabecalho_bruto"] = len(colunas)
    nomes_no_cabecalho = []
    sem_nome = []
    finais = []
    for i, c in enumerate(colunas, 1):
        if c == "":
            sem_nome.append(i)
            finais.append("(coluna sem nome %d)" % i)
            nomes_no_cabecalho.append("")
        else:
            finais.append(c)
            nomes_no_cabecalho.append(c)
    colunas = finais
    info["colunas_sem_nome"] = sem_nome
    info["colunas_nomeadas"] = len(colunas) - len(sem_nome)
    info["nomes_no_cabecalho"] = nomes_no_cabecalho
    if not colunas:
        erros.append("nenhuma coluna foi lida do modelo")
        return [], enc, delim, info
    if not info["colunas_nomeadas"]:
        erros.append("nenhuma coluna do modelo tem nome no cabecalho")
        return [], enc, delim, info

    vistos = {}
    repetidas = []
    for c in colunas:
        n = normalizar(c)
        vistos.setdefault(n, []).append(c)
    for n, lista in vistos.items():
        if len(lista) > 1:
            repetidas.append(", ".join(lista))
    if repetidas and not permitir_repetida:
        erros.append(
            "o modelo tem coluna repetida depois de normalizar o nome (%s). "
            "Duas colunas com o mesmo nome fariam o valor cair em uma so sem "
            "aviso. Rode com --permitir-coluna-repetida para preencher todas "
            "com o mesmo valor, por decisao declarada" % "; ".join(repetidas))
    info["colunas_repetidas"] = repetidas
    return colunas, enc, delim, info


def ler_anomalia(caminho, erros):
    """CSV de duas colunas, campo;valor, gerado pelo modelo. Sempre ponto e virgula."""
    texto, enc = ler_texto(caminho)
    leitor = csv.reader(io.StringIO(texto), delimiter=";")
    pares = []
    for n, linha in enumerate(leitor, start=1):
        if not linha or all(not c.strip() for c in linha):
            continue
        if len(linha) < 2:
            erros.append("linha %d da anomalia nao tem campo e valor: %r"
                         % (n, linha))
            continue
        campo = linha[0].strip()
        valor = ";".join(linha[1:]).strip() if len(linha) > 2 else linha[1].strip()
        if normalizar(campo) in ("campo", "campos") and normalizar(valor) == "valor":
            continue
        pares.append((campo, valor, n))
    if not pares:
        erros.append("o arquivo da anomalia nao tem nenhum par campo;valor")
    return pares, enc


# ------------------------------------------------------------------ historico

def coletar_arquivos(caminhos, nao_lidos, cont, saida):
    arquivos = []
    try:
        dir_saida = Path(saida).resolve()
    except Exception:
        dir_saida = None
    for bruto in caminhos:
        p = Path(bruto)
        if not p.exists():
            raise ValueError("caminho de historico nao encontrado: %s" % bruto)
        if p.is_file():
            candidatos = [p]
        else:
            candidatos = sorted(x for x in p.rglob("*") if x.is_file())
        for arq in candidatos:
            cont["arquivos_encontrados"] += 1
            if dir_saida is not None:
                try:
                    dentro = dir_saida in arq.resolve().parents
                except Exception:
                    dentro = False
                if dentro:
                    cont["arquivos_nao_lidos"] += 1
                    nao_lidos.append(
                        (str(arq), "", "arquivo_nao_lido",
                         "arquivo dentro do diretorio de saida desta rodada. "
                         "Varrer a propria saida acha o registro que acabou de "
                         "ser emitido e devolve reincidencia fantasma", ""))
                    continue
            if arq.name.startswith("."):
                cont["arquivos_nao_lidos"] += 1
                nao_lidos.append((str(arq), "", "arquivo_nao_lido",
                                  "arquivo oculto, nao foi aberto", ""))
                continue
            if arq.suffix.lower() not in EXTENSOES_LIDAS:
                cont["arquivos_nao_lidos"] += 1
                nao_lidos.append((str(arq), "", "arquivo_nao_lido",
                                  "extensao %s nao e lida por este script, "
                                  "exporte para CSV" % (arq.suffix or "sem extensao"),
                                  ""))
                continue
            cont["arquivos_lidos"] += 1
            arquivos.append(arq)
    return arquivos


def varrer_historico(arquivos, cfg, cont, nao_varridos, achados, notas):
    alvo = cfg["termos_alvo"]
    local_alvo = normalizar(cfg["local_alvo"]) if cfg["local_alvo"] else ""
    for arq in arquivos:
        try:
            texto, _enc = ler_texto(arq)
        except Exception as exc:
            cont["arquivos_lidos"] -= 1
            cont["arquivos_nao_lidos"] += 1
            nao_varridos.append((str(arq), "", "arquivo_nao_lido",
                                 "falha ao decodificar: %s" % exc, ""))
            continue
        linhas = texto.splitlines()
        if not linhas:
            cont["arquivos_sem_registro"] += 1
            nao_varridos.append((str(arq), "", "historico_sem_registro",
                                 "o arquivo esta vazio: nenhum registro foi "
                                 "comparado a partir dele", ""))
            continue
        delim = detectar_delimitador(linhas[0]) or ";"
        todas = list(csv.reader(io.StringIO(texto), delimiter=delim))

        # Titulo acima do cabecalho, a mesma armadilha que o modelo ja tratava.
        # Sem isto o arquivo inteiro caia em sem_coluna_de_descricao e a causa
        # gravada nao dizia que o problema era o titulo.
        inicio = 0
        while inicio < len(todas) - 1:
            cheias = len([c for c in todas[inicio] if (c or "").strip()])
            adiante = max([len([c for c in l if (c or "").strip()])
                           for l in todas[inicio + 1:inicio + 6]] or [0])
            if cheias < 2 and adiante >= 2:
                notas.append(
                    "Em %s a linha %d era titulo, nao cabecalho: o cabecalho "
                    "foi lido na linha %d." % (arq.name, inicio + 1, inicio + 2))
                inicio += 1
                continue
            break

        cabecalho = [c.strip() for c in todas[inicio]]
        idx_desc, motivo_sem_coluna = achar_coluna(
            cabecalho, cfg["coluna_descricao"], CANDIDATAS_DESCRICAO)
        # O motivo de cada coluna de apoio nao encontrada era jogado fora, e a
        # reincidencia saia sem numero, sem data e sem local, sem dizer por que.
        for rotulo, declarada in (("data", cfg["coluna_data"]),
                                  ("numero do registro", cfg["coluna_numero"]),
                                  ("local", cfg["coluna_local"])):
            idx, motivo = achar_coluna(cabecalho, declarada, ())
            if rotulo == "data":
                idx_data = idx
            elif rotulo == "local":
                idx_local = idx
            else:
                idx_num = idx
            if declarada and idx is None:
                cont["colunas_de_apoio_nao_encontradas"] += 1
                nao_varridos.append(
                    (str(arq), inicio + 1, "coluna_de_apoio_nao_encontrada",
                     "a coluna de %s nao foi encontrada: %s. A reincidencia "
                     "deste arquivo sai sem esse dado" % (rotulo, motivo),
                     " | ".join(cabecalho)[:200]))

        registros_no_arquivo = 0
        for numero, linha in enumerate(todas[inicio + 1:], start=inicio + 2):
            cont["registros_encontrados"] += 1
            registros_no_arquivo += 1
            if all(not (c or "").strip() for c in linha):
                cont["nao_varridos"] += 1
                nao_varridos.append((str(arq), numero, "linha_vazia",
                                     "linha sem nenhum valor", ""))
                continue
            if idx_desc is None:
                cont["nao_varridos"] += 1
                nao_varridos.append((str(arq), numero, "sem_coluna_de_descricao",
                                     motivo_sem_coluna, " | ".join(linha)[:200]))
                continue
            if len(linha) != len(cabecalho):
                cont["nao_varridos"] += 1
                nao_varridos.append(
                    (str(arq), numero, "contagem_de_colunas_diferente",
                     "a linha tem %d celulas e o cabecalho tem %d"
                     % (len(linha), len(cabecalho)), " | ".join(linha)[:200]))
                continue
            descricao = (linha[idx_desc] or "").strip()
            if not descricao:
                cont["nao_varridos"] += 1
                nao_varridos.append((str(arq), numero, "descricao_vazia",
                                     "a coluna de descricao esta em branco",
                                     " | ".join(linha)[:200]))
                continue

            cont["varridos"] += 1
            termos_linha = termos(descricao)
            comuns = alvo & termos_linha
            menor = min(len(alvo), len(termos_linha)) or 1
            escore = len(comuns) / float(menor)
            local = (linha[idx_local].strip() if idx_local is not None
                     and idx_local < len(linha) else "")
            data_bruta = (linha[idx_data].strip() if idx_data is not None
                          and idx_data < len(linha) else "")
            numero_reg = (linha[idx_num].strip() if idx_num is not None
                          and idx_num < len(linha) else "")
            data = ler_data(data_bruta)
            alerta_data = ""
            if data_bruta and data is None:
                alerta_data = "data_nao_lida"
                cont["datas_nao_lidas"] += 1

            motivo = ""
            if len(comuns) >= cfg["minimo_termos"] and escore >= cfg["limiar"]:
                motivo = "descricao_semelhante"
            elif local_alvo and normalizar(local) == local_alvo:
                motivo = "mesmo_local"

            if motivo:
                cont["reincidencias"] += 1
                achados.append({
                    "arquivo": str(arq),
                    "linha": numero,
                    "numero": numero_reg,
                    "data": data_bruta,
                    "data_lida": data.strftime("%Y-%m-%d") if data else "",
                    "motivo": motivo,
                    "escore": "%.2f" % escore,
                    "termos": " ".join(sorted(comuns)),
                    "local": local,
                    "descricao": descricao[:300],
                    "alerta": alerta_data,
                })
            else:
                cont["sem_semelhanca"] += 1

        if registros_no_arquivo == 0:
            # Historico que existe e nao tem registro: comparar zero registro e
            # dizer "nenhuma reincidencia" e a resposta falsa que o codigo 5
            # existe para impedir.
            cont["arquivos_sem_registro"] += 1
            nao_varridos.append(
                (str(arq), "", "historico_sem_registro",
                 "o arquivo tem cabecalho e nenhum registro abaixo dele. "
                 "Nenhuma comparacao saiu deste arquivo", ""))


def achar_coluna(cabecalho, nome, candidatas):
    """Devolve (indice, motivo). Nunca escolhe entre duas candidatas."""
    if nome:
        alvo = normalizar(nome)
        achados = [i for i, c in enumerate(cabecalho) if normalizar(c) == alvo]
        if len(achados) == 1:
            return achados[0], ""
        if not achados:
            return None, ("a coluna %r nao existe neste arquivo. Colunas: %s"
                          % (nome, ", ".join(cabecalho)))
        return None, ("a coluna %r aparece %d vezes neste arquivo"
                      % (nome, len(achados)))
    if not candidatas:
        return None, ""
    achados = [i for i, c in enumerate(cabecalho)
               if any(p in normalizar(c) for p in candidatas)]
    if len(achados) == 1:
        return achados[0], ""
    if not achados:
        return None, ("nenhuma coluna deste arquivo parece a de descricao. "
                      "Colunas: %s. Declare com --coluna-descricao"
                      % ", ".join(cabecalho))
    nomes = ", ".join(cabecalho[i] for i in achados)
    return None, ("mais de uma coluna parece a de descricao (%s). Declare com "
                  "--coluna-descricao" % nomes)


# --------------------------------------------------------------------- saidas

def esc(texto):
    """Barra vertical dentro de celula quebraria a tabela do markdown."""
    return str(texto).replace("|", "\\|")


def escrever_mapa(destino, dados, status):
    linhas = []
    a = linhas.append
    a("# Mapa de campos do registro de anomalia")
    a("")
    a("status: %s" % status)
    a("")
    a("## Modelo, o registro que a empresa ja usa")
    a("")
    m = dados["modelo"]
    a("| Item | Valor |")
    a("|---|---|")
    a("| Arquivo | `%s` |" % m["arquivo"])
    a("| Tamanho | %d bytes |" % m["bytes"])
    a("| Modificado em | %s |" % m["modificado"])
    a("| Encoding lido | %s |" % m["encoding"])
    a("| Delimitador | %s |" % m.get("delimitador", ""))
    a("| Linha do cabecalho | %s |" % m.get("linha_do_cabecalho", ""))
    a("| Campos no cabecalho bruto | %d |"
      % m.get("campos_do_cabecalho_bruto", len(dados["colunas"])))
    a("| Colunas lidas | %d |" % len(dados["colunas"]))
    a("| Colunas com nome no cabecalho | %d |"
      % m.get("colunas_nomeadas", len(dados["colunas"])))
    a("| Colunas sem nome no cabecalho | %s |"
      % (", ".join("posicao %d" % i for i in m["colunas_sem_nome"])
         if m.get("colunas_sem_nome") else "0"))
    if m.get("colunas_repetidas"):
        a("| Colunas com nome repetido | %s |"
          % esc("; ".join(m["colunas_repetidas"])))
    a("")
    a("O formato da saida e o deste arquivo. A skill nao propoe formato novo.")
    a("")
    a("## Coluna a coluna")
    a("")
    a("| # | Coluna do registro | De onde veio | Estado |")
    a("|---|---|---|---|")
    for i, (col, origem, estado, valor) in enumerate(dados["colunas_detalhe"], 1):
        mostrado = valor
        if dados["sem_valores"] and valor:
            mostrado = "<preenchido, %d caracteres>" % len(valor)
        origem_txt = origem if not mostrado else "%s: %s" % (origem, mostrado)
        a("| %d | %s | %s | %s |" % (i, esc(col), esc(origem_txt), estado))
    a("")
    a("## Campos governados pelo kit")
    a("")
    a("| Campo | Valor | Efeito |")
    a("|---|---|---|")
    for campo, valor, efeito in dados["governados_detalhe"]:
        mostrado = valor
        if dados["sem_valores"] and valor:
            mostrado = "<preenchido, %d caracteres>" % len(valor)
        a("| `%s` | %s | %s |" % (campo, esc(mostrado), efeito))
    a("")
    a("## Destino de cada valor governado")
    a("")
    if dados["destinos"]:
        a("| Valor | Coluna do registro | Como o destino foi decidido |")
        a("|---|---|---|")
        for rotulo, coluna, como in dados["destinos"]:
            a("| %s | %s | %s |" % (rotulo, esc(coluna), como))
    else:
        a("Nenhum valor governado entrou em coluna nesta rodada.")
    a("")
    a("Destino inferido e o script achando uma unica coluna do modelo cujo nome "
      "casa com o campo. Havendo duas candidatas, ele nao escolhe: vira "
      "pendencia e voce declara.")
    a("")
    a("## Classe e fechamento do registro")
    a("")
    for linha in dados["fechamento_regra"]:
        a("- %s" % linha)
    a("")
    a("## Historico varrido")
    a("")
    c = dados["cont"]
    a("| Contagem | Valor |")
    a("|---|---|")
    a("| Arquivos encontrados | %d |" % c["arquivos_encontrados"])
    a("| Arquivos lidos | %d |" % c["arquivos_lidos"])
    a("| Arquivos nao lidos | %d |" % c["arquivos_nao_lidos"])
    a("| Registros encontrados | %d |" % c["registros_encontrados"])
    a("| Registros varridos | %d |" % c["varridos"])
    a("| Registros nao varridos | %d |" % c["nao_varridos"])
    a("| Sem semelhanca | %d |" % c["sem_semelhanca"])
    a("| Reincidencias | %d |" % c["reincidencias"])
    a("| Datas nao lidas em registro varrido | %d |" % c["datas_nao_lidas"])
    a("| Arquivos de historico sem nenhum registro | %d |"
      % c["arquivos_sem_registro"])
    a("| Colunas de apoio nao encontradas | %d |"
      % c["colunas_de_apoio_nao_encontradas"])
    a("")
    for linha in dados["nota_historico"]:
        a("- %s" % linha)
    a("")
    a("## Identidades de fechamento")
    a("")
    if dados["identidades"]:
        a("```")
        for texto, ok in dados["identidades"]:
            a("%-78s %s" % (texto, "fecha" if ok else "NAO FECHA"))
        a("```")
    else:
        a("As identidades saem na gravacao final do mapa, depois da ultima "
          "pendencia gravada e depois de contar as linhas efetivamente "
          "escritas em cada arquivo.")
    a("")
    a("Os contadores sao incrementados dentro do laco, registro a registro. "
      "Nenhum deles e obtido por subtracao: contador derivado fecha sozinho "
      "mesmo quando some dado.")
    a("")
    a("## Pendencias e avisos")
    a("")
    if dados["pendencias"]:
        a("| Campo | Tipo | Bloqueia | Detalhe |")
        a("|---|---|---|---|")
        for campo, tipo, bloqueia, detalhe in dados["pendencias"]:
            if dados["sem_valores"] and tipo in TIPOS_COM_VALOR:
                detalhe = ("o detalhe traz conteudo de celula: leia o "
                           "campos-pendentes.csv na sua maquina")
            a("| %s | %s | %s | %s |" % (esc(campo), tipo,
                                         "sim" if bloqueia else "nao",
                                         esc(detalhe)))
    else:
        a("Nenhuma.")
    a("")
    a("## Limite declarado")
    a("")
    a("Este script nao escreve no sistema da empresa, nao abre o painel e nao "
      "numera o registro. Ele entrega a linha no formato lido do modelo, para "
      "alguem conferir e colar.")
    a("")
    a(RODAPE.format(fonte=os.path.basename(dados["modelo"]["arquivo"])))
    a("")
    Path(destino).write_text("\n".join(linhas), encoding="utf-8")


def escrever_csv(destino, cabecalho, linhas):
    """Grava o CSV e devolve quantos registros foram escritos.

    Sem rodape dentro do arquivo. O rodape de procedencia virava uma linha a
    mais na tabela quando alguem abria no Excel, entrava como registro na skill
    que consome esta saida, e desmentia a identidade que conta registros. Ele
    passou para o procedencia.txt e para os .md.
    """
    with open(destino, "w", encoding="utf-8", newline="") as fh:
        escritor = csv.writer(fh, delimiter=";")
        escritor.writerow(cabecalho)
        for l in linhas:
            escritor.writerow(l)
    return len(linhas)


def escrever_procedencia(destino, fonte, arquivos, avisos):
    linhas = ["Procedencia da rodada", ""]
    linhas.append(RODAPE.format(fonte=fonte))
    linhas.append("")
    linhas.append("Arquivos desta rodada:")
    for a in arquivos:
        linhas.append("  %s" % a)
    if avisos:
        linhas.append("")
        for a in avisos:
            linhas.append(a)
    linhas.append("")
    linhas.append("Os CSV desta pasta nao levam rodape dentro do arquivo: "
                  "toda linha deles e registro.")
    linhas.append("")
    Path(destino).write_text("\n".join(linhas), encoding="utf-8")


def comparar_gabarito(caminho, colunas, nomes_cabecalho, linha_saida):
    """Compara a linha emitida com a linha que a empresa ja fechou.

    Devolve (vereditos, erro). Cada veredito e (coluna, valor_da_empresa,
    valor_emitido, veredito).
    """
    try:
        texto, _enc = ler_texto(caminho)
    except Exception as exc:
        return [], "nao foi possivel ler o gabarito: %s" % exc
    linhas = [l for l in texto.splitlines() if l.strip()]
    if len(linhas) < 2:
        return [], ("o gabarito precisa do cabecalho e de uma linha preenchida. "
                    "Lidas %d linhas com conteudo" % len(linhas))
    delim = detectar_delimitador(linhas[0]) or ";"
    todas = list(csv.reader(io.StringIO("\n".join(linhas)), delimiter=delim))
    cabecalho = [c.strip() for c in todas[0]]
    valores_gab = {}
    for i, c in enumerate(cabecalho):
        if not c:
            continue
        valores_gab[normalizar(c)] = (todas[1][i].strip()
                                      if i < len(todas[1]) else "")
    vereditos = []
    for col, valor in zip(colunas, linha_saida):
        n = normalizar(col)
        if n not in valores_gab:
            vereditos.append((col, "", valor, "coluna nao existe no gabarito"))
            continue
        do_gab = valores_gab[n]
        if not do_gab and not valor:
            vereditos.append((col, do_gab, valor, "vazia nas duas"))
        elif normalizar(do_gab) == normalizar(valor):
            vereditos.append((col, do_gab, valor, "igual"))
        elif not do_gab or not valor:
            vereditos.append((col, do_gab, valor, "divergente"))
        elif ler_data(do_gab) and ler_data(valor):
            # Data e numero de registro nao tem sinonimo: ou e a mesma, ou
            # divergiu. Sem isto 09/05/2026 e 20/09/2026 saiam como equivalentes
            # por dividirem o ano.
            vereditos.append((col, do_gab, valor, "divergente"))
        else:
            a, b = termos(do_gab), termos(valor)
            menor = min(len(a), len(b)) or 1
            # A equivalencia por palavras vale para texto corrido. Em campo
            # curto, codigo ou data, coincidencia parcial nao e equivalencia.
            if menor >= 3 and len(a & b) / float(menor) >= 0.6:
                vereditos.append((col, do_gab, valor,
                                  "equivalente em palavras diferentes"))
            else:
                vereditos.append((col, do_gab, valor, "divergente"))
    nomes = {normalizar(c) for c in nomes_cabecalho if c}
    for n, valor in valores_gab.items():
        if n not in {normalizar(c) for c in colunas} and n not in nomes:
            vereditos.append((n, valor, "", "coluna so no gabarito"))
    return vereditos, ""


def escrever_conferencia(destino, vereditos, obrigatorias, fonte, gabarito):
    divergentes = [v for v in vereditos if v[3] == "divergente"]
    div_obrig = [v for v in divergentes if normalizar(v[0]) in obrigatorias]
    linhas = ["# Conferencia do gabarito", ""]
    linhas.append("Gabarito: `%s`" % gabarito)
    linhas.append("")
    linhas.append("| Coluna | O que a empresa escreveu | O que saiu | Veredito |")
    linhas.append("|---|---|---|---|")
    for col, do_gab, valor, veredito in vereditos:
        linhas.append("| %s | %s | %s | %s |"
                      % (esc(col), esc(do_gab), esc(valor), veredito))
    linhas.append("")
    linhas.append("Colunas conferidas: %d. Divergentes: %d, das quais %d em "
                  "coluna obrigatoria."
                  % (len(vereditos), len(divergentes), len(div_obrig)))
    linhas.append("")
    if div_obrig:
        linhas.append("**Nao libera.** Enquanto houver coluna obrigatoria "
                      "divergente sem explicacao escrita, a skill nao roda em "
                      "caso novo. Escreva aqui embaixo, por coluna, por que a "
                      "diferenca e aceitavel, ou corrija a rodada e refaca.")
    else:
        linhas.append("**Libera.** Nenhuma coluna obrigatoria divergiu. As "
                      "diferencas de palavra em coluna nao obrigatoria ficam "
                      "acima, para leitura.")
    linhas.append("")
    linhas.append(RODAPE.format(fonte=fonte))
    linhas.append("")
    Path(destino).write_text("\n".join(linhas), encoding="utf-8")
    return len(divergentes), div_obrig


def registrar_no_livro(caminho, linha):
    """Acrescenta uma linha ao livro de gabaritos. Devolve (ok, detalhe)."""
    alvo = Path(os.path.expanduser(caminho))
    cabecalho = ["data_da_rodada", "modelo", "gabarito", "colunas_conferidas",
                 "divergentes", "divergentes_em_coluna_obrigatoria", "veredito"]
    try:
        alvo.parent.mkdir(parents=True, exist_ok=True)
        novo = not alvo.exists()
        with open(alvo, "a", encoding="utf-8", newline="") as fh:
            escritor = csv.writer(fh, delimiter=";")
            if novo:
                escritor.writerow(cabecalho)
            escritor.writerow(linha)
        return True, str(alvo)
    except Exception as exc:
        return False, "%s: %s" % (alvo, exc)


# ----------------------------------------------------------------------- main

def main(argv=None):
    p = argparse.ArgumentParser(
        description="Emite o registro de anomalia no formato do registro que a "
                    "empresa ja usa, e varre o historico atras do mesmo desvio.")
    p.add_argument("--modelo", required=True,
                   help="CSV exportado do registro que a empresa usa hoje. O "
                        "cabecalho dele define o formato da saida.")
    p.add_argument("--modelo-em-linhas", action="store_true",
                   help="O modelo e uma lista de campos, um por linha, tirada "
                        "de um formulario em papel ou em editor de texto.")
    p.add_argument("--linha-do-cabecalho", type=int, default=None,
                   help="Numero da linha do cabecalho, quando a planilha tem "
                        "titulo em cima.")
    p.add_argument("--permitir-coluna-repetida", action="store_true")
    p.add_argument("--anomalia",
                   help="CSV campo;valor com o desvio. Obrigatorio fora de "
                        "--so-mapa.")
    p.add_argument("--historico", action="append", default=[],
                   help="Arquivo ou pasta com os registros anteriores. Pode "
                        "repetir.")
    p.add_argument("--sem-historico", action="store_true",
                   help="Declara que nao ha historico para varrer. A rodada "
                        "nunca sai com 0.")
    p.add_argument("--coluna-descricao")
    p.add_argument("--coluna-data")
    p.add_argument("--coluna-numero")
    p.add_argument("--coluna-local")
    p.add_argument("--limiar", type=float, default=0.5)
    p.add_argument("--minimo-termos", type=int, default=2)
    p.add_argument("--limiar-cronico", type=int, default=3)
    p.add_argument("--obrigatorias", default="")
    p.add_argument("--em-branco", default="",
                   help="Colunas que ficam em branco por decisao declarada.")
    p.add_argument("--contramedida-fora-da-linha", action="store_true",
                   help="A contramedida vive em outro registro da empresa. "
                        "Decisao declarada, sai no mapa.")
    p.add_argument("--prefixo-hipotese", default="HIPOTESE NAO TESTADA: ")
    p.add_argument("--sem-valores-no-mapa", action="store_true")
    p.add_argument("--so-mapa", action="store_true")
    p.add_argument("--gabarito",
                   help="CSV no formato do modelo com a linha que a empresa "
                        "escreveu e fechou para este mesmo caso. A rodada "
                        "compara coluna a coluna, grava "
                        "conferencia-do-gabarito.md e registra a liberacao no "
                        "livro de gabaritos.")
    p.add_argument("--livro-de-gabaritos", default=LIVRO_PADRAO,
                   help="Onde a liberacao do gabarito fica registrada entre "
                        "conversas. Padrao: %s" % LIVRO_PADRAO)
    p.add_argument("--saida", required=True)
    p.add_argument("--forcar", action="store_true")
    args = p.parse_args(argv)

    erros = []
    saida = Path(args.saida)
    if saida.exists() and not args.forcar:
        print("erro: o diretorio %s ja existe. Use --forcar para regravar."
              % saida, file=sys.stderr)
        return 3
    if not args.so_mapa and not args.anomalia:
        print("erro: --anomalia e obrigatorio fora de --so-mapa.", file=sys.stderr)
        return 3
    if not args.so_mapa and not args.historico and not args.sem_historico:
        print("erro: sem --historico a pergunta da reincidencia fica sem "
              "resposta. Passe --historico, ou declare --sem-historico.",
              file=sys.stderr)
        return 3

    try:
        colunas, enc_modelo, delim_modelo, info_modelo = ler_modelo(
            args.modelo, args.modelo_em_linhas, args.linha_do_cabecalho,
            args.permitir_coluna_repetida, erros)
    except Exception as exc:
        print("erro ao ler o modelo: %s" % exc, file=sys.stderr)
        return 3
    if erros:
        for e in erros:
            print("erro: %s" % e, file=sys.stderr)
        return 3

    cont = {
        "campos_do_cabecalho_bruto": info_modelo.get(
            "campos_do_cabecalho_bruto", len(colunas)),
        "colunas_nomeadas": info_modelo.get("colunas_nomeadas", len(colunas)),
        "colunas_sem_nome": len(info_modelo.get("colunas_sem_nome", [])),
        "colunas_do_modelo": len(colunas),
        "preenchidas": 0, "sem_valor": 0, "em_branco_declaradas": 0,
        "campos_da_anomalia": 0, "casados": 0, "governados": 0,
        "governados_em_coluna": 0, "sem_lugar_no_modelo": 0,
        "arquivos_encontrados": 0, "arquivos_lidos": 0, "arquivos_nao_lidos": 0,
        "registros_encontrados": 0, "varridos": 0, "nao_varridos": 0,
        "sem_semelhanca": 0, "reincidencias": 0, "datas_nao_lidas": 0,
        "celulas_com_quebra": 0, "arquivos_sem_registro": 0,
        "colunas_de_apoio_nao_encontradas": 0,
    }
    pendencias = []          # (campo, tipo, bloqueia, detalhe)
    destinos = []            # (rotulo, coluna, como o destino foi decidido)
    obrigatorias = {normalizar(c) for c in args.obrigatorias.split(",") if c.strip()}
    em_branco = {normalizar(c) for c in args.em_branco.split(",") if c.strip()}
    colunas_norm = {normalizar(c) for c in colunas}
    indices_sem_nome = set(info_modelo.get("colunas_sem_nome", []))
    nomes_cabecalho = info_modelo.get("nomes_no_cabecalho", list(colunas))

    # Coluna sem nome no cabecalho: a posicao e mantida e a celula sai vazia.
    # No fim do cabecalho e o ponto e virgula sobrando do Excel, e isso e aviso.
    # No meio, alguma coluna real perdeu o nome e a linha pode estar indo para
    # o lugar errado: bloqueia.
    for i in sorted(indices_sem_nome):
        ultima = i == len(colunas)
        pendencias.append(
            ("(coluna sem nome %d)" % i, "coluna_sem_nome_no_cabecalho",
             not ultima,
             "o cabecalho do modelo tem %d campos e o campo %d esta sem nome. "
             "A posicao foi mantida e a celula sai vazia, para a linha nao "
             "deslocar na planilha. %s"
             % (cont["campos_do_cabecalho_bruto"], i,
                "Estando no fim, costuma ser o ponto e virgula sobrando do "
                "export: confira e siga." if ultima else
                "Estando no meio do cabecalho, confira qual coluna e essa "
                "antes de colar: pode ser coluna real que perdeu o nome.")))

    # Coluna declarada em --obrigatorias ou em --em-branco que nao existe no
    # modelo: a declaracao da pessoa desaparecia sem aviso.
    for rotulo, declaradas in (("--obrigatorias", args.obrigatorias),
                               ("--em-branco", args.em_branco)):
        for c in [x.strip() for x in declaradas.split(",") if x.strip()]:
            if normalizar(c) not in colunas_norm:
                pendencias.append(
                    (c, "coluna_declarada_nao_existe", True,
                     "%s cita %r, e o modelo nao tem essa coluna. Sem isto a "
                     "sua declaracao nao teria efeito nenhum e a rodada sairia "
                     "como se voce nao tivesse declarado nada" % (rotulo, c)))

    # ------------------------------------------------------------- anomalia
    valores = {}             # normalizado -> (valor, origem)
    governados = {}
    if args.anomalia:
        pares, _enc_a = ler_anomalia(args.anomalia, erros)
        if erros:
            for e in erros:
                print("erro: %s" % e, file=sys.stderr)
            return 3
        for campo, valor, nlinha in pares:
            cont["campos_da_anomalia"] += 1
            if campo.startswith("kit."):
                if campo not in GOVERNADOS:
                    cont["sem_lugar_no_modelo"] += 1
                    pendencias.append((campo, "campo_kit_desconhecido", True,
                                       "linha %d da anomalia. Campos aceitos: %s"
                                       % (nlinha, ", ".join(GOVERNADOS))))
                    continue
                cont["governados"] += 1
                governados[campo] = valor
                continue
            n = normalizar(campo)
            if n not in colunas_norm:
                cont["sem_lugar_no_modelo"] += 1
                pendencias.append((campo, "campo_sem_coluna_no_modelo", True,
                                   "linha %d da anomalia. O valor nao tem onde "
                                   "entrar no registro da empresa e nao foi "
                                   "descartado" % nlinha))
                continue
            if n in valores:
                cont["sem_lugar_no_modelo"] += 1
                pendencias.append((campo, "coluna_com_dois_valores", True,
                                   "linha %d da anomalia repete uma coluna ja "
                                   "preenchida" % nlinha))
                continue
            cont["casados"] += 1
            valores[n] = (valor, "anomalia")

    # --------------------------------------------- regra da causa e da classe
    governados_detalhe = []
    fechamento_regra = []
    classe = governados.get("kit.classe", "").strip()
    if not classe:
        pendencias.append(("kit.classe", "classe_nao_declarada", True,
                           "declare %s" % " ou ".join(CLASSES)))
    elif classe not in CLASSES:
        pendencias.append(("kit.classe", "classe_invalida", True,
                           "%r nao e %s" % (classe, " nem ".join(CLASSES))))
    governados_detalhe.append(("kit.classe", classe or "(vazio)",
                               "decide se o registro exige tratamento"))

    def candidatas_no_modelo(candidatas):
        """Colunas do modelo cujo nome casa com alguma candidata."""
        if not candidatas:
            return []
        return [c for i, c in enumerate(colunas, 1)
                if i not in indices_sem_nome
                and any(p in normalizar(c) for p in candidatas)]

    def destinar(campo_valor, campo_coluna, rotulo, texto_final,
                 candidatas=(), tipo="sem_coluna_no_modelo"):
        """Coloca um valor governado numa coluna do modelo. Nunca descarta.

        Nao havendo kit.coluna_* declarado, procura uma unica coluna do modelo
        cujo nome case. Uma so: duas viram pendencia. Todo destino inferido sai
        escrito no mapa e no terminal.
        """
        if not texto_final:
            return
        nome_col = governados.get(campo_coluna, "").strip()
        como = "declarado em %s" % campo_coluna
        if (not nome_col and rotulo == "contramedida"
                and args.contramedida_fora_da_linha):
            # Decisao declarada vence inferencia: o tratamento vive em outro
            # arquivo da casa e a contramedida nao entra nesta linha.
            fechamento_regra.append(
                "A contramedida fica fora da linha, por decisao declarada "
                "em --contramedida-fora-da-linha: %s" % texto_final)
            return
        if not nome_col:
            achadas = candidatas_no_modelo(candidatas)
            if len(achadas) == 1:
                nome_col = achadas[0]
                como = "inferido pelo nome da coluna"
            elif len(achadas) > 1:
                pendencias.append(
                    (campo_valor, tipo, True,
                     "mais de uma coluna do modelo pode receber a %s (%s). "
                     "Declare %s: o script nao escolhe entre duas"
                     % (rotulo, ", ".join(achadas), campo_coluna)))
                return
        if not nome_col:
            pendencias.append((campo_valor, tipo, True,
                               "nenhuma coluna do modelo parece a da %s. "
                               "Declare %s com o nome da coluna do registro "
                               "que recebe a %s" % (rotulo, campo_coluna,
                                                    rotulo)))
            return
        n = normalizar(nome_col)
        if n not in colunas_norm:
            pendencias.append((campo_coluna, "coluna_declarada_nao_existe", True,
                               "%r nao e coluna do modelo" % nome_col))
            return
        if n in valores:
            pendencias.append((nome_col, "coluna_com_dois_valores", True,
                               "a coluna recebe a %s e ja tinha valor vindo da "
                               "anomalia" % rotulo))
            return
        cont["governados_em_coluna"] += 1
        valores[n] = (texto_final, rotulo)
        destinos.append((rotulo, nome_col, como))

    causa = governados.get("kit.causa", "").strip()
    status_causa = normalizar(governados.get("kit.causa_status", ""))
    teste_confirmaria = governados.get("kit.teste_que_confirmaria", "").strip()
    teste_realizado = governados.get("kit.teste_realizado", "").strip()
    texto_causa = ""
    if causa:
        if status_causa == CONFIRMADA and teste_realizado:
            texto_causa = "%s | confirmada por: %s" % (causa, teste_realizado)
            fechamento_regra.append("Causa declarada como confirmada, com o "
                                    "teste registrado na propria celula.")
        else:
            if status_causa == CONFIRMADA and not teste_realizado:
                pendencias.append(("kit.teste_realizado", "confirmacao_sem_teste",
                                   True, "a causa foi declarada confirmada sem "
                                         "dizer qual teste a confirmou. Ela sai "
                                         "como hipotese ate o teste entrar"))
            if not teste_confirmaria:
                pendencias.append(("kit.teste_que_confirmaria", "hipotese_sem_teste",
                                   True, "causa sem teste e hipotese, e hipotese "
                                         "so entra no registro acompanhada do "
                                         "teste que a confirmaria"))
            texto_causa = "%s%s" % (args.prefixo_hipotese, causa)
            if teste_confirmaria:
                texto_causa += " | teste que confirmaria: %s" % teste_confirmaria
            fechamento_regra.append("Causa sem teste: entrou no registro marcada "
                                    "como hipotese, com o prefixo %r."
                                    % args.prefixo_hipotese)
        destinar("kit.causa", "kit.coluna_da_causa", "causa", texto_causa,
                 CANDIDATAS_CAUSA)
    governados_detalhe.append(("kit.causa", causa or "(vazio)",
                               "hipotese" if causa and not (
                                   status_causa == CONFIRMADA
                                   and teste_realizado) else
                               ("confirmada por teste" if causa else "sem causa")))

    contramedida = governados.get("kit.contramedida", "").strip()
    dono = governados.get("kit.dono", "").strip()
    prazo = governados.get("kit.prazo", "").strip()
    prazo_lido = ler_data(prazo)
    if classe == "exige_tratamento":
        if not contramedida:
            pendencias.append(("kit.contramedida", "tratamento_sem_contramedida",
                               True, "registro que exige tratamento nao fecha "
                                     "sem contramedida"))
        if not dono:
            pendencias.append(("kit.dono", "tratamento_sem_dono", True,
                               "contramedida sem dono nomeado nao fecha"))
        elif normalizar(dono) in DONOS_GENERICOS:
            pendencias.append(("kit.dono", "dono_generico", True,
                               "%r e setor, nao pessoa. Nomeie quem responde"
                               % dono))
        if not prazo:
            pendencias.append(("kit.prazo", "tratamento_sem_prazo", True,
                               "contramedida sem data nao fecha"))
        elif prazo_lido is None:
            pendencias.append(("kit.prazo", "prazo_nao_e_data", True,
                               "%r nao foi lido como data" % prazo))
        fechamento_regra.append(
            "Classe exige_tratamento: o registro so fecha com contramedida, "
            "dono nomeado e data.")
        destinar("kit.contramedida", "kit.coluna_da_contramedida",
                 "contramedida", contramedida, CANDIDATAS_CONTRAMEDIDA)
        destinar("kit.dono", "kit.coluna_do_dono", "dono", dono,
                 CANDIDATAS_DONO)
        destinar("kit.prazo", "kit.coluna_do_prazo", "prazo", prazo,
                 CANDIDATAS_PRAZO)
    elif classe == "somente_registro":
        fechamento_regra.append(
            "Classe somente_registro: o desvio foi tratado na hora e o que a "
            "empresa exige e o registro. Nenhuma contramedida e cobrada.")
        destinar("kit.contramedida", "kit.coluna_da_contramedida",
                 "contramedida", contramedida, CANDIDATAS_CONTRAMEDIDA)
        destinar("kit.dono", "kit.coluna_do_dono", "dono", dono,
                 CANDIDATAS_DONO)
        destinar("kit.prazo", "kit.coluna_do_prazo", "prazo", prazo,
                 CANDIDATAS_PRAZO)
    for campo in ("kit.contramedida", "kit.dono", "kit.prazo", "kit.local",
                  "kit.teste_que_confirmaria", "kit.teste_realizado",
                  "kit.descricao_do_desvio"):
        governados_detalhe.append((campo, governados.get(campo, "") or "(vazio)", ""))

    descricao_alvo = governados.get("kit.descricao_do_desvio", "").strip()
    if not descricao_alvo and not args.so_mapa:
        pendencias.append(("kit.descricao_do_desvio", "sem_descricao_para_varrer",
                           True, "sem ela a varredura do historico nao tem alvo "
                                 "e a resposta sobre reincidencia seria falsa"))

    # A descricao e o campo que esta skill existe para escrever. Ela alimentava
    # so a varredura, e a celula de descricao do registro podia sair vazia com
    # a rodada fechando. Agora ela tem destino no modelo, declarado ou inferido,
    # e sem destino a rodada nao fecha.
    if descricao_alvo:
        nome_desc = governados.get("kit.coluna_da_descricao", "").strip()
        como_desc = "declarado em kit.coluna_da_descricao"
        ambigua = False
        if not nome_desc:
            achadas = candidatas_no_modelo(CANDIDATAS_DESCRICAO)
            if len(achadas) == 1:
                nome_desc, como_desc = achadas[0], "inferido pelo nome da coluna"
            elif len(achadas) > 1:
                ambigua = True
                pendencias.append(
                    ("kit.coluna_da_descricao", "descricao_sem_coluna_no_modelo",
                     True, "mais de uma coluna do modelo pode receber a "
                           "descricao (%s). Declare kit.coluna_da_descricao: o "
                           "script nao escolhe entre duas" % ", ".join(achadas)))
        if nome_desc:
            n = normalizar(nome_desc)
            if n not in colunas_norm:
                pendencias.append(
                    ("kit.coluna_da_descricao", "coluna_declarada_nao_existe",
                     True, "%r nao e coluna do modelo" % nome_desc))
            elif n in valores:
                atual = valores[n][0]
                if normalizar(atual) == normalizar(descricao_alvo):
                    pendencias.append(
                        (nome_desc, "descricao_digitada_duas_vezes", False,
                         "a descricao veio na coluna e em "
                         "kit.descricao_do_desvio com o mesmo texto. Basta "
                         "kit.descricao_do_desvio: a coluna e preenchida a "
                         "partir dele"))
                else:
                    pendencias.append(
                        (nome_desc, "descricao_divergente", True,
                         "a coluna %r traz %r e kit.descricao_do_desvio traz "
                         "%r. A varredura de reincidencia usou o de "
                         "kit.descricao_do_desvio, entao o registro e a busca "
                         "contariam historias diferentes"
                         % (nome_desc, atual, descricao_alvo)))
            else:
                cont["governados_em_coluna"] += 1
                valores[n] = (descricao_alvo, "descricao")
                destinos.append(("descricao", nome_desc, como_desc))
        elif not ambigua:
            ja = [c for c in colunas
                  if normalizar(valores.get(normalizar(c), ("", ""))[0])
                  == normalizar(descricao_alvo)]
            if ja:
                pendencias.append(
                    (ja[0], "descricao_digitada_duas_vezes", False,
                     "a descricao ja esta na coluna %r, digitada direto. "
                     "Declarando kit.coluna_da_descricao voce digita uma vez "
                     "so" % ja[0]))
            else:
                pendencias.append(
                    ("kit.coluna_da_descricao", "descricao_sem_coluna_no_modelo",
                     True, "a descricao do desvio nao tem coluna de destino e "
                           "nao aparece em nenhuma celula da linha. A linha "
                           "sairia sem a descricao, que e o campo que este "
                           "registro existe para levar"))

    # kit.local tem destino quando existe coluna para ele. Nao tendo, ele serviu
    # a varredura e isso sai dito, sem bloquear: o local costuma ja estar
    # digitado na coluna de equipamento.
    local_kit = governados.get("kit.local", "").strip()
    if local_kit:
        nome_local = governados.get("kit.coluna_do_local", "").strip()
        como_local = "declarado em kit.coluna_do_local"
        if not nome_local:
            achadas = candidatas_no_modelo(CANDIDATAS_LOCAL)
            if len(achadas) == 1:
                nome_local, como_local = achadas[0], "inferido pelo nome da coluna"
        n = normalizar(nome_local) if nome_local else ""
        if n and n in colunas_norm and n not in valores:
            cont["governados_em_coluna"] += 1
            valores[n] = (local_kit, "local")
            destinos.append(("local", nome_local, como_local))
        elif n and n in valores and normalizar(valores[n][0]) != normalizar(local_kit):
            pendencias.append(
                (nome_local or "kit.local", "local_divergente", False,
                 "a coluna %r traz %r e kit.local traz %r. A varredura por "
                 "mesmo local usou o de kit.local"
                 % (nome_local, valores[n][0], local_kit)))
        elif not n:
            ja = [c for c in colunas
                  if normalizar(valores.get(normalizar(c), ("", ""))[0])
                  == normalizar(local_kit)]
            if not ja:
                pendencias.append(
                    ("kit.local", "local_sem_coluna_no_modelo", False,
                     "nenhuma coluna do modelo recebeu o local. Ele serviu a "
                     "varredura por mesmo local e nao entrou na linha. Havendo "
                     "coluna para ele, declare kit.coluna_do_local"))

    # ------------------------------------------------- colunas do modelo
    colunas_detalhe = []
    linha_saida = []
    for posicao, col in enumerate(colunas, 1):
        n = normalizar(col)
        if n in valores:
            valor, origem = valores[n]
            cont["preenchidas"] += 1
            estado = "preenchida"
        elif posicao in indices_sem_nome:
            valor, origem = "", "coluna sem nome no cabecalho"
            cont["sem_valor"] += 1
            estado = "sem nome, posicao mantida"
        elif n in em_branco:
            valor, origem = "", "decisao declarada em --em-branco"
            cont["em_branco_declaradas"] += 1
            estado = "em branco, declarada"
        else:
            valor, origem = "", "nada na anomalia"
            cont["sem_valor"] += 1
            bloqueia = n in obrigatorias
            estado = "PENDENTE, obrigatoria" if bloqueia else "vazia"
            pendencias.append((col, "coluna_sem_valor", bloqueia,
                               "obrigatoria declarada" if bloqueia
                               else "sem valor, e nao foi declarada em branco"))
        limpo, mudou = limpar_celula(valor)
        if mudou:
            cont["celulas_com_quebra"] += 1
        linha_saida.append(limpo)
        colunas_detalhe.append((col, origem, estado, limpo))

    # ------------------------------------------------------------ historico
    nao_varridos = []
    achados = []
    nota_historico = []
    if args.so_mapa:
        nota_historico.append("Rodada --so-mapa: o historico nao foi varrido.")
    elif args.sem_historico:
        nota_historico.append(
            "Declarado --sem-historico: nenhum registro anterior foi varrido, "
            "entao a rodada nao pode dizer que o desvio e novo.")
    else:
        try:
            arquivos = coletar_arquivos(args.historico, nao_varridos, cont,
                                        saida)
        except ValueError as exc:
            print("erro: %s" % exc, file=sys.stderr)
            return 3
        local_alvo = governados.get("kit.local", "").strip()
        if not local_alvo and args.coluna_local:
            local_alvo = valores.get(normalizar(args.coluna_local), ("", ""))[0]
        cfg = {
            "termos_alvo": termos(descricao_alvo),
            "local_alvo": local_alvo,
            "coluna_descricao": args.coluna_descricao,
            "coluna_data": args.coluna_data,
            "coluna_numero": args.coluna_numero,
            "coluna_local": args.coluna_local,
            "limiar": args.limiar,
            "minimo_termos": args.minimo_termos,
        }
        varrer_historico(arquivos, cfg, cont, nao_varridos, achados,
                         nota_historico)
        if cont["reincidencias"] >= args.limiar_cronico:
            nota_historico.append(
                "%d ocorrencias semelhantes no historico entregue. Acima do "
                "limiar de %d: candidato a problema cronico. Quem decide se e "
                "cronico e quem responde pelo processo, nao este script."
                % (cont["reincidencias"], args.limiar_cronico))
        elif cont["reincidencias"]:
            nota_historico.append(
                "%d %s no historico entregue. Leia o reincidencia.csv antes de "
                "tratar o caso como novo."
                % (cont["reincidencias"],
                   "ocorrencia semelhante" if cont["reincidencias"] == 1
                   else "ocorrencias semelhantes"))
        elif cont["registros_encontrados"] == 0:
            nota_historico.append(
                "Nenhum registro foi comparado: o historico entregue nao tem "
                "registro nenhum abaixo do cabecalho. A pergunta sobre "
                "reincidencia ficou sem resposta, e esta rodada nao pode dizer "
                "que o desvio e novo. Confira se o --historico aponta para os "
                "registros anteriores, e nao para o arquivo do modelo.")
        elif cont["varridos"] == 0:
            nota_historico.append(
                "Nenhum registro chegou a ser comparado: os %d registros "
                "encontrados ficaram todos fora da varredura. O motivo de cada "
                "um esta no historico-nao-varrido.csv."
                % cont["registros_encontrados"])
        else:
            nota_historico.append(
                "Nenhuma ocorrencia semelhante nos %d registros varridos. Isso "
                "vale para o que foi varrido, e o que ficou de fora esta no "
                "historico-nao-varrido.csv." % cont["varridos"])
        if (cont["nao_varridos"] or cont["arquivos_nao_lidos"]
                or cont["arquivos_sem_registro"]
                or cont["colunas_de_apoio_nao_encontradas"]):
            nota_historico.append(
                "%d registro, %d arquivo, %d arquivo sem registro e %d coluna "
                "de apoio ficaram fora da varredura ou sairam sem dado. "
                "Enquanto estiverem assim, a resposta sobre reincidencia esta "
                "incompleta."
                % (cont["nao_varridos"], cont["arquivos_nao_lidos"],
                   cont["arquivos_sem_registro"],
                   cont["colunas_de_apoio_nao_encontradas"]))

    # ---------------------------------------------------- abrir o diretorio
    saida.mkdir(parents=True, exist_ok=True)
    fonte = os.path.basename(str(args.modelo))
    dados_mapa = {
        "modelo": info_modelo,
        "colunas": colunas,
        "colunas_detalhe": colunas_detalhe,
        "governados_detalhe": governados_detalhe,
        "destinos": destinos,
        "fechamento_regra": fechamento_regra or ["Nada a declarar."],
        "cont": cont,
        "nota_historico": nota_historico,
        "identidades": [],
        "pendencias": pendencias,
        "sem_valores": args.sem_valores_no_mapa,
    }
    caminho_mapa = saida / "mapa-de-campos.md"
    escrever_mapa(caminho_mapa, dados_mapa, "incompleto")

    # ------------------------------------------- a linha, e o encoding dela
    # A checagem de encoding vem antes das identidades porque ela pode
    # acrescentar pendencia, e a contagem de pendencias e uma das identidades.
    # Montada depois, ela imprimia um numero defasado do arquivo gravado.
    conteudo = ""
    enc_saida = enc_modelo
    if not args.so_mapa and not args.modelo_em_linhas:
        delim = delim_modelo or ";"
        buffer = io.StringIO()
        escritor = csv.writer(buffer, delimiter=delim, lineterminator="\r\n")
        escritor.writerow(nomes_cabecalho)
        escritor.writerow(linha_saida)
        conteudo = buffer.getvalue()
        try:
            conteudo.encode(enc_modelo)
        except UnicodeEncodeError:
            fora = sorted({c for c in conteudo
                           if not c.encode(enc_modelo, "ignore")})
            enc_saida = "utf-8-sig"
            pendencias.append(
                ("linha emitida", "caractere_fora_do_encoding_do_modelo",
                 False, "o modelo foi lido em %s e o texto tem %s. O arquivo "
                        "saiu em utf-8 com BOM em vez de trocar o caractere em "
                        "silencio" % (enc_modelo,
                                      " ".join(repr(c) for c in fora))))

    # -------------------------------------------------------------- gabarito
    caminho_conferencia = None
    nota_gabarito = []
    if args.gabarito and args.so_mapa:
        # Opcao declarada e ignorada em silencio e a mesma doenca do resto.
        pendencias.append(
            ("--gabarito", "gabarito_nao_comparado", False,
             "a rodada --so-mapa nao emite linha, entao nao ha o que comparar "
             "com o gabarito. Rode sem --so-mapa para conferir o gabarito"))
    if args.gabarito and not args.so_mapa:
        vereditos, erro_gab = comparar_gabarito(
            args.gabarito, colunas, nomes_cabecalho, linha_saida)
        if erro_gab:
            pendencias.append(("--gabarito", "gabarito_nao_lido", True, erro_gab))
        else:
            caminho_conferencia = saida / "conferencia-do-gabarito.md"
            n_div, div_obrig = escrever_conferencia(
                caminho_conferencia, vereditos, obrigatorias, fonte,
                args.gabarito)
            for col, do_gab, valor, _v in div_obrig:
                pendencias.append(
                    (col, "gabarito_divergente_em_coluna_obrigatoria", True,
                     "a empresa escreveu %r e esta rodada escreveu %r. "
                     "Enquanto a diferenca nao estiver explicada por escrito no "
                     "conferencia-do-gabarito.md, a skill nao roda em caso novo"
                     % (do_gab, valor)))
            veredito = "nao libera" if div_obrig else "libera"
            ok_livro, detalhe = registrar_no_livro(
                args.livro_de_gabaritos,
                [datetime.now().strftime("%d/%m/%Y %H:%M"), fonte,
                 os.path.basename(str(args.gabarito)), len(vereditos), n_div,
                 "; ".join(v[0] for v in div_obrig), veredito])
            nota_gabarito.append(
                "Gabarito: %d colunas conferidas, %d divergentes, %d em coluna "
                "obrigatoria. Veredito: %s."
                % (len(vereditos), n_div, len(div_obrig), veredito))
            if ok_livro:
                nota_gabarito.append(
                    "Liberacao registrada em %s, e esse registro sobrevive ao "
                    "fim da conversa." % detalhe)
            else:
                pendencias.append(
                    ("--livro-de-gabaritos", "livro_de_gabaritos_nao_gravado",
                     False, "a conferencia foi gravada no diretorio da rodada, "
                            "e o registro que atravessa conversas nao: %s"
                            % detalhe))

    # ------------------------------------------------- gravar e contar linhas
    gravados = {}
    gravados["campos-pendentes.csv"] = escrever_csv(
        saida / "campos-pendentes.csv",
        ["campo", "tipo", "bloqueia", "detalhe"],
        [[c, t, "sim" if b else "nao", d] for c, t, b, d in pendencias])
    if not args.so_mapa:
        gravados["historico-nao-varrido.csv"] = escrever_csv(
            saida / "historico-nao-varrido.csv",
            ["arquivo", "linha", "tipo", "causa", "conteudo_da_linha"],
            nao_varridos)
        gravados["reincidencia.csv"] = escrever_csv(
            saida / "reincidencia.csv",
            ["arquivo", "linha", "numero_do_registro", "data", "data_lida",
             "motivo", "escore", "termos_em_comum", "local",
             "descricao_do_historico", "alerta"],
            [[a["arquivo"], a["linha"], a["numero"], a["data"], a["data_lida"],
              a["motivo"], a["escore"], a["termos"], a["local"],
              a["descricao"], a["alerta"]] for a in achados])

    # --------------------------------------------------------- identidades
    # Montadas depois da ultima pendencia e conferidas contra as linhas
    # efetivamente gravadas em cada arquivo. Nenhuma tem o resultado escrito
    # na mao, e nenhuma compara uma variavel com ela mesma.
    ident = [
        ("campos_do_cabecalho_bruto %d = com_nome %d + sem_nome %d"
         % (cont["campos_do_cabecalho_bruto"], cont["colunas_nomeadas"],
            cont["colunas_sem_nome"]),
         cont["campos_do_cabecalho_bruto"] == cont["colunas_nomeadas"]
         + cont["colunas_sem_nome"]),
        ("colunas_do_modelo %d = preenchidas %d + sem_valor %d + em_branco %d"
         % (cont["colunas_do_modelo"], cont["preenchidas"], cont["sem_valor"],
            cont["em_branco_declaradas"]),
         cont["colunas_do_modelo"] == cont["preenchidas"] + cont["sem_valor"]
         + cont["em_branco_declaradas"]),
        ("campos_da_anomalia %d = casados %d + governados %d + sem_lugar %d"
         % (cont["campos_da_anomalia"], cont["casados"], cont["governados"],
            cont["sem_lugar_no_modelo"]),
         cont["campos_da_anomalia"] == cont["casados"] + cont["governados"]
         + cont["sem_lugar_no_modelo"]),
        ("preenchidas %d = casados %d + governados_em_coluna %d"
         % (cont["preenchidas"], cont["casados"], cont["governados_em_coluna"]),
         cont["preenchidas"] == cont["casados"] + cont["governados_em_coluna"]),
        ("registros_encontrados %d = varridos %d + nao_varridos %d"
         % (cont["registros_encontrados"], cont["varridos"], cont["nao_varridos"]),
         cont["registros_encontrados"] == cont["varridos"] + cont["nao_varridos"]),
        ("varridos %d = sem_semelhanca %d + reincidencias %d"
         % (cont["varridos"], cont["sem_semelhanca"], cont["reincidencias"]),
         cont["varridos"] == cont["sem_semelhanca"] + cont["reincidencias"]),
        ("arquivos_encontrados %d = lidos %d + nao_lidos %d"
         % (cont["arquivos_encontrados"], cont["arquivos_lidos"],
            cont["arquivos_nao_lidos"]),
         cont["arquivos_encontrados"] == cont["arquivos_lidos"]
         + cont["arquivos_nao_lidos"]),
        ("registros gravados em campos-pendentes.csv %d = pendencias %d"
         % (gravados["campos-pendentes.csv"], len(pendencias)),
         gravados["campos-pendentes.csv"] == len(pendencias)),
    ]
    if not args.so_mapa:
        ident.append(
            ("registros gravados em reincidencia.csv %d = reincidencias %d"
             % (gravados["reincidencia.csv"], cont["reincidencias"]),
             gravados["reincidencia.csv"] == cont["reincidencias"]))
        ident.append(
            ("registros gravados em historico-nao-varrido.csv %d = "
             "nao_varridos %d + arquivos_nao_lidos %d + sem_registro %d + "
             "colunas_de_apoio %d"
             % (gravados["historico-nao-varrido.csv"], cont["nao_varridos"],
                cont["arquivos_nao_lidos"], cont["arquivos_sem_registro"],
                cont["colunas_de_apoio_nao_encontradas"]),
             gravados["historico-nao-varrido.csv"] == cont["nao_varridos"]
             + cont["arquivos_nao_lidos"] + cont["arquivos_sem_registro"]
             + cont["colunas_de_apoio_nao_encontradas"]))
    dados_mapa["identidades"] = ident
    dados_mapa["pendencias"] = pendencias

    bloqueantes = [p for p in pendencias if p[2]]
    identidades_ok = all(ok for _t, ok in ident)
    fechado = not bloqueantes and identidades_ok
    base = "linha-para-colar" if fechado else "rascunho-nao-fechado"

    if args.so_mapa:
        escrever_procedencia(
            saida / "procedencia.txt", fonte,
            ["mapa-de-campos.md", "campos-pendentes.csv", "procedencia.txt"],
            ["Rodada --so-mapa: nenhum registro foi emitido e o historico nao "
             "foi varrido."])
        escrever_mapa(caminho_mapa, dados_mapa, "so-mapa, sem registro emitido")
        print("mapa escrito em %s" % caminho_mapa)
        print("rodada --so-mapa: nenhum registro foi emitido.")
        print("")
        print("FECHAMENTO")
        for texto, ok in ident:
            print("  %-78s %s" % (texto, "fecha" if ok else "NAO FECHA"))
        if not identidades_ok:
            print("erro: alguma identidade de fechamento nao fecha.",
                  file=sys.stderr)
            return 3
        return 4

    if args.modelo_em_linhas:
        linhas_md = ["# Registro preenchido", ""]
        if not fechado:
            linhas_md.append("**Rascunho, nao fechado.** Ver campos-pendentes.csv.")
            linhas_md.append("")
        for col, valor in zip(colunas, linha_saida):
            linhas_md.append("**%s:** %s" % (col, valor))
        linhas_md.append("")
        linhas_md.append(RODAPE.format(fonte=fonte))
        linhas_md.append("")
        destino_linha = saida / ("%s.md" % base)
        destino_linha.write_text("\n".join(linhas_md), encoding="utf-8")
        destinos_arquivos = [destino_linha]
    else:
        destino_linha = saida / ("%s.csv" % base)
        with open(destino_linha, "w", encoding=enc_saida, newline="") as fh:
            fh.write(conteudo)
        destino_txt = saida / ("%s.txt" % base)
        destino_txt.write_text("\t".join(linha_saida) + "\n", encoding="utf-8")
        destinos_arquivos = [destino_linha, destino_txt]

    lista_arquivos = ["mapa-de-campos.md"]
    lista_arquivos += [d.name for d in destinos_arquivos]
    lista_arquivos += ["campos-pendentes.csv", "reincidencia.csv",
                       "historico-nao-varrido.csv", "procedencia.txt"]
    if caminho_conferencia is not None:
        lista_arquivos.append(caminho_conferencia.name)
    escrever_procedencia(saida / "procedencia.txt", fonte, lista_arquivos,
                         nota_gabarito)

    # o mapa e reescrito por ultimo, com o fechamento
    if not identidades_ok:
        status = "invalido, nao fecha"
    elif bloqueantes:
        status = "rascunho, nao fechado"
    else:
        status = "completo"
    escrever_mapa(caminho_mapa, dados_mapa, status)
    escrever_csv(saida / "campos-pendentes.csv",
                 ["campo", "tipo", "bloqueia", "detalhe"],
                 [[c, t, "sim" if b else "nao", d] for c, t, b, d in pendencias])

    print("mapa de campos: %s" % caminho_mapa)
    for d in destinos_arquivos:
        print("registro: %s" % d)
    if caminho_conferencia is not None:
        print("gabarito: %s" % caminho_conferencia)
    print("")
    print("FECHAMENTO")
    for texto, ok in ident:
        print("  %-78s %s" % (texto, "fecha" if ok else "NAO FECHA"))
    print("")
    print("VERIFICACOES")
    print("  colunas preenchidas ................ %d de %d"
          % (cont["preenchidas"], cont["colunas_do_modelo"]))
    print("  colunas sem nome no cabecalho ...... %d" % cont["colunas_sem_nome"])
    print("  pendencias bloqueantes ............. %d" % len(bloqueantes))
    print("  avisos nao bloqueantes ............. %d"
          % (len(pendencias) - len(bloqueantes)))
    print("  celulas com quebra de linha trocada  %d" % cont["celulas_com_quebra"])
    print("  registros do historico varridos .... %d de %d"
          % (cont["varridos"], cont["registros_encontrados"]))
    print("  registros fora da varredura ........ %d" % cont["nao_varridos"])
    print("  arquivos fora da varredura ......... %d" % cont["arquivos_nao_lidos"])
    print("  arquivos sem nenhum registro ....... %d"
          % cont["arquivos_sem_registro"])
    print("  colunas de apoio nao encontradas ... %d"
          % cont["colunas_de_apoio_nao_encontradas"])
    print("  reincidencias ...................... %d" % cont["reincidencias"])
    for rotulo, coluna, como in destinos:
        if como.startswith("inferido"):
            print("  destino inferido: %s -> coluna %r" % (rotulo, coluna))
    for linha in nota_gabarito:
        print("  %s" % linha)
    for linha in nota_historico:
        print("  %s" % linha)

    if not identidades_ok:
        print("erro: alguma identidade de fechamento nao fecha. A saida nao vale.",
              file=sys.stderr)
        return 3
    if bloqueantes:
        print("registro nao fechado: %d pendencia bloqueante." % len(bloqueantes),
              file=sys.stderr)
        return 2

    # Varredura incompleta e um eixo proprio: ela nao desaparece porque houve
    # reincidencia. Antes o codigo 1 saia na frente e engolia o 5.
    incompleta = bool(
        cont["nao_varridos"] or cont["arquivos_nao_lidos"]
        or args.sem_historico or cont["datas_nao_lidas"]
        or cont["arquivos_sem_registro"]
        or cont["colunas_de_apoio_nao_encontradas"]
        or cont["registros_encontrados"] == 0)
    if cont["reincidencias"]:
        return 6 if incompleta else 1
    return 5 if incompleta else 0


if __name__ == "__main__":
    sys.exit(main())
