#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do registrar.py.

Biblioteca padrao apenas. Monta cada caso num diretorio temporario, roda o
registrar.py nele e compara o codigo de saida e trechos dos arquivos gerados
com o esperado.

Cada caso foi escrito a partir de uma pergunta, nao de uma funcionalidade:
existe caminho em que esta rodada sai com sucesso tendo perdido, ignorado ou nao
processado dado? Os casos de 1 a 12 e de 43 a 59 sao as respostas a essa
pergunta. Os de 43 em diante vieram de rodadas reais que fecharam com status
completo e entregaram coisa errada.

Nenhum caso escreve fora do diretorio temporario: o livro de gabaritos de cada
rodada de teste vai para dentro dele.

Rode depois de qualquer mudanca no registrar.py:

    python3 ~/.claude/skills/registro-de-anomalia/scripts/testar.py

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\registro-de-anomalia\\scripts\\testar.py"

Sai com 1 se algum caso falhar.
"""

import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
REGISTRAR = AQUI / "registrar.py"
SKILL = AQUI.parent / "SKILL.md"
REFERENCIA = AQUI.parent / "references" / "classes-de-registro.md"

MODELO = ("No;Data;Setor;Equipamento;Descricao da ocorrencia;Causa raiz;"
          "Acao imediata;Acao corretiva;Responsavel;Prazo;Status")

ANOMALIA = [
    ("No", "NC-2026-041"),
    ("Data", "20/09/2026"),
    ("Setor", "Usinagem"),
    ("Equipamento", "Torno 07"),
    ("kit.classe", "exige_tratamento"),
    ("kit.descricao_do_desvio", "Rebarba na face usinada do eixo no torno 07"),
    ("kit.local", "Torno 07"),
    ("kit.causa", "Inserto de acabamento gasto"),
    ("kit.causa_status", "hipotese"),
    ("kit.teste_que_confirmaria",
     "Trocar o inserto e medir a rebarba em dez pecas seguidas"),
    ("kit.contramedida", "Incluir a troca do inserto no plano de setup"),
    ("kit.dono", "Tiago Moraes"),
    ("kit.prazo", "30/09/2026"),
    ("kit.coluna_da_descricao", "Descricao da ocorrencia"),
    ("kit.coluna_da_causa", "Causa raiz"),
    ("kit.coluna_da_contramedida", "Acao corretiva"),
    ("kit.coluna_do_dono", "Responsavel"),
    ("kit.coluna_do_prazo", "Prazo"),
]

# A descricao e digitada uma vez so, em kit.descricao_do_desvio: ela alimenta a
# varredura de reincidencia e entra na coluna do registro pelo
# kit.coluna_da_descricao. Digitar tambem direto na coluna e o caso de
# descricao_digitada_duas_vezes, e texto diferente nos dois lugares bloqueia.

HIST_CAB = "No;Data;Setor;Equipamento;Descricao da ocorrencia;Status"
HIST_SEM_PARECIDO = "\n".join([
    HIST_CAB,
    "NC-2026-012;03/03/2026;Montagem;Prensa 3;Vazamento de oleo na prensa;Fechado",
    "NC-2026-018;14/04/2026;Solda;Robo 2;Porosidade no cordao de solda;Fechado",
])
HIST_COM_PARECIDO = "\n".join([
    HIST_CAB,
    "NC-2026-012;03/03/2026;Montagem;Prensa 3;Vazamento de oleo na prensa;Fechado",
    "NC-2026-020;09/05/2026;Usinagem;Torno 07;Rebarba na face do eixo usinado no "
    "torno 07;Fechado",
])

falhas = []


def registrar_resultado(nome, erros):
    if erros:
        falhas.append((nome, erros))
        print("FALHOU  %s" % nome)
        for e in erros:
            print("        %s" % e)
    else:
        print("ok      %s" % nome)


def texto_anomalia(extra=None, remover=(), trocar=None):
    itens = [(k, v) for k, v in ANOMALIA if k not in remover]
    if trocar:
        itens = [(k, trocar.get(k, v)) for k, v in itens]
    if extra:
        itens = itens + list(extra)
    return "\n".join("%s;%s" % (k, v) for k, v in itens)


def rodar(nome, esperado, checagens, modelo=MODELO, anomalia=None,
          historico=HIST_SEM_PARECIDO, extra=None, enc_modelo="utf-8",
          pasta_historico=None, sem_anomalia=False, pre_criar_saida=False,
          gabarito=None, saida_dentro_do_historico=False):
    """checagens: lista de (arquivo, texto, deve_aparecer).

    arquivo aceita 'stdout', 'stderr', 'existe:<nome>', 'nao-existe:<nome>',
    'fora:<nome>' para um arquivo ao lado da saida, ou o nome de um arquivo
    dentro do diretorio de saida.

    O livro de gabaritos vai sempre para o diretorio temporario: nenhum caso
    escreve na pasta do usuario."""
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        arq_modelo = base / "registro-nc.csv"
        arq_modelo.write_bytes(modelo.encode(enc_modelo))
        if pre_criar_saida:
            (base / "saida").mkdir()
        dir_saida = (base / "historico" / "saida" if saida_dentro_do_historico
                     else base / "saida")
        cmd = [sys.executable, str(REGISTRAR), "--modelo", str(arq_modelo),
               "--saida", str(dir_saida)]
        if not sem_anomalia:
            arq_anom = base / "anomalia.csv"
            arq_anom.write_text(anomalia if anomalia is not None
                                else texto_anomalia(), encoding="utf-8")
            cmd += ["--anomalia", str(arq_anom)]
        if pasta_historico is not None:
            pasta = base / "historico"
            for rel, conteudo in pasta_historico.items():
                alvo = pasta / rel
                alvo.parent.mkdir(parents=True, exist_ok=True)
                alvo.write_text(conteudo, encoding="utf-8")
            cmd += ["--historico", str(pasta)]
        elif historico is not None:
            arq_hist = base / "historico.csv"
            arq_hist.write_text(historico, encoding="utf-8")
            cmd += ["--historico", str(arq_hist)]
        if gabarito is not None:
            arq_gab = base / "gabarito.csv"
            arq_gab.write_text(gabarito, encoding="utf-8")
            cmd += ["--gabarito", str(arq_gab),
                    "--livro-de-gabaritos", str(base / "livro.csv")]
        if extra:
            cmd += extra
        proc = subprocess.run(cmd, capture_output=True, text=True)
        erros = []
        if proc.returncode != esperado:
            erros.append("codigo de saida %d, esperado %d. stderr: %s"
                         % (proc.returncode, esperado, proc.stderr.strip()[:400]))
        for arquivo, texto, deve in checagens:
            if arquivo == "stdout":
                conteudo = proc.stdout
            elif arquivo == "stderr":
                conteudo = proc.stderr
            elif arquivo.startswith("existe:"):
                alvo = dir_saida / arquivo.split(":", 1)[1]
                if not alvo.exists():
                    erros.append("faltou o arquivo %s" % arquivo.split(":", 1)[1])
                continue
            elif arquivo.startswith("nao-existe:"):
                alvo = dir_saida / arquivo.split(":", 1)[1]
                if alvo.exists():
                    erros.append("o arquivo %s nao deveria existir"
                                 % arquivo.split(":", 1)[1])
                continue
            elif arquivo.startswith("fora:"):
                alvo = base / arquivo.split(":", 1)[1]
                if not alvo.exists():
                    erros.append("faltou o arquivo %s fora da saida"
                                 % arquivo.split(":", 1)[1])
                    continue
                conteudo = alvo.read_bytes().decode("utf-8", "replace")
                achou = texto in conteudo
                if achou != deve:
                    erros.append("%s: %r %s"
                                 % (arquivo, texto, "nao apareceu" if deve
                                    else "apareceu e nao devia"))
                continue
            else:
                alvo = dir_saida / arquivo
                if not alvo.exists():
                    erros.append("faltou o arquivo %s" % arquivo)
                    continue
                conteudo = alvo.read_bytes().decode("utf-8", "replace")
            achou = texto in conteudo
            if achou != deve:
                erros.append("%s: %r %s"
                             % (arquivo, texto,
                                "nao apareceu" if deve else "apareceu e nao devia"))
        registrar_resultado(nome, erros)
        return proc


# ---------------------------------------------------------------------------
# 1 a 12: a pergunta e "existe caminho em que isso sai com sucesso tendo
# perdido dado?". Cada caso e uma resposta.
# ---------------------------------------------------------------------------

# 1. Historico sem a coluna de descricao. A varredura nao teria o que comparar,
#    e dizer "nenhuma reincidencia" ali seria falso.
rodar("1 historico sem coluna de descricao nao sai com 0",
      5,
      [("historico-nao-varrido.csv", "sem_coluna_de_descricao", True),
       ("mapa-de-campos.md", "| Registros varridos | 0 |", True),
       ("mapa-de-campos.md", "NAO FECHA", False),
       ("mapa-de-campos.md", "| Registros nao varridos | 2 |", True)],
      historico="\n".join([
          "No;Data;Setor;Situacao",
          "NC-2026-012;03/03/2026;Montagem;Fechado",
          "NC-2026-018;14/04/2026;Solda;Fechado"]))

# 2. Nenhum historico entregue. Sem declaracao explicita a rodada para.
rodar("2 sem historico e sem declaracao para com 3",
      3,
      [("stderr", "declare --sem-historico", True)],
      historico=None)

# 3. Historico declarado inexistente. A rodada anda, mas nunca sai com 0.
rodar("3 --sem-historico nunca sai com 0",
      5,
      [("mapa-de-campos.md", "nao pode dizer que o desvio e novo", True)],
      historico=None, extra=["--sem-historico"])

# 4. Registro em subpasta. Tem que ser varrido, nao pode sumir com as
#    identidades todas fechando.
rodar("4 reincidencia em subpasta e encontrada",
      1,
      [("reincidencia.csv", "antigos", True),
       ("reincidencia.csv", "NC-2026-020", True),
       ("stdout", "NAO FECHA", False)],
      pasta_historico={"2026.csv": HIST_SEM_PARECIDO,
                       "antigos/2025.csv": HIST_COM_PARECIDO},
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-numero", "No"])

# 5. Arquivo que o script nao le dentro da pasta do historico. Conta como fora
#    da varredura, nao como inexistente.
rodar("5 arquivo nao lido na pasta conta como fora da varredura",
      5,
      [("historico-nao-varrido.csv", "arquivo_nao_lido", True),
       ("historico-nao-varrido.csv", "planilha.xlsx", True),
       ("mapa-de-campos.md", "| Arquivos nao lidos | 1 |", True),
       ("mapa-de-campos.md", "| Arquivos lidos | 1 |", True)],
      pasta_historico={"2026.csv": HIST_SEM_PARECIDO,
                       "planilha.xlsx": "binario de mentira"},
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 6. Registro cujo codigo tem a palavra que costuma marcar total, e registro
#    cuja descricao comeca com "Total de". Nenhum dos dois pode ser descartado
#    como linha de total: sao registros.
rodar("6 registro com GERAL no codigo e descricao de total sao varridos",
      1,
      [("reincidencia.csv", "GERAL-2026-014", True),
       ("mapa-de-campos.md", "| Registros varridos | 3 |", True),
       ("mapa-de-campos.md", "| Registros nao varridos | 0 |", True)],
      historico="\n".join([
          HIST_CAB,
          "GERAL-2026-014;10/02/2026;Usinagem;Torno 07;Rebarba na face do eixo "
          "usinado no torno 07;Fechado",
          "NC-2026-015;11/02/2026;Usinagem;Torno 05;Total de refugo do turno "
          "acima do limite;Fechado",
          "NC-2026-018;14/04/2026;Solda;Robo 2;Porosidade no cordao;Fechado"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-numero", "No"])

# 7. Campo da anomalia que nao tem coluna no registro da empresa. O valor nao
#    pode ser jogado fora em silencio.
rodar("7 campo sem coluna no modelo vira pendencia bloqueante",
      2,
      [("campos-pendentes.csv", "campo_sem_coluna_no_modelo", True),
       ("campos-pendentes.csv", "Turno", True),
       ("nao-existe:linha-para-colar.csv", "", True),
       ("existe:rascunho-nao-fechado.csv", "", True)],
      anomalia=texto_anomalia(extra=[("Turno", "B")]))

# 8. Nome de campo governado escrito errado. Nao pode ser ignorado.
rodar("8 campo kit desconhecido vira pendencia",
      2,
      [("campos-pendentes.csv", "campo_kit_desconhecido", True),
       ("campos-pendentes.csv", "kit.contra_medida", True)],
      anomalia=texto_anomalia(extra=[("kit.contra_medida", "trocar inserto")]))

# 9. Duas entradas para a mesma coluna. A segunda nao pode sobrescrever a
#    primeira sem aviso.
rodar("9 coluna com dois valores nao sobrescreve em silencio",
      2,
      [("campos-pendentes.csv", "coluna_com_dois_valores", True)],
      anomalia=texto_anomalia(extra=[("Setor", "Montagem")]))

# 10. Caractere que nao cabe no encoding do modelo. Trocar por "?" seria perder
#     dado em silencio.
rodar("10 caractere fora do encoding do modelo nao e trocado em silencio",
      1,
      [("campos-pendentes.csv", "caractere_fora_do_encoding_do_modelo", True),
       ("mapa-de-campos.md", "em vez de trocar o caractere em silencio", True)],
      modelo="No;Data;Setor;Equipamento;Descricao da ocorrencia;Causa raiz;"
             "Acao imediata;Acao corretiva;Responsavel;Prazo;Situa\u00e7\u00e3o",
      anomalia=texto_anomalia(trocar={
          "kit.descricao_do_desvio":
              "Rebarba na face usinada do eixo no torno 07, diametro ≠ "
              "especificado"}),
      historico=HIST_COM_PARECIDO,
      enc_modelo="cp1252",
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 11. Quebra de linha dentro da celula. A troca por espaco e real e precisa
#     aparecer contada.
rodar("11 quebra de linha na celula sai contada",
      1,
      [("stdout", "celulas com quebra de linha trocada  1", True)],
      anomalia=texto_anomalia(trocar={
          "kit.contramedida": "Incluir a troca do inserto no plano de setup"}) +
      "\nAcao imediata;\"Peca segregada\nna bancada\"",
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 12. Linha vazia, linha com contagem de coluna diferente e data ilegivel. Nada
#     disso pode sumir do fechamento.
rodar("12 linha vazia, coluna faltando e data ilegivel entram no fechamento",
      5,
      [("historico-nao-varrido.csv", "linha_vazia", True),
       ("historico-nao-varrido.csv", "contagem_de_colunas_diferente", True),
       ("mapa-de-campos.md", "| Registros encontrados | 4 |", True),
       ("mapa-de-campos.md", "| Registros nao varridos | 2 |", True),
       ("mapa-de-campos.md", "| Datas nao lidas em registro varrido | 1 |", True),
       ("mapa-de-campos.md", "NAO FECHA", False)],
      historico="\n".join([
          HIST_CAB,
          "NC-2026-012;03/03/2026;Montagem;Prensa 3;Vazamento de oleo;Fechado",
          ";;;;;",
          "NC-2026-013;semdata;Solda;Robo 2;Porosidade no cordao;Fechado",
          "NC-2026-014;05/05/2026;Solda;Robo 2"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-data", "Data"])


# ---------------------------------------------------------------------------
# 13 em diante: as leis de ferro da skill.
# ---------------------------------------------------------------------------

rodar("13 tratamento sem dono nao fecha",
      2,
      [("campos-pendentes.csv", "tratamento_sem_dono", True),
       ("nao-existe:linha-para-colar.csv", "", True),
       ("mapa-de-campos.md", "status: rascunho, nao fechado", True)],
      anomalia=texto_anomalia(remover=("kit.dono",)))

rodar("14 dono generico nao fecha",
      2,
      [("campos-pendentes.csv", "dono_generico", True)],
      anomalia=texto_anomalia(trocar={"kit.dono": "Manutencao"}))

rodar("15 tratamento sem prazo nao fecha",
      2,
      [("campos-pendentes.csv", "tratamento_sem_prazo", True)],
      anomalia=texto_anomalia(remover=("kit.prazo",)))

rodar("16 prazo que nao e data nao fecha",
      2,
      [("campos-pendentes.csv", "prazo_nao_e_data", True)],
      anomalia=texto_anomalia(trocar={"kit.prazo": "proxima semana"}))

rodar("17 hipotese sai marcada como hipotese, com o teste junto",
      1,
      [("nao-existe:rascunho-nao-fechado.csv", "", True),
       ("linha-para-colar.csv", "HIPOTESE NAO TESTADA", True),
       ("linha-para-colar.csv", "teste que confirmaria", True),
       ("mapa-de-campos.md", "entrou no registro marcada", True)],
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

rodar("18 hipotese sem teste nao fecha",
      2,
      [("campos-pendentes.csv", "hipotese_sem_teste", True)],
      anomalia=texto_anomalia(remover=("kit.teste_que_confirmaria",)))

rodar("19 causa declarada confirmada sem teste cai para hipotese e nao fecha",
      2,
      [("campos-pendentes.csv", "confirmacao_sem_teste", True),
       ("rascunho-nao-fechado.csv", "HIPOTESE NAO TESTADA", True)],
      anomalia=texto_anomalia(trocar={"kit.causa_status": "confirmada_por_teste"}))

rodar("20 causa confirmada com teste sai sem prefixo de hipotese",
      1,
      [("linha-para-colar.csv", "HIPOTESE NAO TESTADA", False),
       ("linha-para-colar.csv", "confirmada por:", True)],
      anomalia=texto_anomalia(
          trocar={"kit.causa_status": "confirmada_por_teste"},
          extra=[("kit.teste_realizado",
                  "Inserto trocado e rebarba medida em dez pecas, sumiu")]),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

rodar("21 causa sem coluna declarada e com duas candidatas nao e descartada",
      2,
      [("campos-pendentes.csv", "sem_coluna_no_modelo", True),
       ("campos-pendentes.csv", "o script nao escolhe entre duas", True)],
      modelo=MODELO + ";Causa provavel",
      anomalia=texto_anomalia(remover=("kit.coluna_da_causa",)))

rodar("22 classe nao declarada nao fecha",
      2,
      [("campos-pendentes.csv", "classe_nao_declarada", True)],
      anomalia=texto_anomalia(remover=("kit.classe",)))

rodar("23 somente_registro fecha sem contramedida",
      0,
      [("existe:linha-para-colar.csv", "", True),
       ("mapa-de-campos.md", "status: completo", True),
       ("mapa-de-campos.md", "Nenhuma contramedida e cobrada", True)],
      anomalia=texto_anomalia(
          trocar={"kit.classe": "somente_registro"},
          remover=("kit.contramedida", "kit.dono", "kit.prazo",
                   "kit.coluna_da_contramedida", "kit.coluna_do_dono",
                   "kit.coluna_do_prazo")),
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

rodar("24 contramedida fora da linha e decisao declarada, nao descarte",
      1,
      [("mapa-de-campos.md", "fica fora da linha, por decisao declarada", True),
       ("existe:linha-para-colar.csv", "", True)],
      anomalia=texto_anomalia(remover=("kit.coluna_da_contramedida",)),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--contramedida-fora-da-linha"])

rodar("25 coluna obrigatoria sem valor nao fecha",
      2,
      [("campos-pendentes.csv", "coluna_sem_valor", True),
       ("campos-pendentes.csv", "sim", True)],
      extra=["--obrigatorias", "No,Data,Status"])

rodar("26 coluna em branco declarada nao vira pendencia",
      1,
      [("mapa-de-campos.md", "em branco, declarada", True)],
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--em-branco", "Acao imediata,Status"])


# ---------------------------------------------------------------------------
# 27 em diante: leitura do modelo, que e o passo que define o formato.
# ---------------------------------------------------------------------------

rodar("27 titulo acima do cabecalho nao e lido como cabecalho",
      3,
      [("stderr", "--linha-do-cabecalho", True)],
      modelo="REGISTRO DE NAO CONFORMIDADE\n\n" + MODELO)

rodar("28 com --linha-do-cabecalho o titulo deixa de atrapalhar",
      1,
      [("linha-para-colar.csv", "Causa raiz", True)],
      modelo="REGISTRO DE NAO CONFORMIDADE\n\n" + MODELO,
      historico=HIST_COM_PARECIDO,
      extra=["--linha-do-cabecalho", "3",
             "--coluna-descricao", "Descricao da ocorrencia"])

rodar("29 coluna repetida no modelo para a rodada",
      3,
      [("stderr", "coluna repetida", True)],
      modelo=MODELO + ";Status")

rodar("30 modelo com um campo por linha sai como formulario preenchido",
      1,
      [("existe:linha-para-colar.md", "", True),
       ("linha-para-colar.md", "**Setor:** Usinagem", True)],
      modelo="\n".join(MODELO.split(";")),
      historico=HIST_COM_PARECIDO,
      extra=["--modelo-em-linhas", "--coluna-descricao",
             "Descricao da ocorrencia"])

rodar("31 --so-mapa nao emite registro e sai com 4",
      4,
      [("existe:mapa-de-campos.md", "", True),
       ("nao-existe:linha-para-colar.csv", "", True),
       ("mapa-de-campos.md", "so-mapa, sem registro emitido", True)],
      sem_anomalia=True, historico=None, extra=["--so-mapa"])

rodar("32 o delimitador do modelo e mantido na saida",
      1,
      [("linha-para-colar.csv", "No,Data,Setor", True)],
      modelo=MODELO.replace(";", ","),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])


# ---------------------------------------------------------------------------
# 33 em diante: reincidencia e caminho feliz.
# ---------------------------------------------------------------------------

rodar("33 caminho feliz sem reincidencia sai com 0",
      0,
      [("mapa-de-campos.md", "status: completo", True),
       ("mapa-de-campos.md", "NAO FECHA", False),
       ("reincidencia.csv", "arquivo;linha", True),
       ("mapa-de-campos.md", "| Reincidencias | 0 |", True)],
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-data", "Data", "--coluna-numero", "No"])

rodar("34 reincidencia encontrada sai com 1 e nomeia o registro anterior",
      1,
      [("reincidencia.csv", "NC-2026-020", True),
       ("reincidencia.csv", "descricao_semelhante", True),
       ("mapa-de-campos.md", "Leia o reincidencia.csv", True)],
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-data", "Data", "--coluna-numero", "No"])

rodar("35 tres ocorrencias viram candidato a problema cronico, sem concluir",
      1,
      [("mapa-de-campos.md", "candidato a problema cronico", True),
       ("mapa-de-campos.md", "Quem decide se e cronico", True)],
      historico="\n".join([
          HIST_CAB,
          "NC-2026-020;09/05/2026;Usinagem;Torno 07;Rebarba na face do eixo "
          "usinado no torno 07;Fechado",
          "NC-2026-029;12/06/2026;Usinagem;Torno 07;Rebarba na face usinada do "
          "eixo;Fechado",
          "NC-2026-033;30/07/2026;Usinagem;Torno 07;Eixo com rebarba na face "
          "usinada no torno 07;Fechado"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-numero", "No"])

rodar("36 mesmo equipamento com outra descricao sai marcado como mesmo local",
      1,
      [("reincidencia.csv", "mesmo_local", True),
       ("reincidencia.csv", "NC-2026-031", True)],
      historico="\n".join([
          HIST_CAB,
          "NC-2026-031;12/06/2026;Usinagem;Torno 07;Parada por quebra de "
          "castanha;Fechado"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-local", "Equipamento", "--coluna-numero", "No"])

rodar("37 duas colunas candidatas a descricao param a varredura daquele arquivo",
      5,
      [("historico-nao-varrido.csv", "mais de uma coluna parece", True)],
      historico="\n".join([
          "No;Data;Descricao da ocorrencia;Descricao da acao;Status",
          "NC-2026-012;03/03/2026;Vazamento de oleo;Troca do retentor;Fechado"]))

rodar("38 rodape de IA sai em todo artefato, e fora das linhas dos CSV",
      0,
      [("mapa-de-campos.md", "Gerado com apoio de IA", True),
       ("procedencia.txt", "Gerado com apoio de IA", True),
       ("linha-para-colar.txt", "Gerado com apoio de IA", False),
       ("reincidencia.csv", "Gerado com apoio de IA", False),
       ("campos-pendentes.csv", "Gerado com apoio de IA", False),
       ("historico-nao-varrido.csv", "Gerado com apoio de IA", False),
       ("mapa-de-campos.md", "Revisar antes de assinar", True)],
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

rodar("39 --sem-valores-no-mapa nao deixa valor de celula no mapa",
      0,
      [("mapa-de-campos.md", "Usinagem", False),
       ("mapa-de-campos.md", "<preenchido,", True)],
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--sem-valores-no-mapa"])

rodar("40 diretorio existente nao e regravado sem --forcar",
      3,
      [("stderr", "ja existe", True)],
      extra=["--coluna-descricao", "Descricao da ocorrencia"],
      historico=HIST_SEM_PARECIDO, pre_criar_saida=True)


rodar("42 barra vertical na celula nao quebra a tabela do mapa",
      1,
      [("mapa-de-campos.md", "\\|", True),
       ("linha-para-colar.csv", "lote 8841 | turno B", True)],
      anomalia=texto_anomalia(trocar={
          "kit.descricao_do_desvio":
              "Rebarba na face usinada do eixo, lote 8841 | turno B"}),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])


# ---------------------------------------------------------------------------
# 43 em diante: os caminhos em que a rodada saia com sucesso tendo perdido,
# ignorado ou nao processado dado. Cada um veio de uma rodada real que fechou
# com status completo e entregou coisa errada.
# ---------------------------------------------------------------------------

MODELO_SEM_NOME = ("No;Data;Setor;Equipamento;Descricao da ocorrencia;;"
                   "Causa raiz;Acao imediata;Acao corretiva;Responsavel;"
                   "Prazo;Status")

# 43. Coluna sem nome no meio do cabecalho. Antes ela era descartada em
#     silencio, a contagem passava a ser a de depois do filtro, todas as
#     identidades fechavam e a linha colava deslocada uma coluna a esquerda na
#     planilha da casa.
rodar("43 coluna sem nome no meio do cabecalho mantem a posicao e bloqueia",
      2,
      [("campos-pendentes.csv", "coluna_sem_nome_no_cabecalho", True),
       ("campos-pendentes.csv", "sim", True),
       ("mapa-de-campos.md", "| Campos no cabecalho bruto | 12 |", True),
       ("mapa-de-campos.md", "| Colunas lidas | 12 |", True),
       ("mapa-de-campos.md", "campos_do_cabecalho_bruto 12 = com_nome 11 + "
                             "sem_nome 1", True),
       ("mapa-de-campos.md", "NAO FECHA", False),
       ("nao-existe:linha-para-colar.csv", "", True),
       # a celula vazia guarda o lugar: causa continua na coluna de causa
       ("rascunho-nao-fechado.csv", "eixo no torno 07;;HIPOTESE", True)],
      modelo=MODELO_SEM_NOME,
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 44. A mesma doenca na outra forma, que e o caso comum: o ponto e virgula
#     sobrando no fim do cabecalho exportado do Excel. A posicao tambem e
#     mantida, e aqui o aviso nao bloqueia.
rodar("44 ponto e virgula sobrando no fim do cabecalho nao muda a contagem",
      1,
      [("campos-pendentes.csv", "coluna_sem_nome_no_cabecalho", True),
       ("campos-pendentes.csv", "ponto e virgula sobrando", True),
       ("mapa-de-campos.md", "| Campos no cabecalho bruto | 12 |", True),
       ("mapa-de-campos.md", "posicao 12", True),
       ("existe:linha-para-colar.csv", "", True),
       ("linha-para-colar.csv", "Prazo;Status;", True)],
      modelo=MODELO + ";",
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 45. Historico que existe e nao tem registro. Sair com 0 dizia "esse desvio e
#     novo" depois de comparar zero registro.
rodar("45 historico existente e vazio nao sai com 0",
      5,
      [("historico-nao-varrido.csv", "historico_sem_registro", True),
       ("mapa-de-campos.md", "| Arquivos de historico sem nenhum registro | 1 |",
        True),
       ("stdout", "Nenhum registro foi comparado", True),
       ("stdout", "Nenhuma ocorrencia semelhante", False),
       ("mapa-de-campos.md", "NAO FECHA", False)],
      historico=HIST_CAB,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 46. O --historico apontado para o proprio arquivo do modelo, que era o
#     exemplo impresso no docstring do script. Mesmo efeito do caso 45.
rodar("46 --historico apontado para o modelo nao sai com 0",
      5,
      [("historico-nao-varrido.csv", "historico_sem_registro", True),
       ("stdout", "nao para o arquivo do modelo", True)],
      historico=MODELO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 47. Descricao digitada uma vez so, no campo governado, sem
#     kit.coluna_da_descricao. O destino e inferido e a celula da descricao nao
#     sai vazia.
rodar("47 descricao so no campo governado entra na coluna do registro",
      1,
      [("linha-para-colar.csv", "Rebarba na face usinada do eixo no torno 07",
        True),
       ("stdout", "destino inferido: descricao", True),
       ("mapa-de-campos.md", "inferido pelo nome da coluna", True)],
      anomalia=texto_anomalia(remover=("kit.coluna_da_descricao",)),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 48. Sem coluna de destino para a descricao e sem candidata unica, a rodada
#     nao fecha. Antes ela gravava linha-para-colar.csv com a celula da
#     descricao vazia e status completo.
rodar("48 descricao sem coluna de destino nao fecha e nao grava a linha",
      2,
      [("campos-pendentes.csv", "descricao_sem_coluna_no_modelo", True),
       ("nao-existe:linha-para-colar.csv", "", True),
       ("existe:rascunho-nao-fechado.csv", "", True),
       ("mapa-de-campos.md", "status: rascunho, nao fechado", True)],
      modelo="No;Data;Setor;Equipamento;Causa raiz;Responsavel;Prazo",
      anomalia=texto_anomalia(remover=("kit.coluna_da_descricao",
                                       "kit.coluna_da_contramedida")),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--contramedida-fora-da-linha"])

# 49. Descricao no campo governado divergindo da coluna digitada a mao. O
#     registro e a varredura contariam historias diferentes.
rodar("49 descricao divergente entre coluna e campo governado nao fecha",
      2,
      [("campos-pendentes.csv", "descricao_divergente", True),
       ("nao-existe:linha-para-colar.csv", "", True)],
      anomalia=texto_anomalia(extra=[
          ("Descricao da ocorrencia", "Peca fora de especificacao")]),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 50. Historico com outro nome de coluna de apoio. A reincidencia saia sem
#     numero, sem data e sem local, e o motivo era jogado fora.
rodar("50 coluna de apoio nao encontrada no historico sai com causa escrita",
      6,
      [("historico-nao-varrido.csv", "coluna_de_apoio_nao_encontrada", True),
       ("historico-nao-varrido.csv", "a coluna de numero do registro nao foi "
                                     "encontrada", True),
       ("mapa-de-campos.md", "| Colunas de apoio nao encontradas | 3 |", True),
       ("mapa-de-campos.md", "NAO FECHA", False),
       ("reincidencia.csv", "descricao_semelhante", True)],
      historico="\n".join([
          "Numero;Dt ocorrencia;Setor;TAG;Descricao da ocorrencia;Status",
          "NC-2026-020;09/05/2026;Usinagem;Torno 07;Rebarba na face do eixo "
          "usinado no torno 07;Fechado"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-data", "Data", "--coluna-numero", "No",
             "--coluna-local", "Equipamento"])

# 51. Reincidencia com parte do historico fora da varredura. O codigo 1 saia na
#     frente e engolia o 5: rodada incompleta ficava indistinguivel de completa.
rodar("51 reincidencia com varredura incompleta sai com 6, nao com 1",
      6,
      [("historico-nao-varrido.csv", "contagem_de_colunas_diferente", True),
       ("stdout", "a resposta sobre reincidencia esta incompleta", True)],
      historico="\n".join([
          HIST_CAB,
          "NC-2026-020;09/05/2026;Usinagem;Torno 07;Rebarba na face do eixo "
          "usinado no torno 07;Fechado",
          "Total de registros;3;;;;;;"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-numero", "No"])

# 52. A identidade das pendencias comparava uma variavel com ela mesma, com o
#     resultado escrito na mao, e era montada antes da ultima pendencia. Aqui a
#     pendencia de encoding entra depois: o numero impresso tem que bater com o
#     arquivo gravado.
rodar("52 a identidade das pendencias bate com o arquivo gravado",
      1,
      [("stdout", "registros gravados em campos-pendentes.csv 3 = pendencias 3",
        True),
       ("campos-pendentes.csv", "caractere_fora_do_encoding_do_modelo", True),
       ("stdout", "NAO FECHA", False)],
      modelo="No;Data;Setor;Equipamento;Descricao da ocorrencia;Causa raiz;"
             "Acao imediata;Acao corretiva;Responsavel;Prazo;Situação",
      anomalia=texto_anomalia(trocar={
          "kit.descricao_do_desvio":
              "Rebarba na face usinada do eixo no torno 07, diametro ≠ "
              "especificado"}),
      historico=HIST_COM_PARECIDO,
      enc_modelo="cp1252",
      extra=["--coluna-descricao", "Descricao da ocorrencia"])

# 53. O gabarito: a comparacao coluna a coluna deixa de ser trabalho manual, e
#     a liberacao fica registrada fora da conversa.
rodar("53 gabarito divergente em coluna obrigatoria nao libera",
      2,
      [("existe:conferencia-do-gabarito.md", "", True),
       ("conferencia-do-gabarito.md", "**Nao libera.**", True),
       ("conferencia-do-gabarito.md", "divergente", True),
       ("campos-pendentes.csv", "gabarito_divergente_em_coluna_obrigatoria",
        True),
       ("fora:livro.csv", "nao libera", True)],
      historico=HIST_COM_PARECIDO,
      gabarito="\n".join([
          MODELO,
          "NC-2026-041;20/09/2026;Montagem;Torno 07;Rebarba na face usinada do "
          "eixo no torno 07;Inserto gasto;Peca segregada;Troca do inserto;"
          "Tiago Moraes;30/09/2026;Fechado"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--obrigatorias", "No,Data,Setor,Descricao da ocorrencia"])

rodar("54 gabarito que bate libera e fica registrado no livro",
      1,
      [("conferencia-do-gabarito.md", "**Libera.**", True),
       ("campos-pendentes.csv", "gabarito_divergente_em_coluna_obrigatoria",
        False),
       ("fora:livro.csv", "libera", True),
       ("stdout", "sobrevive ao fim da conversa", True)],
      historico=HIST_COM_PARECIDO,
      gabarito="\n".join([
          MODELO,
          "NC-2026-041;20/09/2026;Usinagem;Torno 07;Rebarba na face usinada do "
          "eixo no torno 07;Inserto de acabamento gasto;Peca segregada;"
          "Incluir a troca do inserto no plano de setup;Tiago Moraes;30/09/2026;Aberto"]),
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--obrigatorias", "No,Data,Setor,Descricao da ocorrencia"])

# 55. Titulo acima do cabecalho do historico. O arquivo inteiro caia fora da
#     varredura e a causa gravada nao dizia que o problema era o titulo.
rodar("55 titulo acima do cabecalho do historico nao derruba o arquivo",
      1,
      [("reincidencia.csv", "NC-2026-020", True),
       ("stdout", "era titulo, nao cabecalho", True),
       ("historico-nao-varrido.csv", "sem_coluna_de_descricao", False)],
      historico="REGISTRO DE NAO CONFORMIDADE\n" + HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--coluna-numero", "No"])

# 56. A saida da rodada dentro da pasta apontada em --historico. Varrer a
#     propria saida devolve o registro que acabou de ser emitido como se fosse
#     ocorrencia anterior.
rodar("56 a saida da rodada dentro do historico nao e varrida",
      5,
      [("historico-nao-varrido.csv", "dentro do diretorio de saida", True),
       ("reincidencia.csv", "linha-para-colar", False)],
      pasta_historico={"2026.csv": HIST_SEM_PARECIDO,
                       "saida/linha-para-colar.csv": HIST_COM_PARECIDO},
      saida_dentro_do_historico=True,
      extra=["--coluna-descricao", "Descricao da ocorrencia", "--forcar"])

# 57. Coluna citada em --obrigatorias que nao existe no modelo. A declaracao da
#     pessoa desaparecia sem aviso e a rodada saia como se nada tivesse sido
#     declarado.
rodar("57 --obrigatorias com coluna que nao existe no modelo nao e ignorada",
      2,
      [("campos-pendentes.csv", "coluna_declarada_nao_existe", True),
       ("campos-pendentes.csv", "Disposicao", True)],
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--obrigatorias", "No,Data,Disposicao"])


rodar("59 --gabarito em rodada --so-mapa nao e ignorado em silencio",
      4,
      [("campos-pendentes.csv", "gabarito_nao_comparado", True),
       ("nao-existe:conferencia-do-gabarito.md", "", True)],
      sem_anomalia=True, historico=None,
      gabarito="\n".join([MODELO, "NC-2026-020;09/05/2026;Usinagem;Torno 07;"
                                  "Rebarba;Inserto gasto;;;;;Fechado"]),
      extra=["--so-mapa"])

rodar("58 --sem-valores-no-mapa nao deixa conteudo de celula na pendencia",
      2,
      [("mapa-de-campos.md", "leia o campos-pendentes.csv na sua maquina", True),
       ("mapa-de-campos.md", "Peca fora de especificacao", False),
       ("campos-pendentes.csv", "Peca fora de especificacao", True)],
      anomalia=texto_anomalia(extra=[
          ("Descricao da ocorrencia", "Peca fora de especificacao")]),
      historico=HIST_COM_PARECIDO,
      extra=["--coluna-descricao", "Descricao da ocorrencia",
             "--sem-valores-no-mapa"])


# ---------------------------------------------------------------------------
# Documentacao: o que o SKILL.md tem que dizer.
# ---------------------------------------------------------------------------

def conferir_documentos():
    erros = []
    if not SKILL.exists():
        erros.append("SKILL.md nao existe")
        registrar_resultado("41 SKILL.md", erros)
        return
    texto = SKILL.read_text(encoding="utf-8")
    ref = REFERENCIA.read_text(encoding="utf-8") if REFERENCIA.exists() else ""
    if not ref:
        erros.append("references/classes-de-registro.md nao existe")
    for arquivo, nome in ((texto, "SKILL.md"), (ref, "classes-de-registro.md")):
        for proibido, rotulo in ((chr(0x2014), "travessao"),
                                  (chr(0x2013), "meia-risca")):
            if proibido in arquivo:
                erros.append("%s tem %s" % (nome, rotulo))
    # O que a pagina nao pode mais dizer, porque o script nao faz mais assim.
    proibidos = [
        ("as oito identidades", "o script imprime dez"),
        ("o diretório tem os seis arquivos", "o numero de arquivos varia por modo"),
        ("Seis arquivos num diretório", "sao sete no modo padrao"),
        ("ler os seis arquivos", "o numero de arquivos varia por modo"),
    ]
    for frase, motivo in proibidos:
        if frase in texto:
            erros.append("SKILL.md ainda diz %r, e %s" % (frase, motivo))
    if "é o que a norma pede" in ref:
        erros.append("a referencia afirma o que a norma pede sem ressalva")
    for clausula in ("8.7", "10.3"):
        if clausula in ref:
            erros.append("a referencia percorre a clausula %s, e a skill nao "
                         "reproduz estrutura de norma" % clausula)
    if "reagir e corrigir" in ref:
        erros.append("a referencia enumera as alineas da 10.2")

    obrigatorios = [
        "O kit prevê dez skills e esta versão traz dez.",
        "as dez identidades saíram com os números",
        "campos_do_cabecalho_bruto = colunas_com_nome + colunas_sem_nome",
        "| 6 | Registro fechado, há reincidência, e ficou coisa fora da varredura |",
        "kit.coluna_da_descricao",
        "kit.coluna_do_local",
        "procedencia.txt",
        "--gabarito",
        "~/.kit-industrial/gabaritos-registro-de-anomalia.csv",
        "Sessenta",
        "aponta para os registros anteriores",
        "rodando sem ficha da área",
        "~/.kit-industrial/ficha-da-area.md",
        "Gerado com apoio de IA a partir de",
        "Não substitui responsabilidade técnica.",
        "Confira na edição vigente da sua empresa",
        "conferencia-entre-duas-fontes",
        "extracao-de-documento-para-tabela",
        "triagem-de-caixa-de-email",
        "comparativo-de-cotacoes",
        "ficha-da-area",
        "relatorio-recorrente",
        "registro-de-anomalia",
        "padrao-conferido-contra-norma",
        "linha-de-base-antes-de-automatizar",
        "indice-do-acervo-da-area",
        "py -3",
        "~/.claude/skills/registro-de-anomalia/scripts/registrar.py",
        "~/.claude/skills/registro-de-anomalia/scripts/testar.py",
    ]
    for o in obrigatorios:
        if o not in texto:
            erros.append("SKILL.md nao diz %r" % o)
    if "description:" in texto:
        inicio = texto.index("description:")
        fim = texto.index("\n---", inicio)
        desc = texto[inicio:fim]
        if len(desc) > 1400:
            erros.append("a description tem %d caracteres, o limite e 1400"
                         % len(desc))
        if "NAO use" not in desc and "NÃO use" not in desc:
            erros.append("a description nao fecha com o que nao usar")
        for vizinha in ("padrao-conferido-contra-norma",
                        "conferencia-entre-duas-fontes"):
            if vizinha not in desc:
                erros.append("a description nao nomeia a skill vizinha %r no "
                             "NAO use, e o nome da pasta e o que faz o "
                             "roteamento acertar de primeira" % vizinha)
    registrar_resultado("41 SKILL.md e a referencia", erros)


def conferir_papelada_do_kit():
    """Depois de instalada, a skill fica sozinha em ~/.claude/skills/ e estes
    arquivos nao existem. Existindo, eles nao podem desmentir a skill."""
    kit = SKILL.parent.parent.parent
    leia_me = kit / "00-LEIA-ME.md"
    if not leia_me.exists():
        registrar_resultado("60 papelada do kit (fora do pacote instalado)", [])
        return
    erros = []
    texto = leia_me.read_text(encoding="utf-8")
    for frase in ("quatro skills prontas", "das dez previstas",
                  "para as quatro skills"):
        if frase in texto:
            erros.append("00-LEIA-ME.md ainda diz %r" % frase)
    for linha in texto.split("\n"):
        if linha.startswith("| `registro-de-anomalia`") and "Prevista" in linha:
            erros.append("00-LEIA-ME.md ainda lista esta skill como prevista")
    for irma in sorted((kit / "skills").glob("*/SKILL.md")):
        t = irma.read_text(encoding="utf-8")
        if "esta versão traz quatro" in t:
            erros.append("%s ainda diz que a versao traz quatro skills"
                         % irma.parent.name)
        if "`registro-de-anomalia`, prevista" in t or (
                "`registro-de-anomalia` | Prevista" in t):
            erros.append("%s ainda chama esta skill de prevista"
                         % irma.parent.name)
    registrar_resultado("60 a papelada do kit nao desmente a skill", erros)


conferir_documentos()
conferir_papelada_do_kit()

print("")
if falhas:
    print("%d caso falhou" % len(falhas))
    sys.exit(1)
print("todos os casos passaram")
sys.exit(0)
