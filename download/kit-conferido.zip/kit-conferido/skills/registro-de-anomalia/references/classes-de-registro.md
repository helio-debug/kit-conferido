# Classes de registro, vocabulário da casa e as armadilhas do preenchimento

Referência da skill `registro-de-anomalia`. Leia antes de decidir a classe do
desvio e antes de preencher o campo de causa.

Nada aqui substitui o procedimento da sua empresa. Onde o procedimento da casa
disser outra coisa, vale o procedimento da casa, e a skill adota o vocabulário
dele.

---

## 1. A separação que decide tudo: registro ou tratamento

O erro mais comum do registro manual não é escrever pouco, é tratar todo desvio
do mesmo jeito. Ou tudo vira investigação de causa, e aí a fila de tratativas
nunca fecha, ou nada vira, e aí o mesmo desvio volta todo mês.

A separação é operacional antes de ser normativa, e o ponto que interessa aqui é
um só: avaliar se o caso pede ação sobre a causa é um passo próprio, não um
automatismo que dispara em todo desvio. Onde a norma da sua empresa trata a ação
corretiva, e o que ela exige ali, é leitura da sua área da qualidade na cópia
vigente. O kit não afirma isso por você.
Confira na edição vigente da sua empresa.

A skill não reproduz texto de norma, não percorre as alíneas da cláusula e não
substitui a leitura da norma pela sua área da qualidade. Quem decide essa
avaliação é quem responde pelo processo, e o critério normalmente já está escrito
no procedimento da casa. A norma que a sua empresa segue pode não ser a ISO 9001.

### O teste de cinco perguntas, quando o procedimento não diz

Uma resposta "sim" já joga o caso em tratamento com causa.

1. O desvio chegou ao cliente, interno ou externo, ou poderia ter chegado?
2. Ele já apareceu antes, no histórico que você tem na mão?
3. Ele afeta segurança, requisito legal, requisito regulamentar ou característica
   crítica do produto?
4. A correção feita na hora resolve o caso, mas deixa a condição que o gerou de
   pé?
5. O custo, o retrabalho ou a parada que ele causou passa do que a casa aceita
   absorver sem análise?

Nenhuma "sim" nas cinco, e o caso é registro: descreve, corrige, dá a disposição,
registra e fecha. É legítimo, é o que o procedimento da sua casa provavelmente já
prevê, e é o que destrava a fila. Confirme o critério no procedimento da sua
empresa e na edição vigente da norma que ela segue, que pode não ser a ISO 9001.

---

## 2. O nome que a sua casa dá

A skill não impõe nome nenhum. Ela usa o que estiver no cabeçalho do registro que
você entregou. Esta lista serve só para reconhecer o mesmo objeto com nomes
diferentes.

| Nome que aparece | Costuma ser |
|---|---|
| RNC, NC, RNC interna | O registro de não conformidade, o caso mais comum |
| Ocorrência, registro de ocorrência | Mesma coisa, vocabulário mais brando, comum quando o registro também recebe desvio pequeno |
| Desvio, registro de desvio | Comum em processo contínuo, químico e farmacêutico |
| Apontamento da qualidade, boletim de inspeção | Registro ligado à inspeção, geralmente por lote |
| RDO, relatório diário | Registro de obra e de manutenção, onde a anomalia divide espaço com o diário |
| Chamado, ordem de serviço | Quando a anomalia entra pela manutenção |
| Tratativa, plano de ação, 8D, A3 | O tratamento, não o registro. Costuma ser outro arquivo, ligado ao registro pelo número |

Quando o registro e o tratamento vivem em arquivos diferentes, a skill preenche a
linha do registro e a contramedida sai declarada fora da linha, em
`--contramedida-fora-da-linha`, com o texto pronto para o outro arquivo.

---

## 3. As colunas que costumam existir, e o que entra em cada uma

A ordem e o nome vêm do seu arquivo. Isto é só o mapa do que cada coluna quer.

| Coluna típica | O que entra | Erro comum |
|---|---|---|
| Número | O identificador da casa, na sequência dela | Número inventado pela skill. Ela não numera: pede o próximo à pessoa ou deixa pendente |
| Data | A data do fato, não a data em que alguém sentou para digitar | Datar pelo dia do preenchimento, o que desmonta qualquer análise por período |
| Setor, área, processo | Onde o desvio aconteceu | Registrar o setor que detectou em vez do que gerou |
| Equipamento, posto, TAG | O ativo, com o código da casa | Escrever "torno" quando existe TAG. Sem o código, a busca por reincidência não acha |
| Produto, item, ordem, lote | O que estava sendo feito | Deixar vazio, o que impede fechar o custo depois |
| Descrição | O fato observável: o que foi encontrado, onde, quanto, medido como | Opinião, culpa e causa dentro da descrição |
| Quantidade afetada | Peças, metros, quilos, horas de parada | Vazio, ou "várias" |
| Detectado por, detectado em | Etapa e momento da detecção | Nome da pessoa no lugar da etapa |
| Disposição | Liberar, retrabalhar, reclassificar, devolver, sucatear, uso sob concessão | Esta decisão não é da skill nem da IA. É de quem tem autoridade declarada no procedimento |
| Ação imediata, contenção | O que foi feito na hora para o desvio não seguir | Confundir com contramedida |
| Causa | A condição que gerou o desvio, quando apurada | Sintoma, culpa, ou hipótese apresentada como fato |
| Ação corretiva, contramedida | O que muda para o desvio não voltar | Texto genérico sem dono e sem data |
| Responsável | Uma pessoa nomeada | Um setor |
| Prazo | Uma data | "Imediato", "urgente", em branco |
| Status, situação | Aberto, em tratamento, aguardando verificação, fechado | Fechar sem verificação de eficácia |
| Verificação da eficácia | Quando, como e com qual evidência se confere que funcionou | Campo que existe na planilha e nunca é preenchido |

---

## 4. Descrição: fato observável, não relato

A descrição é o campo que decide se alguém vai conseguir achar a reincidência
daqui a seis meses. Regras práticas:

- Comece pelo que foi encontrado, não pelo que se supõe.
- Diga onde, em que etapa, e com que evidência (medição, instrumento, foto,
  registro de processo).
- Traga o número: quantas peças, quantos milímetros fora, quantas horas paradas.
- Escreva o código do item e o TAG do equipamento por extenso pelo menos uma vez.
  É o que a varredura de reincidência procura.
- Não escreva nome de pessoa. A descrição registra o fato, não quem estava no
  posto. Além de ser prática ruim de gestão, é dado pessoal indo parar num
  arquivo que circula.

Comparação curta:

| Fraca | Utilizável |
|---|---|
| Peça fora de especificação | Eixo do item 55.120 com rebarba na face usinada, 0,4 mm acima do limite, medida no calibrador da célula, em 12 das 40 peças do lote |
| Máquina com problema | Parada do TAG TN-07 por travamento do carro transversal, 3 h 20 min, terceira do mês |
| Falha do operador | Setup concluído sem a conferência do dispositivo de aperto, prevista na folha de processo |

---

## 5. Causa: hipótese e causa não são a mesma coisa

Causa declarada sem teste é hipótese. A skill registra a hipótese, marcada como
hipótese, com o teste que a confirmaria. Isso não trava o registro: trava só a
afirmação de que a causa está conhecida.

| Hipótese frequente | O teste que confirma |
|---|---|
| Ferramenta ou inserto gasto | Trocar e medir a mesma característica em N peças seguidas |
| Parâmetro de processo fora | Puxar o registro do parâmetro no período e comparar com a faixa da folha |
| Matéria-prima fora | Conferir o certificado do lote e medir amostra do mesmo lote |
| Instrumento descalibrado | Medir a mesma peça com instrumento calibrado e comparar |
| Instrução ausente ou ambígua | Pedir a três pessoas que executem pela instrução e observar a variação |
| Manutenção não executada | Conferir a data da última execução do plano contra o plano |

O que nunca é causa, mesmo quando aparece escrito assim no registro antigo:

- "Falha humana", "desatenção", "erro do operador". Descreve o momento, não a
  condição. Pergunte o que permitiu que o erro passasse.
- "Falta de treinamento", quando ninguém checou o registro de treinamento.
- "Máquina velha", quando não há dado de falha do ativo.
- A repetição do próprio desvio com outras palavras.

---

## 6. Contramedida: o que faz o registro fechar

Registro que exige tratamento não fecha sem contramedida, dono nomeado e data.
Três testes rápidos:

1. **Teste do sumiço.** Se a contramedida for feita e a condição continuar de pé,
   não é contramedida, é correção.
2. **Teste do dono.** Se o dono é um setor, ninguém é. Nomeie a pessoa.
3. **Teste da evidência.** Diga com que evidência a eficácia será verificada, e
   em que data. Sem isso, o fechamento é formal.

Contramedidas que costumam voltar como reincidência: treinamento sem mudança no
padrão, reunião de alinhamento, "atenção redobrada", inspeção 100% por tempo
indeterminado. Nenhuma delas é proibida. Todas precisam de verificação marcada.

---

## 7. Reincidência: quando é o mesmo desvio

A varredura do script compara termos e aponta candidatos. Quem julga é você. O
critério prático:

| É o mesmo desvio | Não é |
|---|---|
| Mesmo item e mesmo modo de falha | Mesmo item com modo de falha diferente |
| Mesmo equipamento e mesmo modo de falha | Mesmo equipamento, falha de outra natureza |
| Mesma etapa do processo e mesma característica fora | Mesma etapa, característica diferente |
| Mesmo fornecedor e mesmo desvio de material | Mesmo fornecedor, outro material |

Três ocorrências do mesmo desvio em janelas diferentes é o sinal clássico de
problema crônico, e crônico muda o encaminhamento: não é mais tratativa isolada,
é pauta de análise com dado do período. A skill aponta o padrão e a contagem. A
decisão de abrir a análise é de quem responde pelo processo.

Sinal que costuma aparecer junto e vale olhar: registros abertos e fechados no
mesmo dia, em série, com a mesma contramedida escrita igual. Quase sempre é
fechamento formal, e é o terreno onde a reincidência cresce sem aparecer no
indicador.

---

Gerado com apoio de IA a partir de material de método e de prática de campo.
Revisar antes de assinar. Não substitui responsabilidade técnica.
