#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ficha.py, grava a ficha da area em caminho absoluto fixo e confere que ela
esta inteira.

Biblioteca padrao apenas: argparse, csv, os, re, sys, unicodedata, datetime,
pathlib. Sem rede. Nunca escreve no rascunho de entrada.

Dois modos, exclusivos entre si.

  --cabecalho-de ARQUIVO   Derivacao. Le SO a linha de cabecalho de um export e
                           imprime os nomes de campo. Recusa arquivo que nao e
                           texto delimitado (xlsx, xls, ods, pdf, doc) antes de
                           ler um byte, e recusa a linha que tem cara de dado
                           em vez de cara de cabecalho. Nao grava ficha, e por
                           isso sai com 4 e nunca com 0. Aceita a forma
                           ARQUIVO:LINHA para dizer a linha de cada arquivo.

  --rascunho ARQUIVO       Gravacao. Confere o rascunho secao por secao e linha
                           por linha, e so entao grava a ficha no destino, de
                           forma atomica, com copia da versao anterior ao lado.

O que o script NAO faz: nao escreve fato nenhum por voce, nao infere e nao
apaga linha. Ele confere, copia e promove lacuna. Toda linha do rascunho ou
entra na ficha ou aparece na lista de problemas com o numero da linha.

O que ele faz por voce, e que antes sobrava para a pessoa: a lacuna declarada
dentro de uma secao de fato e copiada para a secao "Lacunas declaradas", com o
nome da secao de origem na frente. A rodada nao e reprovada por isso e nao pede
digitacao de novo. A promocao sai contada no relatorio e no cabecalho da ficha.

Duas identidades fecham em toda rodada de gravacao:
  1. linhas vistas = soma dos baldes de classificacao
  2. linhas de conteudo vistas dentro de secao = linhas de conteudo escritas no
     corpo da ficha
A segunda existe porque a primeira fecha mesmo quando uma linha e classificada
e nao e gravada.

Codigos de saida:
  0  ficha gravada, com pelo menos uma lacuna declarada
  3  erro de entrada ou conferencia reprovada. Nada foi gravado. Derivacao de
     cabecalho que para tambem sai com 3, como qualquer erro de entrada
  4  rodada de derivacao de cabecalho concluida. Nenhuma ficha gravada
  5  ficha gravada, nenhuma lacuna declarada. Resultado em aberto

Exemplos:

    python3 ~/.claude/skills/ficha-da-area/scripts/ficha.py --cabecalho-de export.csv
    python3 ~/.claude/skills/ficha-da-area/scripts/ficha.py --cabecalho-de export.csv:4
    python3 ~/.claude/skills/ficha-da-area/scripts/ficha.py --rascunho rascunho-ficha.md

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\ficha-da-area\\scripts\\ficha.py" `
        --rascunho rascunho-ficha.md
"""

import argparse
import csv
import os
import re
import sys
import unicodedata
from datetime import date, datetime
from pathlib import Path

FICHA_PADRAO = str(Path.home() / ".kit-industrial" / "ficha-da-area.md")

RODAPE = ("Gerado com apoio de IA a partir de {fonte}. Revisar antes de assinar. "
          "Não substitui responsabilidade técnica.")

AVISO_NAO_CONFERIDA = ("ATENÇÃO: ficha não conferida contra documento da pessoa. "
                       "Quem lê esta ficha repete este status antes de usá-la.")

SECOES_FATO = [
    "Área e posto",
    "Vocabulário local",
    "Sistemas e o que cada um exporta",
    "Ritos e prazos",
    "Normas e certificações",
]
SECAO_LACUNAS = "Lacunas declaradas"
SECOES = SECOES_FATO + [SECAO_LACUNAS]

# Que skill do kit roda pior enquanto a lacuna daquela secao estiver aberta.
# Sai na pagina de lacunas, coluna por coluna, porque essa e a conta que a
# pessoa teria de fazer na mao para saber o que o buraco custa.
CONSUMIDORAS = {
    "Área e posto": "as nove, na hora de decidir o que e prioridade",
    "Vocabulário local": ("registro-de-anomalia, conferencia-entre-duas-fontes, "
                          "extracao-de-documento-para-tabela"),
    "Sistemas e o que cada um exporta": ("conferencia-entre-duas-fontes, "
                                         "relatorio-recorrente, "
                                         "linha-de-base-antes-de-automatizar"),
    "Ritos e prazos": "relatorio-recorrente, triagem-de-caixa-de-email",
    "Normas e certificações": "padrao-conferido-contra-norma",
    SECAO_LACUNAS: "seção não indicada: escreva a lacuna como <seção>: <o que falta>",
}

TAG_FIM = re.compile(
    r"\[(?:derivada de\s+(?P<fonte>[^\]]*)|respondida pela pessoa|lacuna)\]\s*$")
TAG_QUALQUER = re.compile(
    r"\[(?:derivada de[^\]]*|respondida pela pessoa|lacuna)\]")
COLCHETE_FIM = re.compile(r"\[[^\]]*\]\s*$")
META_ANTIGA = re.compile(
    r"^(status|gravada em|linhas de fato|lacunas distintas|linhas promovidas pelo "
    r"script|fontes nomeadas|fontes declaradas sem arquivo no disco|ficha em|"
    r"documento do gabarito|conferida contra)\s*:",
    re.IGNORECASE)
SEPARADOR = re.compile(r"^[-*_=]{3,}$")
MARCA = re.compile(r"^(?:[-*+](?:\s+|$)|\d+[.)](?:\s+|$))")
PREFIXO_RODAPE = "Gerado com apoio de IA a partir de"

DELIMITADORES = (";", ",", "\t", "|")
LINHAS_EXAMINADAS = 20

# Formato que nao e texto delimitado. Recusado pela extensao e pela assinatura,
# antes de qualquer leitura: decodificar xlsx como texto imprime byte comprimido
# do arquivo como se fosse nome de campo, e dentro desse byte pode ir conteudo.
EXTENSOES_RECUSADAS = {
    ".xlsx": "planilha do Excel", ".xlsm": "planilha do Excel com macro",
    ".xlsb": "planilha do Excel binaria", ".xls": "planilha do Excel antiga",
    ".ods": "planilha do LibreOffice", ".pdf": "PDF",
    ".doc": "documento do Word antigo", ".docx": "documento do Word",
    ".ppt": "apresentacao", ".pptx": "apresentacao",
    ".zip": "arquivo compactado", ".rar": "arquivo compactado",
    ".7z": "arquivo compactado", ".gz": "arquivo compactado",
    ".png": "imagem", ".jpg": "imagem", ".jpeg": "imagem",
}
ASSINATURAS = (
    (b"PK\x03\x04", "arquivo compactado, e xlsx, ods e docx sao zip por dentro"),
    (b"%PDF-", "PDF"),
    (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "documento binario do Office antigo"),
    (b"\x89PNG", "imagem PNG"),
    (b"\xff\xd8\xff", "imagem JPEG"),
)
SALVE_COMO_CSV = ("Salve como CSV, em UTF-8 ou ANSI, a aba que voce usa e rode de "
                  "novo. Derivar cabecalho de arquivo que nao e texto delimitado "
                  "imprime lixo binario com cara de nome de campo")

RE_SO_NUMERO = re.compile(r"^[+-]?\(?\d[\d\s.,]*\)?\s*%?$")
RE_DATA = re.compile(
    r"^\d{1,4}[/.\-]\d{1,2}(?:[/.\-]\d{1,4})?(?:[ T]\d{1,2}:\d{2}(?::\d{2})?)?$")
RE_CONTROLE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
RE_ARQ_LINHA = re.compile(r"^(?P<arq>.+):(?P<linha>\d+)$")
RE_DIGITO = re.compile(r"\d")

# Baldes contados dentro do laco. Nenhum deles sai por subtracao: a identidade
# de fechamento so acusa branch esquecido porque cada um e incrementado na hora.
BALDES = [
    "derivadas",
    "respondidas",
    "lacunas_secao",
    "lacunas_em_fato",
    "fato_em_lacunas",
    "sem_fonte",
    "continuacao",
    "tag_invalida",
    "tag_desconhecida",
    "fora_de_secao",
    "titulo_inesperado",
    "cabecalho_antigo",
    "rodape_antigo",
]


# --------------------------------------------------------------------- comuns

def normalizar(t):
    t = unicodedata.normalize("NFKD", t or "")
    t = "".join(c for c in t if not unicodedata.combining(c))
    return t.casefold().strip()


NORM_SECOES = {normalizar(s): s for s in SECOES}


def ler_texto(caminho):
    """Devolve (texto, evidencia do encoding). Nunca devolve texto vazio em
    silencio: arquivo ilegivel sobe como excecao para quem chamou."""
    dados = Path(caminho).read_bytes()
    if dados.startswith(b"\xef\xbb\xbf"):
        return dados.decode("utf-8-sig"), "utf-8 com BOM"
    for enc, rotulo in (("utf-8", "utf-8"), ("cp1252", "cp1252"),):
        try:
            return dados.decode(enc), rotulo
        except UnicodeDecodeError:
            continue
    return dados.decode("latin-1", "replace"), "latin-1 com substituicao"


def em_linhas(texto):
    return texto.replace("\r\n", "\n").replace("\r", "\n").split("\n")


# ------------------------------------------------------- derivacao de cabecalho

def recusar_formato(p):
    """Devolve o motivo de recusa, ou None. Roda antes de decodificar nada."""
    ext = p.suffix.lower()
    if ext in EXTENSOES_RECUSADAS:
        return ("%s e %s pela extensao %s, e nao texto delimitado. %s"
                % (p.name, EXTENSOES_RECUSADAS[ext], ext, SALVE_COMO_CSV))
    try:
        with open(str(p), "rb") as f:
            inicio = f.read(4096)
    except OSError as e:
        return "arquivo %s nao pode ser lido: %s" % (p, e)
    for assinatura, rotulo in ASSINATURAS:
        if inicio.startswith(assinatura):
            return ("%s comeca com assinatura de %s, nao de texto delimitado. %s"
                    % (p.name, rotulo, SALVE_COMO_CSV))
    if b"\x00" in inicio:
        return ("%s tem byte nulo no inicio, entao e binario ou texto em UTF-16, "
                "nao texto delimitado de uma linha por registro. %s"
                % (p.name, SALVE_COMO_CSV))
    return None


def cara_de_ruido(linha):
    motivos = []
    if RE_CONTROLE.search(linha):
        motivos.append("a linha tem byte de controle no meio do texto")
    if linha and linha.count("�") * 20 > len(linha):
        motivos.append("mais de 5% dos caracteres da linha nao pudera ser "
                       "decodificado e virou caractere de substituicao")
    return motivos


def cara_de_preambulo(campos):
    vazios = sum(1 for c in campos if c.strip() == "")
    if len(campos) >= 2 and vazios * 2 > len(campos):
        return ["%d dos %d campos estao vazios, o que e titulo de relatorio "
                "preenchido so na primeira coluna, nao cabecalho" % (vazios, len(campos))]
    return []


def cara_de_dado(campos):
    """Evidencia de que a linha e registro, nao cabecalho: campo que e so numero
    e campo em formato de data. Nome de campo nao e nem um nem outro."""
    motivos = []
    for i, c in enumerate(campos, start=1):
        nome = c.strip()
        if nome == "":
            continue
        if RE_SO_NUMERO.match(nome):
            motivos.append("o campo %d e puramente numerico" % i)
        elif RE_DATA.match(nome):
            motivos.append("o campo %d esta em formato de data" % i)
    return motivos


def nome_repetido(campos):
    """Alerta, nao recusa. Nome repetido e cheiro de linha de dado, mas tambem
    existe em cabecalho de verdade, e recusar sem saida travaria um arquivo
    legitimo sem alternativa nenhuma para a pessoa."""
    nomes = [normalizar(c) for c in campos if c.strip() != ""]
    return sorted(set(x for x in nomes if nomes.count(x) > 1))


def reprovar_candidata(linha, campos):
    """Motivos para nao tratar esta linha como cabecalho. Os textos nao carregam
    valor de campo: o numero da coluna basta para a pessoa conferir, e nome de
    pessoa em coluna de dado nao vai para a saida."""
    return cara_de_ruido(linha) + cara_de_preambulo(campos) + cara_de_dado(campos)


def campos_da_linha(linha, delim):
    try:
        return next(csv.reader([linha], delimiter=delim))
    except (csv.Error, StopIteration):
        return linha.split(delim)


def campos_por_linha(linhas, delim):
    return [len(campos_da_linha(l, delim)) for l in linhas]


def escolher_delimitador(linhas):
    melhor, melhor_nota = None, (0, 0)
    for d in DELIMITADORES:
        contas = [c for c in campos_por_linha(linhas, d) if c > 1]
        if not contas:
            continue
        moda = max(set(contas), key=contas.count)
        nota = (contas.count(moda), moda)
        if nota > melhor_nota:
            melhor, melhor_nota = d, nota
    return melhor


def primeira_candidata(amostra, contas, moda, delim):
    """Primeiro numero de linha que tem a largura do corpo e passa nos tres
    testes de cara de cabecalho. None quando nenhuma passa."""
    for (num, linha), c in zip(amostra, contas):
        if c != moda:
            continue
        if not reprovar_candidata(linha, campos_da_linha(linha, delim)):
            return num
    return None


def derivar_cabecalho(caminho, linha_pedida):
    """Imprime os nomes de campo da linha de cabecalho. Devolve lista de
    problemas. Nenhuma linha de dado vai para a saida: das outras linhas o
    script usa apenas a contagem de separadores, e a linha escolhida so e
    impressa depois de passar no teste de cara de cabecalho."""
    p = Path(caminho)
    if not p.is_file():
        return ["arquivo nao encontrado: %s" % caminho]

    recusa = recusar_formato(p)
    if recusa:
        return [recusa]

    try:
        texto, enc = ler_texto(p)
    except OSError as e:
        return ["arquivo %s nao pode ser lido: %s" % (caminho, e)]

    todas = em_linhas(texto)
    uteis = [(i + 1, l) for i, l in enumerate(todas) if l.strip() != ""]
    if not uteis:
        return ["arquivo %s esta vazio ou so tem linhas em branco. "
                "Zero campo nao e resultado, e ausencia de resultado" % caminho]

    amostra = uteis[:LINHAS_EXAMINADAS]
    delim = escolher_delimitador([l for _, l in amostra])
    if delim is None:
        return ["nao foi possivel identificar o separador de %s. Nao vou supor "
                "que a linha inteira e um campo so: abra o arquivo, confirme o "
                "separador e rode de novo, ou informe a linha do cabecalho na "
                "forma %s:N se o cabecalho nao estiver na primeira linha"
                % (caminho, p.name)]

    contas = campos_por_linha([l for _, l in amostra], delim)
    moda = max(set(contas), key=contas.count)
    sugestao = primeira_candidata(amostra, contas, moda, delim)

    if linha_pedida:
        alvo = None
        for num, l in uteis:
            if num == linha_pedida:
                alvo = (num, l)
                break
        if alvo is None:
            return ["a linha %d de %s esta em branco ou nao existe"
                    % (linha_pedida, caminho)]
    else:
        if contas[0] != moda:
            return ["em %s a primeira linha tem %d campo(s) e o corpo do arquivo "
                    "tem %d. Isso e preambulo de relatorio, nao cabecalho. %s. "
                    "Nao vou chutar"
                    % (caminho, contas[0], moda, _onde_esta(p.name, sugestao))]
        alvo = amostra[0]

    num, linha = alvo
    campos = campos_da_linha(linha, delim)

    reprovas = reprovar_candidata(linha, campos)
    if reprovas:
        return ["a linha %d de %s nao tem cara de cabecalho: %s. Nao imprimi a "
                "linha, porque linha de dado carrega nome de pessoa, cliente e "
                "fornecedor, e isso nao vai para o chat. %s"
                % (num, caminho, "; ".join(reprovas),
                   _onde_esta(p.name, sugestao if sugestao != num else None))]

    rotulo_delim = {"\t": "tabulacao"}.get(delim, delim)
    print("arquivo: %s" % caminho)
    print("encoding: %s" % enc)
    print("separador: %s" % rotulo_delim)
    print("linha do cabecalho: %d" % num)
    print("campos: %d" % len(campos))
    sem_nome = 0
    for i, c in enumerate(campos, start=1):
        nome = c.strip()
        if nome == "":
            sem_nome += 1
            print("  %2d. (coluna sem nome)" % i)
        else:
            print("  %2d. %s" % (i, nome))
    if sem_nome:
        print("ALERTA: %d coluna(s) sem nome. Coluna sem nome e coluna que some "
              "depois, sem ninguem notar. Nomeie na origem antes de usar o export."
              % sem_nome)
    repetidos = nome_repetido(campos)
    if repetidos:
        print("ALERTA: %d nome(s) de campo aparece(m) em mais de uma coluna. "
              "Cabecalho de verdade tem nome unico: confirme que esta e a linha de "
              "cabecalho, e nao uma linha de dado, antes de colar." % len(repetidos))
    print("Foi impressa apenas a linha %d, e ela passou no teste de cara de "
          "cabecalho: nenhum campo puramente numerico, nenhum campo em formato de "
          "data, nenhum caractere de controle. Das outras linhas o script contou "
          "separadores e nao imprimiu nenhuma delas." % num)
    print("Confira os nomes de campo antes de colar: em alguns exports o nome da "
          "coluna carrega cliente, projeto ou fornecedor.")
    return []


def _onde_esta(nome, sugestao):
    if sugestao:
        return ("O cabecalho parece estar na linha %d: confirme e rode de novo "
                "com --cabecalho-de %s:%d" % (sugestao, nome, sugestao))
    return ("Nenhuma das primeiras %d linhas uteis tem cara de cabecalho: abra o "
            "arquivo, ache a linha de cabecalho e rode com --cabecalho-de %s:N"
            % (LINHAS_EXAMINADAS, nome))


# ------------------------------------------------------------- fontes nomeadas

def fonte_de_pagina(fonte):
    return normalizar(fonte).startswith("site:")


def conferir_fonte_de_pagina(fonte):
    n = normalizar(fonte)
    if "copiado em" not in n and "copiada em" not in n:
        return ("fonte de pagina sem data de copia. A forma e [derivada de site: "
                "<endereco>, copiado em <data>], porque pagina muda e a ficha "
                "precisa dizer de quando e o que afirma")
    if not RE_DIGITO.search(fonte):
        return "fonte de pagina com data sem numero nenhum"
    return None


def achar_fonte(nome, bases):
    alvo = Path(nome)
    candidatos = [alvo] if alvo.is_absolute() else [b / alvo for b in bases]
    for c in candidatos:
        try:
            if c.is_file():
                return c
        except OSError:
            continue
    return None


# ----------------------------------------------------- conferencia do rascunho

def separar_prefixo_de_secao(texto):
    """A lacuna pode dizer em que secao o buraco fica, na forma
    "<secao>: <o que falta>". Devolve (secao ou None, texto sem o prefixo)."""
    if ":" not in texto:
        return None, texto
    bruto, resto = texto.split(":", 1)
    chave = normalizar(bruto)
    if chave in NORM_SECOES and resto.strip():
        return NORM_SECOES[chave], resto.strip()
    return None, texto


def conferir_rascunho(caminho, fontes_declaradas=()):
    """Le o rascunho e classifica cada linha de conteudo dentro do laco.
    Devolve um dicionario com contadores, problemas, corpo a gravar e lacunas."""
    r = {
        "contas": dict((b, 0) for b in BALDES),
        "vistas": 0,
        "problemas": [],
        "corpo": [],
        "lacunas": [],
        "fontes": [],
        "fontes_ausentes": [],
        "por_secao": dict((s, 0) for s in SECOES),
        "encoding": "",
        "conteudo_visto": 0,
        "conteudo_escrito": 0,
        "promovidas": 0,
    }
    texto, enc = ler_texto(caminho)
    r["encoding"] = enc
    linhas = em_linhas(texto)
    bases = [Path.cwd(), Path(caminho).resolve().parent]
    declaradas = set(normalizar(x) for x in fontes_declaradas)

    def marcar(balde):
        r["contas"][balde] += 1

    def escrever(linha_bruta):
        r["corpo"].append(linha_bruta)
        r["conteudo_escrito"] += 1

    def proxima_util(k):
        for j in range(k + 1, len(linhas)):
            s = linhas[j].strip()
            if s == "" or SEPARADOR.match(s):
                continue
            return s
        return None

    secao = None
    vistas_secao = set()
    pos_lacunas = None
    ultima_sem_fonte = None

    for idx, bruta in enumerate(linhas):
        n = idx + 1
        l = bruta.strip()
        if l == "" or SEPARADOR.match(l):
            r["corpo"].append(bruta.rstrip())
            continue

        if l.startswith("## "):
            titulo = l[3:].strip()
            chave = normalizar(titulo)
            if chave not in NORM_SECOES:
                r["problemas"].append(
                    "linha %d: secao desconhecida %r. As secoes da ficha sao: %s"
                    % (n, titulo, "; ".join(SECOES)))
                r["vistas"] += 1
                marcar("titulo_inesperado")
                continue
            oficial = NORM_SECOES[chave]
            if oficial in vistas_secao:
                r["problemas"].append(
                    "linha %d: a secao %r aparece duas vezes. Duas secoes com o "
                    "mesmo nome fazem uma das duas sumir na leitura" % (n, oficial))
                r["vistas"] += 1
                marcar("titulo_inesperado")
                continue
            vistas_secao.add(oficial)
            secao = oficial
            r["corpo"].append("## " + oficial)
            if oficial == SECAO_LACUNAS:
                pos_lacunas = len(r["corpo"])
            continue

        # O rodape da rodada anterior comeca a linha e nao termina em marca de
        # origem. Frase do rodape citada DENTRO de uma linha de fato e conteudo,
        # e conteudo nao pode ser descartado por conter uma frase.
        if l.startswith(PREFIXO_RODAPE) and not TAG_FIM.search(l):
            r["vistas"] += 1
            marcar("rodape_antigo")
            continue

        if l.startswith("#"):
            if secao is None:
                r["vistas"] += 1
                marcar("cabecalho_antigo")
            else:
                r["problemas"].append(
                    "linha %d: titulo inesperado dentro da secao %r: %s"
                    % (n, secao, l[:60]))
                r["vistas"] += 1
                marcar("titulo_inesperado")
            continue

        if secao is None:
            r["vistas"] += 1
            if META_ANTIGA.match(l) or normalizar(l).startswith("atencao:"):
                marcar("cabecalho_antigo")
            else:
                marcar("fora_de_secao")
                r["problemas"].append(
                    "linha %d: texto antes da primeira secao, fora de qualquer "
                    "secao: %s" % (n, l[:60]))
            continue

        # Daqui para baixo e linha de conteudo. Uma e so uma classificacao, e
        # toda uma delas vai para o corpo: e a segunda identidade.
        r["vistas"] += 1
        r["conteudo_visto"] += 1
        escrever(bruta.rstrip())
        r["por_secao"][secao] += 1
        if secao == SECAO_LACUNAS:
            pos_lacunas = len(r["corpo"])

        # Um fato, uma linha fisica, marca no fim. Linha de conteudo que nao
        # comeca com marcador de lista e continuacao da linha de cima, e
        # continuacao terminada em marca virava fato com texto pela metade.
        if not MARCA.match(l):
            marcar("continuacao")
            if ultima_sem_fonte is not None:
                r["problemas"].append(
                    "linha %d: parece continuacao da linha %d. Um fato, uma linha "
                    "fisica, marca de origem no fim: junte as duas numa linha so"
                    % (n, ultima_sem_fonte))
            else:
                r["problemas"].append(
                    "linha %d: linha de conteudo sem marcador de lista. Toda linha "
                    "da ficha comeca com \"- \" e termina na marca de origem: %s"
                    % (n, l[:60]))
            ultima_sem_fonte = None
            continue

        texto_item = MARCA.sub("", l).strip()

        if len(TAG_QUALQUER.findall(l)) > 1:
            marcar("tag_invalida")
            r["problemas"].append(
                "linha %d: mais de uma marca de origem na mesma linha. Uma linha, "
                "uma origem: %s" % (n, l[:60]))
            ultima_sem_fonte = None
            continue

        m = TAG_FIM.search(l)
        if m is None:
            if TAG_QUALQUER.search(l):
                marcar("tag_invalida")
                r["problemas"].append(
                    "linha %d: a marca de origem nao esta no fim da linha: %s"
                    % (n, l[:60]))
                ultima_sem_fonte = None
            elif COLCHETE_FIM.search(l):
                marcar("tag_desconhecida")
                r["problemas"].append(
                    "linha %d: a linha termina em colchete que nao e marca de "
                    "origem valida. As tres validas sao [derivada de <arquivo>], "
                    "[respondida pela pessoa] e [lacuna]: %s" % (n, l[:60]))
                ultima_sem_fonte = None
            else:
                marcar("sem_fonte")
                if texto_item == "":
                    r["problemas"].append(
                        "linha %d: marcador de lista sem texto" % n)
                    ultima_sem_fonte = None
                else:
                    seguinte = proxima_util(idx)
                    continua = (seguinte is not None
                                and not seguinte.startswith("#")
                                and not MARCA.match(seguinte)
                                and TAG_FIM.search(seguinte) is not None)
                    if continua:
                        r["problemas"].append(
                            "linha %d: a marca de origem esta na linha de baixo, "
                            "nao nesta. Um fato, uma linha fisica: junte as duas "
                            "numa linha so" % n)
                    else:
                        r["problemas"].append(
                            "linha %d: linha de fato sem origem nomeada: %s"
                            % (n, l[:60]))
                    ultima_sem_fonte = n
            continue

        ultima_sem_fonte = None
        achado = m.group(0)
        if "derivada de" in achado:
            fonte = (m.group("fonte") or "").strip()
            if fonte == "":
                marcar("tag_desconhecida")
                r["problemas"].append(
                    "linha %d: [derivada de] sem o nome do arquivo de origem" % n)
            elif secao == SECAO_LACUNAS:
                marcar("fato_em_lacunas")
                r["problemas"].append(
                    "linha %d: linha de fato dentro de %r. A pagina de lacunas so "
                    "carrega o que nao se sabe" % (n, SECAO_LACUNAS))
            else:
                marcar("derivadas")
                if fonte not in r["fontes"]:
                    r["fontes"].append(fonte)
                # Requisito de clausula nao sai de certificado: certificado da
                # norma, edicao, escopo, planta e validade.
                if ("clausula" in normalizar(texto_item)
                        and "certificad" in normalizar(fonte)):
                    r["problemas"].append(
                        "linha %d: requisito de clausula com marca de derivada de "
                        "certificado. Certificado da norma, edicao, escopo, planta "
                        "e validade, e nao da o requisito clausula por clausula. "
                        "Escopo e validade ficam derivados do certificado; o "
                        "requisito sai como [respondida pela pessoa], quando "
                        "alguem leu a clausula na copia da empresa, ou como "
                        "[lacuna]" % n)
                # Fonte nomeada tem de existir. Lei de ferro 1: nada entra como
                # fato sem fonte nomeada, e nome de arquivo inventado e o caminho
                # mais barato para um fato sem lastro.
                if fonte_de_pagina(fonte):
                    falta = conferir_fonte_de_pagina(fonte)
                    if falta:
                        r["problemas"].append("linha %d: %s" % (n, falta))
                elif normalizar(fonte) in declaradas:
                    if fonte not in r["fontes_ausentes"]:
                        r["fontes_ausentes"].append(fonte)
                elif achar_fonte(fonte, bases) is None:
                    r["problemas"].append(
                        "linha %d: a fonte %r nao existe no diretorio de trabalho "
                        "nem ao lado do rascunho. Ou o nome esta errado, ou o fato "
                        "nao tem lastro. Sendo arquivo que ficou na maquina de "
                        "quem derivou, rode com --fonte-declarada %r, que grava a "
                        "ausencia na ficha em vez de esconder" % (n, fonte, fonte))
        elif "respondida pela pessoa" in achado:
            if secao == SECAO_LACUNAS:
                marcar("fato_em_lacunas")
                r["problemas"].append(
                    "linha %d: linha de fato dentro de %r. A pagina de lacunas so "
                    "carrega o que nao se sabe" % (n, SECAO_LACUNAS))
            else:
                marcar("respondidas")
        else:
            if secao == SECAO_LACUNAS:
                marcar("lacunas_secao")
            else:
                marcar("lacunas_em_fato")
            limpo = TAG_FIM.sub("", texto_item).strip()
            declarada, limpo = separar_prefixo_de_secao(limpo)
            if declarada is None:
                declarada = secao
            r["lacunas"].append({"secao": declarada, "texto": limpo,
                                 "origem": secao, "linha": n})

    for s in SECOES:
        if s not in vistas_secao:
            r["problemas"].append(
                "falta a secao %r. A ficha tem as seis: %s" % (s, "; ".join(SECOES)))

    for s in SECOES_FATO:
        if s in vistas_secao and r["por_secao"][s] == 0:
            r["problemas"].append(
                "a secao %r existe e esta vazia. Secao vazia nao e secao "
                "preenchida: ou entra fato com origem, ou entra lacuna" % s)

    promover(r, pos_lacunas)

    soma = sum(r["contas"].values())
    r["soma"] = soma
    if soma != r["vistas"]:
        r["problemas"].append(
            "a contabilidade da leitura nao fecha: %d linha(s) vista(s) contra %d "
            "classificada(s). Alguma linha entrou e nao foi contada em nenhum "
            "balde" % (r["vistas"], soma))

    if r["conteudo_escrito"] - r["promovidas"] != r["conteudo_visto"]:
        r["problemas"].append(
            "a segunda identidade nao fecha: %d linha(s) de conteudo lida(s) "
            "dentro de secao contra %d escrita(s) no corpo da ficha, fora as %d "
            "promovida(s). Linha classificada e nao gravada e dado perdido com "
            "rodada aparentemente boa"
            % (r["conteudo_visto"], r["conteudo_escrito"] - r["promovidas"],
               r["promovidas"]))

    r["linhas_de_fato"] = (r["contas"]["derivadas"] + r["contas"]["respondidas"]
                           + r["contas"]["lacunas_em_fato"]
                           + r["contas"]["lacunas_secao"])
    r["distintas"] = lacunas_distintas(r)
    conferir_lacunas_na_ficha(r)
    return r


def promover(r, pos_lacunas):
    """Copia para a secao "Lacunas declaradas" a lacuna que so existe dentro de
    uma secao de fato. Sem isso, a secao que as outras nove leem como lista de
    buracos ficaria menor do que a propria ficha reconhece, e a alternativa
    antiga era reprovar a rodada e mandar a pessoa digitar de novo."""
    if pos_lacunas is None:
        return
    ja = set(normalizar(x["texto"]) for x in r["lacunas"]
             if x["origem"] == SECAO_LACUNAS)
    novas = []
    for x in r["lacunas"]:
        if x["origem"] == SECAO_LACUNAS:
            continue
        chave = normalizar(x["texto"])
        if chave in ja:
            continue
        ja.add(chave)
        novas.append("- %s: %s [lacuna]" % (x["secao"], x["texto"]))
    if not novas:
        return
    r["corpo"][pos_lacunas:pos_lacunas] = novas
    r["conteudo_escrito"] += len(novas)
    r["promovidas"] += len(novas)


def lacunas_distintas(r):
    """A mesma lacuna costuma aparecer na secao de fato e repetida na lista. A
    pagina junta as duas e mantem o nome da secao de fato, que diz onde o buraco
    fica. Juntar e declarado, nao silencioso: as duas contagens saem."""
    distintas = []
    vistas = {}
    for x in r["lacunas"]:
        chave = normalizar(x["texto"])
        if chave in vistas:
            i = vistas[chave]
            if distintas[i]["secao"] == SECAO_LACUNAS and x["secao"] != SECAO_LACUNAS:
                distintas[i] = dict(x)
            continue
        vistas[chave] = len(distintas)
        distintas.append(dict(x))
    return distintas


def conferir_lacunas_na_ficha(r):
    """Terceira conta: toda lacuna lida tem de estar na secao Lacunas declaradas
    do corpo que vai ser gravado, e na pagina. Depois da promocao isso vale por
    construcao, e a conta continua aqui porque promocao quebrada precisa parar a
    rodada, nao sair com codigo 0."""
    dentro = set()
    secao = None
    for linha in r["corpo"]:
        l = linha.strip()
        if l.startswith("## "):
            secao = NORM_SECOES.get(normalizar(l[3:].strip()))
            continue
        if secao != SECAO_LACUNAS or not l:
            continue
        item = MARCA.sub("", l).strip()
        item = TAG_FIM.sub("", item).strip()
        _, item = separar_prefixo_de_secao(item)
        dentro.add(normalizar(item))
    faltando = [x["texto"] for x in r["distintas"]
                if normalizar(x["texto"]) not in dentro]
    if faltando:
        r["problemas"].append(
            "%d lacuna(s) reconhecida(s) na ficha nao aparece(m) na secao %r do "
            "corpo que seria gravado, e e essa secao que as outras nove leem como "
            "lista de buracos: %s" % (len(faltando), SECAO_LACUNAS,
                                      "; ".join(x[:50] for x in faltando)))


# ------------------------------------------------------------------- gravacao

def fazer_copia(destino):
    """Copia carimbada ao lado. Nunca sobrescreve copia: duas gravacoes no mesmo
    segundo recebem sufixo, senao a segunda apagaria a primeira em silencio, e o
    passo 6 pede exatamente gravar de novo ate zerar."""
    p = Path(destino)
    if not p.is_file():
        return None
    carimbo = datetime.now().strftime("%Y%m%d-%H%M%S")
    alvo = p.parent / ("%s.%s%s" % (p.stem, carimbo, p.suffix))
    k = 1
    while alvo.exists():
        alvo = p.parent / ("%s.%s-%02d%s" % (p.stem, carimbo, k, p.suffix))
        k += 1
        if k > 99:
            alvo = p.parent / ("%s.%s-%s%s" % (p.stem, carimbo,
                                               datetime.now().strftime("%f"),
                                               p.suffix))
            break
    alvo.write_bytes(p.read_bytes())
    return alvo


def gravar_atomico(destino, texto):
    """Escreve num temporario ao lado do destino e troca com os.replace. Ou a
    ficha anterior continua inteira, ou a nova esta inteira. Nunca meio arquivo."""
    p = Path(destino)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.parent / ("%s.tmp-%d" % (p.name, os.getpid()))
    try:
        with open(str(tmp), "w", encoding="utf-8", newline="\n") as f:
            f.write(texto)
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp), str(p))
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def montar_ficha(r, destino, status, agora, documento=None):
    fontes = "; ".join(r["fontes"]) if r["fontes"] else "entrevista com a pessoa da area"
    cab = [
        "# Ficha da área",
        "",
        "status: %s" % status,
        "gravada em: %s" % agora,
        "ficha em: %s" % destino,
    ]
    if documento:
        cab.append("documento do gabarito: %s" % documento)
    cab += [
        "linhas de fato: %d (derivadas de arquivo %d, respondidas pela pessoa %d, "
        "lacunas %d)" % (r["linhas_de_fato"], r["contas"]["derivadas"],
                         r["contas"]["respondidas"],
                         r["contas"]["lacunas_em_fato"] + r["contas"]["lacunas_secao"]),
        "lacunas distintas: %d" % len(r["distintas"]),
    ]
    if r["promovidas"]:
        cab.append("linhas promovidas pelo script: %d (lacuna declarada dentro de "
                   "secao de fato, copiada para Lacunas declaradas)" % r["promovidas"])
    cab.append("fontes nomeadas: %s" % fontes)
    if r["fontes_ausentes"]:
        cab.append("fontes declaradas sem arquivo no disco: %s"
                   % "; ".join(r["fontes_ausentes"]))
    if not documento:
        cab.append(AVISO_NAO_CONFERIDA)
    cab.append("")
    corpo = list(r["corpo"])
    while corpo and corpo[0].strip() == "":
        corpo.pop(0)
    while corpo and corpo[-1].strip() == "":
        corpo.pop()
    pe = ["", RODAPE.format(fonte=fontes), ""]
    return "\n".join(cab + corpo + pe)


def escapar(t):
    return t.replace("|", "\\|")


def montar_lacunas(r, destino, status, agora):
    linhas = [
        "# Lacunas declaradas da área",
        "",
        "status da ficha: %s" % status,
        "gravada em: %s" % agora,
        "ficha completa em: %s" % destino,
        "",
    ]
    distintas = r["distintas"]
    if distintas:
        afetadas = sorted(set(x["secao"] for x in distintas))
        frase = ("São %d lacunas, em %d das seis seções da ficha. Cada uma é uma "
                 "pergunta que a área ainda não responde sobre si mesma."
                 % (len(distintas), len(afetadas)))
        repetidas = len(r["lacunas"]) - len(distintas)
        if repetidas:
            frase += (" A ficha tem %d linha(s) de lacuna: %d aparece(m) na seção "
                      "de fato e repetida(s) na lista." % (len(r["lacunas"]),
                                                           repetidas))
        if r["promovidas"]:
            frase += (" %d lacuna(s) estava(m) só dentro de uma seção de fato e foi "
                      "copiada pelo script para a seção Lacunas declaradas."
                      % r["promovidas"])
        linhas.append(frase)
        linhas += ["", "| Seção | O que não se sabe hoje | Quem do kit roda pior "
                       "sem isso |", "|---|---|---|"]
        for x in distintas:
            linhas.append("| %s | %s | %s |"
                          % (escapar(x["secao"]), escapar(x["texto"]),
                             escapar(CONSUMIDORAS.get(x["secao"], "as nove"))))
    else:
        linhas.append("Nenhuma lacuna declarada nesta rodada.")
        linhas.append("")
        linhas.append("Numa primeira ficha isso quase sempre quer dizer que a "
                      "entrevista inferiu em vez de registrar. Antes de usar a "
                      "ficha, responda: o que você não conseguiria explicar da sua "
                      "própria área se alguém perguntasse agora?")
    fontes = "; ".join(r["fontes"]) if r["fontes"] else "entrevista com a pessoa da area"
    linhas += ["", RODAPE.format(fonte=fontes), ""]
    return "\n".join(linhas)


# ----------------------------------------------------------------------- main

def separar_alvo(bruto, padrao):
    """Aceita ARQUIVO:LINHA. Arquivo que existe com dois-pontos no nome ganha."""
    m = RE_ARQ_LINHA.match(bruto)
    if m and not Path(bruto).exists():
        return m.group("arq"), int(m.group("linha"))
    return bruto, padrao


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Grava a ficha da area em caminho absoluto e confere que ela "
                    "esta inteira.")
    ap.add_argument("--cabecalho-de", action="append", default=[], metavar="ARQUIVO",
                    help="le so a linha de cabecalho do export e imprime os campos. "
                         "Aceita ARQUIVO:LINHA para dizer em que linha esta o "
                         "cabecalho daquele arquivo")
    ap.add_argument("--linha-do-cabecalho", type=int, default=0, metavar="N",
                    help="numero da linha do cabecalho, quando o export tem "
                         "preambulo. Vale para um arquivo por rodada: com mais de "
                         "um, use a forma ARQUIVO:LINHA")
    ap.add_argument("--rascunho", metavar="ARQUIVO",
                    help="rascunho da ficha, em markdown, com as seis secoes")
    ap.add_argument("--ficha", default=FICHA_PADRAO, metavar="CAMINHO",
                    help="destino da ficha. Padrao: %s" % FICHA_PADRAO)
    ap.add_argument("--saida-lacunas", default=None, metavar="CAMINHO",
                    help="pagina de lacunas. Padrao: lacunas-da-area-<data>.md "
                         "no diretorio atual")
    ap.add_argument("--fonte-declarada", action="append", default=[],
                    metavar="ARQUIVO",
                    help="fonte nomeada que ficou na maquina de quem derivou e nao "
                         "esta neste disco. A ausencia e gravada no cabecalho da "
                         "ficha em vez de passar calada")
    ap.add_argument("--conferida-contra", default=None, metavar="DOCUMENTO",
                    help="documento ja escrito pela pessoa contra o qual a ficha "
                         "foi conferida linha a linha. Tem de existir no disco")
    ap.add_argument("--em", default=None, metavar="AAAA-MM-DD",
                    help="data da conferencia contra o documento, em AAAA-MM-DD, "
                         "nao futura")
    ap.add_argument("--linhas-conferidas", type=int, default=None, metavar="N",
                    help="quantas linhas de fato foram conferidas. Precisa ser "
                         "igual ao total de linhas de fato da ficha")
    a = ap.parse_args(argv)

    if a.cabecalho_de and a.rascunho:
        print("erro: --cabecalho-de e --rascunho sao modos diferentes. Rode um "
              "de cada vez", file=sys.stderr)
        return 3
    if not a.cabecalho_de and not a.rascunho:
        ap.print_help()
        return 3

    if a.cabecalho_de:
        if len(a.cabecalho_de) > 1 and a.linha_do_cabecalho:
            print("erro: --linha-do-cabecalho e um valor so e voce informou %d "
                  "arquivos. Um export com preambulo e outro sem nao tem a mesma "
                  "linha de cabecalho: use a forma ARQUIVO:LINHA em cada "
                  "--cabecalho-de, ou rode um arquivo por vez"
                  % len(a.cabecalho_de), file=sys.stderr)
            return 3
        problemas = []
        for bruto in a.cabecalho_de:
            arq, linha = separar_alvo(bruto, a.linha_do_cabecalho)
            print("")
            problemas += derivar_cabecalho(arq, linha)
        if problemas:
            print("")
            for p in problemas:
                print("PROBLEMA: %s" % p, file=sys.stderr)
            print("Derivacao reprovada. Nenhuma ficha foi gravada e nenhum campo "
                  "duvidoso foi impresso: codigo de saida 3.", file=sys.stderr)
            return 3
        print("")
        print("Derivacao apenas. Nenhuma ficha foi gravada: codigo de saida 4.")
        return 4

    rasc = Path(a.rascunho)
    if not rasc.is_file():
        print("erro: rascunho nao encontrado: %s" % a.rascunho, file=sys.stderr)
        return 3
    destino = Path(a.ficha)
    try:
        mesmo = rasc.resolve() == destino.resolve()
    except OSError:
        mesmo = False
    if mesmo:
        print("erro: o rascunho e o proprio destino. Copie a ficha para outro "
              "nome, edite a copia e rode sobre ela", file=sys.stderr)
        return 3

    conf = None
    doc_gabarito = None
    if a.conferida_contra or a.em or a.linhas_conferidas is not None:
        faltando = []
        if not a.conferida_contra:
            faltando.append("--conferida-contra")
        if not a.em:
            faltando.append("--em")
        if a.linhas_conferidas is None:
            faltando.append("--linhas-conferidas")
        if faltando:
            print("erro: para marcar a ficha como conferida faltam: %s. Conferencia "
                  "sem documento, sem data e sem contagem nao e conferencia"
                  % ", ".join(faltando), file=sys.stderr)
            return 3
        doc_gabarito = achar_fonte(a.conferida_contra,
                                   [Path.cwd(), rasc.resolve().parent])
        if doc_gabarito is None:
            print("erro: o documento do gabarito %r nao existe no diretorio de "
                  "trabalho nem ao lado do rascunho. O carimbo de conferida afirma "
                  "que alguem leu a ficha linha a linha contra esse documento: o "
                  "documento tem de existir para a afirmacao ser rastreavel"
                  % a.conferida_contra, file=sys.stderr)
            return 3
        try:
            dia = datetime.strptime(a.em.strip(), "%Y-%m-%d").date()
        except ValueError:
            print("erro: --em precisa ser uma data em AAAA-MM-DD. Recebi %r, que "
                  "nao e data e nao vira carimbo" % a.em, file=sys.stderr)
            return 3
        if dia > date.today():
            print("erro: --em traz a data futura %s. Conferencia que ainda nao "
                  "aconteceu nao se carimba" % a.em, file=sys.stderr)
            return 3
        conf = True

    try:
        r = conferir_rascunho(rasc, a.fonte_declarada)
    except OSError as e:
        print("erro: rascunho %s nao pode ser lido: %s" % (a.rascunho, e),
              file=sys.stderr)
        return 3

    print("rascunho: %s (encoding %s)" % (a.rascunho, r["encoding"]))
    print("linhas classificadas: %d" % r["vistas"])
    for b in BALDES:
        print("  %s: %d" % (b, r["contas"][b]))
    print("identidade: vistas %d = soma dos baldes %d %s"
          % (r["vistas"], r["soma"], "fecha" if r["vistas"] == r["soma"] else "NAO FECHA"))
    escritas = r["conteudo_escrito"] - r["promovidas"]
    print("identidade 2: conteudo dentro de secao visto %d = escrito no corpo %d %s"
          % (r["conteudo_visto"], escritas,
             "fecha" if r["conteudo_visto"] == escritas else "NAO FECHA"))
    print("linhas de fato: %d" % r["linhas_de_fato"])
    print("lacunas: %d linha(s), %d distinta(s), %d promovida(s) para a secao %s"
          % (len(r["lacunas"]), len(r["distintas"]), r["promovidas"], SECAO_LACUNAS))
    if r["fontes"]:
        print("fontes nomeadas: %s" % "; ".join(r["fontes"]))
    if r["fontes_ausentes"]:
        print("fontes declaradas sem arquivo no disco: %s"
              % "; ".join(r["fontes_ausentes"]))
    if r["contas"]["cabecalho_antigo"] or r["contas"]["rodape_antigo"]:
        print("bloco de cabecalho e rodape da rodada anterior descartado e "
              "regravado: %d linha(s)"
              % (r["contas"]["cabecalho_antigo"] + r["contas"]["rodape_antigo"]))

    if conf and a.linhas_conferidas != r["linhas_de_fato"]:
        r["problemas"].append(
            "a ficha tem %d linha(s) de fato e --linhas-conferidas diz %d. A lei do "
            "gabarito pede a ficha inteira conferida contra o documento, nao uma "
            "amostra" % (r["linhas_de_fato"], a.linhas_conferidas))

    if r["problemas"]:
        print("")
        for p in r["problemas"]:
            print("PROBLEMA: %s" % p, file=sys.stderr)
        print("%d problema(s). Nada foi gravado: a ficha anterior, se existir, "
              "continua como estava." % len(r["problemas"]), file=sys.stderr)
        return 3

    agora = datetime.now().strftime("%Y-%m-%d %H:%M")
    doc_abs = str(doc_gabarito.resolve()) if doc_gabarito else None
    if conf:
        status = ("conferida contra %s em %s, %d linha(s)"
                  % (Path(a.conferida_contra).name, a.em, a.linhas_conferidas))
    else:
        status = "rascunho, nao conferida contra documento da pessoa"

    caminho_lac = a.saida_lacunas or ("lacunas-da-area-%s.md"
                                      % datetime.now().strftime("%Y-%m-%d"))
    destino_abs = str(destino if destino.is_absolute() else destino.resolve())

    copia = fazer_copia(destino)
    copia_lac = fazer_copia(caminho_lac)
    gravar_atomico(destino, montar_ficha(r, destino_abs, status, agora, doc_abs))
    gravar_atomico(caminho_lac, montar_lacunas(r, destino_abs, status, agora))

    print("")
    print("ficha gravada em: %s" % destino_abs)
    if copia:
        print("versao anterior guardada em: %s" % copia)
    print("pagina de lacunas: %s" % Path(caminho_lac).resolve())
    if copia_lac:
        print("pagina de lacunas anterior guardada em: %s" % copia_lac)
    print("status: %s" % status)
    if doc_abs:
        print("documento do gabarito: %s" % doc_abs)

    if not r["distintas"]:
        print("")
        print("ALERTA: a ficha foi gravada sem nenhuma lacuna declarada. Numa "
              "primeira ficha isso quase sempre quer dizer que a entrevista "
              "inferiu em vez de registrar. Codigo de saida 5.")
        return 5
    return 0


if __name__ == "__main__":
    sys.exit(main())
