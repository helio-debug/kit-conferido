#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do ficha.py.

Biblioteca padrao apenas. Cada caso roda num diretorio temporario, com esse
diretorio como diretorio de trabalho, e o destino da ficha e sempre dentro dele:
nenhum caso escreve em ~/.kit-industrial.

Os casos foram escritos a partir de uma pergunta, nao a partir da lista de
funcionalidades: existe caminho em que o script sai com sucesso tendo perdido
dado, ignorado dado ou vazado dado? Cada resposta "sim" virou um caso.

  - preambulo de relatorio na primeira linha, que faria a derivacao devolver um
    campo so e sair bem
  - preambulo retangular, com o titulo do relatorio na coluna A e as outras
    vazias, que passa pela contagem de campos e faz a ficha dizer que o sistema
    exporta um campo chamado "Relatorio de Apontamento"
  - arquivo que nao e texto delimitado, xlsx e pdf, que decodificado como texto
    imprime byte comprimido do arquivo como se fosse nome de campo
  - linha de cabecalho apontada para uma linha de dado, que imprimiria nome de
    pessoa no chat sob a frase "nenhum valor de dado foi lido"
  - frase do rodape citada dentro de uma linha de fato, que era descartada por
    substring e nunca chegava ao corpo da ficha, com a rodada saindo com 0
  - arquivo vazio, que devolveria zero campo como se fosse resultado
  - linha de fato sem origem, que entraria na ficha como fato sem fonte
  - fato quebrado em duas linhas fisicas, em que a metade de baixo terminava em
    marca valida e era contada como fato derivado com o texto pela metade
  - fonte nomeada que nao existe no disco, que assina a procedencia da ficha com
    um nome de arquivo inventado
  - texto antes da primeira secao, que some do laco se o laco so olhar dentro
    de secao
  - secao presente e vazia, que passaria num teste de "tem todas as secoes"
  - lacuna declarada so na secao de fato, que precisa chegar a secao que as
    outras nove leem sem reprovar a rodada e sem pedir digitacao de novo
  - requisito de clausula com marca de derivada de certificado, que e deducao
    carimbada como fato
  - ficha sem nenhuma lacuna, que sairia com 0 parecendo area sem duvida
  - conferencia de gabarito declarada sobre uma amostra, sobre documento que nao
    existe, ou com data que nao e data
  - duas gravacoes no mesmo segundo, que sobrescreviam a copia de seguranca
  - a propria ficha gravada usada como rascunho da rodada seguinte, que nao pode
    perder nem duplicar lacuna
  - rascunho reprovado com ficha anterior no destino, que nao pode perder a
    ficha anterior nem escrever a pagina de lacunas
  - o outro lado da mesma doenca: teste de cara de cabecalho que travaria um
    arquivo legitimo sem saida, no caso do nome de campo repetido

Rode depois de qualquer mudanca no ficha.py:

    python3 ~/.claude/skills/ficha-da-area/scripts/testar.py

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\ficha-da-area\\scripts\\testar.py"

Sai com 1 se algum caso falhar.
"""

import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
FICHA = AQUI / "ficha.py"

falhas = []
total = [0]


def registrar(nome, erros):
    total[0] += 1
    if erros:
        falhas.append(nome)
        print("FALHOU  %s" % nome)
        for e in erros:
            print("        %s" % e)
    else:
        print("ok      %s" % nome)


SECOES_PADRAO = [
    ("Área e posto",
     ['- Área: usinagem, planta 2. Posto: coordenação de produção. '
      '[respondida pela pessoa]']),
    ("Vocabulário local",
     ['- OP é ordem de produção e OS é ordem de serviço da manutenção. '
      '[derivada de procedimento-antigo.pdf]']),
    ("Sistemas e o que cada um exporta",
     ['- O sistema de chão de fábrica exporta apontamento em CSV com 14 campos. '
      '[derivada de export-apontamento.csv]']),
    ("Ritos e prazos",
     ['- Reunião de produção toda segunda às 7h30, com a manutenção. '
      '[respondida pela pessoa]']),
    ("Normas e certificações",
     ['- Escopo certificado: usinagem e montagem, planta 2. Validade até 03/2027. '
      '[derivada de certificado-iso.pdf]',
      '- NORMA-X, edição 2020, cláusula 4.2: exige controle da produção e da '
      'prestação de serviço. Confira na edição vigente da sua empresa. '
      '[respondida pela pessoa]']),
    ("Lacunas declaradas",
     ['- Não sei quem responde pelo cadastro de item no sistema. [lacuna]']),
]

# Fontes nomeadas no rascunho padrao. Existem no diretorio da rodada porque a
# lei de ferro 1 pede fonte que existe, e o script confere.
FONTES_PADRAO = ("procedimento-antigo.pdf", "export-apontamento.csv",
                 "certificado-iso.pdf", "apresentacao-da-area.pptx")


def criar_fontes(base, nomes=FONTES_PADRAO):
    for n in nomes:
        (base / n).write_text("conteudo de teste\n", encoding="utf-8")


def montar(trocas=None, remover=(), prefixo="", sufixo=""):
    """Monta um rascunho a partir do padrao. trocas: {secao: [linhas]}.
    No padrao, a linha de Ritos e prazos cai sempre na linha 11."""
    trocas = trocas or {}
    partes = []
    if prefixo:
        partes.append(prefixo.rstrip("\n"))
    for nome, linhas in SECOES_PADRAO:
        if nome in remover:
            continue
        partes.append("## " + nome)
        for l in trocas.get(nome, linhas):
            partes.append(l)
        partes.append("")
    if sufixo:
        partes.append(sufixo.rstrip("\n"))
    return "\n".join(partes) + "\n"


def ler(p):
    try:
        return Path(p).read_text(encoding="utf-8")
    except OSError:
        return None


def conferir(erros, alvo, conteudo, texto, deve):
    if conteudo is None:
        if deve:
            erros.append("nao existe o arquivo %s, entao nao contem %r"
                         % (alvo, texto))
        return
    if deve and texto not in conteudo:
        erros.append("%s nao contem %r" % (alvo, texto))
    if not deve and texto in conteudo:
        erros.append("%s contem %r e nao devia" % (alvo, texto))


def rodar_rascunho(nome, texto_rascunho, esperado, checagens, extra=(),
                   ficha_previa=None, duas_vezes=None, fontes=FONTES_PADRAO):
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        criar_fontes(base, fontes)
        rasc = base / "rascunho.md"
        rasc.write_text(texto_rascunho, encoding="utf-8")
        alvo = base / "destino" / "ficha-da-area.md"
        lac = base / "lacunas.md"
        if ficha_previa is not None:
            alvo.parent.mkdir(parents=True, exist_ok=True)
            alvo.write_text(ficha_previa, encoding="utf-8")
        cmd = [sys.executable, str(FICHA), "--rascunho", str(rasc),
               "--ficha", str(alvo), "--saida-lacunas", str(lac)] + list(extra)
        if duas_vezes is not None:
            primeira = subprocess.run(cmd, capture_output=True, text=True,
                                      cwd=str(base))
            if primeira.returncode != 0:
                registrar(nome, ["a primeira rodada falhou com codigo %d: %s"
                                 % (primeira.returncode,
                                    primeira.stderr.strip()[:300])])
                return
            rasc.write_text(duas_vezes, encoding="utf-8")
        p = subprocess.run(cmd, capture_output=True, text=True, cwd=str(base))
        erros = []
        if p.returncode != esperado:
            erros.append("codigo de saida %d, esperado %d. stderr: %s"
                         % (p.returncode, esperado, p.stderr.strip()[:400]))
        fontes_saida = {"stdout": p.stdout, "stderr": p.stderr,
                        "ficha": ler(alvo), "lacunas": ler(lac)}
        for alvo_nome, trecho, deve in checagens:
            if alvo_nome == "lacunas_ausente":
                if lac.exists():
                    erros.append("a pagina de lacunas foi escrita numa rodada "
                                 "que devia ter parado antes de gravar")
                continue
            if alvo_nome == "backup":
                copias = list((base / "destino").glob("ficha-da-area.*.md"))
                conteudo = "\n".join(x for x in (ler(c) for c in copias) if x)
                conferir(erros, "backup", conteudo or None, trecho, deve)
                continue
            conferir(erros, alvo_nome, fontes_saida[alvo_nome], trecho, deve)
        sobras = list(base.rglob("*.tmp-*"))
        if sobras:
            erros.append("sobrou arquivo temporario: %s" % sobras)
        registrar(nome, erros)


def rodar_cabecalho(nome, arquivos, esperado, checagens, extra=()):
    """arquivos: lista de (nome, conteudo) ou (nome, conteudo, sufixo). Conteudo
    em bytes e gravado como binario, para o caso do xlsx."""
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        cmd = [sys.executable, str(FICHA)]
        for item in arquivos:
            n, conteudo = item[0], item[1]
            sufixo = item[2] if len(item) > 2 else ""
            a = base / n
            if isinstance(conteudo, bytes):
                a.write_bytes(conteudo)
            else:
                a.write_text(conteudo, encoding="utf-8")
            cmd += ["--cabecalho-de", str(a) + sufixo]
        cmd += list(extra)
        p = subprocess.run(cmd, capture_output=True, text=True, cwd=str(base))
        erros = []
        if p.returncode != esperado:
            erros.append("codigo de saida %d, esperado %d. stderr: %s"
                         % (p.returncode, esperado, p.stderr.strip()[:400]))
        fontes = {"stdout": p.stdout, "stderr": p.stderr}
        for alvo_nome, trecho, deve in checagens:
            conferir(erros, alvo_nome, fontes[alvo_nome], trecho, deve)
        registrar(nome, erros)


# --------------------------------------------------------------------- casos

def main():
    print("Derivacao de cabecalho")

    rodar_cabecalho(
        "cabecalho simples: imprime campo, nao imprime valor",
        [("export.csv",
          "Codigo;Descricao;Qtde;Data\n0012;EIXO SEGREDO;10;01/02/2026\n")],
        4,
        [("stdout", "Codigo", True),
         ("stdout", "campos: 4", True),
         ("stdout", "EIXO SEGREDO", False),
         ("stdout", "01/02/2026", False),
         ("stdout", "Nenhuma ficha foi gravada", True)])

    rodar_cabecalho(
        "preambulo de relatorio nao vira cabecalho de um campo so",
        [("export.csv",
          "Relatorio de ordens em carteira\n\n"
          "Codigo;Descricao;Qtde;Data\n0012;EIXO;10;01/02/2026\n"
          "0013;BUCHA;4;02/02/2026\n")],
        3,
        [("stderr", "export.csv:3", True),
         ("stdout", "campos: 1", False),
         ("stdout", "Relatorio de ordens em carteira", False)])

    rodar_cabecalho(
        "preambulo resolvido com --linha-do-cabecalho",
        [("export.csv",
          "Relatorio de ordens em carteira\n\n"
          "Codigo;Descricao;Qtde;Data\n0012;EIXO;10;01/02/2026\n")],
        4,
        [("stdout", "linha do cabecalho: 3", True),
         ("stdout", "campos: 4", True),
         ("stdout", "EIXO", False)],
        extra=["--linha-do-cabecalho", "3"])

    # Achado gravissimo: preambulo retangular. O CSV do Excel preenche a coluna A
    # com o titulo do relatorio e deixa as outras vazias, entao a contagem de
    # campos bate com a do corpo e a guarda antiga nao disparava.
    rodar_cabecalho(
        "preambulo retangular do Excel nao vira campo chamado Relatorio",
        [("apontamento.csv",
          "Relatorio de Apontamento de Producao;;;;;;;\n"
          "Filtro: 01/08/2026 a 31/08/2026;;;;;;;\n"
          ";;;;;;;\n"
          "OP;Item;Descricao;Qtde;Operador;Maquina;Data;Turno\n"
          "104882;PN-4471;FLANGE;120;OPERADOR A;TCN-07;03/08/2026;1\n")],
        3,
        [("stderr", "campos estao vazios", True),
         ("stderr", "apontamento.csv:4", True),
         ("stdout", "Relatorio de Apontamento de Producao", False),
         ("stdout", "coluna sem nome", False)])

    # Achado gravissimo: --linha-do-cabecalho errado por uma linha imprimia a
    # linha de dado, com nome de pessoa, sob a frase de que nada foi lido.
    rodar_cabecalho(
        "linha apontada para linha de dado e recusada sem imprimir a linha",
        [("apontamento.csv",
          "Relatorio de Apontamento;;;;;;;\n"
          ";;;;;;;\n"
          "OP;Item;Descricao;Qtde;Operador;Maquina;Data;Turno\n"
          "104882;PN-4471;FLANGE USINADA;120;JOAO P FERREIRA;TCN-07;03/08/2026;1\n",
          ":4")],
        3,
        [("stderr", "nao tem cara de cabecalho", True),
         ("stderr", "puramente numerico", True),
         ("stdout", "JOAO P FERREIRA", False),
         ("stdout", "104882", False),
         ("stdout", "campos: 8", False)])

    # Achado gravissimo: xlsx decodificado como latin-1 imprimia byte comprimido
    # do arquivo como nome de campo, e sharedStrings.xml carrega conteudo real.
    rodar_cabecalho(
        "xlsx e recusado pela extensao antes de qualquer leitura",
        [("Apontamento_Agosto.xlsx",
          b"PK\x03\x04\x14\x00\x08\x00\x08\x00ruido\tbinario\tqualquer"
          b"\x00xl/workbook.xml")],
        3,
        [("stderr", "Salve como CSV", True),
         ("stderr", "planilha do Excel", True),
         ("stdout", "campos:", False),
         ("stdout", "workbook", False)])

    rodar_cabecalho(
        "arquivo zipado com extensao de texto e recusado pela assinatura",
        [("export.csv",
          b"PK\x03\x04\x14\x00ruido;binario;aqui\nmais;lixo;ainda\n")],
        3,
        [("stderr", "assinatura", True),
         ("stderr", "Salve como CSV", True),
         ("stdout", "campos:", False)])

    rodar_cabecalho(
        "arquivo vazio nao devolve zero campo como resultado",
        [("export.csv", "\n\n\n")],
        3,
        [("stderr", "vazio", True),
         ("stdout", "campos:", False)])

    rodar_cabecalho(
        "sem separador reconhecivel, reporta em vez de supor um campo",
        [("export.csv", "linha um\nlinha dois\nlinha tres\n")],
        3,
        [("stderr", "separador", True),
         ("stdout", "campos: 1", False)])

    rodar_cabecalho(
        "coluna sem nome vira alerta, nao passa calada",
        [("export.csv", "Codigo;;Qtde\n0012;x;10\n")],
        4,
        [("stdout", "coluna sem nome", True),
         ("stdout", "ALERTA", True)])

    # Procurado por conta propria, do outro lado da mesma doenca: o teste de cara
    # de cabecalho nao pode travar arquivo legitimo sem saida. Nome de campo
    # repetido existe em cabecalho de verdade, entao alerta, nunca recusa.
    rodar_cabecalho(
        "cabecalho com nome de campo repetido sai com alerta, nao com recusa",
        [("export.csv", "Data;Item;Data;Qtde\nx;y;z;w\n")],
        4,
        [("stdout", "campos: 4", True),
         ("stdout", "aparece(m) em mais de uma coluna", True),
         ("stdout", "ALERTA", True),
         ("stderr", "nao tem cara de cabecalho", False)])

    # Achado menor: um export com preambulo e outro sem nao rodavam na mesma
    # chamada, porque --linha-do-cabecalho e um valor so.
    rodar_cabecalho(
        "dois exports com cabecalho em linhas diferentes rodam numa chamada",
        [("apontamento.csv",
          "Relatorio;;;\n;;;\nOP;Item;Qtde;Data\n1;PN-1;2;03/08/2026\n", ":3"),
         ("cadastro.csv",
          "Item;Descricao;Unidade\nPN-1;FLANGE;PC\n")],
        4,
        [("stdout", "linha do cabecalho: 3", True),
         ("stdout", "linha do cabecalho: 1", True),
         ("stdout", "Unidade", True),
         ("stdout", "FLANGE", False)])

    rodar_cabecalho(
        "--linha-do-cabecalho com dois arquivos e recusado, em vez de valer para os dois",
        [("a.csv", "Relatorio;;;\n;;;\nOP;Item;Qtde;Data\n1;PN-1;2;03/08/2026\n"),
         ("b.csv", "Item;Descricao;Unidade\nPN-1;FLANGE;PC\n")],
        3,
        [("stderr", "ARQUIVO:LINHA", True)],
        extra=["--linha-do-cabecalho", "3"])

    print("")
    print("Gravacao da ficha")

    rodar_rascunho(
        "rascunho completo grava ficha e pagina de lacunas",
        montar(), 0,
        [("ficha", "## Área e posto", True),
         ("ficha", "status: rascunho, nao conferida", True),
         ("ficha", "linhas de fato: 7", True),
         ("ficha", "lacunas distintas: 1", True),
         ("ficha", "fontes nomeadas: procedimento-antigo.pdf", True),
         ("ficha", "Não substitui responsabilidade técnica.", True),
         ("ficha", "ATENÇÃO: ficha não conferida", True),
         ("lacunas", "cadastro de item", True),
         ("lacunas", "| Seção | O que não se sabe hoje | Quem do kit roda pior", True),
         ("stdout", "identidade: vistas 7 = soma dos baldes 7 fecha", True),
         ("stdout", "identidade 2: conteudo dentro de secao visto 7 = escrito no "
                    "corpo 7 fecha", True),
         ("stdout", "ficha gravada em:", True)])

    # Achado gravissimo: a frase do rodape era procurada por substring solto, e
    # qualquer linha de fato que a citasse era descartada em silencio, com a
    # identidade fechando e a rodada saindo com 0.
    rodar_rascunho(
        "frase do rodape dentro de uma linha de fato e conteudo, nao rodape",
        montar(trocas={"Sistemas e o que cada um exporta": [
            '- O sistema de chão de fábrica exporta apontamento em CSV. '
            '[derivada de export-apontamento.csv]',
            '- Todo relatório que sai daqui leva a linha Gerado com apoio de IA a '
            'partir de, exigida pela qualidade. [respondida pela pessoa]']}),
        0,
        [("stdout", "rodape_antigo: 0", True),
         ("stdout", "identidade 2: conteudo dentro de secao visto 8 = escrito no "
                    "corpo 8 fecha", True),
         ("ficha", "exigida pela qualidade", True),
         ("ficha", "linhas de fato: 8", True)])

    rodar_rascunho(
        "secao faltando reprova, nao toca na ficha anterior e nao grava lacunas",
        montar(remover=("Normas e certificações",)), 3,
        [("stderr", "falta a secao", True),
         ("ficha", "SENTINELA ANTIGA", True),
         ("lacunas_ausente", "", True)],
        ficha_previa="SENTINELA ANTIGA\n")

    rodar_rascunho(
        "linha de fato sem origem reprova com o numero da linha",
        montar(trocas={"Ritos e prazos": ["- Reunião de produção toda segunda."]}),
        3,
        [("stderr", "linha 11: linha de fato sem origem nomeada", True),
         ("stdout", "sem_fonte: 1", True),
         ("lacunas_ausente", "", True)])

    # Achado grave: os exemplos da referencia vinham quebrados em duas linhas
    # fisicas. A metade de baixo terminava em marca valida e era contada como
    # fato derivado, com o texto pela metade.
    rodar_rascunho(
        "fato quebrado em duas linhas fisicas reprova e a continuacao nao vira fato",
        montar(trocas={"Sistemas e o que cada um exporta": [
            "- Apontamento de produção: export em CSV com 8 campos, separador "
            "ponto e vírgula:",
            "  OP, Item, Descricao, Qtde, Operador, Maquina, Data, Turno. "
            "[derivada de export-apontamento.csv]"]}),
        3,
        [("stderr", "a marca de origem esta na linha de baixo", True),
         ("stderr", "parece continuacao da linha 8", True),
         ("stdout", "continuacao: 1", True),
         ("stdout", "derivadas: 2", True),
         ("stdout", "derivadas: 3", False),
         ("stdout", "export-apontamento.csv", False),
         ("lacunas_ausente", "", True)])

    # Achado grave: a marca [derivada de X] era aceita com X sendo qualquer
    # texto, e o nome inventado ia para a linha de procedencia que a pessoa
    # assina.
    rodar_rascunho(
        "fonte nomeada que nao existe no disco reprova antes de gravar",
        montar(trocas={"Ritos e prazos": [
            "- Fechamento no terceiro dia útil. [derivada de IT-042-rev3.pdf]"]}),
        3,
        [("stderr", "nao existe no diretorio de trabalho", True),
         ("stderr", "IT-042-rev3.pdf", True),
         ("lacunas_ausente", "", True)])

    rodar_rascunho(
        "fonte que ficou na outra maquina entra declarada, nao calada",
        montar(trocas={"Ritos e prazos": [
            "- Fechamento no terceiro dia útil. [derivada de IT-042-rev3.pdf]"]}),
        0,
        [("ficha", "fontes declaradas sem arquivo no disco: IT-042-rev3.pdf", True),
         ("stdout", "fontes declaradas sem arquivo no disco", True)],
        extra=["--fonte-declarada", "IT-042-rev3.pdf"])

    rodar_rascunho(
        "fonte de pagina sem data de copia reprova",
        montar(trocas={"Área e posto": [
            "- A planta 2 produz componentes usinados. [derivada de site: "
            "empresa.example/unidades]"]}),
        3,
        [("stderr", "sem data de copia", True)])

    rodar_rascunho(
        "fonte de pagina com endereco e data e aceita sem existir no disco",
        montar(trocas={"Área e posto": [
            "- A planta 2 produz componentes usinados. [derivada de site: "
            "empresa.example/unidades, copiado em 2026-09-20]"]}),
        0,
        [("ficha", "site: empresa.example/unidades", True)])

    rodar_rascunho(
        "secao presente e vazia reprova",
        montar(trocas={"Vocabulário local": []}), 3,
        [("stderr", "existe e esta vazia", True)])

    # Achado grave: a trava por contagem reprovava rascunho correto. Agora a
    # lacuna que so existe na secao de fato e copiada para a secao que as outras
    # nove leem, e a rodada segue.
    rodar_rascunho(
        "lacuna so na secao de fato e promovida, em vez de reprovar a rodada",
        montar(trocas={
            "Sistemas e o que cada um exporta": [
                "- O sistema de chão de fábrica exporta apontamento. "
                "[derivada de export-apontamento.csv]",
                "- Não sei se o ERP exporta a ordem em CSV. [lacuna]",
                "- Não sei quem tem licença de export. [lacuna]"]}),
        0,
        [("stderr", "escondendo lacuna", False),
         ("stdout", "lacunas: 3 linha(s), 3 distinta(s), 2 promovida(s)", True),
         ("ficha", "- Sistemas e o que cada um exporta: Não sei se o ERP exporta "
                   "a ordem em CSV. [lacuna]", True),
         ("ficha", "linhas promovidas pelo script: 2", True),
         ("lacunas", "São 3 lacunas, em 2 das seis seções", True),
         ("lacunas", "| Sistemas e o que cada um exporta | Não sei quem tem "
                     "licença de export.", True),
         ("lacunas", "copiada pelo script", True)])

    rodar_rascunho(
        "lacuna com o prefixo da secao sai na pagina com a secao certa",
        montar(trocas={"Lacunas declaradas": [
            "- Sistemas e o que cada um exporta: não sei se o sistema de "
            "manutenção exporta. [lacuna]"]}),
        0,
        [("lacunas", "| Sistemas e o que cada um exporta | não sei se o sistema "
                     "de manutenção exporta.", True),
         ("lacunas", "| Lacunas declaradas |", False),
         ("ficha", "linhas promovidas pelo script", False)])

    # Achado grave do segundo revisor: requisito de clausula nao sai de
    # certificado, e o exemplo da propria referencia fazia isso.
    rodar_rascunho(
        "requisito de clausula com marca de derivada de certificado reprova",
        montar(trocas={"Normas e certificações": [
            "- NORMA-X, edição 2020, cláusula 4.2: exige controle das condições "
            "de produção. Confira na edição vigente da sua empresa. "
            "[derivada de certificado-iso.pdf]"]}),
        3,
        [("stderr", "requisito de clausula", True),
         ("stderr", "escopo, planta", True),
         ("lacunas_ausente", "", True)])

    rodar_rascunho(
        "ficha sem nenhuma lacuna grava com codigo 5, nunca 0",
        montar(trocas={"Lacunas declaradas": []}), 5,
        [("stdout", "ALERTA", True),
         ("ficha", "## Lacunas declaradas", True),
         ("lacunas", "Nenhuma lacuna declarada", True),
         ("lacunas", "inferiu em vez de registrar", True)])

    rodar_rascunho(
        "lacuna repetida na lista conta uma vez e a juncao e declarada",
        montar(trocas={
            "Sistemas e o que cada um exporta": [
                "- O chão de fábrica exporta apontamento. "
                "[derivada de export-apontamento.csv]",
                "- Não sei se o ERP exporta a ordem em CSV. [lacuna]"],
            "Lacunas declaradas": [
                "- Não sei se o ERP exporta a ordem em CSV. [lacuna]",
                "- Não sei quem responde pelo cadastro de item. [lacuna]"]}),
        0,
        [("lacunas", "São 2 lacunas", True),
         ("lacunas", "3 linha(s) de lacuna", True),
         ("lacunas", "| Sistemas e o que cada um exporta | Não sei se o ERP", True),
         ("ficha", "lacunas distintas: 2", True),
         ("ficha", "linhas promovidas pelo script", False)])

    rodar_rascunho(
        "texto antes da primeira secao nao some do laco",
        montar(prefixo="Anotei isso na reunião e depois organizo."), 3,
        [("stderr", "fora de qualquer", True),
         ("stdout", "fora_de_secao: 1", True),
         ("stdout", "fecha", True)])

    rodar_rascunho(
        "marca de origem no meio da linha reprova",
        montar(trocas={"Ritos e prazos":
                       ["- [lacuna] não sei o dia da reunião de manutenção."]}),
        3,
        [("stderr", "nao esta no fim da linha", True)])

    rodar_rascunho(
        "colchete parecido com marca de origem reprova em vez de passar",
        montar(trocas={"Ritos e prazos":
                       ["- Reunião toda segunda. [derivado do procedimento]"]}),
        3,
        [("stderr", "nao e marca de origem valida", True),
         ("stdout", "tag_desconhecida: 1", True)])

    rodar_rascunho(
        "[derivada de] sem nome de arquivo reprova",
        montar(trocas={"Ritos e prazos": ["- Reunião toda segunda. [derivada de ]"]}),
        3,
        [("stderr", "sem o nome do arquivo", True)])

    rodar_rascunho(
        "duas marcas na mesma linha reprovam",
        montar(trocas={"Ritos e prazos":
                       ["- Reunião toda segunda. [respondida pela pessoa] "
                        "[derivada de ata.pdf]"]}),
        3,
        [("stderr", "mais de uma marca", True)])

    rodar_rascunho(
        "fato dentro da secao de lacunas reprova",
        montar(trocas={"Lacunas declaradas":
                       ["- O dono do cadastro é a engenharia. "
                        "[respondida pela pessoa]"]}),
        3,
        [("stderr", "linha de fato dentro", True)])

    rodar_rascunho(
        "secao repetida reprova",
        montar(sufixo="## Ritos e prazos\n- Outra coisa. [respondida pela pessoa]"),
        3,
        [("stderr", "aparece duas vezes", True)])

    rodar_rascunho(
        "marcador de lista sem texto reprova",
        montar(trocas={"Ritos e prazos":
                       ["- Reunião toda segunda. [respondida pela pessoa]", "-"]}),
        3,
        [("stderr", "linha 12: marcador de lista sem texto", True)])

    rodar_rascunho(
        "BOM e fim de linha do Windows nao escondem as secoes",
        "﻿" + montar().replace("\n", "\r\n"), 0,
        [("ficha", "## Área e posto", True),
         ("stdout", "linhas de fato: 7", True)])

    print("")
    print("Lei do gabarito")

    rodar_rascunho(
        "conferencia de gabarito por amostra e recusada",
        montar(), 3,
        [("stderr", "7 linha(s) de fato", True),
         ("stderr", "nao uma amostra", True),
         ("lacunas_ausente", "", True)],
        extra=["--conferida-contra", "apresentacao-da-area.pptx",
               "--em", "2026-09-20", "--linhas-conferidas", "2"])

    rodar_rascunho(
        "conferencia sem data e sem contagem e recusada",
        montar(), 3,
        [("stderr", "faltam: --em, --linhas-conferidas", True)],
        extra=["--conferida-contra", "apresentacao-da-area.pptx"])

    # Achado medio: o carimbo era afirmacao pura. Documento que nunca existiu e
    # data que nao e data eram aceitos e gravados no status da ficha.
    rodar_rascunho(
        "conferencia contra documento que nao existe e recusada",
        montar(), 3,
        [("stderr", "nao existe no diretorio de trabalho", True),
         ("lacunas_ausente", "", True)],
        extra=["--conferida-contra", "apresentacao-que-nao-existe.pptx",
               "--em", "2026-09-20", "--linhas-conferidas", "7"])

    rodar_rascunho(
        "data de conferencia que nao e data e recusada",
        montar(), 3,
        [("stderr", "AAAA-MM-DD", True),
         ("lacunas_ausente", "", True)],
        extra=["--conferida-contra", "apresentacao-da-area.pptx",
               "--em", "ontem de tarde", "--linhas-conferidas", "7"])

    rodar_rascunho(
        "data de conferencia no futuro e recusada",
        montar(), 3,
        [("stderr", "data futura", True)],
        extra=["--conferida-contra", "apresentacao-da-area.pptx",
               "--em", "2099-01-01", "--linhas-conferidas", "7"])

    rodar_rascunho(
        "conferencia completa carimba o status e o caminho do documento",
        montar(), 0,
        [("ficha", "conferida contra apresentacao-da-area.pptx em 2026-09-20, "
                   "7 linha(s)", True),
         ("ficha", "documento do gabarito: ", True),
         ("ficha", "ATENÇÃO: ficha não conferida", False),
         ("lacunas", "conferida contra", True)],
        extra=["--conferida-contra", "apresentacao-da-area.pptx",
               "--em", "2026-09-20", "--linhas-conferidas", "7"])

    print("")
    print("Historico e reuso")

    rodar_rascunho(
        "segunda rodada guarda a versao anterior ao lado",
        montar(), 0,
        [("backup", "cadastro de item", True),
         ("stdout", "versao anterior guardada em:", True),
         ("ficha", "consumo de chapa", True),
         ("ficha", "cadastro de item", False)],
        duas_vezes=montar(trocas={
            "Lacunas declaradas":
                ["- Não sei o consumo de chapa por ordem. [lacuna]"]}))

    rodar_rascunho(
        "ficha gerada reaproveitada como rascunho nao duplica cabecalho",
        montar(prefixo="# Ficha da área\n\nstatus: rascunho, nao conferida\n"
                       "gravada em: 2026-09-19 10:00\n"
                       "fontes nomeadas: export-apontamento.csv",
               sufixo="Gerado com apoio de IA a partir de export-apontamento.csv. "
                      "Revisar antes de assinar. Não substitui responsabilidade "
                      "técnica."),
        0,
        [("stdout", "descartado e regravado", True),
         ("stdout", "cabecalho_antigo: 4", True),
         ("stdout", "rodape_antigo: 1", True),
         ("ficha", "gravada em: 2026-09-19", False)])

    # Achado medio: a copia de seguranca tinha resolucao de um segundo e o passo
    # 6 manda gravar de novo ate zerar. Duas gravacoes no mesmo segundo apagavam
    # a copia anterior.
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        criar_fontes(base)
        rasc = base / "rascunho.md"
        rasc.write_text(montar(), encoding="utf-8")
        alvo = base / "destino" / "ficha-da-area.md"
        lac = base / "lacunas.md"
        cmd = [sys.executable, str(FICHA), "--rascunho", str(rasc),
               "--ficha", str(alvo), "--saida-lacunas", str(lac)]
        erros = []
        for i in range(3):
            p = subprocess.run(cmd, capture_output=True, text=True, cwd=str(base))
            if p.returncode != 0:
                erros.append("rodada %d saiu com %d: %s"
                             % (i + 1, p.returncode, p.stderr.strip()[:200]))
        copias = sorted((base / "destino").glob("ficha-da-area.*.md"))
        if len(copias) != 2:
            erros.append("tres gravacoes deviam deixar 2 copias da ficha, deixaram "
                         "%d: %s" % (len(copias), [c.name for c in copias]))
        copias_lac = sorted(base.glob("lacunas.*.md"))
        if len(copias_lac) != 2:
            erros.append("a pagina de lacunas tambem precisa de copia: esperava 2, "
                         "achei %d" % len(copias_lac))
        registrar("tres gravacoes no mesmo segundo deixam duas copias, nao uma",
                  erros)

    # Procurado por conta propria, atras da mesma doenca: a ficha gravada volta
    # como rascunho na rodada de atualizacao. A linha promovida pelo script nao
    # pode ser promovida de novo, nem contada duas vezes, nem perdida.
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        criar_fontes(base)
        rasc = base / "rascunho.md"
        rasc.write_text(montar(trocas={
            "Sistemas e o que cada um exporta": [
                "- O chão de fábrica exporta apontamento. "
                "[derivada de export-apontamento.csv]",
                "- Não sei se o ERP exporta a ordem em CSV. [lacuna]"]}),
            encoding="utf-8")
        alvo = base / "destino" / "ficha-da-area.md"
        lac = base / "lacunas.md"
        cmd = [sys.executable, str(FICHA), "--rascunho", str(rasc),
               "--ficha", str(alvo), "--saida-lacunas", str(lac)]
        erros = []
        p1 = subprocess.run(cmd, capture_output=True, text=True, cwd=str(base))
        if p1.returncode != 0:
            erros.append("a primeira rodada saiu com %d: %s"
                         % (p1.returncode, p1.stderr.strip()[:300]))
        if "1 promovida(s)" not in p1.stdout:
            erros.append("a primeira rodada devia promover 1 lacuna")
        volta = base / "volta.md"
        volta.write_text(ler(alvo) or "", encoding="utf-8")
        cmd2 = [sys.executable, str(FICHA), "--rascunho", str(volta),
                "--ficha", str(alvo), "--saida-lacunas", str(lac)]
        p2 = subprocess.run(cmd2, capture_output=True, text=True, cwd=str(base))
        if p2.returncode != 0:
            erros.append("a ficha gravada nao volta como rascunho: codigo %d, %s"
                         % (p2.returncode, p2.stderr.strip()[:300]))
        if "0 promovida(s)" not in p2.stdout:
            erros.append("a segunda rodada nao devia promover nada de novo: %s"
                         % p2.stdout[-400:])
        depois = ler(alvo) or ""
        if "lacunas distintas: 2" not in depois:
            erros.append("a volta mudou a contagem de lacunas distintas")
        if depois.count("Não sei se o ERP exporta a ordem em CSV.") != 2:
            erros.append("a lacuna promovida foi duplicada ou perdida na volta: %d "
                         "ocorrencia(s)"
                         % depois.count("Não sei se o ERP exporta a ordem em CSV."))
        registrar("a ficha gravada volta como rascunho sem duplicar nem perder "
                  "lacuna", erros)

    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        criar_fontes(base)
        r = base / "rascunho.md"
        r.write_text(montar(), encoding="utf-8")
        p = subprocess.run([sys.executable, str(FICHA), "--rascunho", str(r),
                            "--ficha", str(r), "--saida-lacunas",
                            str(base / "lac.md")],
                           capture_output=True, text=True, cwd=str(base))
        erros = []
        if p.returncode != 3:
            erros.append("codigo %d, esperado 3" % p.returncode)
        if "o proprio destino" not in p.stderr:
            erros.append("stderr nao avisa que o rascunho e o destino: %s"
                         % p.stderr.strip()[:200])
        registrar("rascunho apontado para o proprio destino e recusado", erros)

    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        criar_fontes(base)
        r = base / "rascunho.md"
        r.write_text(montar(), encoding="utf-8")
        e = base / "export.csv"
        e.write_text("Codigo;Qtde\n1;2\n", encoding="utf-8")
        p = subprocess.run([sys.executable, str(FICHA), "--rascunho", str(r),
                            "--cabecalho-de", str(e)],
                           capture_output=True, text=True, cwd=str(base))
        erros = []
        if p.returncode != 3:
            erros.append("codigo %d, esperado 3" % p.returncode)
        if "modos diferentes" not in p.stderr:
            erros.append("stderr nao explica que os dois modos nao rodam juntos")
        registrar("os dois modos juntos sao recusados", erros)

    print("")
    print("Contrato do proprio script")
    fonte = FICHA.read_text(encoding="utf-8")
    erros = []
    if '".kit-industrial" / "ficha-da-area.md"' not in fonte:
        erros.append("o destino padrao deixou de ser "
                     "~/.kit-industrial/ficha-da-area.md")
    if "os.replace" not in fonte:
        erros.append("a gravacao deixou de ser atomica: os.replace sumiu")
    if "identidade 2" not in fonte:
        erros.append("a segunda identidade sumiu: linha classificada e nao "
                     "gravada volta a passar")
    if "EXTENSOES_RECUSADAS" not in fonte:
        erros.append("a recusa de arquivo que nao e texto delimitado sumiu")
    if "Não substitui responsabilidade técnica." not in fonte:
        erros.append("o rodape do script voltou a divergir do rodape contratado "
                     "na SKILL.md")
    for imp in ("import pandas", "import requests", "import openpyxl",
                "import numpy", "import yaml", "urllib.request"):
        if imp in fonte:
            erros.append("dependencia fora da biblioteca padrao, ou rede: %s" % imp)
    registrar("contrato do script", erros)

    print("")
    print("%d caso(s), %d falha(s)" % (total[0], len(falhas)))
    for f in falhas:
        print("FALHOU: %s" % f)
    return 1 if falhas else 0


if __name__ == "__main__":
    sys.exit(main())
