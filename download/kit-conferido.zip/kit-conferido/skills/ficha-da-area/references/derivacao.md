# O que cada fonte entrega, e onde ela engana

Catálogo das fontes que a pessoa já tem na mão. Cada uma dá um pedaço da ficha sem
custar pergunta. Leia antes de perguntar qualquer coisa: pergunta feita sobre o que já
estava no arquivo queima a única coisa escassa aqui, que é a paciência de quem responde.

Cada item traz o que a fonte dá, o que ela não dá, a armadilha e como a linha entra na
ficha.

**Regra que vale para as cinco.** A linha da ficha carrega o nome do arquivo de onde
saiu, e nada mais entra como fato. Quando a fonte sugere mas não afirma, a linha vira
pergunta na entrevista ou lacuna. Nunca vira fato com a marca de derivada.

**Um fato, uma linha física, marca no fim.** O script confere linha por linha e a marca de
origem fecha a linha. Fato quebrado em duas linhas é reprovado: a de cima cai como linha
sem origem e a de baixo como continuação. Os exemplos abaixo estão em linha única de
propósito, e podem ser copiados como estão.

**A fonte nomeada tem que existir.** O script procura cada arquivo citado no diretório de
trabalho e ao lado do rascunho, e para quando não acha: nome de arquivo plausível e
inexistente é o caminho mais barato para um fato sem lastro, e esse nome vai para a linha
de procedência que a pessoa assina. Arquivo que ficou na máquina de quem derivou entra com
`--fonte-declarada <arquivo>`, que grava a ausência no cabeçalho da ficha em vez de
esconder.

---

## 1. A linha de cabeçalho de um export

A fonte mais barata do kit. Uma linha de texto responde duas seções.

**Dá.** O nome de cada campo como o sistema o escreve, a quantidade de campos, o
separador, o encoding, e quase sempre o nome do sistema no nome do arquivo. Dá também
metade do vocabulário local: o sistema chama de `OP`, de `Ordem`, de `OF` ou de `Nº
Ordem`, e é esse o nome que a casa usa na tela.

**Não dá.** Quem consegue tirar o export, com que frequência, e se o export é completo
ou filtrado pela tela em que a pessoa estava. Isso é pergunta.

**Armadilha, e ela derruba a derivação inteira.** Export de ERP costuma vir com
preâmbulo: título do relatório na linha 1, filtros na 2, em branco na 3, cabeçalho real
na 4 ou na 6. Ler a linha 1 devolve um campo só, com o nome do relatório, e a ficha sai
dizendo que o sistema exporta um campo. O script para nesse caso e pede
a linha do cabeçalho na forma `--cabecalho-de <arquivo>:<linha>`, em vez de chutar. Ele
recusa também o preâmbulo retangular, que é o caso do CSV gerado pelo Excel: o título do
relatório na coluna A e as outras vazias, com a contagem de campos batendo com a do corpo.

**Segunda armadilha.** Coluna sem nome. Em export com separador no fim da linha, ou com
coluna técnica sem cabeçalho, aparece campo vazio. Coluna sem nome é coluna que some nas
etapas seguintes sem ninguém notar. O script alerta e a linha da ficha registra o fato.

**Terceira armadilha, e esta vaza dado.** Apontar a linha errada imprime uma linha de dado,
que costuma carregar nome de pessoa. O script testa a linha antes de imprimir, e recusa
quando acha campo puramente numérico, campo em formato de data ou caractere de controle. A
linha recusada não é impressa. Nome de campo repetido sai como alerta, porque também existe
em cabeçalho de verdade.

**Quarta armadilha.** O export chega em `.xlsx` na maioria das áreas. O script recusa pela
extensão e pela assinatura do arquivo, antes de ler um byte: salve como CSV a aba que você
usa e rode de novo. Decodificar planilha como texto imprime byte comprimido do arquivo com
cara de nome de campo, e dentro desse byte vai conteúdo real da planilha.

**Como entra na ficha.**

```
- Apontamento de produção: export em CSV com 8 campos, separador ponto e vírgula, campos OP, Item, Descricao, Qtde, Operador, Maquina, Data, Turno. [derivada de export-apontamento.csv]
```

---

## 2. Um procedimento antigo

POP, instrução de trabalho, manual de integração, plano de controle. Vale mesmo estando
desatualizado, e às vezes vale mais: o que ele descreve e não acontece mais é justamente
o que mudou.

**Dá.** O vocabulário da casa escrito por alguém da casa. Os ritos com nome e
periodicidade. Os postos envolvidos. A codificação de documento. A norma à qual o
procedimento responde, quando o cabeçalho diz. A frequência dos registros.

**Não dá.** Se aquilo ainda é feito assim. Procedimento é o que a empresa escreveu, não
o que a área faz hoje.

**Armadilha.** Copiar o procedimento para dentro da ficha. A ficha é uma página de
contexto, não um resumo do procedimento. Se a linha não muda o comportamento de nenhuma
das outras nove skills, ela não entra.

**Segunda armadilha.** Data de revisão. Procedimento revisado há seis anos numa área que
trocou de sistema há dois descreve um sistema que não existe. Confirme a data na
entrevista, e havendo dúvida a linha vira lacuna.

**Como entra na ficha.**

```
- "Parada" no procedimento significa máquina parada com apontamento aberto, e não intervalo de turno. [derivada de IT-042-rev3.pdf]
- Vocabulário local: confirmar se a IT-042 rev3, de 2020, ainda descreve o fluxo atual. [lacuna]
```

---

## 3. O site da empresa

**Esta skill não acessa a rede.** A pessoa cola o texto da página, ou salva a página num
arquivo. A fonte nomeada é o endereço mais a data em que o texto foi copiado, porque
página muda e a ficha precisa dizer de quando é o que ela afirma. A forma que o script
aceita é `[derivada de site: <endereco>, copiado em <data>]`: é a única fonte que não
precisa existir em disco, e por isso é a única em que a data é obrigatória.

**Dá.** O que a planta produz, as unidades, os mercados atendidos, os certificados que a
empresa exibe, e a nomenclatura pública das linhas de produto.

**Não dá.** Nada de dentro. Site diz o que a empresa quer que se leia sobre ela.
Capacidade, turno, gargalo e sistema não estão lá.

**Armadilha.** Texto de marketing entra na ficha como fato de operação. "Processo
totalmente automatizado" no site convive com apontamento em papel no chão de fábrica.
Da página entra o que é verificável e estável: produto, unidade, certificado exibido.

**Como entra na ficha.**

```
- A planta 2 produz componentes usinados para linha automotiva. [derivada de site: empresa.exemplo/unidades, copiado em 2026-09-20]
```

---

## 4. Um certificado

Certificado de sistema de gestão, certificado de cliente, certificado de calibração,
laudo de terceira parte.

**Dá.** A norma pelo número e pela edição, o escopo certificado escrito em uma frase, a
planta coberta, o organismo certificador e a validade. O escopo é a linha mais útil: ele
diz o que está dentro e o que ficou fora.

**Não dá.** Conformidade, e não dá o requisito da cláusula. Certificado é escopo e
validade, não é atendimento cláusula por cláusula. Conferir procedimento contra norma é
outra skill do kit, `padrao-conferido-contra-norma`.

**Regra explícita, e o script reprova quem a quebra.** Requisito de cláusula nunca deriva
de certificado. O que o certificado nomeia é norma, edição, escopo, planta, organismo e
validade: é isso que entra como `[derivada de <certificado>]`. O requisito da cláusula sai
como `[respondida pela pessoa]`, quando alguém leu a cláusula na cópia da empresa, ou como
`[lacuna]`. Linha que afirma o requisito com marca de derivada de certificado é dedução
carimbada como fato, que é a lei de ferro 2 quebrada.

**Armadilha, e esta é regra do kit inteiro.** Não se reproduz texto de norma. A ficha
cita a cláusula pelo número, diz o requisito em palavras próprias e manda conferir na
edição vigente da empresa. Norma é material licenciado, e a cópia que vale é a que a
empresa comprou.

**Segunda armadilha.** Certificado vencido, ou escopo que cobre outra planta. Confira a
validade e a planta antes de transformar em linha de fato.

**Como entra na ficha.**

```
- Escopo certificado: usinagem e montagem, planta 2. Validade até 03/2027. [derivada de certificado-iso-2024.pdf]
- NORMA-X, edição 2020, cláusula 4.2: exige controle das condições de produção e de prestação de serviço. Confira na edição vigente da sua empresa. [respondida pela pessoa]
- Normas e certificações: ninguém aqui leu a 4.2 na cópia vigente da empresa. [lacuna]
```

A primeira linha é o que o certificado diz. A segunda só existe porque alguém abriu a
cláusula na cópia da empresa e afirmou. Não tendo aberto, a segunda não entra e entra a
terceira.

NORMA-X é norma fictícia, e o exemplo usa fictícia de propósito. Escrever aqui o que uma
cláusula de norma real exige, sem a norma na mão e sem ninguém ter entregue o requisito,
é afirmar requisito que ninguém leu, num exemplo que vai ser copiado em toda rodada. Na
sua ficha entram o nome e a edição da norma que a sua empresa segue.

---

## 5. A planilha do indicador

A planilha que a pessoa atualiza para a reunião, ou o painel que ela alimenta.

**Dá.** Quais indicadores a área reporta de fato, com que periodicidade, em que unidade,
e de onde vêm os números, porque a coluna de origem quase sempre está lá. Dá também o
rito: a data de atualização revela a frequência real.

**Não dá.** Se o indicador presta, se a meta é acordada, nem se alguém decide alguma
coisa com ele. Medir o antes de uma tarefa é outra skill,
`linha-de-base-antes-de-automatizar`.

**Armadilha.** A planilha tem dez abas e três indicadores vivos. Entram na ficha os que
foram atualizados no último ciclo, e os outros viram lacuna com o nome.

**Onde a linha entra.** Em **Ritos e prazos**, porque o que a ficha guarda do indicador é o
rito: o que é reportado, com que periodicidade e em que reunião. A ficha não tem seção de
indicador, e medir o antes de uma tarefa é `linha-de-base-antes-de-automatizar`.

**Como entra na ficha.**

```
- Reporto OEE por célula, mensal, na reunião de produção, e o número vem do apontamento. [derivada de painel-producao-2026.xlsx]
- Ritos e prazos: não sei quem definiu a meta de OEE de 72%. [lacuna]
```

---

## O que nunca se deriva

Não entra na ficha, em nenhum modo, derivado de fonte nenhuma:

| Não entra | Por quê |
|---|---|
| Nome de pessoa | A ficha descreve posto e área. Posto sobrevive à troca de pessoa, e nome vira dado pessoal circulando em arquivo de contexto |
| Folha de pagamento, salário, remuneração individual | Não entra em nenhum modo do kit, nem no modo local |
| Preço de fornecedor identificado | Cotação tem skill própria, e preço com fornecedor nomeado não é contexto de área |
| Dado de cliente identificado | Mesmo motivo. O que entra é o tipo de cliente, não o cliente |
| Projeto sob sigilo | Entra pelo nome interno genérico, ou não entra |

A ficha é lida por todas as outras nove skills, em toda rodada. O que está nela circula
mais do que qualquer outro arquivo do kit. Esse é o motivo da lista acima ser curta e
dura.

---

## As três marcas de origem

Toda linha de fato termina em uma, e só uma, destas três:

| Marca | Quando |
|---|---|
| `[derivada de <arquivo>]` | Saiu de um arquivo que existe no disco, com o nome do arquivo. O script confere a existência |
| `[derivada de site: <endereco>, copiado em <data>]` | Texto colado de uma página. É a mesma marca, na forma que dispensa arquivo em disco e exige a data |
| `[respondida pela pessoa]` | Saiu da entrevista. A pessoa afirmou |
| `[lacuna]` | Ninguém sabe hoje. Fica registrada, nunca preenchida por inferência |

Linha sem marca não entra na ficha: o script para, mostra o número da linha e não grava
nada. Linha com duas marcas também para. Uma linha, uma origem, uma linha física.

A lacuna pode dizer em que seção o buraco fica, na forma `- <seção>: <o que falta>
[lacuna]`. É o que faz a página de lacunas apontar o lugar em vez de repetir o nome da
seção de lacunas. A lacuna declarada dentro de uma seção de fato é copiada pelo script para
a seção **Lacunas declaradas**, com o nome da seção de origem na frente, e a cópia sai
contada no relatório: nada some, e ninguém digita de novo.

O que não existe é uma quarta marca para "deduzi disso". Dedução sem afirmação é lacuna.
