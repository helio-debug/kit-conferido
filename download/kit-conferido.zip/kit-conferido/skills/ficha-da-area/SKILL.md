---
name: ficha-da-area
description: >
  Escreve a ficha da área em `~/.kit-industrial/ficha-da-area.md`, o arquivo de contexto
  que as outras nove skills do kit leem antes de começar: vocabulário local, sistemas e o
  que cada um exporta, ritos e prazos, normas, e a lista de lacunas declaradas. Não é
  formulário. Deriva o que dá para derivar da linha de cabeçalho de um export, de um
  procedimento antigo, do texto do site e de um certificado, e pergunta no máximo cinco
  coisas, só o que não deu para derivar. Cada linha da ficha carrega de onde veio, e o que
  ninguém sabe vira lacuna registrada em vez de palpite. Fecha com a página de lacunas
  declaradas, que é o que a pessoa mostra no mesmo dia. Use SEMPRE que aparecer: "monta a
  ficha da área", "configura o kit para a minha área", "as skills não conhecem meu
  vocabulário", "cadastra os sistemas que eu uso", "o Claude não sabe como a gente chama as
  coisas aqui", "preciso descrever a minha área", "o que o kit precisa saber da fábrica",
  "atualiza a ficha da área", "mudou o sistema, refaz a ficha". NÃO use para levantar
  processo, mapear fluxo ou montar diagnóstico: ela descreve o contexto em uma página,
  não analisa. NÃO use para indexar a pasta de documentos (indice-do-acervo-da-area),
  para conferir procedimento contra norma (padrao-conferido-contra-norma) nem para medir
  o número do antes (linha-de-base-antes-de-automatizar).
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. Esta é a única que **escreve**
`~/.kit-industrial/ficha-da-area.md`. As outras nove leem esse arquivo no primeiro passo
delas, e é por isso que a ficha não é documentação: é o que muda a saída das outras.

| Caso | Skill | Relação com esta |
|---|---|---|
| Dois arquivos que deveriam dizer a mesma coisa | `conferencia-entre-duas-fontes` | Lê a ficha para escolher a coluna-chave e nomear as colunas pelo nome da casa |
| Documento, PDF escaneado ou foto de folha preenchida à mão que precisa virar tabela | `extracao-de-documento-para-tabela` | Lê a ficha para saber os campos que a área espera |
| Caixa de e-mail que precisa ser triada | `triagem-de-caixa-de-email` | Lê a ficha para reconhecer sistema, rito e prazo citados nas mensagens |
| Propostas de fornecedores em unidades diferentes | `comparativo-de-cotacoes` | Lê a ficha para a unidade que a área usa |
| Refazer todo mês o mesmo relatório | `relatorio-recorrente` | Lê a ficha para os ritos e a data de fechamento |
| Registrar um desvio no formato que a empresa já usa | `registro-de-anomalia` | É a maior consumidora do vocabulário local |
| Procedimento vigente contra a cláusula da norma | `padrao-conferido-contra-norma` | Lê da ficha quais normas a empresa segue. Conformidade é lá, não aqui |
| O número do antes, antes de automatizar | `linha-de-base-antes-de-automatizar` | Lê da ficha o vocabulário, os sistemas e o que cada um exporta, que é onde o número do antes costuma já estar |
| Pasta de documentos que ninguém acha | `indice-do-acervo-da-area` | Ela lista os documentos da pasta. Esta aqui deriva dos documentos, não do índice: rode-a antes quando ninguém sabe o que existe |

---

# Ficha da área

A pessoa instala o kit e roda a primeira skill. A skill não sabe que `OP` ali é ordem de
produção, que "parada" não é intervalo, que o export do apontamento tem oito campos e que
o fechamento é no terceiro dia útil. Ela acerta assim mesmo, com mais pergunta e mais
erro de nome, e a pessoa corrige as mesmas coisas em toda conversa nova.

A ficha resolve isso uma vez. Ela é curta, mora em caminho fixo e é lida por todas as
outras nove.

**A versão anterior desta skill foi descartada**, e o motivo está escrito aqui para não
voltar: ela pedia um formulário longo e não devolvia nada que a pessoa mostrasse a
alguém. Esta versão faz o contrário. Deriva do que a pessoa já tem, pergunta no máximo
cinco coisas e fecha com a página de lacunas declaradas, que é uma página pronta para
levar para a mesa do chefe no mesmo dia.

Esta skill termina em arquivo. São dois, e os caminhos são informados:
`~/.kit-industrial/ficha-da-area.md` e `lacunas-da-area-<data>.md` no diretório de
trabalho. Resposta em prosa descrevendo a área é falha de execução.

**Ela não acessa a rede, não acessa ERP e não acessa servidor de arquivos.** Nem o site
da empresa: a pessoa cola o texto ou salva a página. Ela diz isso na cara antes de
começar.

---

## Leis de ferro

1. **Nada entra como fato sem fonte nomeada, e a fonte tem que existir.** Toda linha da
   ficha termina em `[derivada de <arquivo>]`, `[respondida pela pessoa]` ou `[lacuna]`, e
   ocupa uma linha física. Linha sem marca não é gravada: o script para, diz o número da
   linha e não escreve nada. O arquivo citado é procurado no disco, porque nome de arquivo
   plausível e inexistente é o caminho mais barato para um fato sem lastro, e esse nome vai
   para a linha de procedência que a pessoa assina. Fonte que ficou na outra máquina entra
   com `--fonte-declarada`, e a ausência fica gravada no cabeçalho da ficha.
2. **"Não sei" vira lacuna registrada, nunca preenchida por inferência.** Não existe uma
   quarta marca para "deduzi disso". Dedução sem afirmação é lacuna. Esta é a lei que
   torna a ficha confiável para as outras nove: elas podem tratar cada linha como fato
   porque o que não é fato está declarado como buraco.
3. **Deriva antes de perguntar, e pergunta no máximo cinco vezes.** Pergunta feita sobre
   o que já estava no arquivo queima a única coisa escassa aqui, que é a paciência de quem
   responde. Cinco é teto, não meta.
4. **A ficha não é diagnóstico.** Linha que não muda a saída de nenhuma das outras nove
   skills não entra. A ficha descreve o contexto em uma página; ela não analisa processo,
   não propõe melhoria e não classifica oportunidade.
5. **A página de lacunas sai na mesma rodada.** Ficha sem a lista do que a área não sabe
   sobre si mesma é metade do trabalho, e é a metade sem valor de demonstração.
6. **Enquanto não for conferida contra um documento que a pessoa já escreveu, a ficha diz
   isso na primeira linha.** O status é `rascunho, nao conferida`, e o script grava uma
   linha de `ATENÇÃO` no cabeçalho, dentro do arquivo, para o aviso viajar junto com a
   ficha em vez de depender de quem a lê.

---

## Passo 1: ver se a ficha já existe

As outras nove skills abrem lendo `~/.kit-industrial/ficha-da-area.md` e, não existindo,
declaram "rodando sem ficha da área" e seguem. **Esta é a exceção do kit: ela escreve esse
arquivo.** O passo 1 aqui é outro, e serve para não apagar o que já existe.

Confira se o arquivo existe:

```
cat ~/.kit-industrial/ficha-da-area.md
```

No PowerShell, `type "$env:USERPROFILE\.kit-industrial\ficha-da-area.md"`.

- **Não existe.** Esta é a primeira ficha. Diga isso na primeira linha da resposta.
- **Existe.** Esta rodada é atualização. Leia a ficha inteira, diga a data da gravação
  anterior e o status dela, e trate cada linha como candidata: o que continua verdadeiro
  permanece com a mesma marca de origem, o que mudou recebe marca nova, e o que ninguém
  confirma vira lacuna. Não reaproveite linha antiga sem alguém olhar para ela.

O script guarda a versão anterior ao lado, com carimbo de data e hora, sempre que grava
por cima, e faz o mesmo com a página de lacunas. Duas gravações no mesmo segundo não
disputam o mesmo nome de cópia. Nada é perdido em silêncio.

**Critério de conclusão:** a primeira linha da resposta diz "primeira ficha da área" ou
"atualizando a ficha gravada em <data>, status <status>".

---

## Passo 2: perguntar o que tem dentro antes de abrir arquivo

Antes de pedir qualquer arquivo, três perguntas, nesta ordem:

1. **O dado é sensível?** As cinco classes: nome de pessoa; folha de pagamento, salário e
   remuneração individual; preço de fornecedor identificado; dado de cliente
   identificado; projeto sob sigilo. Folha, salário e remuneração individual **não entram
   em nenhum modo**, nem no local: a ficha descreve posto e área, nunca pessoa. Se sim,
   ou se a pessoa não souber, vá para o modo de dado sensível e não leia o conteúdo.
   Ofereça sempre o modo derivado, que aqui é literal: a pessoa roda `--cabecalho-de` na
   máquina dela e cola apenas os nomes de campo.
2. **Esses arquivos podem sair da pasta de rede?** A decisão é da empresa, não do kit.
   Não podendo, tudo roda local e a pessoa cola só o que ela mesma escolher.
3. **Quais desses documentos você já tem aberto agora?** Não vale pedir documento que
   precisa ser caçado. A ficha é feita com o que está na mesa; o resto vira lacuna.

**Critério de conclusão:** as três respostas estão registradas e o modo está escolhido
antes de qualquer arquivo ser aberto.

---

## Passo 3: derivar

Leia `references/derivacao.md` e percorra as cinco fontes: a linha de cabeçalho de um
export, um procedimento antigo, o texto do site, um certificado e a planilha do
indicador. Cada uma diz o que entrega, o que não entrega e onde engana.

Para o export, use o script em vez de abrir o arquivo. Ele lê **só** a linha de cabeçalho
e imprime os nomes de campo; nas outras linhas ele conta separadores e não imprime
nenhuma delas:

```
python3 ~/.claude/skills/ficha-da-area/scripts/ficha.py --cabecalho-de export-apontamento.csv
```

No PowerShell:

```
py -3 "$env:USERPROFILE\.claude\skills\ficha-da-area\scripts\ficha.py" `
    --cabecalho-de export-apontamento.csv
```

Três recusas do script neste passo, e todas saem com código 3:

- **Arquivo que não é texto delimitado.** `.xlsx`, `.xls`, `.ods`, `.pdf`, `.doc` são
  recusados pela extensão e pela assinatura, antes de ler um byte. Salve como CSV a aba que
  você usa e rode de novo.
- **Preâmbulo de relatório.** Título e filtros antes do cabeçalho real, na forma irregular
  ou na retangular do CSV do Excel, que tem o título na coluna A e as outras vazias. O
  script aponta a linha que parece cabeçalho e pede confirmação.
- **Linha que tem cara de dado.** Antes de imprimir, o script testa a linha escolhida:
  campo puramente numérico, campo em formato de data, caractere de controle. Reprovando, a
  linha não é impressa, porque linha de dado carrega nome de pessoa. Nome de campo repetido
  sai como alerta e não como recusa: acontece em cabeçalho de verdade, e recusar travaria um
  arquivo legítimo sem saída.

A linha do cabeçalho vai junto com o arquivo, na forma `--cabecalho-de arquivo.csv:4`. Um
export com preâmbulo e outro sem rodam na mesma chamada. O `--linha-do-cabecalho N` é um
valor só e vale para uma rodada de um arquivo.

A derivação que conclui sai com código 4, porque nenhuma ficha foi gravada. A derivação que
para em qualquer das três recusas sai com 3, como qualquer erro de entrada.

Cada linha derivada nomeia o arquivo de onde saiu. Fonte que sugere mas não afirma não
vira fato: vira pergunta do passo 4, ou lacuna.

**Critério de conclusão:** está dito quantas linhas foram derivadas e de quais arquivos,
e cada arquivo citado existe. Nenhuma pergunta foi feita ainda.

---

## Passo 4: perguntar, no máximo cinco

Pergunte só o que a derivação não respondeu. Se ela já respondeu uma destas, a pergunta
cai e **não é substituída por outra**. Menos é melhor. Nunca há uma sexta.

1. **O que a sua área entrega, para quem, o que trava quando atrasa, e o que você faz
   toda semana que toma mais tempo do que deveria?**
   Nenhum arquivo responde isso, e é a linha que faz as outras skills entenderem
   prioridade. A última parte é a pergunta canônica de descoberta do kit, e é aqui que ela
   é feita. A resposta entra em **Área e posto**, em uma linha. Medir quanto essa tarefa
   custa hoje é `linha-de-base-antes-de-automatizar`, não esta skill.
2. **Desses sistemas, quais você mesmo exporta e quais dependem de outra pessoa?**
   A lista de sistemas vem do export. Quem consegue tirar o dado, não.
3. **Qual palavra desta lista significa aqui uma coisa diferente do que significa fora?**
   Mostre o vocabulário derivado do procedimento e peça a correção. É a pergunta que mais
   muda a saída das outras nove.
4. **Qual é o rito da semana e o do fechamento do mês: o que acontece, quando, e quem
   cobra o quê?**
5. **O que você não consegue responder sobre a sua própria área?**
   Esta é obrigatória e é a última. A resposta é a página de lacunas, e ela é o entregável
   que a pessoa mostra no mesmo dia. Quando vier "acho que não tem nada", ofereça as
   candidatas de sempre: quem é dono de cada cadastro, de onde sai cada número do painel,
   qual documento é o vigente, o que o turno da noite faz diferente.

**Critério de conclusão:** o número de perguntas feitas está dito, é cinco ou menos, e
cada uma é uma que a derivação não respondia.

---

## Passo 5: escrever o rascunho e gravar pelo script

Escreva o rascunho em markdown, no diretório de trabalho, com as seis seções abaixo,
nesta ordem e com estes nomes. **Um fato, uma linha física, marca de origem no fim.** Fato
quebrado em duas linhas é reprovado, e o script diz qual linha é continuação de qual. Toda
linha de conteúdo começa com `- `.

A lacuna pode dizer em que seção o buraco fica, na forma `- <seção>: <o que falta>
[lacuna]`. A lacuna declarada dentro de uma seção de fato é copiada pelo script para
**Lacunas declaradas**, com o nome da seção na frente, e a cópia sai contada: a seção que
as outras nove leem como lista de buracos nunca fica menor do que a ficha reconhece, e
ninguém digita a mesma lacuna duas vezes.

```markdown
## Área e posto
- Usinagem, planta 2. Coordenação de produção, três turnos. [respondida pela pessoa]
- A área entrega ordem usinada para a montagem, e o atraso trava a linha. [respondida pela pessoa]

## Vocabulário local
- OP é ordem de produção, OS é ordem de serviço da manutenção. [derivada de IT-042-rev3.pdf]
- "Parada" é máquina parada com apontamento aberto, não intervalo de turno. [respondida pela pessoa]

## Sistemas e o que cada um exporta
- Apontamento: export em CSV com 8 campos, OP, Item, Descricao, Qtde, Operador, Maquina, Data, Turno. [derivada de export-apontamento.csv]
- O ERP exporta a carteira em CSV, mas quem tira é o PCP. [respondida pela pessoa]
- Não sei se o sistema de manutenção exporta alguma coisa. [lacuna]

## Ritos e prazos
- Reunião de produção toda segunda, com manutenção e PCP. [respondida pela pessoa]
- Fechamento no terceiro dia útil. [derivada de IT-042-rev3.pdf]

## Normas e certificações
- Escopo certificado: usinagem e montagem, planta 2. Validade até 03/2027. [derivada de certificado-iso-2024.pdf]
- NORMA-X, edição 2020, cláusula 4.2: exige controle das condições de produção. Confira na edição vigente da sua empresa. [respondida pela pessoa]

## Lacunas declaradas
- Sistemas e o que cada um exporta: não sei quem responde pelo cadastro de item. [lacuna]
- Ritos e prazos: não sei qual indicador da minha área a diretoria olha. [lacuna]
```

NORMA-X é norma fictícia. O exemplo não afirma o que uma cláusula de norma real exige,
porque ninguém leu essa cláusula por você. Na sua ficha entram o nome, a edição e a
cláusula da norma que a sua empresa segue.

Grave pelo script. Ele confere, copia e promove lacuna; ele não escreve fato nenhum por
você e não infere nada:

```
python3 ~/.claude/skills/ficha-da-area/scripts/ficha.py --rascunho rascunho-ficha.md
```

No PowerShell:

```
py -3 "$env:USERPROFILE\.claude\skills\ficha-da-area\scripts\ficha.py" `
    --rascunho rascunho-ficha.md
```

O destino padrão é `~/.kit-industrial/ficha-da-area.md`, e `--ficha` troca esse caminho.
A página de lacunas sai em `lacunas-da-area-<data>.md` no diretório atual, e
`--saida-lacunas` troca o caminho dela. `--fonte-declarada <arquivo>` é para a fonte que
ficou na máquina de quem derivou: a ausência entra no cabeçalho da ficha em vez de passar
calada.

**Dependência declarada:** Python 3.8 ou superior, biblioteca padrão apenas (`argparse`,
`csv`, `os`, `re`, `sys`, `unicodedata`, `datetime`, `pathlib`). Sem instalação, sem rede,
sem escrita no rascunho de entrada.

### Por que existe script aqui

Redigir a ficha é trabalho de leitura, e o modelo faz melhor. O script cobre as cinco
coisas que leitura não faz:

- **Gravar em caminho absoluto fixo, de forma atômica.** A ficha mora fora do diretório de
  trabalho e é lida por nove skills. Ela nunca pode existir pela metade. O script escreve
  num temporário ao lado do destino e troca com `os.replace`: ou a ficha anterior continua
  inteira, ou a nova está inteira.
- **Guardar a versão anterior.** Toda gravação por cima deixa uma cópia carimbada ao lado,
  da ficha e da página de lacunas, e cópia nunca é sobrescrita.
- **Conferir que a ficha está inteira antes de gravar.** Seção faltando, seção vazia,
  linha sem origem, fonte que não existe no disco, fato quebrado em duas linhas, requisito
  de cláusula derivado de certificado: tudo isso derruba a rodada com o número da linha, e
  nada é gravado.
- **Promover a lacuna para a seção que as outras nove leem.** É a única linha que o script
  escreve, ela é cópia de uma linha do rascunho, e a cópia sai contada no relatório e no
  cabeçalho da ficha.
- **Ler cabeçalho sem ler conteúdo, e recusar o que não é cabeçalho.** É o que permite
  derivar de um export cujo conteúdo não pode sair da máquina.

### Ler o relatório antes de comemorar

O script imprime um balde por classe de linha e duas identidades:

```
identidade: vistas 13 = soma dos baldes 13 fecha
identidade 2: conteudo dentro de secao visto 13 = escrito no corpo 13 fecha
```

A segunda existe porque a primeira fecha mesmo quando uma linha é classificada e não é
gravada. Foi assim que uma linha de fato que citava a frase do rodapé sumia da ficha com a
rodada saindo com código 0.

**Os baldes são contados dentro do laço, um por linha, nenhum por subtração.** Essa é a
diferença que faz a identidade valer alguma coisa: contador derivado por subtração fecha
sozinho mesmo quando uma linha se perdeu no caminho, e a rodada sai com cara de certa.
Aqui, se uma linha entrar e não for classificada, `vistas` e a soma divergem e a rodada
para.

| Código de saída | Significado |
|---|---|
| 0 | Ficha gravada, com pelo menos uma lacuna declarada |
| 3 | Erro de entrada ou conferência reprovada, inclusive derivação de cabeçalho que parou. Nada foi gravado, e a ficha anterior continua como estava |
| 4 | Rodada de derivação de cabeçalho concluída. Nenhuma ficha gravada |
| 5 | Ficha gravada, nenhuma lacuna declarada. Resultado em aberto |

O código 4 existe para que a derivação não devolva 0, que significaria ficha gravada. O
código 5 existe porque ficha sem nenhuma lacuna quase sempre quer dizer que a entrevista
inferiu em vez de registrar: numa primeira ficha, alguém precisa responder por isso antes
do arquivo ser usado.

**Critério de conclusão:** o script saiu com 0, ou com 5 e a ausência de lacuna foi
respondida; as duas identidades fecham; e os dois caminhos gravados estão ditos na resposta.

---

## Passo 6: a lei do gabarito

A regra do kit é que a pessoa roda primeiro sobre um caso que ela já fez à mão, compara
com o resultado dela e só usa no trabalho real depois que bater. Aqui o caso já feito à
mão é **um documento que ela mesma escreveu sobre a própria área**: uma apresentação da
área, o material de integração de quem entra, o último relatório que ela mandou para a
chefia, um procedimento que ela assinou.

Como roda:

1. Abra o documento ao lado da ficha.
2. Percorra a ficha **linha a linha**, não por amostra, e marque cada uma como certa ou
   errada contra o documento. Linha que o documento contradiz está errada. Linha que o
   documento não cobre não está errada: fica como está, e a marca de origem dela já diz de
   onde veio.
3. Havendo linha errada, corrija o rascunho e grave de novo. Repita até zero.
4. Toda linha conferida, carimbe:

```
python3 ~/.claude/skills/ficha-da-area/scripts/ficha.py --rascunho rascunho-ficha.md \
    --conferida-contra "apresentacao-da-area.pptx" --em 2026-09-20 --linhas-conferidas 13
```

No PowerShell:

```
py -3 "$env:USERPROFILE\.claude\skills\ficha-da-area\scripts\ficha.py" `
    --rascunho rascunho-ficha.md `
    --conferida-contra "apresentacao-da-area.pptx" --em 2026-09-20 --linhas-conferidas 13
```

O script recusa o carimbo quando falta o documento, a data ou a contagem. Recusa também
quando o documento informado não existe no disco, quando `--em` não é uma data em
`AAAA-MM-DD`, quando a data é futura, e quando `--linhas-conferidas` é diferente do total
de linhas de fato da ficha. Conferir três de treze e marcar como conferida é exatamente o
que a lei do gabarito existe para impedir. O caminho do documento fica gravado no cabeçalho
da ficha, para a afirmação ser rastreável depois.

Enquanto o carimbo não sai, o status da ficha é `rascunho, nao conferida` e o script grava a
linha de `ATENÇÃO` no cabeçalho. **A ficha é gravada no passo 5, antes do gabarito**, e é
essa linha dentro do arquivo que avisa quem a abrir. O passo 1 das outras nove pede o eco do
status na primeira linha da resposta; a garantia, porém, é o aviso no arquivo, não a
promessa sobre o comportamento das outras.

**Critério de conclusão:** o status gravado na ficha nomeia o documento, a data e a
contagem, e a contagem é igual ao total de linhas de fato.

---

## Passo 7: entregar a página de lacunas

A página é o entregável visível do dia. Ela sai sozinha do script, e o trabalho aqui é
entregá-la sabendo o que ela é: a lista das perguntas que a área ainda não responde sobre
si mesma, cada uma com a seção em que o buraco fica e com as skills do kit que rodam pior
enquanto ele estiver aberto. Essa terceira coluna é derivada da seção, e é a conta que a
pessoa teria de fazer na mão para saber o que cada buraco custa.

Diga o caminho dela, diga quantas lacunas são, e não a transforme em plano de ação. Lacuna
é pergunta em aberto. Priorizar, estimar e decidir o que fazer com cada uma é outra
conversa, e não é desta skill.

**Critério de conclusão:** o caminho dos dois arquivos está dito e o número de lacunas
está dito.

---

## Contrato de saída

### 1. `~/.kit-industrial/ficha-da-area.md`

Caminho absoluto fixo, porque é ali que as outras nove procuram. O script escreve o bloco
de cabeçalho, copia o corpo do rascunho sem editar nem apagar linha, acrescenta as lacunas
promovidas dentro de **Lacunas declaradas** e fecha com o rodapé.

```
# Ficha da área

status: rascunho, nao conferida contra documento da pessoa
gravada em: 2026-09-20 20:11
ficha em: /Users/<voce>/.kit-industrial/ficha-da-area.md
linhas de fato: 13 (derivadas de arquivo 4, respondidas pela pessoa 6, lacunas 3)
lacunas distintas: 3
linhas promovidas pelo script: 1 (lacuna declarada dentro de secao de fato, copiada para Lacunas declaradas)
fontes nomeadas: IT-042-rev3.pdf; export-apontamento.csv; certificado-iso-2024.pdf
ATENÇÃO: ficha não conferida contra documento da pessoa. Quem lê esta ficha repete este status antes de usá-la.
```

Linha de lacuna e lacuna distinta saem com nome separado, porque a mesma lacuna declarada
duas vezes é uma linha a mais e um buraco só. Conferida a ficha, a linha de `ATENÇÃO` sai e
entra `documento do gabarito:` com o caminho.

Seções obrigatórias, nesta ordem: **Área e posto**, **Vocabulário local**, **Sistemas e o
que cada um exporta**, **Ritos e prazos**, **Normas e certificações**, **Lacunas
declaradas**. As cinco primeiras não podem estar vazias. A sexta pode, e nesse caso a
rodada sai com código 5.

A versão anterior fica ao lado, como `ficha-da-area.<AAAAMMDD-HHMMSS>.md`. Duas gravações
no mesmo segundo não disputam o mesmo nome: a segunda recebe sufixo, e cópia não é
sobrescrita. O passo 6 manda gravar de novo até zerar, então isso acontece.

### 2. `lacunas-da-area-<data>.md`

No diretório de trabalho, porque é a página que circula. Traz o status da ficha, o caminho
da ficha completa e a tabela de lacunas, uma por linha, com a seção em que ela fica e as
skills do kit que rodam pior sem ela. A mesma lacuna declarada na seção de fato e repetida
na lista entra uma vez só, e a junção sai declarada com as duas contagens. Rodando duas
vezes no mesmo dia, a página anterior também é guardada ao lado antes de a nova ser
escrita.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de <fonte>. Revisar antes de assinar. Não substitui
responsabilidade técnica.
```

Onde `<fonte>` é a lista de arquivos nomeados nas marcas de origem.

---

## Modo de dado sensível

Três níveis. O padrão, quando a pessoa não decide, é o nível 2.

**Nível 1, só os nomes de campo.** A pessoa roda `--cabecalho-de` na máquina dela e cola
apenas a lista de campos que o script imprimiu. Das outras linhas o script conta
separadores e não imprime nenhuma, e a linha escolhida só é impressa depois de passar no
teste de cara de cabeçalho: linha com campo puramente numérico, campo em formato de data ou
caractere de controle é recusada sem ser impressa. Antes de colar, confira os nomes: em alguns exports o
nome da coluna carrega cliente, projeto ou fornecedor.

**Nível 2, rascunho local (padrão).** A pessoa escreve o rascunho e roda o script na
máquina dela. Depois cola só o relatório do terminal, que por construção tem contagem,
nome de balde e nome de arquivo, e nenhuma linha de conteúdo. O modelo confere o
fechamento e diz se a rodada é válida.

**Nível 3, nada sai.** O modelo entrega o modelo de rascunho e a linha de comando, e a
pessoa responde apenas se fechou ou não fechou, e qual problema apareceu.

Regra que não se quebra: folha de pagamento, salário e remuneração individual não entram
em nenhum dos três. Nome de pessoa também não: a ficha descreve posto, e posto sobrevive à
troca de pessoa.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**A pessoa não tem nenhuma das cinco fontes.** Sem export, sem procedimento, sem
certificado, sem texto de site e sem planilha de indicador, a ficha sairia inteira de
entrevista, e é o que esta skill foi refeita para não ser. Diga isso, faça as cinco
perguntas, grave a ficha com todas as linhas marcadas como respondidas pela pessoa, e
registre em lacunas que nenhuma linha tem lastro documental. A ficha vale menos, e a
página diz por quê.

**O export só existe dentro do sistema.** A skill não acessa ERP. Sem o arquivo salvo, o
sistema entra pelo nome e o que ele exporta vira lacuna.

**O procedimento está em papel, ou é foto.** Isso é extração, não derivação. A skill do
kit que faz extração medida contra gabarito é `extracao-de-documento-para-tabela`.
Encadeie, ou registre o vocabulário como respondido pela pessoa.

**A pessoa quer a ficha de uma área que não é a dela.** Para. Ficha escrita por quem não
responde pela área vira palpite com marca de fato, e as outras nove passam a tratar
palpite como fato. Quem responde pela área responde a entrevista.

**A pessoa pede conformidade.** Dizer se o procedimento atende a norma não é esta skill.
É `padrao-conferido-contra-norma`. Aqui a norma entra pelo número e pelo escopo, sem
reprodução de texto: cláusula por número, requisito em palavras próprias, e confira na
edição vigente da sua empresa.

**O rascunho é o próprio destino.** O script recusa. Copie a ficha para outro nome, edite
a cópia e rode sobre ela.

---

## Referência

A pasta da skill fica em `~/.claude/skills/ficha-da-area/` depois de instalada. Os
arquivos de referência são lidos por esse caminho, e os scripts são chamados pelo caminho
completo. Caminho relativo como `scripts/ficha.py` só funciona de dentro da pasta da
skill: fora dela o Python responde `can't open file`.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/ficha-da-area/references/derivacao.md` | As cinco fontes de derivação, cada uma com o que entrega, o que não entrega, a armadilha e o exemplo da linha pronta. Mais a lista do que nunca se deriva e as três marcas de origem. Leia antes de perguntar qualquer coisa. |
| `~/.claude/skills/ficha-da-area/scripts/ficha.py` | Derivação de cabeçalho e gravação atômica da ficha, em Python de biblioteca padrão. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/ficha-da-area/scripts/testar.py` | Teste de regressão do `ficha.py`, biblioteca padrão apenas, 50 casos. Cada caso nasceu de uma pergunta, não de uma funcionalidade: existe caminho em que isto sai com sucesso tendo perdido dado? Daí vieram o preâmbulo de relatório que viraria cabeçalho de um campo só, o preâmbulo retangular do CSV do Excel que passava pela contagem de campos, o `.xlsx` decodificado como texto, a linha de dado impressa por um erro de uma linha no número, a frase do rodapé citada dentro de um fato e descartada em silêncio, o arquivo vazio que devolveria zero campo como resultado, a linha de fato sem origem, o fato quebrado em duas linhas físicas, a fonte nomeada que não existe no disco, o requisito de cláusula derivado de certificado, o texto antes da primeira seção que some do laço, a seção presente e vazia, a lacuna declarada só na seção de fato, a ficha sem nenhuma lacuna, a conferência de gabarito declarada sobre amostra ou contra documento inexistente, as duas gravações no mesmo segundo que se sobrescreviam, a própria ficha gravada usada como rascunho da rodada seguinte, e o rascunho reprovado que não pode levar junto a ficha anterior. Rode `python3 ~/.claude/skills/ficha-da-area/scripts/testar.py` depois de qualquer mudança no script, ou `py -3 "$env:USERPROFILE\.claude\skills\ficha-da-area\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
