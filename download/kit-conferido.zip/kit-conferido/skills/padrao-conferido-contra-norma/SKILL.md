---
name: padrao-conferido-contra-norma
description: >
  Cruza o procedimento vigente da empresa contra o requisito da norma que a própria pessoa
  entregou e devolve a lista de furos item por item, com o que falta e onde. Separa furo de
  forma (falta registro de aprovação, falta revisão, falta dono, falta data de vigência,
  falta histórico) de furo de conteúdo (não trata a exigência, trata sem registro, trata sem
  critério, trata sem dono). Não reproduz texto de norma: cita a cláusula por número, diz o
  requisito com palavras próprias e manda conferir na edição vigente da empresa. Requisito
  que a pessoa não entregou sai como "a conferir na sua edição", nunca como furo. Use SEMPRE
  que aparecer: "esse procedimento atende a norma?", "confere esse POP contra a ISO", "lista
  os furos desse procedimento", "vem auditoria e quero saber onde estou descoberto", "o que
  falta nesse procedimento", "cruza esse procedimento com a cláusula que eu te passei", "meu
  procedimento cobre esse requisito?", "prepara esse documento para a auditoria", "o auditor
  vai bater em quê aqui", "confere essa instrução de trabalho contra a NR", "essa IT atende
  à norma regulamentadora?". NÃO use para escrever nem reescrever o procedimento, para montar
  repositório com controle de versão e registro de ciência (isso é sistema, não arquivo),
  para emitir parecer de conformidade ou evidência de certificação, nem para conferir dois
  arquivos de dado entre si.
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que esta skill
ocupe o lugar das outras.

| Caso | Skill | Fronteira |
|---|---|---|
| Procedimento em PDF escaneado, foto ou papel, que precisa virar texto antes | `extracao-de-documento-para-tabela` | Encadeie. Linha mal lida vira furo falso, então a extração tem que ser medida contra gabarito antes de a conferência começar |
| Achar qual é o procedimento vigente no meio das revisões antigas da pasta de rede | `indice-do-acervo-da-area` | Roda antes desta sempre que ninguém souber qual arquivo é a versão em vigor. Conferir a revisão errada invalida tudo |
| Dois arquivos de dado que deveriam dizer a mesma coisa | `conferencia-entre-duas-fontes` | Lá se compara valor contra valor. Aqui se compara texto de procedimento contra exigência |
| Um desvio que já aconteceu, e precisa virar registro | `registro-de-anomalia` | O furo daqui é potencial e é do papel. A anomalia é ocorrida e é do processo. Furo que já gerou desvio vira registro lá |
| Acompanhar mês a mês o fechamento dos furos | `relatorio-recorrente` | Independente desta. O acompanhamento mês a mês dos furos é manual: ela exige um relatório de um mês fechado já aprovado, e `furos.csv` solto não é entrada dela |
| Vocabulário da casa, nome dos campos de controle do template e sistemas em uso | `ficha-da-area` | Ela escreve `~/.kit-industrial/ficha-da-area.md`, que esta lê no passo 1 |
| Medir quanto custa hoje conferir procedimento à mão, antes de falar em automatizar | `linha-de-base-antes-de-automatizar` | Esta skill dá o resultado. Ela dá o número do antes |
| Separar, na caixa cheia, o que a auditoria está cobrando e com que prazo | `triagem-de-caixa-de-email` | Ela indexa e prioriza. O procedimento que ela separar entra aqui |
| Propostas de fornecedores em unidades diferentes | `comparativo-de-cotacoes` | Assunto diferente, sem sobreposição |

---

# Padrão conferido contra norma

Vem auditoria. A pessoa abre o procedimento, abre a norma ao lado, lê as duas e tenta
lembrar o que já conferiu. Faz isso com doze, trinta, oitenta procedimentos. No fim não
sabe dizer quais cláusulas passaram por todos os documentos e quais ela olhou num e
esqueceu no outro.

Esta skill termina em arquivo. A saída é um conjunto de arquivos gravados em disco, num
diretório com a data da rodada, e o caminho é informado no fim. Resposta em prosa dizendo
"esse procedimento parece bem completo" é falha de execução.

**Ela não tem a norma.** Não tem o texto, não tem a edição, não tem as alíneas, e não vai
buscar. Ela trabalha sobre o requisito que **a pessoa** entregou, ou sobre o sumário da
edição que a pessoa possui. Requisito que a pessoa não entregou e que a skill acha que
lembra sai marcado como a conferir na edição dela, nunca como furo. Ela diz isso na cara
antes de começar.

---

## Leis de ferro

1. **Não reproduz texto de norma, em lugar nenhum.** Cita a cláusula por número, diz o
   requisito com palavras próprias e em ordem própria, e fecha com "confira na edição
   vigente da sua empresa". Enumerar as alíneas de uma cláusula na ordem dela também é
   reprodução, e parafrasear frase a frase na mesma sequência também.
2. **Requisito que a pessoa não entregou nunca vira furo.** Sai em
   `a-conferir-na-sua-edicao.csv`, com o motivo. Furo inventado contra norma que não está
   na mão é o pior erro possível aqui: quem assina é o engenheiro e quem é apontado como
   fonte é este kit. O script recusa mecanicamente, e derruba a rodada com código 3.
3. **Sem edição declarada, não roda.** A numeração de cláusula muda de uma edição para
   outra. Cláusula sem edição é um número, não um requisito.
4. **Furo de forma e furo de conteúdo são separados e não se compensam.** Documento com
   todos os campos de controle preenchidos e que não trata a exigência continua com furo de
   conteúdo. O inverso também vale.
5. **O que sai é achado, não é não conformidade.** A skill não emite parecer de
   conformidade, não substitui auditoria e o resultado não é evidência para organismo
   certificador. Quem assina é o engenheiro.
6. **Contagem que não fecha invalida a rodada.** Todo requisito lido tem exatamente um
   destino, e nenhum destino sai por subtração. Destino derivado por subtração fecha sozinho
   mesmo com requisito perdido no caminho.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Existindo, use o vocabulário local, o nome que a
casa dá aos campos de controle do template e a lista de normas que a área já segue. Não
existindo, declare em voz alta **"rodando sem ficha da área"** e siga normalmente.

Rodar sem ficha não degrada a conferência. Só obriga a perguntar, no passo 4, quais campos
de controle o template da empresa exige, em vez de assumir os oito padrão.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi carregada ou se a
conferência está rodando sem ficha e, carregada, repete o status gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir o arquivo

Procedimento é documento interno, e na indústria costuma trazer dado que não deveria sair da
máquina. Pergunte antes de abrir, e ofereça sempre o modo derivado.

Cinco classes:

1. **Nome de pessoa.** Quem elaborou, quem aprovou, o dono, a lista de distribuição. É a
   classe mais frequente aqui, porque os campos de controle existem justamente para nomear
   gente. Modo derivado: trocar cada nome pelo cargo antes de entregar o arquivo, ou rodar o
   script com `--sem-valores`.
2. **Folha de pagamento, salário e remuneração individual.** **Esta não entra em nenhum
   modo.** Peça o arquivo sem essas colunas, ou rode pelo script local, que não envia
   conteúdo.
3. **Preço de fornecedor identificado.** Aparece em procedimento de compras e de
   qualificação. Modo derivado: substituir por faixa, ou suprimir.
4. **Dado de cliente identificado.** Aparece em procedimento de atendimento, de assistência
   e de inspeção de recebimento.
5. **Projeto sob sigilo.** Procedimento amarrado a projeto sob acordo. Se sim, ou se a
   pessoa não souber, vá para o **modo de dado sensível** e não leia o conteúdo.

Pergunte também: **quantos procedimentos vão entrar nesta rodada, e ela se repete?**
Auditoria anual e revisão periódica repetem, e repetição decide pelo script.

**Critério de conclusão:** as respostas das cinco classes e das duas perguntas estão
registradas, e a escolha entre leitura e script está feita antes de qualquer arquivo ser
aberto.

---

## Passo 3: travar a norma, a edição e a origem de cada requisito

Leia `references/leitura-de-requisito.md` antes deste passo.

Monte `requisitos.csv`, uma linha por requisito, com estas colunas:

| Coluna | Conteúdo |
|---|---|
| `clausula` | O número, como está na edição que a pessoa tem |
| `norma` | O nome da norma |
| `edicao` | Ano ou identificação da edição. Obrigatória, lei de ferro 3 |
| `origem` | `entregue`, `sumario` ou `nao_entregue` |
| `tipo` | `deve` ou `convem`. Recomendação não atendida não é furo |
| `condicao` | A condição, quando o requisito é condicional |
| `requisito` | A exigência com palavras próprias, em ordem própria, nunca o texto da norma |

A coluna `origem` é a que autoriza a skill a apontar furo:

- `entregue`: a pessoa colou a cláusula, leu em voz alta, descreveu a exigência com as
  palavras dela ou mostrou a página. **Só esta admite `atendido` ou `furo`.**
- `sumario`: a pessoa tem o índice ou o título da cláusula. Título de cláusula não diz o que
  a cláusula exige. Só admite `a_conferir`.
- `nao_entregue`: a skill suspeita que existe requisito ali e ele não está na mão. Só admite
  `a_conferir`.

Quando a pessoa disser apenas um número de cláusula, **pergunte o requisito com as palavras
dela**. Não preencha de memória. Preenchido de memória, o requisito entra como
`nao_entregue` e sai como a conferir.

O `requisitos.csv` é **entrada de trabalho, não artefato de entrega**: ele não leva o rodapé
do fim desta skill. Linha que comece com `#` é lida como comentário e não entra na conferência.

`origem` e `tipo` só valem o que está aqui. No fechamento o script compara as duas colunas
da matriz com as deste arquivo e derruba a rodada quando divergem: mudar `sumario` para
`entregue` na matriz para destravar um furo é o erro que a lei de ferro 2 proíbe.

**Critério de conclusão:** todo requisito tem cláusula, norma, edição e origem, nenhum
requisito tem origem em branco, e a pessoa confirmou que as linhas com `origem=entregue` são
de fato o que ela entregou.

---

## Passo 4: ler a estrutura do documento controlado

| Situação | Como rodar |
|---|---|
| Um procedimento de até seis páginas e até quinze requisitos | Leitura, com o fechamento do passo 7 escrito à mão |
| Acima disso | Script obrigatório |
| Mais de um procedimento na rodada | Script obrigatório |
| Conferência que se repete (auditoria anual, revisão periódica) | Script obrigatório |
| Dado sensível de qualquer das cinco classes | Script obrigatório |

**Por que o script existe aqui.** Ele não julga conteúdo e não vai julgar. Ele faz quatro
coisas que a leitura não faz bem:

1. **Aplica o mesmo checklist de campo de controle em todos os procedimentos da rodada.**
   Repita `--procedimento` uma vez por arquivo. A forma dos oito campos sai conferida nos
   oitenta documentos sem ninguém reler nada, a matriz sai com uma linha por par
   procedimento x requisito, e o fechamento devolve `cobertura-por-clausula.csv`, que é a
   resposta para a pergunta da abertura: quais cláusulas passaram por todos os documentos.
2. **Classifica toda linha do arquivo**, para que nenhuma saia em silêncio, e lê o cabeçalho
   de controle nos dois layouts: vertical (`rótulo: valor`) e tabela horizontal, que é o mais
   comum de POP exportado do Word.
3. **Recusa mecanicamente o furo apontado contra requisito que a pessoa não entregou**, e
   recusa furo em requisito `convem`. É a lei de ferro 2 virando código, e é a única das seis
   que o modelo sozinho não cumpre de forma confiável.
4. **Não deixa rodada sair bem tendo perdido dado.** Não sobrescreve matriz já julgada nem
   com `--forcar`, não escreve nenhum arquivo de entrega antes de a rodada ser declarada
   válida, apaga entrega de rodada anterior quando a nova é derrubada, e derruba o fechamento
   quando o procedimento mudou depois da rodada de estrutura, porque nesse caso toda linha
   apontada como evidência está vencida.

O cruzamento requisito por requisito continua sendo trabalho do modelo e da pessoa: é o passo
5, e o script não opina nele.

**Dependência declarada:** Python 3.8 ou superior, biblioteca padrão apenas (`argparse`,
`csv`, `hashlib`, `re`, `sys`, `unicodedata`, `datetime`, `pathlib`). Sem instalação, sem
rede, sem escrita nos arquivos de entrada.

**Onde o script está depois de instalado.** A instalação copia a pasta da skill para
`~/.claude/skills/padrao-conferido-contra-norma/`. A rodada acontece na pasta dos arquivos
de trabalho, não na pasta da skill, e por isso o script é chamado pelo caminho completo.
Caminho relativo como `scripts/conferir-estrutura.py` só funciona de dentro da pasta da
skill: fora dela o Python responde `can't open file`.

No macOS e no Linux:

```
python3 ~/.claude/skills/padrao-conferido-contra-norma/scripts/conferir-estrutura.py \
    --procedimento PR-QA-014.md --requisitos requisitos.csv \
    --saida conferencia-2026-09-20
```

Com mais de um procedimento na mesma rodada, repita a opção. Cada procedimento ganha um
subdiretório com os arquivos mecânicos dele, e o consolidado fica na raiz da rodada:

```
python3 ~/.claude/skills/padrao-conferido-contra-norma/scripts/conferir-estrutura.py \
    --procedimento PR-QA-014.md --procedimento PR-QA-015.md \
    --requisitos requisitos.csv --saida conferencia-2026-09-20
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho vai entre
aspas com `$env:USERPROFILE` no lugar do `~`, e a linha continua com acento grave no lugar
da barra invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\padrao-conferido-contra-norma\scripts\conferir-estrutura.py" `
    --procedimento PR-QA-014.md --requisitos requisitos.csv `
    --saida conferencia-2026-09-20
```

Opções que mudam a rodada:

| Opção | Para quê |
|---|---|
| `--procedimento` | O arquivo do procedimento. **Repetível**: uma vez por procedimento da rodada |
| `--campos` | A lista de campos de controle que o **template da sua empresa** exige. O padrão são oito: `codigo`, `revisao`, `data_vigencia`, `elaborado_por`, `aprovado_por`, `dono`, `historico_revisao`, `ciencia` |
| `--campo-extra chave=rotulo1\|rotulo2` | O campo que a casa chama de outro jeito. Tire isso da ficha da área |
| `--sem-valores` | Não grava valor de campo de controle, título de seção nem linha do procedimento. Três campos carregam nome de pessoa, e título de seção carrega texto do documento |
| `--estrito` | Requisito em `a_conferir` bloqueia a rodada, código 2. Use quando a entrega é para auditoria. Havendo furo junto, o código 1 prevalece, e a rodada diz isso |
| `--forcar` | Sobrescreve o diretório da rodada, que é o caso normal depois de corrigir o `requisitos.csv`. Recusa com código 3 quando a `matriz-cobertura.csv` que está lá já tem julgamento de gente. O fechamento não precisa dele |
| `--fechar MATRIZ` | Roda o fechamento sobre a matriz já preenchida. É o passo 5 |

A entrada é texto: `.md` ou `.txt`. O script não lê PDF, não lê `.docx` e não lê `.xlsx`.

**Critério de conclusão:** o diretório tem `forma.csv`, `secoes.csv`, `linhas-ignoradas.csv`,
`matriz-cobertura.csv`, `impressao-do-procedimento.csv` e `leitura-da-estrutura.md`, o código
de saída é **4**, e o bloco de fechamento impresso no terminal tem `fecha` em todas as linhas.
Com mais de um procedimento, os três primeiros ficam num subdiretório por procedimento e a
raiz ganha `consolidado-de-forma.csv`. Rodada de estrutura derrubada **não deixa**
`matriz-cobertura.csv` no diretório: não existe matriz para preencher em rodada que não vale.
Na leitura sem script, o mesmo conteúdo é escrito à mão.

### Ler o bloco de verificações antes de julgar qualquer conteúdo

Três linhas do bloco mudam a rodada, e o passo é resolver antes de continuar:

- **`linhas repetidas com conteudo mantidas` maior que zero.** Uma linha que se repete em
  todas as páginas e carrega exigência de verdade não é rodapé. O script a mantém e a
  reporta. Leia `linhas-ignoradas.csv` e confirme.
- **`linhas de cabecalho sem campo nem secao` maior que zero.** É texto que nenhuma seção
  cobre, e por isso nenhum requisito pode apontar para ele. Ou vira seção, ou é declarado
  como irrelevante.
- **`campos de controle vazios` maior que zero.** Campo presente e vazio é a aparência do
  campo. Título de seção com nada embaixo, traço, `n/a`, linha de preenchimento.

---

## Passo 5: cruzar requisito por requisito

Agora sim o conteúdo. Abra `matriz-cobertura.csv` e preencha uma linha por par
`procedimento` x requisito. Esta é a parte que o script não faz.

| Veredito | Quando | O que é obrigatório junto |
|---|---|---|
| `atendido` | O procedimento trata a exigência | `onde` (a seção) e `linha` (o número da linha). Atendimento sem evidência é afirmação sem prova, e o script recusa |
| `furo` | Só para `origem=entregue` e `tipo=deve` | `o_que_falta`, do vocabulário fechado, e `onde` quando houver trecho parcial |
| `a_conferir` | Obrigatório para `sumario` e `nao_entregue`, e também para condição não resolvida, recomendação (`convem`) não atendida, norma de produto sem a tabela, e assunto tratado em outro documento não apresentado | `motivo` |

**A coluna `linha` vale para linha que diz alguma coisa.** Valem as linhas com conteúdo dentro
de alguma seção e as linhas dos campos de controle do cabeçalho, que é onde a cláusula de
controle de documento é atendida de fato. Linha branca, linha removida como rodapé e linha que
não existe são recusadas: apontar para elas é fabricar evidência.

**As colunas `procedimento`, `origem` e `tipo` não se editam na matriz.** Elas vêm do
`--procedimento` e do `requisitos.csv`, e divergência derruba a rodada com código 3.

O vocabulário de `o_que_falta` está em `references/leitura-de-requisito.md` e é fechado:
`nao_tratado`, `tratado_parcial`, `tratado_sem_registro`, `tratado_sem_dono`,
`tratado_sem_criterio`, `referencia_quebrada`, `exclusao_nao_declarada`. Valor fora da lista
derruba a rodada.

Os quatro do meio são os que a conferência manual mais perde, porque o procedimento fala do
assunto e o olho dá por atendido. Exigência tratada sem registro, sem dono ou sem critério é
exatamente o que o auditor pede para ver e ninguém acha.

Salve como `matriz-preenchida.csv` e rode o fechamento:

```
python3 ~/.claude/skills/padrao-conferido-contra-norma/scripts/conferir-estrutura.py \
    --procedimento PR-QA-014.md --requisitos requisitos.csv \
    --saida conferencia-2026-09-20 --fechar matriz-preenchida.csv
```

| Código de saída | Significado |
|---|---|
| 0 | Fechou, nenhum furo de forma, nenhum furo de conteúdo, nada a conferir, nada fora da conferência |
| 1 | Fechou e há furo, de forma ou de conteúdo |
| 2 | `--estrito` e sobrou requisito em `a_conferir`, sem nenhum furo. Com furo junto, o código 1 prevalece |
| 3 | Erro de entrada, identidade que não fecha, requisito não parseado, matriz já julgada que `--forcar` tentaria apagar, procedimento alterado depois da rodada de estrutura, matriz com linha pendente, matriz com linha a menos, `procedimento`, `origem` ou `tipo` trocados na matriz, veredito proibido pela origem ou pelo tipo, nenhuma seção reconhecida, ou nenhum requisito com origem `entregue` |
| 4 | Rodada de estrutura, sem fechamento. O conteúdo não foi conferido por ninguém ainda |
| 5 | Fechou sem furo, mas sobrou coisa fora da conferência |

O código 0 é estreito de propósito. A rodada de estrutura **nunca** devolve 0: devolve 4,
porque sair com 0 sem ninguém ter olhado o conteúdo seria dizer que o procedimento atende à
norma. E o 5 existe porque "nenhum furo" com requisito por conferir, campo vazio ou linha
fora de seção não é a mesma coisa que "nenhum furo".

**Critério de conclusão:** nenhuma linha da matriz ficou em `pendente`, o script fechou com
0, 1, 2 ou 5, e `furos.csv`, `a-conferir-na-sua-edicao.csv`, `consolidado-da-rodada.csv`,
`cobertura-por-clausula.csv` e o esqueleto do `plano-de-correcao.md` foram gerados pelo
próprio script a partir da matriz. Furo que não passou pela matriz não existe. Fechamento
derrubado não deixa nenhum desses arquivos no diretório, e apaga os da rodada anterior: CSV
de rodada inválida com cara de entrega pronta é pior do que arquivo nenhum.

---

## Passo 6: teste do gabarito

**A pessoa roda primeiro sobre um caso que ela já fez à mão, compara com o resultado dela, e
só usa no trabalho real depois que bater.** Aqui o gabarito é fácil de achar: um relatório de
auditoria interna já emitido, um relatório de auditoria externa recebido, ou um procedimento
que ela mesma já conferiu e anotou.

Três conferências, nesta ordem:

1. **Todo furo do gabarito aparece?** Cada achado da lista dela tem que estar em
   `furos.csv`, ou estar em `a-conferir-na-sua-edicao.csv` com o motivo de não ter sido
   julgado. Achado do gabarito que não aparece em lugar nenhum reprova a rodada.
2. **Todo furo novo tem requisito na mão?** A skill pode achar furo que a pessoa não achou,
   e isso é ganho legítimo. Mas cada furo novo tem que apontar para uma linha com
   `origem=entregue`. **Furo novo apoiado em requisito que ela não entregou reprova a
   rodada inteira**, mesmo que ele esteja certo. Este é o teste que importa.
3. **Nenhum atendido é falso?** Escolha três linhas marcadas `atendido` e abra o
   procedimento na linha indicada. Se o trecho não trata a exigência, a rodada está errada.

Contagem que fecha o teste: **zero achados do gabarito perdidos, zero furos sem requisito
entregue, três atendidos conferidos na linha.** Enquanto os três não baterem, não se usa em
procedimento que vai para auditoria.

**Critério de conclusão:** está dito qual gabarito foi usado, e os três números estão
escritos na nota.

---

## Passo 7: fechamento

Confira as identidades. Todas fecham, e os números vão na nota. As quatro primeiras são por
procedimento, e cada procedimento a mais da rodada soma as quatro:

```
linhas do arquivo              = brancas + cabecalho + em secao + removidas
linhas contadas no laco        = total de linhas do arquivo
linhas em linhas-ignoradas     = removidas + mantidas
campos de controle exigidos    = preenchidos + vazios + ausentes
```

Da rodada, na estrutura:

```
campos conferidos na rodada    = preenchidos + vazios + ausentes, somados
linhas da matriz montada       = requisitos x procedimentos
```

Do fechamento:

```
linhas da matriz preenchida    = atendidos + furos + a_conferir + pendentes + invalidos
pares procedimento x requisito = linhas na matriz
linhas em furos.csv            = furos de forma + furos de conteudo
linhas no consolidado          = linhas julgadas na matriz
```

Com um procedimento são seis identidades na rodada de estrutura e nove no fechamento.

Cada parcela é incrementada dentro do laço, uma vez por item. Nenhuma sai por subtração, e o
motivo é o defeito que já custou caro nas outras skills do kit: identidade derivada por
subtração fecha sozinha mesmo com dado perdido, e a rodada sai com cara de certa.

As identidades provam que a contabilidade da rodada é consistente, não que a rodada prestou.
O que pode falhar de fato vem no bloco seguinte: seções reconhecidas, requisitos com origem
entregue, requisitos não parseados, furos de forma, furos de conteúdo, requisitos em
`a_conferir`, campos vazios, campos ausentes, linhas repetidas com conteúdo mantidas, linhas
de cabeçalho sem campo nem seção. Zero em seções reconhecidas ou em requisitos entregues
invalida a rodada. As outras exigem uma decisão registrada.

**Critério de conclusão:** todas as identidades foram impressas com os números e todas
fecham, cada linha do bloco de verificações foi lida e respondida, e a nota diz o caminho do
diretório. Identidade quebrada: a entrega para e o motivo é dito.

---

## Contrato de saída

Um diretório com a data da rodada. A nota é o primeiro e o último arquivo escrito. Com mais
de um procedimento, os arquivos mecânicos de cada um ficam num subdiretório com o nome dele e
o consolidado fica na raiz.

**Arquivo de entrega só existe em rodada válida.** `furos.csv`,
`a-conferir-na-sua-edicao.csv`, `consolidado-da-rodada.csv`, `cobertura-por-clausula.csv` e
`plano-de-correcao.md` são escritos depois do fechamento fechar, nunca antes. Rodada derrubada
apaga os cinco.

### 1. `nota-de-leitura.md`, primeiro, sempre

Abre com `status: incompleto` e só vira `status: completo` na última gravação, depois do
fechamento. Os quatro valores são `incompleto`, `so-estrutura, conteudo nao conferido`,
`completo` e `invalido, nao fecha`.

Seções obrigatórias:

- **Procedimento.** Nome do arquivo, revisão e data lidas do próprio documento, tamanho,
  data de modificação, linhas.
- **Normas e edições.** Uma linha por norma, com a edição declarada pela pessoa e como ela
  chegou (papel, sistema, sumário).
- **Origem dos requisitos.** Quantos `entregue`, quantos `sumario`, quantos `nao_entregue`,
  e o que cada categoria autorizou.
- **Campos de controle.** A lista exigida, de onde ela veio (ficha da área ou padrão), e o
  resultado campo a campo.
- **Índice de seções.** Com as linhas de início e fim.
- **O que ficou fora da conferência, e por quê.** Linhas removidas, linhas mantidas, cabeçalho
  sem seção, condições não resolvidas.
- **Teste do gabarito.** Qual gabarito, os três números do passo 6.
- **Fechamento.** As identidades e o bloco de verificações.
- **Limite declarado.** A frase de que a skill não tem a norma, não emite parecer de
  conformidade e não é evidência para organismo certificador.

### 2. `furos.csv`

Gerado pelo script a partir da matriz, nunca escrito à mão. Colunas: `procedimento`, `classe`
(`forma` ou `conteudo`), `clausula`, `norma`, `edicao`, `o_que_falta`, `explicacao`,
`requisito`, `onde`, `linha`, `origem_do_requisito`, `observacao`.

Uma linha por furo. Furo de forma não carrega cláusula: ele é do documento controlado, não
da norma.

### 3. `a-conferir-na-sua-edicao.csv`

Colunas: `procedimento`, `clausula`, `norma`, `edicao`, `origem_do_requisito`, `requisito`,
`motivo`, `o_que_fazer`, que sai sempre com a mesma frase: conferir na edição vigente da sua
empresa.

**Este é o arquivo que separa achado de invenção.** Tudo que a skill suspeita e não pode
provar cai aqui, e nada daqui aparece em `furos.csv`.

### 4. `matriz-cobertura.csv`

O razão da rodada. Uma linha por par `procedimento` x requisito, com o veredito, a evidência
e o motivo. Sai em `pendente` na rodada de estrutura e volta preenchida no fechamento. Nenhum
furo existe fora dela. Rodada de estrutura derrubada não deixa matriz.

### 5. `consolidado-da-rodada.csv` e `cobertura-por-clausula.csv`

O primeiro tem uma linha por par `procedimento` x cláusula julgado, com veredito, evidência e
motivo. O segundo tem uma linha por cláusula, com em quantos procedimentos ela saiu
`atendido`, `furo` e `a_conferir`, e o nome dos procedimentos em que ela ficou com furo.

**É o que a abertura desta skill promete.** Com doze, trinta ou oitenta procedimentos, é aqui
que se lê qual cláusula passou por todos e qual foi olhada num documento e esquecida no outro.

### 6. `plano-de-correcao.md`

O que tira trabalho da mesa. O script grava o esqueleto no fechamento, um bloco por furo, na
ordem em que a pessoa vai resolver, e o modelo completa o que depender de leitura:

- **Furo de forma:** o campo que falta, onde colocar, e o valor a preencher quando ele já
  existe em outro lugar do documento.
- **Furo de conteúdo:** o que precisa passar a existir no procedimento, dito como
  pendência e **não como texto pronto**. Escrever o parágrafo é a skill de escrever
  procedimento, que este kit não tem, e o motivo está na falha honesta.
- **Cada bloco fecha com a pergunta pronta para o dono do procedimento**, quando o furo
  depende de informação que só ele tem.

### 7. Arquivos mecânicos do script

`forma.csv` (campo a campo), `secoes.csv` (índice com linhas), `linhas-ignoradas.csv` (toda
linha que saiu, com causa e destino `removida` ou `mantida`) e
`impressao-do-procedimento.csv` (linhas, caracteres e resumo criptográfico de cada
procedimento, que é como o fechamento sabe se o arquivo mudou). Mais
`leitura-da-estrutura.md`, que é o bloco de fechamento em texto e é o arquivo que se cola no
modo de dado sensível. Com mais de um procedimento, a raiz ganha `consolidado-de-forma.csv`,
uma linha por par procedimento x campo de controle.

### 8. `requisitos-nao-parseados.csv`

Só aparece quando existe requisito sem cláusula, sem texto, sem norma, sem edição ou sem
origem. Ele não entra na matriz e não pode sumir em silêncio: a rodada é derrubada com código
3 e este arquivo diz qual linha e por quê.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de <fonte>. Revisar antes de assinar. Não substitui
responsabilidade técnica.
```

Vale para o que a rodada **entrega**. O `requisitos.csv` é entrada de trabalho e não leva
rodapé; entrando, a linha é lida como comentário.

---

## Modo de dado sensível

Três níveis. O padrão, quando a pessoa não decide, é o nível 2.

**Nível 1, só a estrutura.** A pessoa cola apenas os títulos das seções e a linha dos campos
de controle, com os nomes trocados por cargo. Dá para conferir a forma inteira e devolver a
linha de comando pronta. Nenhum texto de procedimento é lido, e nenhum furo de conteúdo é
apontado: a skill diz isso em vez de fingir que conferiu.

**Nível 2, script local (padrão).** A pessoa roda o script na máquina dela com
`--sem-valores`. O conteúdo nunca chega ao modelo. Depois ela cola só
`leitura-da-estrutura.md`, que com `--sem-valores` traz nome de arquivo, nome de campo, número
de seção, faixa de linhas e contagem, e nada mais: o valor de cada campo e o **título de cada
seção** saem como `<omitido>`, porque item numerado do corpo do procedimento vira seção no
índice e o título sairia por extenso. A mesma supressão vale para `secoes.csv` e
`linhas-ignoradas.csv`. Nome de arquivo de procedimento costuma identificar o setor e o
projeto: renomeie antes de rodar, ou apague a primeira seção antes de colar. O modelo confere as decisões e o fechamento e diz se a
rodada é válida. O cruzamento de conteúdo, nesse nível, é da pessoa, e a skill entrega o
roteiro para ela fazer.

**Nível 3, nada sai.** O modelo entrega a linha de comando e a explicação de como ler os
arquivos. A pessoa responde apenas "fechou" ou "não fechou" e, se não fechou, qual identidade
quebrou.

Regra que não se quebra: com dado sensível, leitura e filtragem são locais. Nunca peça o
procedimento colado para resumir.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**Ela não é a skill de escrever procedimento, e isso é decisão, não falta.** O que o cliente
pede junto com a conferência é repositório com controle de versão e registro de ciência de
quem leu. Isso é sistema, não arquivo. Uma skill que grava um markdown com um campo escrito
"revisão 03" entrega a **aparência** disso: o número está lá, e não existe controle nenhum
por trás dele. Ninguém é notificado, ninguém dá ciência, a revisão anterior não fica
guardada, e duas pessoas podem gravar revisão 03 diferentes no mesmo dia. Esta skill faz só
o que cabe numa skill e faz bem: confere o procedimento que já existe e devolve a lista de
furos. O repositório continua sendo projeto.

**A norma não está na mão.** A pessoa cita o número e não tem o texto nem o sumário. A skill
não roda a conferência de conteúdo. Ela confere a forma, lista as cláusulas citadas como a
conferir e diz o que precisaria para continuar.

**Norma de produto, de ensaio ou de dimensional.** A exigência ali é tabela de valor,
tolerância e condição de ensaio. Sem a tabela na mão não existe conferência, e parafrasear
valor de memória é o erro mais caro que esta skill poderia cometer. Para na parte numérica e
diz por quê.

**Procedimento em PDF escaneado, foto ou papel.** Não é conferência, é extração. Linha mal
lida vira furo falso, e furo falso manda o dono do procedimento atrás de um problema que não
existe. Use `extracao-de-documento-para-tabela`, que devolve valor, confiança e origem por
campo e só libera o uso real depois que a taxa de acerto foi medida contra gabarito. Depois
traga o texto para cá.

**Procedimento em `.docx` ou `.xlsx`.** O script é biblioteca padrão e não lê nenhum dos
dois. Salve como `.txt` ou `.md`. A tabela de controle horizontal, com os rótulos numa linha e
os valores na linha de baixo, é lida como tabela. O que não sobrevive é a tabela que virou uma
linha corrida na exportação: confira o cabeçalho depois de salvar, porque é nele que estão os
campos.

**Não se sabe qual é a revisão vigente.** Conferir a revisão errada invalida tudo, inclusive
os furos que estiverem certos. Rode `indice-do-acervo-da-area` antes, ou confirme com o dono
do documento.

**Numeração de seção do procedimento que é lista, não seção.** Um item numerado longo dentro
do texto vira seção no índice. Isso não perde dado e aparece em `secoes.csv`, mas infla o
índice. Quando atrapalhar, diga, e aponte a evidência pelo número da linha em vez do nome da
seção.

**Parecer de conformidade, certificado, ou evidência para auditor externo.** Não faz, e não
vai fazer. O que sai é achado para o engenheiro trabalhar.

---

## Referência

A pasta da skill fica em `~/.claude/skills/padrao-conferido-contra-norma/` depois de
instalada. Os arquivos de referência são lidos por esse caminho, e os scripts são chamados
pelo caminho completo.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/padrao-conferido-contra-norma/references/leitura-de-requisito.md` | O que conta como reprodução de norma e o teste de três perguntas antes de gravar a linha. As três origens e o que cada uma autoriza. Nove armadilhas de leitura de requisito: "deve" contra "convém que", informação documentada que não pede procedimento escrito, cláusula renumerada entre edições, atendimento por remissão, exclusão de escopo, nota que não é requisito, requisito condicional, norma de produto e de ensaio, e assunto tratado em outro documento da casa. O vocabulário fechado dos furos. Leia antes do passo 3. |
| `~/.claude/skills/padrao-conferido-contra-norma/scripts/conferir-estrutura.py` | Conferência de forma do documento controlado, de um ou de vários procedimentos na mesma rodada, e razão da cobertura par a par, em Python de biblioteca padrão. Lê cabeçalho de controle vertical e tabela horizontal, consolida a rodada por cláusula, e não escreve arquivo de entrega antes de a rodada fechar. Não lê norma, não guarda texto de norma e não julga conteúdo. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/padrao-conferido-contra-norma/scripts/testar.py` | Teste de regressão do `conferir-estrutura.py`, biblioteca padrão apenas. Quarenta e dois casos, escritos a partir de uma pergunta só, repetida contra cada caminho do script: existe caminho em que isso sai com sucesso tendo perdido dado? Por isso a maioria é de rodada que precisa falhar: requisito com origem em branco, requisito sem edição, requisito que sumiu da matriz entre uma rodada e outra, veredito de furo em requisito que a pessoa não entregou, veredito de atendido no mesmo caso, origem trocada na matriz para destravar o furo, recomendação marcada como furo, procedimento editado entre a estrutura e o fechamento, matriz já julgada que `--forcar` tentaria apagar, atendido sem evidência, atendido apontando linha que não existe, atendido apontando linha branca, seção de histórico de revisões presente e vazia, campo preenchido com marcador de preenchimento, `N.A.` com pontos, linha de rodapé que carrega exigência de verdade, seção numerada curta que não pode sumir, procedimento sem nenhuma seção, rodada inválida que não pode deixar entrega no diretório, e a rodada de estrutura que nunca pode sair com 0. Do lado do que precisa passar: tabela de controle horizontal lida campo a campo, revisão `00` como valor preenchido, evidência apontada para campo de controle do cabeçalho, e dois procedimentos na mesma rodada com consolidação por cláusula. Os dois últimos casos não rodam o script: conferem que a papelada bate com o que existe (nome da pasta, limite da description, dependência declarada, o kit não listando esta skill como prevista) e que nenhum arquivo da skill afirma o requisito de uma cláusula de norma real. A norma das fixtures é fictícia de propósito. Rode `python3 ~/.claude/skills/padrao-conferido-contra-norma/scripts/testar.py` depois de qualquer mudança, ou `py -3 "$env:USERPROFILE\.claude\skills\padrao-conferido-contra-norma\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
