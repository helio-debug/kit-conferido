#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
conferir-estrutura.py, conferencia de forma do documento controlado e razao da
cobertura requisito por requisito, de um ou de varios procedimentos na mesma
rodada.

O QUE ESTE SCRIPT FAZ

  1. Le cada procedimento vigente em texto e diz, campo a campo, quais campos
     de controle existem preenchidos, quais existem vazios e quais faltam.
     Le tanto o cabecalho vertical (rotulo: valor) quanto a tabela de controle
     horizontal, que e o layout mais comum de POP exportado do Word.
  2. Indexa as secoes com linha de inicio e de fim, e classifica TODA linha do
     arquivo, para que nenhuma linha saia da conferencia em silencio.
  3. Monta a matriz de cobertura: uma linha por par procedimento x requisito,
     com o veredito em pendente, para o modelo preencher.
  4. No fechamento (--fechar), rele a matriz preenchida, confere que nenhum
     procedimento mudou desde a rodada de estrutura, valida linha por linha e
     so entao escreve furos.csv, a-conferir-na-sua-edicao.csv, o consolidado da
     rodada e o esqueleto do plano de correcao.

O QUE ESTE SCRIPT NAO FAZ, E NAO VAI FAZER

  Nao le norma, nao guarda texto de norma, nao tem requisito de cor e nao julga
  conteudo. O cruzamento entre o que o procedimento diz e o que o requisito
  exige e trabalho do modelo, e entra pela coluna veredito da matriz.

AS REGRAS QUE ELE EXISTE PARA IMPOR

  1. Requisito cuja origem nao e "entregue" NUNCA vira furo. Ele sai forcado
     para a-conferir-na-sua-edicao.csv, e tentar marca-lo como furo ou como
     atendido derruba a rodada com codigo 3. A origem vale a do arquivo de
     requisitos, nao a da matriz: editar a celula origem na matriz para
     destravar um furo tambem derruba a rodada.
  2. Requisito do tipo convem e recomendacao. Recomendacao nao atendida nao e
     furo, e marcar furo nela derruba a rodada.
  3. Nenhum arquivo de entrega e escrito por rodada invalida, e nenhuma rodada
     sai com sucesso tendo perdido dado: matriz ja julgada nao e sobrescrita
     nem com --forcar, e procedimento alterado entre a estrutura e o fechamento
     derruba a rodada, porque toda linha apontada como evidencia esta vencida.

DEPENDENCIA DECLARADA: biblioteca padrao do Python 3.8 ou superior, e nada
mais. Modulos usados: argparse, csv, hashlib, re, sys, unicodedata, datetime,
pathlib. Nao instala pacote, nao acessa rede, nao escreve nos arquivos de
entrada.

Depois da instalacao o script fica em
~/.claude/skills/padrao-conferido-contra-norma/scripts/conferir-estrutura.py, e
a rodada acontece na pasta dos arquivos de trabalho. Chame pelo caminho
completo: caminho relativo como scripts/conferir-estrutura.py so funciona de
dentro da pasta da skill.

CODIGOS DE SAIDA

  0  fechou, nenhum furo de forma, nenhum furo de conteudo, nada a conferir e
     nada ficou fora da conferencia
  1  fechou e ha furo, de forma ou de conteudo. Com --estrito e furo junto, o
     codigo 1 prevalece sobre o 2
  2  --estrito e sobrou requisito em a_conferir, sem nenhum furo
  3  erro de entrada, identidade que nao fecha, requisito nao parseado, matriz
     ja julgada que --forcar tentou sobrescrever, procedimento alterado depois
     da rodada de estrutura, matriz com linha pendente, matriz com linha a
     menos, origem trocada na matriz, veredito proibido pela origem ou pelo
     tipo, nenhuma secao reconhecida, ou nenhum requisito com origem entregue
  4  rodada de estrutura, sem fechamento: a matriz saiu em pendente e o
     conteudo nao foi conferido por ninguem ainda
  5  fechou sem furo, mas sobrou coisa fora da conferencia: requisito em
     a_conferir, campo de controle presente e vazio, linha repetida com
     conteudo mantida, ou linha fora de qualquer secao

O codigo 0 e estreito de proposito. A rodada de estrutura nunca devolve 0: ela
devolve 4, porque sair com 0 sem ninguem ter olhado o conteudo seria dizer que
o procedimento atende a norma. E o codigo 5 existe porque "nenhum furo" com
dado fora da conferencia nao e a mesma coisa que "nenhum furo".
"""

import argparse
import csv
import hashlib
import re
import sys
import unicodedata
from datetime import date
from pathlib import Path

VERSAO = "1.1"

OK = 0
COM_FURO = 1
ESTRITO_BLOQUEIA = 2
ERRO = 3
SEM_FECHAMENTO = 4
SOBROU_FORA = 5

ENCODINGS_TENTADOS = ("utf-8-sig", "utf-8", "cp1252", "latin-1")
DELIMITADORES = (";", ",", "\t", "|")

RODAPE = ("# Gerado com apoio de IA a partir do procedimento vigente e dos requisitos "
          "entregues pela pessoa. Revisar antes de assinar. Nao substitui "
          "responsabilidade tecnica.")

OMITIDO = "<omitido>"

# Arquivos de entrega: so existem quando a rodada de fechamento e valida. Numa
# rodada derrubada eles sao apagados, para nao deixar arquivo velho passando por
# novo nem CSV de rodada invalida com cara de entrega pronta.
ARQUIVOS_DE_ENTREGA = ("furos.csv", "a-conferir-na-sua-edicao.csv",
                       "consolidado-da-rodada.csv", "cobertura-por-clausula.csv",
                       "plano-de-correcao.md")

ARQUIVO_IMPRESSAO = "impressao-do-procedimento.csv"

# ---------------------------------------------------------------------------
# 1. Campos de controle do documento controlado
# ---------------------------------------------------------------------------
# Cada chave tem os rotulos aceitos, ja sem acento e em minuscula. A ordem
# importa: o rotulo mais longo e testado primeiro, senao "data" casa antes de
# "data de vigencia" e o script reporta o campo errado.
#
# Os dois ultimos, historico_revisao e ciencia, quase nunca aparecem como
# "rotulo: valor". Aparecem como titulo de secao com uma tabela embaixo, e por
# isso tem tratamento proprio: titulo achado e secao sem nenhuma linha util
# embaixo sai como presente_vazio, nunca como presente_preenchido.

CAMPOS_DE_CONTROLE = [
    ("codigo", ["codigo do documento", "numero do documento", "documento no",
                "documento n", "identificacao do documento", "codigo", "doc"]),
    ("titulo", ["titulo do documento", "nome do documento", "titulo"]),
    ("revisao", ["revisao no", "numero da revisao", "revisao", "versao", "rev"]),
    ("data_vigencia", ["data de vigencia", "vigente desde", "data de emissao",
                       "data de aprovacao", "vigencia", "emitido em", "data"]),
    ("elaborado_por", ["elaborado por", "elaboracao", "preparado por",
                       "redigido por", "autor"]),
    ("aprovado_por", ["aprovado por", "aprovacao", "aprovador", "aprovada por"]),
    ("dono", ["dono do processo", "responsavel pelo processo", "gestor do processo",
              "area responsavel", "processo dono", "dono"]),
    ("historico_revisao", ["historico de revisoes", "historico de revisao",
                           "controle de alteracoes", "registro de alteracoes",
                           "historico de alteracoes", "controle de revisoes"]),
    ("ciencia", ["registro de ciencia", "lista de distribuicao", "distribuicao",
                 "ciencia dos envolvidos", "registro de treinamento",
                 "divulgacao e treinamento"]),
]

CAMPOS_DE_SECAO = ("historico_revisao", "ciencia")

CAMPOS_COM_NOME_DE_PESSOA = ("elaborado_por", "aprovado_por", "dono")

# titulo fica fora do padrao de proposito: em quase todo procedimento o titulo e
# o cabecalho da pagina e nao um campo rotulado, e exigi-lo por padrao produziria
# um furo de forma que nao existe. Quem quiser, passa em --campos.
CAMPOS_PADRAO = ("codigo,revisao,data_vigencia,elaborado_por,aprovado_por,dono,"
                 "historico_revisao,ciencia")

# Valor que existe no papel e nao diz nada. Na duvida entre tratar como
# preenchido e reportar como vazio, este script reporta como vazio.
#
# "0" e "00" NAO entram aqui: revisao 00 e a identificacao padrao da primeira
# emissao de um documento controlado, e trata-la como campo vazio produz furo de
# forma contra um documento corretamente preenchido.
PLACEHOLDERS = {
    "", "-", "--", "---", "n/a", "na", "n.a.", "nao aplicavel", "x", "xx", "xxx",
    "a definir", "a preencher", "preencher", "tbd", "?", "??", "[ ]", "()",
    "< >", "<>",
}
PADRAO_PLACEHOLDER = re.compile(r"^[\s_\.\-\*]*$")

# Furo de forma: vocabulario fechado, um por campo de controle.
FURO_DE_FORMA = {
    "codigo": "sem_codigo_de_documento",
    "titulo": "sem_titulo",
    "revisao": "sem_identificacao_de_revisao",
    "data_vigencia": "sem_data_de_vigencia",
    "elaborado_por": "sem_registro_de_elaboracao",
    "aprovado_por": "sem_registro_de_aprovacao",
    "dono": "sem_dono",
    "historico_revisao": "sem_historico_de_revisao",
    "ciencia": "sem_registro_de_ciencia",
}

# O que fazer com o furo de forma, e a pergunta que vai ao dono do procedimento
# quando o valor nao esta em lugar nenhum do documento. Entra no esqueleto do
# plano-de-correcao.md.
PENDENCIA_DE_FORMA = {
    "codigo": "dar ao documento o codigo do padrao de codificacao da casa e por no cabecalho de controle",
    "titulo": "escrever o titulo no cabecalho de controle, nao so no rodape da pagina",
    "revisao": "identificar a revisao no cabecalho de controle",
    "data_vigencia": "registrar a data a partir da qual esta revisao vale",
    "elaborado_por": "registrar quem elaborou esta revisao",
    "aprovado_por": "registrar quem aprovou esta revisao",
    "dono": "nomear a funcao dona do processo",
    "historico_revisao": "abrir a tabela de historico com o que mudou em cada revisao",
    "ciencia": "registrar quem recebeu e quem deu ciencia desta revisao",
}

PERGUNTA_DE_FORMA = {
    "codigo": "qual codigo este documento tem no sistema de gestao, e quem mantem essa lista?",
    "titulo": "qual e o titulo oficial deste documento?",
    "revisao": "qual e a revisao vigente deste documento, e onde ela e controlada?",
    "data_vigencia": "desde quando esta revisao vale?",
    "elaborado_por": "quem elaborou esta revisao?",
    "aprovado_por": "quem aprovou esta revisao, e onde essa aprovacao fica guardada?",
    "dono": "qual funcao responde por este processo hoje?",
    "historico_revisao": "o que mudou da revisao anterior para esta?",
    "ciencia": "quem precisa dar ciencia desta revisao, e como isso e registrado hoje?",
}

# Furo de conteudo: vocabulario fechado. O modelo escolhe um destes na coluna
# o_que_falta da matriz. Valor fora da lista derruba a rodada.
FURO_DE_CONTEUDO = {
    "nao_tratado": "nada no procedimento trata a exigencia",
    "tratado_parcial": "parte da exigencia esta tratada, parte nao",
    "tratado_sem_registro": "manda fazer, nao diz qual registro prova que foi feito",
    "tratado_sem_dono": "acao sem responsavel nomeado",
    "tratado_sem_criterio": "manda conferir sem criterio de aceitacao nem frequencia",
    "referencia_quebrada": "atende por remissao a documento que nao existe ou nao foi apresentado",
    "exclusao_nao_declarada": "na pratica nao se aplica, e a exclusao nao esta declarada",
}

PENDENCIA_DE_CONTEUDO = {
    "nao_tratado": "o procedimento precisa passar a tratar a exigencia. Pendencia, nao texto pronto",
    "tratado_parcial": "completar a parte que falta, dita como pendencia",
    "tratado_sem_registro": "nomear o registro que prova a execucao e onde ele fica",
    "tratado_sem_dono": "nomear a funcao responsavel pela acao",
    "tratado_sem_criterio": "escrever o criterio de aceitacao e a frequencia",
    "referencia_quebrada": "apresentar o documento remetido, ou trazer a exigencia para dentro deste",
    "exclusao_nao_declarada": "declarar a exclusao em documento controlado",
}

PERGUNTA_DE_CONTEUDO = {
    "nao_tratado": "quem faz isso hoje na pratica, e em que documento isso deveria estar escrito?",
    "tratado_parcial": "qual parte disso ja e feita e nao esta escrita?",
    "tratado_sem_registro": "qual registro prova hoje que essa etapa foi feita, e onde ele fica guardado?",
    "tratado_sem_dono": "qual funcao responde por essa etapa?",
    "tratado_sem_criterio": "qual e o criterio de aceitacao praticado hoje, e com que frequencia?",
    "referencia_quebrada": "o documento citado existe? qual e o codigo e a revisao vigente dele?",
    "exclusao_nao_declarada": "essa atividade realmente nao se aplica aqui? onde essa exclusao esta declarada?",
}

VEREDITOS = ("atendido", "furo", "a_conferir", "pendente")
ORIGENS = ("entregue", "sumario", "nao_entregue")
TIPOS = ("deve", "convem")

COLUNAS_MATRIZ = ["procedimento", "clausula", "norma", "edicao", "origem", "tipo",
                  "condicao", "requisito", "veredito", "o_que_falta", "onde", "linha",
                  "motivo"]

COLUNAS_FUROS = ["procedimento", "classe", "clausula", "norma", "edicao", "o_que_falta",
                 "explicacao", "requisito", "onde", "linha", "origem_do_requisito",
                 "observacao"]

COLUNAS_A_CONFERIR = ["procedimento", "clausula", "norma", "edicao", "origem_do_requisito",
                      "requisito", "motivo", "o_que_fazer"]

MOTIVO_NAO_ENTREGUE = ("requisito nao entregue pela pessoa, conferir na edicao vigente "
                       "da sua empresa")

# ---------------------------------------------------------------------------
# 2. Leitura de texto
# ---------------------------------------------------------------------------


def ler_texto(caminho):
    """Devolve (texto, encoding). NFC na leitura, para que tirar acento
    preserve o comprimento da linha e o indice do valor continue valendo."""
    bruto = Path(caminho).read_bytes()
    for enc in ENCODINGS_TENTADOS:
        try:
            texto = bruto.decode(enc)
        except UnicodeDecodeError:
            continue
        return unicodedata.normalize("NFC", texto), enc
    return unicodedata.normalize("NFC", bruto.decode("latin-1", "replace")), "latin-1 (com perda)"


def sem_acento(s):
    d = unicodedata.normalize("NFD", s)
    return "".join(c for c in d if not unicodedata.combining(c))


def normalizar_linha(linha):
    """Minuscula, sem acento, tabulacao virada em espaco. Preserva o
    comprimento quando da, e quando nao da o chamador percebe e usa a propria
    linha normalizada para extrair o valor."""
    s = sem_acento(linha).lower().replace("\t", " ")
    return s


def normalizar_chave(s):
    s = sem_acento(s).lower().replace("\t", " ")
    s = re.sub(r"\s+", " ", s)
    return s.strip(" .:-")


def eh_placeholder(valor):
    v = normalizar_chave(valor)
    if v in PLACEHOLDERS:
        return True
    # N.A. e N.A sobrevivem a normalizar_chave com um ponto no meio, e passariam
    # como valor preenchido. Colapsar a pontuacao interna resolve as tres
    # variantes de uma vez: n/a, n.a. e n a.
    colapsado = re.sub(r"[^0-9a-z]+", "", v)
    if colapsado and colapsado in PLACEHOLDERS:
        return True
    return bool(PADRAO_PLACEHOLDER.match(valor))


def impressao_do_texto(texto):
    """Contagem de linhas, de caracteres e resumo criptografico do procedimento.
    O fechamento rele o arquivo e compara: procedimento editado depois da rodada
    de estrutura vence toda linha apontada como evidencia na matriz."""
    return {"linhas": len(texto.splitlines()),
            "caracteres": len(texto),
            "impressao": hashlib.sha256(texto.encode("utf-8")).hexdigest()[:16]}


def apelido(caminho):
    """Nome curto e sem espaco, para diretorio de procedimento na rodada."""
    base = sem_acento(Path(caminho).stem).lower()
    base = re.sub(r"[^a-z0-9]+", "-", base).strip("-")
    return base or "procedimento"


# ---------------------------------------------------------------------------
# 3. Linhas de rodape corrido e linhas repetidas
# ---------------------------------------------------------------------------

PADROES_DE_RODAPE = [
    (re.compile(r"^\s*p[ag]g(?:ina)?\.?\s*\d+\s*(?:de|/)\s*\d+\s*$"), "marcador_de_pagina"),
    (re.compile(r"^\s*\d+\s*/\s*\d+\s*$"), "marcador_de_pagina"),
    (re.compile(r"^\s*[-_=*~]{3,}\s*$"), "separador"),
]

PALAVRAS_SEM_CONTEUDO = {
    "pagina", "de", "do", "da", "dos", "das", "rev", "revisao", "versao", "pag",
    "folha", "emitido", "em", "data", "codigo", "documento", "anexo", "controlado",
    "copia", "impressa", "nao", "e", "o", "a", "os", "as", "no", "na", "para",
    "por", "com", "sem", "uso", "interno", "confidencial",
}


def palavras_de_conteudo(linha):
    """Palavras com quatro letras ou mais que nao sao vocabulario de rodape e
    nao sao numero. Serve para nao apagar em silencio uma linha que se repete
    em todas as paginas mas carrega exigencia de verdade."""
    fora = []
    for p in re.findall("[a-z]+", normalizar_linha(linha)):
        if len(p) >= 4 and p not in PALAVRAS_SEM_CONTEUDO:
            fora.append(p)
    return fora


def marcar_rodape(linhas):
    """Devolve {indice_1based: (causa, destino)}. destino em
    {'removida', 'mantida'}. Linha repetida que carrega conteudo fica mantida:
    e a armadilha que apaga a exigencia escrita no rodape de todas as paginas."""
    marcas = {}
    contagem = {}
    for linha in linhas:
        chave = normalizar_chave(linha)
        if chave:
            contagem[chave] = contagem.get(chave, 0) + 1

    for i, linha in enumerate(linhas, start=1):
        if not linha.strip():
            continue
        alvo = normalizar_linha(linha)
        causa = None
        for padrao, nome in PADROES_DE_RODAPE:
            if padrao.match(alvo):
                causa = nome
                break
        if causa is None and contagem.get(normalizar_chave(linha), 0) >= 3:
            causa = "repetida_em_tres_ou_mais_paginas"
        if causa is None:
            continue
        if len(palavras_de_conteudo(linha)) >= 5:
            marcas[i] = ("repetida_mas_com_conteudo", "mantida")
        else:
            marcas[i] = (causa, "removida")
    return marcas


# ---------------------------------------------------------------------------
# 4. Secoes
# ---------------------------------------------------------------------------

PADRAO_NUMERADA = re.compile(r"^\s*(\d+(?:\.\d+)*)[\.\)]?\s+(\S.*)$")
PADRAO_MARKDOWN = re.compile(r"^\s*(#{1,6})\s+(\S.*)$")
PADRAO_ANEXO = re.compile(r"^\s*(anexo|apendice)\s+([a-z0-9]+)\b\s*[\.\-:]?\s*(.*)$")


def eh_titulo_caixa_alta(linha):
    """Titulo em caixa alta, o formato mais comum de procedimento antigo.
    Exige duas palavras, no maximo oitenta caracteres e nada de ponto final."""
    bruta = linha.strip()
    if not (4 <= len(bruta) <= 80):
        return False
    if bruta.endswith("."):
        return False
    letras = [c for c in bruta if c.isalpha()]
    if len(letras) < 4:
        return False
    if any(c.islower() for c in letras):
        return False
    return len(bruta.split()) >= 2


def indexar_secoes(linhas, marcas):
    """Devolve (secoes, linha_da_primeira_secao). Cada secao e um dict com
    numero, titulo, linha_inicio, linha_fim, linhas_de_conteudo."""
    titulos = []
    for i, linha in enumerate(linhas, start=1):
        if marcas.get(i, ("", ""))[1] == "removida":
            continue
        if not linha.strip():
            continue
        alvo = normalizar_linha(linha).strip()
        m = PADRAO_MARKDOWN.match(linha)
        if m:
            titulos.append((i, "", m.group(2).strip()))
            continue
        m = PADRAO_ANEXO.match(alvo)
        if m:
            titulos.append((i, (m.group(1) + " " + m.group(2)).upper(), linha.strip()))
            continue
        m = PADRAO_NUMERADA.match(linha)
        if m and len(m.group(2).strip()) <= 120:
            titulos.append((i, m.group(1), m.group(2).strip()))
            continue
        if eh_titulo_caixa_alta(linha):
            titulos.append((i, "", linha.strip()))

    secoes = []
    for pos, (inicio, numero, titulo) in enumerate(titulos):
        fim = (titulos[pos + 1][0] - 1) if pos + 1 < len(titulos) else len(linhas)
        conteudo = 0
        for j in range(inicio + 1, fim + 1):
            if marcas.get(j, ("", ""))[1] == "removida":
                continue
            if linhas[j - 1].strip():
                conteudo += 1
        secoes.append({"numero": numero, "titulo": titulo, "linha_inicio": inicio,
                       "linha_fim": fim, "linhas_de_conteudo": conteudo})
    primeira = titulos[0][0] if titulos else None
    return secoes, primeira


# ---------------------------------------------------------------------------
# 5. Campos de controle
# ---------------------------------------------------------------------------

SEPARADORES = "[:\\-\u2013\u2014\\t]"  # dois-pontos, hifen, meia-risca, travessao, tabulacao


def celulas_de_tabela(linha):
    return [c.strip() for c in linha.strip().strip("|").split("|")]


def eh_linha_de_tabela(linha):
    return linha.strip().startswith("|")


def eh_separador_de_tabela(linha):
    """A linha |---|---| que separa o cabecalho dos valores."""
    if not eh_linha_de_tabela(linha):
        return False
    celulas = celulas_de_tabela(linha)
    if not any(celulas):
        return False
    return all(c == "" or re.fullmatch(r":?-+:?", c) for c in celulas)


def linha_sem_conteudo_util(linha):
    """Linha que ocupa espaco e nao diz nada: separador de tabela, celula so com
    marcador de preenchimento, traco, n/a."""
    if eh_separador_de_tabela(linha):
        return True
    if eh_linha_de_tabela(linha):
        return all(eh_placeholder(c) for c in celulas_de_tabela(linha))
    return eh_placeholder(linha)


def achar_valor_rotulado(linha, rotulo):
    """Procura 'rotulo <separador> valor' ou 'rotulo  valor' no inicio da
    linha, ou numa celula de tabela vertical. Devolve o valor ou None."""
    bruta = linha.rstrip("\n")
    alvo = normalizar_linha(bruta)
    mesmo_tamanho = len(alvo) == len(bruta)
    fonte = bruta if mesmo_tamanho else alvo

    if bruta.strip().startswith("|"):
        if eh_separador_de_tabela(bruta):
            return None
        celulas = celulas_de_tabela(bruta)
        if celulas and normalizar_chave(celulas[0]) == rotulo:
            return celulas[1] if len(celulas) > 1 else ""
        return None

    padrao = re.compile(r"^\s*" + re.escape(rotulo) +
                        "\\s*(?:n[o\u00ba\u00b0]\\.?)?\\s*(?:" + SEPARADORES + r"\s*|\s{2,})(.*)$")
    m = padrao.match(alvo)
    if not m:
        return None
    return fonte[m.start(1):m.end(1)].strip() if mesmo_tamanho else m.group(1).strip()


def achar_titulo_de_secao(linha, rotulo):
    return normalizar_chave(linha) == rotulo


def chave_do_rotulo(celula, dicionario, exigidos):
    alvo = normalizar_chave(celula)
    if not alvo:
        return None
    for chave in exigidos:
        for rotulo in dicionario.get(chave, []):
            if alvo == rotulo:
                return chave
    return None


def dentro_de_secao_de_historico(numero, secoes, dicionario):
    """True quando a linha cai numa secao de historico de revisoes ou de lista de
    distribuicao. A tabela dessas secoes tem coluna de revisao e coluna de data, e
    ler campo de controle dela e ler a revisao errada."""
    rotulos = []
    for chave in CAMPOS_DE_SECAO:
        rotulos += dicionario.get(chave, [])
    for s in secoes:
        if s["linha_inicio"] <= numero <= s["linha_fim"]:
            return normalizar_chave(s["titulo"]) in rotulos
    return False


def mapear_tabela_horizontal(linhas, secoes, dicionario, exigidos):
    """Tabela de controle horizontal: uma linha de rotulos no topo e a linha de
    valores embaixo. E o layout mais comum de POP exportado do Word, e ler so a
    primeira celula da linha devolveria o rotulo da coluna seguinte como se
    fosse o valor do campo, produzindo furo de forma falso contra campo
    preenchido.

    Devolve (achados, linhas_da_tabela). achados: {chave: (rotulo, valor,
    numero_da_linha_lida)}. linhas_da_tabela: as linhas que pertencem a alguma
    tabela horizontal reconhecida, para a leitura vertical nao tocar nelas.

    Cabecalho e a linha de tabela em que pelo menos dois rotulos de campo de
    controle diferentes casam. Uma linha so com um rotulo casando e tabela
    vertical, e continua sendo lida como rotulo na primeira celula e valor na
    segunda."""
    achados = {}
    da_tabela = set()
    total = len(linhas)
    i = 1
    while i <= total:
        linha = linhas[i - 1]
        if not eh_linha_de_tabela(linha) or eh_separador_de_tabela(linha):
            i += 1
            continue
        cabecalho = celulas_de_tabela(linha)
        casadas = {}
        for pos, celula in enumerate(cabecalho):
            chave = chave_do_rotulo(celula, dicionario, exigidos)
            if chave and chave not in casadas:
                casadas[chave] = pos
        if len(casadas) < 2 or dentro_de_secao_de_historico(i, secoes, dicionario):
            i += 1
            continue
        j = i + 1
        while j <= total and (not linhas[j - 1].strip() or eh_separador_de_tabela(linhas[j - 1])):
            j += 1
        tem_valores = j <= total and eh_linha_de_tabela(linhas[j - 1])
        valores = celulas_de_tabela(linhas[j - 1]) if tem_valores else []
        limite = j if tem_valores else i
        for k in range(i, limite + 1):
            if k <= total and eh_linha_de_tabela(linhas[k - 1]):
                da_tabela.add(k)
        for chave, pos in casadas.items():
            if chave in achados:
                continue
            valor = valores[pos] if pos < len(valores) else ""
            achados[chave] = (normalizar_chave(cabecalho[pos]), valor, limite)
        i = limite + 1
    return achados, da_tabela


def conferir_campos(linhas, marcas, secoes, exigidos, dicionario):
    """Um registro por campo exigido. Tres situacoes possiveis, e nenhuma
    delas e inferida: presente_preenchido, presente_vazio, ausente."""
    horizontais, linhas_da_tabela = mapear_tabela_horizontal(linhas, secoes, dicionario,
                                                            exigidos)
    achados = []
    for chave in exigidos:
        rotulos = dicionario[chave]
        registro = {"campo": chave, "situacao": "ausente", "rotulo_encontrado": "",
                    "linha": "", "origem_da_linha": "", "valor": ""}
        candidato = None

        for i, linha in enumerate(linhas, start=1):
            if i in linhas_da_tabela:
                continue
            achou = None
            for rotulo in rotulos:
                valor = achar_valor_rotulado(linha, rotulo)
                if valor is not None:
                    achou = (rotulo, valor)
                    break
            if achou:
                origem = ("rodape" if marcas.get(i, ("", ""))[1] == "removida" else "corpo")
                candidato = (i, achou[0], achou[1], origem)
                break

        if chave in horizontais:
            rotulo, valor, numero = horizontais[chave]
            if candidato is None or numero < candidato[0]:
                candidato = (numero, rotulo, valor, "tabela_de_controle_horizontal")

        if candidato:
            registro["linha"] = candidato[0]
            registro["rotulo_encontrado"] = candidato[1]
            registro["valor"] = candidato[2]
            registro["origem_da_linha"] = candidato[3]
            registro["situacao"] = ("presente_vazio" if eh_placeholder(candidato[2])
                                    else "presente_preenchido")
            achados.append(registro)
            continue

        if chave in CAMPOS_DE_SECAO:
            for secao in secoes:
                achou = False
                for rotulo in rotulos:
                    if achar_titulo_de_secao(secao["titulo"], rotulo):
                        achou = True
                        break
                if not achou:
                    continue
                # Secao presente cujo conteudo e so separador de tabela, traco ou
                # N.A. e a aparencia do campo, nao o campo. Contar linha nao
                # basta: o ramo de titulo de secao tem que perguntar se alguma
                # linha diz alguma coisa.
                uteis = 0
                for k in range(secao["linha_inicio"] + 1, secao["linha_fim"] + 1):
                    if marcas.get(k, ("", ""))[1] == "removida":
                        continue
                    conteudo = linhas[k - 1]
                    if not conteudo.strip():
                        continue
                    if linha_sem_conteudo_util(conteudo):
                        continue
                    uteis += 1
                registro["rotulo_encontrado"] = normalizar_chave(secao["titulo"])
                registro["linha"] = secao["linha_inicio"]
                registro["origem_da_linha"] = "titulo_de_secao"
                registro["valor"] = ("<secao com %d linha(s) de conteudo, %d util(eis)>"
                                     % (secao["linhas_de_conteudo"], uteis))
                registro["situacao"] = "presente_preenchido" if uteis > 0 else "presente_vazio"
                break

        achados.append(registro)
    return achados


# ---------------------------------------------------------------------------
# 6. Requisitos
# ---------------------------------------------------------------------------


def detectar_delimitador(texto):
    primeira = texto.splitlines()[0] if texto.splitlines() else ""
    melhor, quantas = ";", -1
    for d in DELIMITADORES:
        n = primeira.count(d)
        if n > quantas:
            melhor, quantas = d, n
    return melhor if quantas > 0 else ";"


def ler_requisitos(caminho):
    """Devolve (linhas_ok, nao_parseados). Nenhuma linha e descartada: a que
    nao passa vai para nao_parseados com o motivo, e derruba a rodada. A linha
    de comentario, que comeca com #, e a unica que sai de fora, e e assim que o
    rodape de artefato colado por engano no requisitos.csv deixa de derrubar a
    rodada."""
    texto, _enc = ler_texto(caminho)
    delim = detectar_delimitador(texto)
    leitor = csv.DictReader(texto.splitlines(), delimiter=delim)
    campos = [normalizar_chave(c or "") for c in (leitor.fieldnames or [])]
    obrigatorias = ("clausula", "requisito", "origem", "norma", "edicao")
    faltando = [c for c in obrigatorias if c not in campos]
    if faltando:
        raise ValueError("faltam colunas no arquivo de requisitos: %s. Colunas lidas: %s"
                         % (", ".join(faltando), ", ".join(campos) or "nenhuma"))

    ok, ruins = [], []
    for numero, bruta in enumerate(leitor, start=2):
        linha = {normalizar_chave(k or ""): (v or "").strip()
                 for k, v in bruta.items() if k is not None}
        if linha.get("clausula", "").startswith("#"):
            continue
        problemas = []
        for c in obrigatorias:
            if not linha.get(c):
                problemas.append("coluna %s vazia" % c)
        origem = normalizar_chave(linha.get("origem", ""))
        if origem and origem not in ORIGENS:
            problemas.append("origem '%s' fora de %s" % (origem, "/".join(ORIGENS)))
        tipo = normalizar_chave(linha.get("tipo", "")) or "deve"
        if tipo not in TIPOS:
            problemas.append("tipo '%s' fora de %s" % (tipo, "/".join(TIPOS)))
        if problemas:
            ruins.append({"linha_do_arquivo": numero,
                          "clausula": linha.get("clausula", ""),
                          "motivo": "; ".join(problemas)})
            continue
        ok.append({"clausula": linha["clausula"], "norma": linha["norma"],
                   "edicao": linha["edicao"], "origem": origem, "tipo": tipo,
                   "condicao": linha.get("condicao", ""),
                   "requisito": linha["requisito"]})
    return ok, ruins


def montar_matriz(procedimentos, requisitos):
    """Uma linha por par procedimento x requisito. E o mesmo checklist aplicado
    a todos os procedimentos da rodada, que e a razao de o script existir."""
    linhas = []
    for proc in procedimentos:
        for r in requisitos:
            linha = dict(r)
            linha["procedimento"] = proc["nome"]
            if r["origem"] == "entregue":
                linha["veredito"] = "pendente"
                linha["motivo"] = ""
            else:
                # Trava da lei de ferro 2, aplicada na origem e nao na revisao.
                linha["veredito"] = "a_conferir"
                linha["motivo"] = MOTIVO_NAO_ENTREGUE
            linha["o_que_falta"] = ""
            linha["onde"] = ""
            linha["linha"] = ""
            linhas.append(linha)
    return linhas


def ler_matriz_preenchida(caminho):
    texto, _enc = ler_texto(caminho)
    delim = detectar_delimitador(texto)
    leitor = csv.DictReader(texto.splitlines(), delimiter=delim)
    linhas = []
    for bruta in leitor:
        # Linha de comentario, e o rodape de artefato que o script mesmo grava no
        # fim da matriz. Ele cai na primeira coluna, que hoje e procedimento.
        if any((bruta.get(c) or "").startswith("#") for c in ("procedimento", "clausula")):
            continue
        linhas.append({normalizar_chave(k or ""): (v or "").strip()
                       for k, v in bruta.items() if k is not None})
    return linhas


def linhas_julgadas_na_matriz(saida):
    """Quantas linhas da matriz-cobertura.csv que ja esta no diretorio carregam
    julgamento de gente. Serve para --forcar nunca apagar trabalho feito."""
    caminho = Path(saida) / "matriz-cobertura.csv"
    if not caminho.exists():
        return 0
    try:
        linhas = ler_matriz_preenchida(caminho)
    except Exception:  # noqa: BLE001
        return 0
    julgadas = 0
    for linha in linhas:
        veredito = normalizar_chave(linha.get("veredito", ""))
        if veredito in ("atendido", "furo"):
            julgadas += 1
            continue
        if any(linha.get(c) for c in ("o_que_falta", "onde", "linha")):
            julgadas += 1
            continue
        if veredito == "a_conferir" and normalizar_chave(linha.get("motivo", "")) \
                not in ("", normalizar_chave(MOTIVO_NAO_ENTREGUE)):
            julgadas += 1
    return julgadas


# ---------------------------------------------------------------------------
# 7. Escrita
# ---------------------------------------------------------------------------


def escrever_csv(caminho, colunas, linhas, rodape=True):
    with open(caminho, "w", encoding="utf-8-sig", newline="") as f:
        escritor = csv.writer(f, delimiter=";")
        escritor.writerow(colunas)
        for linha in linhas:
            escritor.writerow([linha.get(c, "") for c in colunas])
        if rodape:
            escritor.writerow([RODAPE] + [""] * (len(colunas) - 1))


def escrever_texto(caminho, linhas):
    Path(caminho).write_text("\n".join(linhas) + "\n", encoding="utf-8")


def apagar_entrega(saida):
    """Rodada invalida nao deixa arquivo de entrega no diretorio. Arquivo de
    rodada anterior que fique ali passa por entrega nova, e quem abrir a pasta
    depois le furo de uma rodada que nao vale."""
    apagados = []
    for nome in ARQUIVOS_DE_ENTREGA:
        caminho = Path(saida) / nome
        if caminho.exists():
            caminho.unlink()
            apagados.append(nome)
    return apagados


def escrever_impressoes(saida, procedimentos):
    escrever_csv(Path(saida) / ARQUIVO_IMPRESSAO,
                 ["procedimento", "linhas", "caracteres", "impressao"],
                 [{"procedimento": p["nome"], "linhas": p["impressao"]["linhas"],
                   "caracteres": p["impressao"]["caracteres"],
                   "impressao": p["impressao"]["impressao"]} for p in procedimentos])


def ler_impressoes(saida):
    """Devolve {nome: {linhas, caracteres, impressao}} ou None quando o arquivo
    nao existe, o que significa que nao houve rodada de estrutura aqui."""
    caminho = Path(saida) / ARQUIVO_IMPRESSAO
    if not caminho.exists():
        return None
    texto, _enc = ler_texto(caminho)
    leitor = csv.DictReader(texto.splitlines(), delimiter=";")
    guardadas = {}
    for bruta in leitor:
        nome = (bruta.get("procedimento") or "").strip()
        if not nome or nome.startswith("#"):
            continue
        guardadas[nome] = {"linhas": (bruta.get("linhas") or "").strip(),
                           "caracteres": (bruta.get("caracteres") or "").strip(),
                           "impressao": (bruta.get("impressao") or "").strip()}
    return guardadas


def escrever_plano(caminho, furos, procedimentos):
    """Esqueleto do plano de correcao, gerado do furos.csv: um bloco por furo, o
    que falta, onde, a pendencia e a pergunta pronta ao dono do procedimento.
    O script nao escreve o paragrafo do procedimento, e nao vai escrever."""
    forma = [f for f in furos if f["classe"] == "forma"]
    conteudo = [f for f in furos if f["classe"] == "conteudo"]
    linhas = ["# Plano de correcao", "",
              "Um bloco por furo. Primeiro o que se resolve no cabecalho de controle,",
              "depois o que depende de decisao de processo. O texto do procedimento nao",
              "vem escrito aqui de proposito: o que sai e pendencia, e quem redige e o",
              "dono do documento.", "",
              "Procedimentos da rodada: %s" % ", ".join(p["nome"] for p in procedimentos),
              "", "## Furos de forma (%d)" % len(forma), ""]
    for n, f in enumerate(forma, start=1):
        campo = f.get("campo", "")
        linhas += ["### %d. %s, em %s" % (n, f["o_que_falta"], f["procedimento"]),
                   "- o que falta: %s" % f["explicacao"],
                   "- onde: %s" % f["onde"],
                   "- pendencia: %s" % PENDENCIA_DE_FORMA.get(campo,
                                                             "preencher o campo no cabecalho de controle"),
                   "- pergunta ao dono do procedimento: %s"
                   % PERGUNTA_DE_FORMA.get(campo, "onde esta esse dado hoje?"),
                   ""]
    if not forma:
        linhas += ["Nenhum.", ""]
    linhas += ["## Furos de conteudo (%d)" % len(conteudo), ""]
    for n, f in enumerate(conteudo, start=1):
        falta = f["o_que_falta"]
        linhas += ["### %d. clausula %s, %s %s, em %s"
                   % (n, f["clausula"], f["norma"], f["edicao"], f["procedimento"]),
                   "- o que falta: %s (%s)" % (falta, f["explicacao"]),
                   "- requisito, nas palavras da pessoa: %s" % f["requisito"],
                   "- onde: %s, linha %s" % (f["onde"], f["linha"] or "nao apontada"),
                   "- pendencia: %s" % PENDENCIA_DE_CONTEUDO.get(falta, "tratar a exigencia"),
                   "- pergunta ao dono do procedimento: %s"
                   % PERGUNTA_DE_CONTEUDO.get(falta, "como isso e feito hoje?"),
                   ""]
    if not conteudo:
        linhas += ["Nenhum.", ""]
    linhas += ["Confira o requisito na edicao vigente da sua empresa antes de fechar cada",
               "bloco. Esta lista e achado, nao e nao conformidade.", "",
               RODAPE.lstrip("# ")]
    escrever_texto(caminho, linhas)


# ---------------------------------------------------------------------------
# 8. Fechamento, formatacao
# ---------------------------------------------------------------------------


def bloco(titulo, linhas):
    return ["", titulo, "-" * len(titulo)] + linhas


def formatar_identidade(nome, total, parcelas):
    soma = sum(v for _, v in parcelas)
    corpo = " + ".join("%s %d" % (n, v) for n, v in parcelas)
    estado = "fecha" if soma == total else "NAO FECHA"
    return "%-34s %6d = %s  (%d)  %s" % (nome, total, corpo, soma, estado), soma == total


# ---------------------------------------------------------------------------
# 9. Um procedimento
# ---------------------------------------------------------------------------


def processar_procedimento(caminho, exigidos, dicionario):
    """Devolve (proc, erro). Nenhuma parcela sai por subtracao: cada linha do
    arquivo e classificada dentro do laco, uma vez."""
    texto, encoding = ler_texto(caminho)
    linhas = texto.splitlines()
    if not linhas:
        return None, "o procedimento %s esta vazio." % caminho

    marcas = marcar_rodape(linhas)
    secoes, primeira_secao = indexar_secoes(linhas, marcas)

    contagem = {"branca": 0, "cabecalho": 0, "secao": 0, "removida": 0}
    contadas = 0
    for i, linha in enumerate(linhas, start=1):
        contadas += 1
        if marcas.get(i, ("", ""))[1] == "removida":
            contagem["removida"] += 1
        elif not linha.strip():
            contagem["branca"] += 1
        elif primeira_secao is None or i < primeira_secao:
            contagem["cabecalho"] += 1
        else:
            contagem["secao"] += 1

    ignoradas = [{"linha": i, "causa": causa, "destino": destino,
                  "conteudo": linhas[i - 1].strip()[:200]}
                 for i, (causa, destino) in sorted(marcas.items())]
    mantidas = sum(1 for x in ignoradas if x["destino"] == "mantida")
    removidas = sum(1 for x in ignoradas if x["destino"] == "removida")

    campos = conferir_campos(linhas, marcas, secoes, exigidos, dicionario)

    # Linha do cabecalho que nao e branca, nao foi removida como rodape e nao
    # carrega nenhum campo de controle: e texto que nenhuma secao cobre, e por
    # isso nenhum requisito pode apontar para ela. Nao vira furo, vira leitura
    # obrigatoria antes de chamar a rodada de limpa.
    linhas_de_campo = {c["linha"] for c in campos if c["linha"]}
    cabecalho_nao_explicado = 0
    if primeira_secao is not None:
        for i in range(1, primeira_secao):
            if marcas.get(i, ("", ""))[1] == "removida":
                continue
            if not linhas[i - 1].strip():
                continue
            if i in linhas_de_campo:
                continue
            cabecalho_nao_explicado += 1

    preenchidos = sum(1 for c in campos if c["situacao"] == "presente_preenchido")
    vazios = sum(1 for c in campos if c["situacao"] == "presente_vazio")
    ausentes = sum(1 for c in campos if c["situacao"] == "ausente")

    nome = Path(caminho).name
    identidades = []
    identidades.append(formatar_identidade("linhas do arquivo", len(linhas), [
        ("brancas", contagem["branca"]), ("cabecalho", contagem["cabecalho"]),
        ("em secao", contagem["secao"]), ("removidas", contagem["removida"])]))
    identidades.append(formatar_identidade("linhas contadas no laco", len(linhas),
                                           [("contadas", contadas)]))
    identidades.append(formatar_identidade("linhas em linhas-ignoradas", len(ignoradas), [
        ("removidas", removidas), ("mantidas", mantidas)]))
    identidades.append(formatar_identidade("campos de controle exigidos", len(exigidos), [
        ("preenchidos", preenchidos), ("vazios", vazios), ("ausentes", ausentes)]))

    proc = {"caminho": str(caminho), "nome": nome, "apelido": apelido(caminho),
            "encoding": encoding, "linhas": linhas, "marcas": marcas, "secoes": secoes,
            "primeira_secao": primeira_secao, "contagem": contagem, "ignoradas": ignoradas,
            "mantidas": mantidas, "removidas": removidas, "campos": campos,
            "preenchidos": preenchidos, "vazios": vazios, "ausentes": ausentes,
            "cabecalho_nao_explicado": cabecalho_nao_explicado,
            "impressao": impressao_do_texto(texto), "identidades": identidades}
    return proc, None


def linhas_de_evidencia(proc):
    """Onde um veredito atendido pode apontar. Linha de secao que diz alguma
    coisa, mais a linha de cada campo de controle: os campos de controle ficam
    no cabecalho, antes da primeira secao, e a clausula de controle de documento
    e atendida justamente ali. Linha branca e linha removida como rodape ficam
    fora: apontar para elas e fabricar evidencia."""
    validas = set()
    for s in proc["secoes"]:
        for j in range(s["linha_inicio"], s["linha_fim"] + 1):
            if proc["marcas"].get(j, ("", ""))[1] == "removida":
                continue
            if not proc["linhas"][j - 1].strip():
                continue
            validas.add(j)
    for c in proc["campos"]:
        if c["linha"]:
            validas.add(int(c["linha"]))
    return validas


def escrever_mecanicos(destino, proc, sem_valores):
    destino = Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    campos = [dict(c) for c in proc["campos"]]
    if sem_valores:
        for c in campos:
            if c["valor"]:
                c["valor"] = OMITIDO
    escrever_csv(destino / "forma.csv",
                 ["campo", "situacao", "rotulo_encontrado", "linha", "origem_da_linha", "valor"],
                 campos)
    secoes = [dict(s) for s in proc["secoes"]]
    ignoradas = [dict(x) for x in proc["ignoradas"]]
    if sem_valores:
        # Titulo de secao e linha ignorada carregam texto do procedimento: item
        # numerado do corpo vira secao, e a frase inteira sairia no arquivo que o
        # modo de dado sensivel manda colar.
        for s in secoes:
            s["titulo"] = OMITIDO
        for x in ignoradas:
            x["conteudo"] = OMITIDO
    escrever_csv(destino / "secoes.csv",
                 ["numero", "titulo", "linha_inicio", "linha_fim", "linhas_de_conteudo"],
                 secoes)
    escrever_csv(destino / "linhas-ignoradas.csv",
                 ["linha", "causa", "destino", "conteudo"], ignoradas)


def indice_de_secoes(proc, sem_valores):
    if not proc["secoes"]:
        return ["nenhuma secao reconhecida"]
    saida = []
    for s in proc["secoes"]:
        titulo = OMITIDO if sem_valores else s["titulo"]
        saida.append("%s %s  (linhas %d a %d, %d de conteudo)"
                     % (s["numero"] or "-", titulo, s["linha_inicio"], s["linha_fim"],
                        s["linhas_de_conteudo"]))
    return saida


# ---------------------------------------------------------------------------
# 10. Rodada
# ---------------------------------------------------------------------------


def rodar(args):
    saida = Path(args.saida)
    caminhos = list(args.procedimento or [])
    nomes = [Path(c).name for c in caminhos]
    if len(set(nomes)) != len(nomes):
        print("ERRO: dois procedimentos da rodada tem o mesmo nome de arquivo. O nome do "
              "arquivo identifica o procedimento na matriz e no consolidado: renomeie um "
              "deles antes de rodar.")
        return ERRO

    dicionario = {chave: list(rotulos) for chave, rotulos in CAMPOS_DE_CONTROLE}
    for extra in args.campo_extra or []:
        if "=" not in extra:
            print("ERRO: --campo-extra espera chave=rotulo1|rotulo2, veio '%s'." % extra)
            return ERRO
        chave, rotulos = extra.split("=", 1)
        chave = normalizar_chave(chave).replace(" ", "_")
        dicionario.setdefault(chave, [])
        dicionario[chave] = [normalizar_chave(r) for r in rotulos.split("|") if r.strip()] + \
            dicionario[chave]

    exigidos = []
    for c in args.campos.split(","):
        chave = normalizar_chave(c).replace(" ", "_")
        if chave and chave not in exigidos:
            exigidos.append(chave)
    desconhecidos = [c for c in exigidos if c not in dicionario]
    if desconhecidos:
        print("ERRO: campo de controle sem rotulo conhecido: %s. Declare com --campo-extra."
              % ", ".join(desconhecidos))
        return ERRO
    if not exigidos:
        print("ERRO: --campos vazio. Sem campo de controle exigido nao existe conferencia "
              "de forma.")
        return ERRO

    if args.fechar:
        if not saida.exists():
            print("ERRO: o diretorio %s nao existe. O fechamento roda sobre o diretorio da "
                  "rodada de estrutura, e a rodada de estrutura vem primeiro." % saida)
            return ERRO
    else:
        if saida.exists() and not args.forcar:
            print("ERRO: o diretorio %s ja existe. Use --forcar para sobrescrever." % saida)
            return ERRO
        if saida.exists() and args.forcar:
            julgadas = linhas_julgadas_na_matriz(saida)
            if julgadas:
                print("ERRO: a matriz-cobertura.csv de %s ja tem %d linha(s) com julgamento "
                      "de gente, e --forcar apagaria tudo. Renomeie a matriz preenchida para "
                      "matriz-preenchida.csv, ou aponte --saida para outro diretorio. "
                      "--forcar sobrescreve arquivo mecanico, nao apaga julgamento."
                      % (saida, julgadas))
                return ERRO
        saida.mkdir(parents=True, exist_ok=True)

    procs = []
    for caminho in caminhos:
        proc, erro = processar_procedimento(caminho, exigidos, dicionario)
        if erro:
            print("ERRO: %s" % erro)
            return ERRO
        procs.append(proc)

    try:
        requisitos, nao_parseados = ler_requisitos(args.requisitos)
    except ValueError as erro:
        print("ERRO: %s" % erro)
        return ERRO

    um_so = len(procs) == 1
    for proc in procs:
        proc["destino"] = saida if um_so else (saida / proc["apelido"])
    # No fechamento os arquivos mecanicos NAO sao reescritos: eles sao da rodada
    # de estrutura e tem que continuar batendo com a impressao guardada. Reescreve-
    # los a partir de um arquivo que pode ter sido editado trocaria a leitura da
    # rodada por outra, sem ninguem pedir.
    if not args.fechar:
        for proc in procs:
            escrever_mecanicos(proc["destino"], proc, args.sem_valores)
    if not um_so and not args.fechar:
        consolidado_forma = []
        for proc in procs:
            for c in proc["campos"]:
                linha = dict(c)
                linha["procedimento"] = proc["nome"]
                if args.sem_valores and linha["valor"]:
                    linha["valor"] = OMITIDO
                consolidado_forma.append(linha)
        escrever_csv(saida / "consolidado-de-forma.csv",
                     ["procedimento", "campo", "situacao", "rotulo_encontrado", "linha",
                      "origem_da_linha", "valor"], consolidado_forma)

    relatorio = ["# Leitura da estrutura do documento controlado", "",
                 "versao do script: %s" % VERSAO,
                 "data da rodada: %s" % date.today().isoformat(),
                 "procedimentos na rodada: %d" % len(procs),
                 "requisitos: %s" % args.requisitos,
                 "campos de controle exigidos: %s" % ", ".join(exigidos),
                 "modo: %s" % ("fechamento" if args.fechar else "estrutura, sem fechamento"),
                 "valores: %s" % ("--sem-valores: sem valor de campo, sem titulo de secao e "
                                  "sem linha do procedimento" if args.sem_valores
                                  else "completos")]

    identidades = []
    for proc in procs:
        horizontal = any(c["origem_da_linha"] == "tabela_de_controle_horizontal"
                         for c in proc["campos"])
        relatorio += bloco("Procedimento %s" % proc["nome"], [
            "arquivo: %s" % proc["caminho"],
            "encoding lido: %s" % proc["encoding"],
            "linhas: %d, caracteres: %d, impressao: %s"
            % (proc["impressao"]["linhas"], proc["impressao"]["caracteres"],
               proc["impressao"]["impressao"]),
            "secoes reconhecidas: %d" % len(proc["secoes"]),
            "cabecalho de controle lido como tabela horizontal: %s"
            % ("sim" if horizontal else "nao"),
            "campos preenchidos: %d, vazios: %d, ausentes: %d"
            % (proc["preenchidos"], proc["vazios"], proc["ausentes"]),
        ])
        relatorio += bloco("Indice de secoes de %s" % proc["nome"],
                           indice_de_secoes(proc, args.sem_valores))
        for texto, ok in proc["identidades"]:
            identidades.append((texto, ok))

    exigidos_total = len(exigidos) * len(procs)
    identidades.append(formatar_identidade(
        "campos conferidos na rodada", exigidos_total,
        [("preenchidos", sum(p["preenchidos"] for p in procs)),
         ("vazios", sum(p["vazios"] for p in procs)),
         ("ausentes", sum(p["ausentes"] for p in procs))]))

    entregues = sum(1 for r in requisitos if r["origem"] == "entregue")
    vazios_total = sum(p["vazios"] for p in procs)
    ausentes_total = sum(p["ausentes"] for p in procs)
    mantidas_total = sum(p["mantidas"] for p in procs)
    removidas_total = sum(p["removidas"] for p in procs)
    cabecalho_total = sum(p["cabecalho_nao_explicado"] for p in procs)
    sem_secao = [p["nome"] for p in procs if not p["secoes"]]

    if args.fechar:
        codigo, extra_relatorio, ok_fechamento = fechar(
            args, saida, procs, requisitos, nao_parseados, exigidos, identidades,
            entregues, vazios_total, ausentes_total, mantidas_total, cabecalho_total,
            sem_secao)
        relatorio += extra_relatorio
        relatorio.append("")
        relatorio.append(RODAPE.lstrip("# "))
        escrever_texto(saida / "leitura-da-estrutura.md", relatorio)
        print("\n".join(relatorio))
        print("\ndiretorio: %s" % saida.resolve())
        todas_fecham = all(ok for _texto, ok in identidades)
        if not (todas_fecham and ok_fechamento):
            apagados = apagar_entrega(saida)
            print("\nERRO: a rodada de fechamento nao vale. Nenhum arquivo de entrega foi "
                  "escrito%s." % (", e %s de rodada anterior foi(ram) apagado(s)"
                                  % ", ".join(apagados) if apagados else ""))
            return ERRO
        return codigo

    matriz = montar_matriz(procs, requisitos)
    if nao_parseados:
        escrever_csv(saida / "requisitos-nao-parseados.csv",
                     ["linha_do_arquivo", "clausula", "motivo"], nao_parseados)
    identidades.append(formatar_identidade(
        "linhas da matriz montada", len(requisitos) * len(procs),
        [(p["nome"], len(requisitos)) for p in procs] or [("na matriz", 0)]))

    relatorio += bloco("Fechamento", [texto for texto, _ok in identidades])
    relatorio += bloco("Verificacoes que podem falhar de fato", [
        "procedimentos na rodada:                %d" % len(procs),
        "secoes reconhecidas, somadas:           %d" % sum(len(p["secoes"]) for p in procs),
        "requisitos lidos:                       %d" % len(requisitos),
        "requisitos com origem entregue:         %d" % entregues,
        "requisitos nao parseados:               %d" % len(nao_parseados),
        "pares procedimento x requisito:         %d" % len(matriz),
        "campos de controle vazios:              %d" % vazios_total,
        "campos de controle ausentes:            %d" % ausentes_total,
        "linhas removidas como rodape:           %d" % removidas_total,
        "linhas repetidas com conteudo mantidas: %d" % mantidas_total,
        "linhas de cabecalho sem campo nem secao: %d" % cabecalho_total,
    ])
    relatorio.append("")
    relatorio.append(RODAPE.lstrip("# "))
    escrever_texto(saida / "leitura-da-estrutura.md", relatorio)
    print("\n".join(relatorio))
    print("\ndiretorio: %s" % saida.resolve())

    invalida = []
    if not all(ok for _texto, ok in identidades):
        invalida.append("ERRO: identidade que nao fecha. A rodada nao vale.")
    if nao_parseados:
        invalida.append("ERRO: %d requisito(s) nao parseado(s), em requisitos-nao-parseados.csv. "
                        "Requisito sem clausula, sem texto, sem norma, sem edicao ou sem origem "
                        "nao entra na matriz e nao pode sumir em silencio." % len(nao_parseados))
    if sem_secao:
        invalida.append("ERRO: nenhuma secao reconhecida em %s. Sem indice de secao nao existe "
                        "'onde' para apontar, e a rodada sairia dizendo que nada falta."
                        % ", ".join(sem_secao))
    if entregues == 0:
        invalida.append("ERRO: nenhum requisito com origem 'entregue'. Sem requisito na mao a "
                        "skill nao aponta furo de conteudo, e sair com sucesso aqui seria dizer "
                        "que o procedimento atende a norma.")

    if invalida:
        # Rodada de estrutura que nao vale nao deixa matriz para preencher nem
        # impressao para o fechamento comparar: preencher a matriz de uma rodada
        # invalida e trabalho perdido, e fechar sobre ela e entrega falsa.
        for nome in ("matriz-cobertura.csv", ARQUIVO_IMPRESSAO):
            caminho = saida / nome
            if caminho.exists():
                caminho.unlink()
        apagar_entrega(saida)
        for texto in invalida:
            print("\n" + texto)
        print("\nNenhuma matriz-cobertura.csv foi deixada no diretorio: corrija o que esta "
              "acima e rode a estrutura de novo.")
        return ERRO

    escrever_csv(saida / "matriz-cobertura.csv", COLUNAS_MATRIZ, matriz)
    escrever_impressoes(saida, procs)

    print("\nA matriz saiu em pendente, com uma linha por par procedimento x requisito. O "
          "conteudo ainda NAO foi conferido por ninguem. Preencha a coluna veredito e rode "
          "de novo com --fechar.")
    return SEM_FECHAMENTO


# ---------------------------------------------------------------------------
# 11. Fechamento
# ---------------------------------------------------------------------------


def fechar(args, saida, procs, requisitos, nao_parseados, exigidos, identidades,
           entregues, vazios_total, ausentes_total, mantidas_total, cabecalho_total,
           sem_secao):
    """Rele a matriz preenchida, confere que nenhum procedimento mudou desde a
    rodada de estrutura, valida linha por linha e so escreve os arquivos de
    entrega depois de a rodada ser declarada valida."""
    relatorio = []
    problemas = []

    if nao_parseados:
        problemas.append("%d requisito(s) nao parseado(s) no arquivo de requisitos"
                         % len(nao_parseados))
    if sem_secao:
        problemas.append("nenhuma secao reconhecida em %s" % ", ".join(sem_secao))
    if entregues == 0:
        problemas.append("nenhum requisito com origem entregue")

    # O procedimento e relido no fechamento. Entre uma rodada e outra a pessoa
    # costuma editar o arquivo, porque foi para isso que ela pediu a lista de
    # furos, e nesse caso toda linha apontada na matriz esta vencida.
    guardadas = ler_impressoes(saida)
    if guardadas is None:
        problemas.append("nao existe %s neste diretorio: o fechamento precisa da rodada de "
                         "estrutura do mesmo diretorio, e sem ela nao ha como saber se o "
                         "procedimento mudou" % ARQUIVO_IMPRESSAO)
    else:
        for proc in procs:
            g = guardadas.get(proc["nome"])
            atual = proc["impressao"]
            if g is None:
                problemas.append("o procedimento %s nao estava na rodada de estrutura deste "
                                 "diretorio" % proc["nome"])
            elif g.get("impressao") != atual["impressao"] or \
                    g.get("linhas") != str(atual["linhas"]):
                problemas.append("o procedimento %s mudou depois da rodada de estrutura "
                                 "(%s linhas e impressao %s na estrutura, %d linhas e "
                                 "impressao %s agora). Toda linha apontada na matriz esta "
                                 "vencida: refaca a rodada de estrutura e refaca os apontamentos."
                                 % (proc["nome"], g.get("linhas"), g.get("impressao"),
                                    atual["linhas"], atual["impressao"]))
        for nome in sorted(guardadas):
            if nome not in [p["nome"] for p in procs]:
                problemas.append("o procedimento %s estava na rodada de estrutura e nao "
                                 "entrou no fechamento: requisito nao pode sumir junto com "
                                 "o procedimento" % nome)

    esperados = {}
    for proc in procs:
        for r in requisitos:
            chave = (proc["nome"], r["clausula"], r["norma"], r["edicao"])
            esperados.setdefault(chave, []).append(r)

    preenchida = ler_matriz_preenchida(args.fechar)
    um_so = len(procs) == 1
    nome_unico = procs[0]["nome"] if um_so else ""
    validas_por_proc = {p["nome"]: linhas_de_evidencia(p) for p in procs}

    contadas = 0
    por_veredito = {"atendido": 0, "furo": 0, "a_conferir": 0, "pendente": 0, "invalido": 0}
    vistas = {}
    furos = []
    a_conferir = []
    consolidado = []

    for pos, linha in enumerate(preenchida, start=2):
        contadas += 1
        procedimento = (linha.get("procedimento") or "").strip() or nome_unico
        clausula = linha.get("clausula", "")
        norma = linha.get("norma", "")
        edicao = linha.get("edicao", "")
        veredito = normalizar_chave(linha.get("veredito", ""))
        chave = (procedimento, clausula, norma, edicao)
        vistas[chave] = vistas.get(chave, 0) + 1

        if procedimento not in validas_por_proc:
            por_veredito["invalido"] += 1
            problemas.append("linha %d da matriz: a coluna procedimento diz '%s', que nao e "
                             "nenhum dos procedimentos da rodada (%s)"
                             % (pos, procedimento, ", ".join(sorted(validas_por_proc))))
            continue
        if chave not in esperados:
            por_veredito["invalido"] += 1
            problemas.append("linha %d da matriz: clausula %s/%s/%s nao existe no arquivo de "
                             "requisitos" % (pos, norma, edicao, clausula))
            continue
        if veredito not in VEREDITOS:
            por_veredito["invalido"] += 1
            problemas.append("linha %d da matriz: veredito '%s' fora de %s"
                             % (pos, veredito, "/".join(VEREDITOS)))
            continue

        # A origem e o tipo valem os do arquivo de requisitos, nunca os da
        # matriz. Editar a celula origem de sumario para entregue destravaria o
        # furo contra norma que a pessoa nao entregou, que e o erro que este
        # script existe para impedir.
        req = esperados[chave][0]
        origem = req["origem"]
        tipo = req["tipo"]
        origem_na_matriz = normalizar_chave(linha.get("origem", ""))
        tipo_na_matriz = normalizar_chave(linha.get("tipo", ""))
        if origem_na_matriz and origem_na_matriz != origem:
            por_veredito["invalido"] += 1
            problemas.append("linha %d da matriz, clausula %s: a coluna origem diz '%s' e o "
                             "arquivo de requisitos diz '%s'. A origem e do arquivo de "
                             "requisitos e nao se edita na matriz."
                             % (pos, clausula, origem_na_matriz, origem))
            continue
        if tipo_na_matriz and tipo_na_matriz != tipo:
            por_veredito["invalido"] += 1
            problemas.append("linha %d da matriz, clausula %s: a coluna tipo diz '%s' e o "
                             "arquivo de requisitos diz '%s'. O tipo e do arquivo de "
                             "requisitos e nao se edita na matriz."
                             % (pos, clausula, tipo_na_matriz, tipo))
            continue
        if origem != "entregue" and veredito != "a_conferir":
            por_veredito["invalido"] += 1
            problemas.append("linha %d da matriz, clausula %s: origem '%s' so admite veredito "
                             "a_conferir, veio '%s'. Requisito que a pessoa nao entregou nao "
                             "vira furo nem vira atendido." % (pos, clausula, origem, veredito))
            continue
        if tipo == "convem" and veredito == "furo":
            por_veredito["invalido"] += 1
            problemas.append("linha %d da matriz, clausula %s: tipo 'convem' nao admite furo. "
                             "Recomendacao nao atendida nao e furo: marque a_conferir com o "
                             "motivo, ou corrija o tipo para 'deve' no requisitos.csv se a "
                             "exigencia e obrigatoria na edicao da sua empresa."
                             % (pos, clausula))
            continue

        por_veredito[veredito] += 1
        consolidado.append({"procedimento": procedimento, "clausula": clausula,
                            "norma": norma, "edicao": edicao, "origem": origem,
                            "tipo": tipo, "veredito": veredito,
                            "o_que_falta": linha.get("o_que_falta", ""),
                            "onde": linha.get("onde", ""), "linha": linha.get("linha", ""),
                            "motivo": linha.get("motivo", "")})

        if veredito == "pendente":
            problemas.append("linha %d da matriz, clausula %s: veredito ainda em pendente"
                             % (pos, clausula))
            continue

        if veredito == "atendido":
            onde = linha.get("onde", "")
            numero = linha.get("linha", "")
            if not onde or not numero:
                problemas.append("linha %d da matriz, clausula %s: atendido sem 'onde' ou sem "
                                 "'linha'. Atendimento sem evidencia e afirmacao sem prova."
                                 % (pos, clausula))
                continue
            if not numero.isdigit() or int(numero) not in validas_por_proc[procedimento]:
                problemas.append("linha %d da matriz, clausula %s: a linha %s de %s nao e "
                                 "evidencia valida. Valem as linhas com conteudo dentro de "
                                 "alguma secao e as linhas dos campos de controle do "
                                 "cabecalho; linha branca, linha de rodape removida e linha "
                                 "que nao existe ficam fora."
                                 % (pos, clausula, numero, procedimento))
            continue

        if veredito == "furo":
            falta = normalizar_chave(linha.get("o_que_falta", "")).replace(" ", "_")
            if falta not in FURO_DE_CONTEUDO:
                problemas.append("linha %d da matriz, clausula %s: o_que_falta '%s' fora do "
                                 "vocabulario %s" % (pos, clausula, falta,
                                                     "/".join(sorted(FURO_DE_CONTEUDO))))
                continue
            furos.append({"procedimento": procedimento, "classe": "conteudo",
                          "clausula": clausula, "norma": norma, "edicao": edicao,
                          "o_que_falta": falta, "explicacao": FURO_DE_CONTEUDO[falta],
                          "requisito": linha.get("requisito", "") or req["requisito"],
                          "onde": linha.get("onde", "") or "nao localizado no procedimento",
                          "linha": linha.get("linha", ""),
                          "origem_do_requisito": origem,
                          "observacao": linha.get("motivo", "")})
            continue

        if veredito == "a_conferir":
            if not linha.get("motivo", ""):
                problemas.append("linha %d da matriz, clausula %s: a_conferir sem motivo"
                                 % (pos, clausula))
            a_conferir.append({"procedimento": procedimento, "clausula": clausula,
                               "norma": norma, "edicao": edicao,
                               "origem_do_requisito": origem,
                               "requisito": linha.get("requisito", "") or req["requisito"],
                               "motivo": linha.get("motivo", ""),
                               "o_que_fazer": "conferir na edicao vigente da sua empresa"})

    for chave, lista in esperados.items():
        if vistas.get(chave, 0) < len(lista):
            problemas.append("clausula %s da norma %s %s sumiu da matriz no procedimento %s: "
                             "o arquivo de requisitos tem %d linha(s) e a matriz tem %d. "
                             "Requisito nao pode sumir entre uma rodada e outra."
                             % (chave[1], chave[2], chave[3], chave[0], len(lista),
                                vistas.get(chave, 0)))

    for proc in procs:
        for c in proc["campos"]:
            if c["situacao"] == "ausente":
                furos.append({"procedimento": proc["nome"], "classe": "forma", "clausula": "",
                              "norma": "", "edicao": "", "campo": c["campo"],
                              "o_que_falta": FURO_DE_FORMA.get(c["campo"], "campo_ausente"),
                              "explicacao": "campo de controle '%s' nao existe no documento"
                                            % c["campo"],
                              "requisito": "controle de documento",
                              "onde": "cabecalho do documento", "linha": "",
                              "origem_do_requisito": "estrutura do documento controlado",
                              "observacao": ""})
            elif c["situacao"] == "presente_vazio":
                furos.append({"procedimento": proc["nome"], "classe": "forma", "clausula": "",
                              "norma": "", "edicao": "", "campo": c["campo"],
                              "o_que_falta": FURO_DE_FORMA.get(c["campo"], "campo_vazio"),
                              "explicacao": "campo de controle '%s' existe e esta vazio ou com "
                                            "marcador de preenchimento" % c["campo"],
                              "requisito": "controle de documento",
                              "onde": "linha %s" % c["linha"], "linha": c["linha"],
                              "origem_do_requisito": "estrutura do documento controlado",
                              "observacao": ""})

    furos_forma = sum(1 for f in furos if f["classe"] == "forma")
    furos_conteudo = sum(1 for f in furos if f["classe"] == "conteudo")

    identidades.append(formatar_identidade(
        "linhas da matriz preenchida", contadas,
        [(k, v) for k, v in sorted(por_veredito.items())]))
    identidades.append(formatar_identidade(
        "pares procedimento x requisito", len(requisitos) * len(procs),
        [("na matriz", contadas)]))
    identidades.append(formatar_identidade("linhas em furos.csv", len(furos),
                                           [("forma", furos_forma),
                                            ("conteudo", furos_conteudo)]))
    identidades.append(formatar_identidade("linhas no consolidado", len(consolidado),
                                           [("julgadas na matriz",
                                             contadas - por_veredito["invalido"])]))

    # Cobertura por clausula: a pergunta da abertura da skill, que e saber quais
    # clausulas passaram por todos os procedimentos da rodada.
    cobertura = {}
    for linha in consolidado:
        chave = (linha["clausula"], linha["norma"], linha["edicao"])
        alvo = cobertura.setdefault(chave, {"clausula": linha["clausula"],
                                            "norma": linha["norma"],
                                            "edicao": linha["edicao"],
                                            "origem": linha["origem"],
                                            "tipo": linha["tipo"],
                                            "procedimentos": 0, "atendido": 0, "furo": 0,
                                            "a_conferir": 0, "pendente": 0,
                                            "_com_furo": []})
        alvo["procedimentos"] += 1
        if linha["veredito"] in alvo:
            alvo[linha["veredito"]] += 1
        if linha["veredito"] == "furo":
            alvo["_com_furo"].append(linha["procedimento"])
    linhas_cobertura = []
    for chave in sorted(cobertura):
        alvo = dict(cobertura[chave])
        alvo["procedimentos_com_furo"] = ", ".join(alvo.pop("_com_furo"))
        linhas_cobertura.append(alvo)

    atendidas_em_todos = sum(1 for c in cobertura.values()
                             if c["atendido"] == c["procedimentos"])
    com_furo_em_algum = sum(1 for c in cobertura.values() if c["furo"] > 0)

    relatorio += bloco("Fechamento", [texto for texto, _ok in identidades])
    verificacoes = [
        "procedimentos na rodada:                %d" % len(procs),
        "secoes reconhecidas, somadas:           %d" % sum(len(p["secoes"]) for p in procs),
        "requisitos com origem entregue:         %d" % entregues,
        "requisitos nao parseados:               %d" % len(nao_parseados),
        "furos de forma:                         %d" % furos_forma,
        "furos de conteudo:                      %d" % furos_conteudo,
        "requisitos em a_conferir:               %d" % len(a_conferir),
        "campos de controle vazios:              %d" % vazios_total,
        "campos de controle ausentes:            %d" % ausentes_total,
        "linhas repetidas com conteudo mantidas: %d" % mantidas_total,
        "linhas de cabecalho sem campo nem secao: %d" % cabecalho_total,
        "clausulas atendidas em todos os procedimentos: %d de %d"
        % (atendidas_em_todos, len(cobertura)),
        "clausulas com furo em ao menos um procedimento: %d" % com_furo_em_algum,
    ]
    relatorio += bloco("Verificacoes que podem falhar de fato", verificacoes)

    if problemas:
        relatorio += bloco("Problemas que derrubam a rodada", ["- " + p for p in problemas])

    soma_vereditos = sum(por_veredito.values())
    ok_fechamento = (not problemas and all(ok for _texto, ok in identidades)
                     and soma_vereditos == contadas and not nao_parseados
                     and not sem_secao and entregues > 0)

    if not ok_fechamento:
        return ERRO, relatorio, False

    escrever_csv(saida / "furos.csv", COLUNAS_FUROS, furos)
    escrever_csv(saida / "a-conferir-na-sua-edicao.csv", COLUNAS_A_CONFERIR, a_conferir)
    escrever_csv(saida / "consolidado-da-rodada.csv",
                 ["procedimento", "clausula", "norma", "edicao", "origem", "tipo",
                  "veredito", "o_que_falta", "onde", "linha", "motivo"], consolidado)
    escrever_csv(saida / "cobertura-por-clausula.csv",
                 ["clausula", "norma", "edicao", "origem", "tipo", "procedimentos",
                  "atendido", "furo", "a_conferir", "pendente", "procedimentos_com_furo"],
                 linhas_cobertura)
    if furos:
        escrever_plano(saida / "plano-de-correcao.md", furos, procs)
    else:
        caminho_plano = Path(saida) / "plano-de-correcao.md"
        if caminho_plano.exists():
            caminho_plano.unlink()

    if furos:
        if args.estrito and a_conferir:
            relatorio += bloco("Sobre --estrito", [
                "Sobraram %d requisito(s) em a_conferir, e ha furo na rodada. Com furo "
                "presente o codigo 1 prevalece sobre o 2: a entrega para pelo furo antes de "
                "parar pelo que falta conferir." % len(a_conferir)])
        return COM_FURO, relatorio, True
    if args.estrito and a_conferir:
        return ESTRITO_BLOQUEIA, relatorio, True
    sobrou = bool(a_conferir) or vazios_total or mantidas_total or cabecalho_total
    if sobrou:
        relatorio += bloco("Por que esta rodada nao sai com 0", [
            "Nenhum furo foi apontado, e ainda assim sobrou coisa fora da conferencia:",
            "requisitos em a_conferir %d, campos vazios %d, linhas repetidas com conteudo %d, "
            "linhas de cabecalho sem campo nem secao %d." % (len(a_conferir), vazios_total,
                                                            mantidas_total, cabecalho_total),
            "'Nenhum furo' com dado fora da conferencia nao e a mesma coisa que 'nenhum furo'."])
        return SOBROU_FORA, relatorio, True
    return OK, relatorio, True


def main():
    p = argparse.ArgumentParser(
        description="Confere a estrutura do documento controlado e mantem a razao da "
                    "cobertura requisito por requisito, de um ou de varios procedimentos "
                    "na mesma rodada. Nao le norma e nao julga conteudo.")
    p.add_argument("--procedimento", required=True, action="append",
                   help="procedimento vigente em .txt ou .md (PDF e xlsx nao entram). "
                        "Repita a opcao para varios procedimentos na mesma rodada")
    p.add_argument("--requisitos", required=True,
                   help="CSV com clausula;requisito;origem;norma;edicao e, opcional, tipo e condicao")
    p.add_argument("--saida", required=True, help="diretorio da rodada")
    p.add_argument("--campos", default=CAMPOS_PADRAO,
                   help="campos de controle exigidos, separados por virgula. Padrao: " + CAMPOS_PADRAO)
    p.add_argument("--campo-extra", action="append", default=[],
                   help="chave=rotulo1|rotulo2, para o campo que a sua empresa chama de outro jeito")
    p.add_argument("--fechar", metavar="MATRIZ",
                   help="caminho da matriz-cobertura.csv ja preenchida; roda o fechamento")
    p.add_argument("--estrito", action="store_true",
                   help="requisito em a_conferir bloqueia a rodada (codigo 2). Havendo furo "
                        "junto, o codigo 1 prevalece")
    p.add_argument("--sem-valores", action="store_true",
                   help="nao grava valor de campo, titulo de secao nem linha do procedimento "
                        "(eles carregam nome de pessoa e texto do documento)")
    p.add_argument("--forcar", action="store_true",
                   help="sobrescreve o diretorio de saida. Recusa quando a matriz que esta "
                        "la ja tem julgamento de gente")
    args = p.parse_args()
    try:
        return rodar(args)
    except FileNotFoundError as erro:
        print("ERRO: arquivo nao encontrado: %s" % erro)
        return ERRO


if __name__ == "__main__":
    sys.exit(main())
