#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testar.py, teste de regressao do conferir-estrutura.py.

Biblioteca padrao apenas. Gera cada caso num diretorio temporario, roda o
conferir-estrutura.py nele e compara o codigo de saida e trechos dos arquivos
gerados com o esperado.

Os casos nao foram escritos a partir das funcionalidades. Foram escritos a
partir de uma pergunta so, repetida contra cada caminho do script:

    existe caminho em que isso sai com sucesso tendo perdido dado?

Por isso a maioria dos casos aqui e de rodada que PRECISA falhar: requisito
com origem em branco, requisito que sumiu da matriz entre uma rodada e outra,
veredito de furo em requisito que a pessoa nao entregou, origem trocada na
matriz para destravar o furo, recomendacao marcada como furo, procedimento
editado entre a estrutura e o fechamento, matriz ja julgada que --forcar
tentaria apagar, evidencia apontada para linha branca, secao de historico de
revisoes presente e vazia, linha de rodape que carrega exigencia de verdade,
campo preenchido com marcador de preenchimento, procedimento sem nenhuma secao.

A norma das fixtures e ficticia de proposito (NORMA-X, edicao 2020). Dentro do
teste ela simula um requisito entregue pela pessoa, e o arquivo e distribuido
com o kit: afirmar aqui o que uma clausula de norma real exige seria reproduzir
requisito de norma sem a norma na mao, que e o que esta skill proibe.

Rode depois de qualquer mudanca no conferir-estrutura.py:

    python3 ~/.claude/skills/padrao-conferido-contra-norma/scripts/testar.py

No PowerShell:

    py -3 "$env:USERPROFILE\\.claude\\skills\\padrao-conferido-contra-norma\\scripts\\testar.py"

Sai com 1 se algum caso falhar.
"""

import csv
import re
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
SCRIPT = AQUI / "conferir-estrutura.py"

falhas = []
avisos = []

CABECALHO_REQ = "clausula;norma;edicao;origem;tipo;condicao;requisito"

COLUNAS_MATRIZ = ["procedimento", "clausula", "norma", "edicao", "origem", "tipo",
                  "condicao", "requisito", "veredito", "o_que_falta", "onde", "linha",
                  "motivo"]

PROC_COMPLETO = """PROCEDIMENTO OPERACIONAL PADRAO
Codigo: PR-QA-014
Revisao: 03
Data de vigencia: 12/03/2026
Elaborado por: engenharia de processo
Aprovado por: gerencia da qualidade
Dono do processo: coordenacao de manutencao

1. OBJETIVO
Definir como a manutencao preventiva do compressor e executada e registrada.

2. APLICACAO
Aplica-se ao compressor da central de ar comprimido.

3. PROCEDIMENTO
Executar a rotina mensal conforme o plano de manutencao.
Registrar cada execucao na ordem de servico do sistema.

4. REGISTROS
Ordem de servico arquivada por vinte e quatro meses.

5. HISTORICO DE REVISOES
rev 03 12/03/2026 inclusao do registro de execucao
rev 02 04/11/2025 revisao geral

6. LISTA DE DISTRIBUICAO
manutencao, qualidade e producao
"""

# Cabecalho de controle fora de qualquer secao: e o caso do procedimento que
# comeca pela tabela de controle e so depois abre a primeira secao numerada.
PROC_CABECALHO = """Codigo: PR-QA-020
Revisao: 02
Data de vigencia: 01/02/2026
Elaborado por: engenharia de processo
Aprovado por: gerencia da qualidade
Dono do processo: coordenacao de manutencao

1. OBJETIVO
Definir a inspecao semanal da bomba.

2. PROCEDIMENTO
Conferir pressao e anotar na ficha de inspecao.

3. HISTORICO DE REVISOES
rev 02 01/02/2026 inclusao da ficha

4. LISTA DE DISTRIBUICAO
manutencao e qualidade
"""

# Tabela de controle horizontal: uma linha de rotulos e a linha de valores
# embaixo. E o layout mais comum de POP exportado do Word.
PROC_TABELA_HORIZONTAL = """PROCEDIMENTO OPERACIONAL PADRAO

| Codigo | Revisao | Data de vigencia | Elaborado por | Aprovado por | Dono do processo |
|---|---|---|---|---|---|
| PR-QA-014 | 00 | 12/03/2026 | engenharia de processo | gerencia da qualidade | coordenacao de manutencao |

1. OBJETIVO
Definir como a manutencao preventiva do compressor e executada e registrada.

2. PROCEDIMENTO
Registrar cada execucao na ordem de servico do sistema.

3. HISTORICO DE REVISOES
| Rev | Data | Descricao |
|---|---|---|
| 00 | 12/03/2026 | primeira emissao |

4. LISTA DE DISTRIBUICAO
manutencao, qualidade e producao
"""

REQ_DOIS_ENTREGUES = "\n".join([
    CABECALHO_REQ,
    "4.2;NORMA-X;2020;entregue;deve;;o documento controlado tem identificacao, "
    "data, revisao e aprovador registrados",
    "4.3;NORMA-X;2020;entregue;deve;;a execucao da rotina tem registro que prova "
    "que ela foi feita",
]) + "\n"

RODAPE_DE_ARTEFATO = ("# Gerado com apoio de IA a partir do procedimento vigente e dos "
                      "requisitos entregues pela pessoa. Revisar antes de assinar. Nao "
                      "substitui responsabilidade tecnica.")


def registrar(nome, erros):
    if erros:
        falhas.append((nome, erros))
        print("FALHOU  %s" % nome)
        for e in erros:
            print("        %s" % e)
    else:
        print("ok      %s" % nome)


def linha_de(texto, trecho):
    """Numero da linha, base 1, em que o trecho aparece. Os testes apontam
    evidencia por conteudo e nao por numero cravado, senao mexer na fixture
    quebra o teste sem nenhum defeito ter aparecido."""
    for i, linha in enumerate(texto.splitlines(), start=1):
        if trecho in linha:
            return i
    raise AssertionError("trecho nao encontrado na fixture: %s" % trecho)


def linha_branca_de(texto):
    for i, linha in enumerate(texto.splitlines(), start=1):
        if not linha.strip():
            return i
    raise AssertionError("a fixture nao tem linha branca")


def rodar_estrutura_varios(pasta, procedimentos, requisitos, extra=()):
    for nome, texto in procedimentos:
        (pasta / nome).write_text(texto, encoding="utf-8")
    (pasta / "requisitos.csv").write_text(requisitos, encoding="utf-8")
    cmd = [sys.executable, str(SCRIPT)]
    for nome, _texto in procedimentos:
        cmd += ["--procedimento", str(pasta / nome)]
    cmd += ["--requisitos", str(pasta / "requisitos.csv"),
            "--saida", str(pasta / "rodada"), "--forcar"] + list(extra)
    return subprocess.run(cmd, capture_output=True, text=True)


def rodar_estrutura(pasta, procedimento, requisitos, extra=()):
    return rodar_estrutura_varios(pasta, [("procedimento.md", procedimento)],
                                  requisitos, extra)


def ler_matriz(pasta):
    caminho = pasta / "rodada" / "matriz-cobertura.csv"
    with open(caminho, encoding="utf-8-sig", newline="") as f:
        linhas = [l for l in csv.DictReader(f, delimiter=";")
                  if not any((l.get(c) or "").startswith("#")
                             for c in ("procedimento", "clausula"))]
    return linhas


def escrever_matriz(caminho, linhas):
    with open(caminho, "w", encoding="utf-8-sig", newline="") as f:
        escritor = csv.writer(f, delimiter=";")
        escritor.writerow(COLUNAS_MATRIZ)
        for linha in linhas:
            escritor.writerow([linha.get(c, "") for c in COLUNAS_MATRIZ])


def rodar_fechamento(pasta, linhas, extra=(), procedimentos=("procedimento.md",)):
    caminho = pasta / "matriz-preenchida.csv"
    escrever_matriz(caminho, linhas)
    cmd = [sys.executable, str(SCRIPT)]
    for nome in procedimentos:
        cmd += ["--procedimento", str(pasta / nome)]
    cmd += ["--requisitos", str(pasta / "requisitos.csv"),
            "--saida", str(pasta / "rodada"), "--fechar", str(caminho)] + list(extra)
    return subprocess.run(cmd, capture_output=True, text=True)


def conferir(res, pasta, esperado_codigo, checagens):
    """checagens: lista de (arquivo ou None para stdout, texto, deve_aparecer).
    Com texto None, a checagem e sobre a existencia do arquivo."""
    erros = []
    if res.returncode != esperado_codigo:
        erros.append("codigo de saida %d, esperado %d. Saida:\n%s\n%s"
                     % (res.returncode, esperado_codigo, res.stdout[-1500:], res.stderr[-800:]))
    for arquivo, texto, deve in checagens:
        if arquivo is not None and texto is None:
            existe = (pasta / "rodada" / arquivo).exists()
            if existe != deve:
                erros.append("%s: %s" % (arquivo, "deveria existir e nao existe" if deve
                                         else "nao deveria existir e existe"))
            continue
        if arquivo is None:
            conteudo = res.stdout
            rotulo = "stdout"
        else:
            caminho = pasta / "rodada" / arquivo
            rotulo = arquivo
            if not caminho.exists():
                erros.append("arquivo %s nao foi gerado" % arquivo)
                continue
            conteudo = caminho.read_text(encoding="utf-8-sig")
        presente = texto in conteudo
        if presente != deve:
            erros.append("%s: '%s' %s" % (rotulo, texto,
                                          "deveria aparecer e nao apareceu" if deve
                                          else "nao deveria aparecer e apareceu"))
    return erros


def atendido_em(linhas, proc_texto, trecho, onde):
    for l in linhas:
        l["veredito"] = "atendido"
        l["onde"] = onde
        l["linha"] = str(linha_de(proc_texto, trecho))
    return linhas


# ---------------------------------------------------------------------------
# Casos
# ---------------------------------------------------------------------------


def caso_estrutura_nunca_sai_zero(pasta):
    """A rodada de estrutura nao conferiu conteudo nenhum. Sair com 0 aqui
    seria dizer que o procedimento atende a norma."""
    res = rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("matriz-cobertura.csv", "pendente", True),
        (None, "ainda NAO foi conferido", True),
        ("forma.csv", "presente_preenchido", True),
        ("impressao-do-procedimento.csv", "procedimento.md", True),
    ])


def caso_origem_em_branco_derruba(pasta):
    """Requisito sem origem declarada e requisito que o modelo lembrou. Ele
    nao pode entrar na matriz em silencio."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;2020;entregue;deve;;identificacao e aprovacao registradas",
        "4.3;NORMA-X;2020;;deve;;registro que prova a execucao",
    ]) + "\n"
    res = rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    return conferir(res, pasta, 3, [
        ("requisitos-nao-parseados.csv", "coluna origem vazia", True),
        (None, "nao pode sumir em silencio", True),
    ])


def caso_edicao_em_branco_derruba(pasta):
    """Numero de clausula sem edicao nao identifica requisito nenhum: a
    numeracao muda de uma edicao para outra."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;;entregue;deve;;identificacao e aprovacao registradas",
    ]) + "\n"
    res = rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    return conferir(res, pasta, 3, [("requisitos-nao-parseados.csv",
                                     "coluna edicao vazia", True)])


def caso_nenhum_requisito_entregue_derruba(pasta):
    """So sumario na mao. Nao da para apontar furo de conteudo, e sair com
    sucesso seria dizer que nao falta nada."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.9;NORMA-X;2020;sumario;deve;;titulo da clausula, texto nao entregue",
    ]) + "\n"
    res = rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    return conferir(res, pasta, 3, [(None, "nenhum requisito com origem", True)])


def caso_procedimento_sem_secao_derruba(pasta):
    """Texto corrido sem titulo nenhum. Sem indice de secao nao existe 'onde'
    para apontar, e a rodada sairia dizendo que nada falta."""
    proc = ("Codigo: PR-01\nRevisao: 01\nData: 01/01/2026\n"
            "elaborado por: fulano\naprovado por: ciclano\ndono: manutencao\n"
            "o compressor e mantido mensalmente conforme combinado.\n")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 3, [(None, "nenhuma secao reconhecida", True)])


def caso_historico_presente_e_vazio(pasta):
    """Titulo 'Historico de revisoes' com nada embaixo e a aparencia do campo,
    nao o campo. Tem que sair como vazio e virar furo de forma."""
    proc = PROC_COMPLETO.replace(
        "rev 03 12/03/2026 inclusao do registro de execucao\n"
        "rev 02 04/11/2025 revisao geral\n", "")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    erros = conferir(res, pasta, 4, [("forma.csv", "historico_revisao;presente_vazio", True)])
    linhas = atendido_em(ler_matriz(pasta), proc, "Registrar cada execucao", "3. PROCEDIMENTO")
    res2 = rodar_fechamento(pasta, linhas)
    return erros + conferir(res2, pasta, 1, [
        ("furos.csv", "sem_historico_de_revisao", True),
        ("furos.csv", "procedimento.md;forma;", True),
        ("plano-de-correcao.md", "pergunta ao dono do procedimento", True),
    ])


def caso_placeholder_nao_e_preenchido(pasta):
    """'Aprovado por: ______' e campo vazio. Tratar como preenchido apaga o
    furo mais comum do documento controlado."""
    proc = PROC_COMPLETO.replace("Aprovado por: gerencia da qualidade",
                                 "Aprovado por: ______")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("forma.csv", "aprovado_por;presente_vazio", True),
        ("forma.csv", "aprovado_por;presente_preenchido", False),
    ])


def caso_rodape_com_conteudo_fica_mantido(pasta):
    """Linha repetida em todas as paginas que carrega exigencia de verdade nao
    pode ser apagada como rodape."""
    marca = "O uso de protecao auditiva dentro da casa de compressores e obrigatorio"
    proc = PROC_COMPLETO.replace("1. OBJETIVO", marca + "\n1. OBJETIVO")
    proc = proc.replace("3. PROCEDIMENTO", marca + "\n3. PROCEDIMENTO")
    proc = proc.replace("5. HISTORICO", marca + "\n5. HISTORICO")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("linhas-ignoradas.csv", "repetida_mas_com_conteudo;mantida", True),
        ("linhas-ignoradas.csv", "repetida_mas_com_conteudo;removida", False),
        (None, "fecha", True),
        (None, "NAO FECHA", False),
    ])


def caso_rodape_sem_conteudo_e_removido(pasta):
    proc = PROC_COMPLETO.replace("1. OBJETIVO", "Pagina 1 de 3\n1. OBJETIVO")
    proc = proc.replace("3. PROCEDIMENTO", "Pagina 1 de 3\n3. PROCEDIMENTO")
    proc = proc.replace("5. HISTORICO", "Pagina 1 de 3\n5. HISTORICO")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("linhas-ignoradas.csv", ";removida;Pagina 1 de 3", True),
        (None, "NAO FECHA", False),
    ])


def caso_secao_numerada_curta_nao_some(pasta):
    """'3.3 GERAL' e secao, nao lixo. Secao perdida vira furo falso."""
    proc = PROC_COMPLETO.replace("4. REGISTROS",
                                 "3.3 GERAL\nvale para toda a planta.\n\n4. REGISTROS")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [("secoes.csv", "3.3;GERAL", True)])


def caso_campo_em_tabela_markdown(pasta):
    """Tabela vertical, rotulo na primeira celula e valor na segunda."""
    proc = PROC_COMPLETO.replace("Revisao: 03", "| Revisao | 03 |")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [("forma.csv", "revisao;presente_preenchido", True)])


def caso_tabela_de_controle_horizontal(pasta):
    """Uma linha de rotulos no topo e a linha de valores embaixo. Lendo so a
    primeira celula, o script devolvia o rotulo da coluna seguinte como valor do
    campo e emitia cinco furos de forma contra campos preenchidos."""
    res = rodar_estrutura(pasta, PROC_TABELA_HORIZONTAL, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("forma.csv", "codigo;presente_preenchido;codigo;5;tabela_de_controle_horizontal;PR-QA-014", True),
        ("forma.csv", "revisao;presente_preenchido", True),
        ("forma.csv", "data_vigencia;presente_preenchido", True),
        ("forma.csv", "elaborado_por;presente_preenchido", True),
        ("forma.csv", "aprovado_por;presente_preenchido", True),
        ("forma.csv", "dono;presente_preenchido", True),
        ("forma.csv", "ausente", False),
        (None, "cabecalho de controle lido como tabela horizontal: sim", True),
    ])


def caso_revisao_zero_zero_e_valor(pasta):
    """Revisao 00 e a identificacao padrao da primeira emissao de um documento
    controlado. Tratar como campo vazio produz furo contra documento certo."""
    proc = PROC_COMPLETO.replace("Revisao: 03", "Revisao: 00")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("forma.csv", "revisao;presente_preenchido", True),
        ("forma.csv", "revisao;presente_vazio", False),
    ])


def caso_na_com_pontos_e_campo_vazio(pasta):
    """N.A. com ponto no fim escapava da deteccao de marcador de preenchimento e
    passava como campo preenchido, e a secao cujo unico conteudo e N.A. contava
    como preenchida porque o ramo de titulo de secao so contava linhas."""
    proc = PROC_COMPLETO.replace(
        "5. HISTORICO DE REVISOES\n"
        "rev 03 12/03/2026 inclusao do registro de execucao\n"
        "rev 02 04/11/2025 revisao geral\n",
        "5. HISTORICO DE REVISOES\nN.A.\n")
    proc = proc.replace("manutencao, qualidade e producao", "N.A.")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("forma.csv", "historico_revisao;presente_vazio", True),
        ("forma.csv", "ciencia;presente_vazio", True),
        ("forma.csv", "presente_preenchido;historico", False),
    ])


def caso_rodape_no_requisitos_nao_derruba(pasta):
    """O rodape de artefato colado no requisitos.csv e comentario, nao requisito.
    Derrubar a rodada por causa dele manda a pessoa atras de um erro que ela
    cometeu seguindo a propria skill."""
    reqs = REQ_DOIS_ENTREGUES + RODAPE_DE_ARTEFATO + "\n"
    res = rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    return conferir(res, pasta, 4, [
        (None, "requisitos lidos:                       2", True),
        ("requisitos-nao-parseados.csv", None, False),
    ])


def caso_forcar_nao_apaga_matriz_julgada(pasta):
    """--forcar reescrevia a matriz e zerava a coluna veredito ja preenchida,
    saindo com 4, que e codigo de sucesso. Perda silenciosa de trabalho feito."""
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    linhas[0]["veredito"] = "atendido"
    linhas[0]["onde"] = "4. REGISTROS"
    linhas[0]["linha"] = str(linha_de(PROC_COMPLETO, "Ordem de servico arquivada"))
    linhas[1]["veredito"] = "furo"
    linhas[1]["o_que_falta"] = "tratado_sem_criterio"
    escrever_matriz(pasta / "rodada" / "matriz-cobertura.csv", linhas)
    res = rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 3, [
        (None, "com julgamento de gente", True),
        ("matriz-cobertura.csv", "atendido", True),
        ("matriz-cobertura.csv", "tratado_sem_criterio", True),
    ])


def caso_sem_valores_nao_vaza_secao(pasta):
    """No modo de dado sensivel a pessoa cola leitura-da-estrutura.md. Item
    numerado do corpo vira secao, e o titulo saia por extenso no arquivo: com
    nome de cliente, nome de fornecedor e valor de compra dentro."""
    proc = PROC_COMPLETO.replace(
        "3. PROCEDIMENTO\n",
        "3. PROCEDIMENTO\n3.1 conferir o anexo sob sigilo do contrato do cliente COMPRADOR SA\n")
    res = rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES, extra=("--sem-valores",))
    return conferir(res, pasta, 4, [
        ("leitura-da-estrutura.md", "COMPRADOR SA", False),
        ("leitura-da-estrutura.md", "<omitido>", True),
        ("secoes.csv", "COMPRADOR SA", False),
        ("linhas-ignoradas.csv", "COMPRADOR SA", False),
        ("forma.csv", "gerencia da qualidade", False),
        (None, "COMPRADOR SA", False),
    ])


def caso_furo_em_requisito_nao_entregue_derruba(pasta):
    """O pior erro possivel da skill: apontar furo contra norma que nao esta
    na mao. O script recusa, nao avisa."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;2020;entregue;deve;;identificacao e aprovacao registradas",
        "4.9;NORMA-X;2020;sumario;deve;;titulo da clausula, texto nao entregue",
    ]) + "\n"
    rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    linhas = ler_matriz(pasta)
    for l in linhas:
        if l["origem"] == "entregue":
            l["veredito"] = "atendido"
            l["onde"] = "cabecalho"
            l["linha"] = str(linha_de(PROC_COMPLETO, "Aprovado por"))
        else:
            l["veredito"] = "furo"
            l["o_que_falta"] = "nao_tratado"
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [
        (None, "so admite veredito a_conferir", True),
        ("furos.csv", None, False),
    ])


def caso_origem_trocada_na_matriz_derruba(pasta):
    """A trava da lei de ferro 2 lia a origem da matriz, e nao do arquivo de
    requisitos. Trocar a celula de sumario para entregue destravava o furo
    contra norma que a pessoa nunca entregou."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;2020;entregue;deve;;identificacao e aprovacao registradas",
        "4.9;NORMA-X;2020;sumario;deve;;titulo da clausula, texto nao entregue",
    ]) + "\n"
    rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    linhas = ler_matriz(pasta)
    for l in linhas:
        if l["clausula"] == "4.9":
            l["origem"] = "entregue"
            l["veredito"] = "furo"
            l["o_que_falta"] = "nao_tratado"
            l["motivo"] = ""
        else:
            l["veredito"] = "atendido"
            l["onde"] = "cabecalho"
            l["linha"] = str(linha_de(PROC_COMPLETO, "Aprovado por"))
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [
        (None, "nao se edita na matriz", True),
        ("furos.csv", None, False),
    ])


def caso_recomendacao_nao_vira_furo(pasta):
    """tipo=convem e recomendacao. Recomendacao nao atendida nao e furo, e a
    coluna tipo era lida na entrada e nunca mais consultada."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;2020;entregue;deve;;identificacao e aprovacao registradas",
        "4.7;NORMA-X;2020;entregue;convem;;recomendacao entregue pela pessoa",
    ]) + "\n"
    rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    linhas = ler_matriz(pasta)
    for l in linhas:
        if l["tipo"] == "convem":
            l["veredito"] = "furo"
            l["o_que_falta"] = "nao_tratado"
        else:
            l["veredito"] = "atendido"
            l["onde"] = "cabecalho"
            l["linha"] = str(linha_de(PROC_COMPLETO, "Aprovado por"))
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [
        (None, "nao admite furo", True),
        ("furos.csv", None, False),
    ])


def caso_atendido_em_requisito_nao_entregue_derruba(pasta):
    """Sem o texto do requisito na mao tambem nao da para dizer que atende."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;2020;entregue;deve;;identificacao e aprovacao registradas",
        "4.8;NORMA-X;2020;nao_entregue;deve;;clausula citada de memoria",
    ]) + "\n"
    rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    linhas = atendido_em(ler_matriz(pasta), PROC_COMPLETO, "Aprovado por", "cabecalho")
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [(None, "so admite veredito a_conferir", True)])


def caso_linha_sumida_da_matriz_derruba(pasta):
    """Requisito que desaparece entre a rodada de estrutura e o fechamento e
    exatamente a perda silenciosa que o codigo 0 esconderia."""
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = atendido_em(ler_matriz(pasta), PROC_COMPLETO, "Registrar cada execucao",
                         "3. PROCEDIMENTO")
    res = rodar_fechamento(pasta, linhas[:-1])
    return conferir(res, pasta, 3, [(None, "sumiu da matriz", True)])


def caso_pendente_no_fechamento_derruba(pasta):
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    linhas[0]["veredito"] = "atendido"
    linhas[0]["onde"] = "3. PROCEDIMENTO"
    linhas[0]["linha"] = str(linha_de(PROC_COMPLETO, "Registrar cada execucao"))
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [(None, "ainda em pendente", True)])


def caso_atendido_sem_evidencia_derruba(pasta):
    """Atendimento sem onde e sem linha e afirmacao sem prova, e e o caminho
    mais facil para uma rodada limpa e falsa."""
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    for l in linhas:
        l["veredito"] = "atendido"
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [(None, "sem evidencia", True)])


def caso_atendido_em_linha_inexistente_derruba(pasta):
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    for l in linhas:
        l["veredito"] = "atendido"
        l["onde"] = "3. PROCEDIMENTO"
        l["linha"] = "9999"
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [(None, "nao e evidencia valida", True)])


def caso_atendido_em_linha_branca_derruba(pasta):
    """Linha branca dentro de uma secao existe e nao diz nada. Aceita-la como
    evidencia e fabricar prova sem perder nenhuma identidade."""
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    for l in linhas:
        l["veredito"] = "atendido"
        l["onde"] = "3. PROCEDIMENTO"
        l["linha"] = str(linha_branca_de(PROC_COMPLETO))
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [
        (None, "nao e evidencia valida", True),
        ("furos.csv", None, False),
    ])


def caso_atendido_em_campo_de_controle_no_cabecalho(pasta):
    """Os campos de controle ficam antes da primeira secao. A clausula de
    controle de documento e atendida justamente ali, e o script recusava a
    unica evidencia correta que existe para ela."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;2020;entregue;deve;;identificacao, data, revisao e aprovador registrados",
    ]) + "\n"
    res = rodar_estrutura(pasta, PROC_CABECALHO, reqs)
    erros = conferir(res, pasta, 4, [("forma.csv", "aprovado_por;presente_preenchido", True)])
    linhas = atendido_em(ler_matriz(pasta), PROC_CABECALHO, "Aprovado por",
                         "cabecalho de controle")
    res2 = rodar_fechamento(pasta, linhas)
    return erros + conferir(res2, pasta, 0, [
        (None, "nao e evidencia valida", False),
        ("furos.csv", "conteudo;", False),
    ])


def caso_procedimento_alterado_entre_rodadas_derruba(pasta):
    """A pessoa corrige o procedimento depois de receber a lista de furos, e
    toda linha apontada na matriz fica vencida. O script aceitava, contanto que
    o numero caisse dentro de alguma secao, e gravava evidencia para o trecho
    errado."""
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = atendido_em(ler_matriz(pasta), PROC_COMPLETO, "Registrar cada execucao",
                         "3. PROCEDIMENTO")
    alterado = "Observacao de campo incluida na revisao seguinte.\nOutra linha incluida.\n" \
        + PROC_COMPLETO
    (pasta / "procedimento.md").write_text(alterado, encoding="utf-8")
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [
        (None, "mudou depois da rodada de estrutura", True),
        ("furos.csv", None, False),
    ])


def caso_rodada_invalida_nao_deixa_entrega(pasta):
    """furos.csv era escrito antes de a rodada ser declarada valida. O
    diretorio ficava com entrega completa de uma rodada que nao vale."""
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    linhas[0]["veredito"] = "atendido"
    linhas[0]["onde"] = "cabecalho"
    linhas[0]["linha"] = str(linha_de(PROC_COMPLETO, "Aprovado por"))
    linhas[1]["veredito"] = "furo"
    linhas[1]["o_que_falta"] = "tratado_sem_criterio"
    linhas[1]["onde"] = "3. PROCEDIMENTO"
    primeira = rodar_fechamento(pasta, linhas)
    erros = conferir(primeira, pasta, 1, [("furos.csv", "tratado_sem_criterio", True)])
    linhas[1]["veredito"] = "pendente"
    linhas[1]["o_que_falta"] = ""
    segunda = rodar_fechamento(pasta, linhas)
    return erros + conferir(segunda, pasta, 3, [
        (None, "ainda em pendente", True),
        ("furos.csv", None, False),
        ("a-conferir-na-sua-edicao.csv", None, False),
        ("consolidado-da-rodada.csv", None, False),
        ("plano-de-correcao.md", None, False),
    ])


def caso_o_que_falta_fora_do_vocabulario_derruba(pasta):
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    linhas[0]["veredito"] = "atendido"
    linhas[0]["onde"] = "3. PROCEDIMENTO"
    linhas[0]["linha"] = str(linha_de(PROC_COMPLETO, "Registrar cada execucao"))
    linhas[1]["veredito"] = "furo"
    linhas[1]["o_que_falta"] = "parece fraco"
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 3, [(None, "fora do vocabulario", True)])


def caso_furo_de_conteudo_sai_1(pasta):
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    linhas[0]["veredito"] = "atendido"
    linhas[0]["onde"] = "cabecalho"
    linhas[0]["linha"] = str(linha_de(PROC_COMPLETO, "Aprovado por"))
    linhas[1]["veredito"] = "furo"
    linhas[1]["o_que_falta"] = "tratado_sem_criterio"
    linhas[1]["onde"] = "3. PROCEDIMENTO"
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 1, [
        ("furos.csv", "conteudo;4.3;NORMA-X", True),
        ("furos.csv", "tratado_sem_criterio", True),
        ("a-conferir-na-sua-edicao.csv", "4.3", False),
        ("plano-de-correcao.md", "tratado_sem_criterio", True),
    ])


def caso_tudo_atendido_sai_0(pasta):
    """O unico caminho para o codigo 0: forma completa, todo requisito
    entregue e atendido com evidencia, e nada fora da conferencia."""
    rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    linhas = ler_matriz(pasta)
    linhas[0]["veredito"] = "atendido"
    linhas[0]["onde"] = "cabecalho"
    linhas[0]["linha"] = str(linha_de(PROC_COMPLETO, "Aprovado por"))
    linhas[1]["veredito"] = "atendido"
    linhas[1]["onde"] = "4. REGISTROS"
    linhas[1]["linha"] = str(linha_de(PROC_COMPLETO, "Ordem de servico arquivada"))
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 0, [
        ("furos.csv", "conteudo;", False),
        ("furos.csv", "forma;", False),
        ("plano-de-correcao.md", None, False),
        ("cobertura-por-clausula.csv", "4.2;NORMA-X;2020", True),
    ])


def caso_sem_furo_mas_com_a_conferir_sai_5(pasta):
    """'Nenhum furo' com requisito por conferir nao e 'nenhum furo'."""
    reqs = REQ_DOIS_ENTREGUES + \
        "4.9;NORMA-X;2020;sumario;deve;;titulo da clausula, texto nao entregue\n"
    rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    linhas = ler_matriz(pasta)
    for l in linhas:
        if l["origem"] != "entregue":
            continue
        l["veredito"] = "atendido"
        l["onde"] = "4. REGISTROS"
        l["linha"] = str(linha_de(PROC_COMPLETO, "Ordem de servico arquivada"))
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 5, [
        (None, "nao sai com 0", True),
        ("a-conferir-na-sua-edicao.csv", "4.9", True),
        ("a-conferir-na-sua-edicao.csv", "conferir na edicao vigente", True),
    ])


def caso_estrito_bloqueia_a_conferir(pasta):
    reqs = REQ_DOIS_ENTREGUES + \
        "4.9;NORMA-X;2020;sumario;deve;;titulo da clausula, texto nao entregue\n"
    rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    linhas = ler_matriz(pasta)
    for l in linhas:
        if l["origem"] != "entregue":
            continue
        l["veredito"] = "atendido"
        l["onde"] = "4. REGISTROS"
        l["linha"] = str(linha_de(PROC_COMPLETO, "Ordem de servico arquivada"))
    res = rodar_fechamento(pasta, linhas, extra=("--estrito",))
    return conferir(res, pasta, 2, [])


def caso_estrito_com_furo_sai_1(pasta):
    """Com furo presente o codigo 1 prevalece sobre o 2, e a rodada diz isso em
    vez de deixar a promessa de --estrito sem resposta."""
    reqs = REQ_DOIS_ENTREGUES + \
        "4.9;NORMA-X;2020;sumario;deve;;titulo da clausula, texto nao entregue\n"
    rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    linhas = ler_matriz(pasta)
    for l in linhas:
        if l["origem"] != "entregue":
            continue
        if l["clausula"] == "4.3":
            l["veredito"] = "furo"
            l["o_que_falta"] = "tratado_sem_criterio"
            l["onde"] = "3. PROCEDIMENTO"
            continue
        l["veredito"] = "atendido"
        l["onde"] = "4. REGISTROS"
        l["linha"] = str(linha_de(PROC_COMPLETO, "Ordem de servico arquivada"))
    res = rodar_fechamento(pasta, linhas, extra=("--estrito",))
    return conferir(res, pasta, 1, [(None, "o codigo 1 prevalece sobre o 2", True)])


def caso_campo_ausente_vira_furo_de_forma(pasta):
    proc = PROC_COMPLETO.replace("Dono do processo: coordenacao de manutencao\n", "")
    rodar_estrutura(pasta, proc, REQ_DOIS_ENTREGUES)
    linhas = atendido_em(ler_matriz(pasta), proc, "Ordem de servico arquivada", "4. REGISTROS")
    res = rodar_fechamento(pasta, linhas)
    return conferir(res, pasta, 1, [("furos.csv", "sem_dono", True)])


def caso_sem_valores_nao_grava_nome(pasta):
    """Os campos de aprovacao e de dono carregam nome de pessoa."""
    res = rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES, extra=("--sem-valores",))
    return conferir(res, pasta, 4, [
        ("forma.csv", "gerencia da qualidade", False),
        ("forma.csv", "<omitido>", True),
    ])


def caso_rodape_em_todo_artefato(pasta):
    res = rodar_estrutura(pasta, PROC_COMPLETO, REQ_DOIS_ENTREGUES)
    return conferir(res, pasta, 4, [
        ("forma.csv", "Revisar antes de assinar", True),
        ("secoes.csv", "Nao substitui responsabilidade tecnica", True),
        ("matriz-cobertura.csv", "Gerado com apoio de IA", True),
        ("leitura-da-estrutura.md", "Revisar antes de assinar", True),
    ])


def caso_dois_procedimentos_na_mesma_rodada(pasta):
    """A razao numero um que a skill da para o script existir: o mesmo checklist
    em todos os procedimentos da rodada, com consolidacao por clausula. Antes
    era um procedimento por execucao, sem consolidado nenhum."""
    outro = PROC_COMPLETO.replace("Dono do processo: coordenacao de manutencao\n", "")
    outro = outro.replace("PR-QA-014", "PR-QA-015")
    res = rodar_estrutura_varios(pasta, [("pop-a.md", PROC_COMPLETO), ("pop-b.md", outro)],
                                 REQ_DOIS_ENTREGUES)
    erros = conferir(res, pasta, 4, [
        ("pop-a/forma.csv", "dono;presente_preenchido", True),
        ("pop-b/forma.csv", "dono;ausente", True),
        ("consolidado-de-forma.csv", "pop-b.md;dono;ausente", True),
        ("matriz-cobertura.csv", "pop-a.md;4.2", True),
        ("matriz-cobertura.csv", "pop-b.md;4.3", True),
        (None, "pares procedimento x requisito:         4", True),
    ])
    linhas = ler_matriz(pasta)
    for l in linhas:
        texto = PROC_COMPLETO if l["procedimento"] == "pop-a.md" else outro
        if l["clausula"] == "4.3" and l["procedimento"] == "pop-b.md":
            l["veredito"] = "furo"
            l["o_que_falta"] = "tratado_sem_registro"
            l["onde"] = "3. PROCEDIMENTO"
            continue
        l["veredito"] = "atendido"
        l["onde"] = "4. REGISTROS"
        l["linha"] = str(linha_de(texto, "Ordem de servico arquivada"))
    res2 = rodar_fechamento(pasta, linhas, procedimentos=("pop-a.md", "pop-b.md"))
    return erros + conferir(res2, pasta, 1, [
        ("consolidado-da-rodada.csv", "pop-a.md;4.2", True),
        ("consolidado-da-rodada.csv", "pop-b.md;4.3;NORMA-X;2020;entregue;deve;furo", True),
        ("cobertura-por-clausula.csv", "4.3;NORMA-X;2020;entregue;deve;2;1;1;0;0;pop-b.md", True),
        ("furos.csv", "pop-b.md;forma;", True),
        ("furos.csv", "pop-a.md;forma;", False),
        ("plano-de-correcao.md", "pop-b.md", True),
        (None, "clausulas atendidas em todos os procedimentos: 1 de 2", True),
    ])


def caso_estrutura_invalida_nao_deixa_matriz(pasta):
    """Rodada de estrutura derrubada nao deixa matriz para preencher nem
    impressao para o fechamento comparar. Preencher a matriz de uma rodada que
    nao vale e trabalho perdido, e fechar sobre ela e entrega falsa."""
    reqs = "\n".join([
        CABECALHO_REQ,
        "4.2;NORMA-X;2020;entregue;deve;;identificacao e aprovacao registradas",
        "4.3;NORMA-X;2020;;deve;;registro que prova a execucao",
    ]) + "\n"
    res = rodar_estrutura(pasta, PROC_COMPLETO, reqs)
    erros = conferir(res, pasta, 3, [
        ("matriz-cobertura.csv", None, False),
        ("impressao-do-procedimento.csv", None, False),
        ("requisitos-nao-parseados.csv", None, True),
    ])
    linhas = [{"procedimento": "procedimento.md", "clausula": "4.2", "norma": "NORMA-X",
               "edicao": "2020", "origem": "entregue", "tipo": "deve",
               "requisito": "identificacao e aprovacao registradas", "veredito": "atendido",
               "onde": "1. OBJETIVO", "linha": str(linha_de(PROC_COMPLETO, "Aprovado por"))}]
    res2 = rodar_fechamento(pasta, linhas)
    return erros + conferir(res2, pasta, 3, [
        (None, "precisa da rodada de estrutura", True),
        ("furos.csv", None, False),
    ])


# ---------------------------------------------------------------------------
# Casos de papelada: eles nao rodam o script, conferem o que a skill promete
# por escrito contra o que existe.
# ---------------------------------------------------------------------------

PASTA_DA_SKILL = AQUI.parent
ARQUIVOS_DA_SKILL = (
    PASTA_DA_SKILL / "SKILL.md",
    PASTA_DA_SKILL / "references" / "leitura-de-requisito.md",
    AQUI / "conferir-estrutura.py",
    AQUI / "testar.py",
)


def caso_papelada_da_skill(_pasta):
    """O que a skill promete por escrito tem que bater com o que existe: nome,
    limite da description, dependencia declarada, e a papelada do kit, que fica
    fora do pacote instalado e nao pode desmentir a skill."""
    erros = []
    skill = PASTA_DA_SKILL / "SKILL.md"
    texto = skill.read_text(encoding="utf-8")
    if "name: %s" % PASTA_DA_SKILL.name not in texto:
        erros.append("o campo name da SKILL.md nao bate com o nome da pasta")
    linhas = texto.splitlines()
    desc = []
    dentro = False
    for linha in linhas[1:]:
        if linha.startswith("description:"):
            dentro = True
            continue
        if dentro and (linha.startswith("---") or (linha and not linha.startswith("  "))):
            break
        if dentro:
            desc.append(linha.strip())
    descricao = " ".join(x for x in desc if x)
    if not descricao:
        erros.append("nao consegui ler a description da SKILL.md")
    elif len(descricao) > 1400:
        erros.append("a description tem %d caracteres, o limite e 1400" % len(descricao))
    if "NÃO use" not in descricao and "NAO use" not in descricao:
        erros.append("a description nao fecha com o que nao usar")
    if "hashlib" not in texto:
        erros.append("a dependencia declarada na SKILL.md nao lista hashlib, que o "
                     "conferir-estrutura.py importa")
    for arquivo in ARQUIVOS_DA_SKILL:
        conteudo = arquivo.read_text(encoding="utf-8")
        for caractere, nome in (("\u2014", "travessao"), ("\u2013", "meia-risca")):
            if caractere in conteudo:
                erros.append("%s tem %s, que a regra da casa proibe" % (arquivo.name, nome))
    leia_me = PASTA_DA_SKILL.parent.parent / "00-LEIA-ME.md"
    if leia_me.exists():
        papel = leia_me.read_text(encoding="utf-8")
        for frase in ("quatro skills prontas", "das dez previstas", "para as quatro skills"):
            if frase in papel:
                erros.append("00-LEIA-ME.md ainda diz %r" % frase)
        for linha in papel.split("\n"):
            if linha.startswith("| `padrao-conferido-contra-norma`") and "Prevista" in linha:
                erros.append("00-LEIA-ME.md ainda lista esta skill como prevista")
    return erros


# ---------------------------------------------------------------------------
# Varredura de norma real, no pacote inteiro.
#
# A regra nasceu aqui e valia so para os arquivos desta skill. Um revisor de
# conformidade achou outra skill do mesmo pacote afirmando o que uma clausula de
# norma real exige, num exemplo copiado em toda rodada. A regra nao e desta skill,
# e do kit: o pacote e distribuido inteiro, e quem abre qualquer arquivo dele le o
# kit afirmando requisito de norma que ninguem entregou.
#
# O que a varredura reprova:
#   1. citar clausula numerada sem ser a norma ficticia do kit;
#   2. prender uma norma real a uma edicao, no formato familia numero dois-pontos ano;
#   3. dizer o que uma norma real exige, manda, requer, obriga, determina ou estabelece;
#   4. trazer uma das clausulas reais que ja apareceram em versao anterior do kit.
#
# O que ela deixa passar de proposito, porque fala de norma sem afirmar requisito:
# nomear a familia da norma ("pode nao ser a ISO 9001"), citar designacao de norma
# em fixture de extrator de termo, e nome de codificacao de texto.
# ---------------------------------------------------------------------------

RAIZ_DO_KIT = PASTA_DA_SKILL.parent.parent
SUFIXOS_VARRIDOS = (".md", ".py", ".txt", ".csv", ".json")

FAMILIAS_DE_NORMA = "ISO|IEC|NBR|ABNT|IATF|ASME|ASTM|ANSI|DIN|AWS|OHSAS"
RE_CLAUSULA_NUMERADA = re.compile(
    r"(?i)cl[áa]usula[s]?\s+(?:n[.º°o]\s*)?\d+\.\d+(?:\.\d+)*")
RE_NORMA_COM_EDICAO = re.compile(
    r"(?i)\b(?:" + FAMILIAS_DE_NORMA +
    r")\s*/?\s*(?:[A-Z]{2,5}\s*)?\d{3,6}\s*[:;]\s*(?:19|20)\d{2}")
RE_NORMA_QUE_EXIGE = re.compile(
    r"(?i)\b(?:" + FAMILIAS_DE_NORMA + r")\s*/?\s*\d{3,6}[^\n]{0,80}?\b"
    r"(?:exige|exigem|manda|mandam|requer|requerem|obriga|obrigam|"
    r"determina|determinam|estabelece|estabelecem)\b")
RE_NORMA_FICTICIA = re.compile(r"(?i)NORMA-[A-Z]")

# Montadas em pedacos de proposito: escritas inteiras, elas apareceriam neste
# arquivo e o proprio teste casaria com o que ele proibe.
CLAUSULAS_REAIS = ("7" + ".5.2", "8" + ".5.1", "9" + ".1.1")


def arquivos_do_pacote():
    """Os arquivos de texto do kit. Devolve (arquivos, aviso). Instalada, a skill
    fica sozinha em ~/.claude/skills/ e o pacote nao esta em volta dela: nesse caso
    a varredura nao roda e diz que nao rodou, em vez de passar calada."""
    if not (RAIZ_DO_KIT / "00-LEIA-ME.md").exists() or not (RAIZ_DO_KIT / "skills").is_dir():
        return [], ("o pacote nao esta em volta desta skill (copia instalada): a "
                    "varredura de norma real no pacote NAO rodou")
    achados = [c for c in sorted(RAIZ_DO_KIT.rglob("*"))
               if c.is_file() and c.suffix in SUFIXOS_VARRIDOS]
    return achados, ""


def norma_real_no_arquivo(caminho):
    """Trechos do arquivo que afirmam clausula ou requisito de norma real."""
    texto = caminho.read_text(encoding="utf-8", errors="replace").replace("\r", "")
    achados = []
    for m in RE_CLAUSULA_NUMERADA.finditer(texto):
        janela = texto[max(0, m.start() - 80):m.end() + 40]
        if not RE_NORMA_FICTICIA.search(janela):
            achados.append("cita %r sem ser a norma ficticia do kit"
                           % " ".join(m.group(0).split()))
    for m in RE_NORMA_COM_EDICAO.finditer(texto):
        achados.append("prende %r a uma edicao de norma real"
                       % " ".join(m.group(0).split()))
    for m in RE_NORMA_QUE_EXIGE.finditer(texto):
        achados.append("afirma o que norma real exige em %r"
                       % " ".join(m.group(0).split()))
    for literal in CLAUSULAS_REAIS:
        if literal in texto:
            achados.append("traz %r, que e numero de clausula de norma real" % literal)
    return achados


def caso_sem_clausula_de_norma_real(_pasta):
    """Nenhum arquivo do pacote afirma o que uma clausula de norma real exige. As
    fixtures e os exemplos usam norma ficticia, porque o arquivo e distribuido e
    quem o abre le o kit afirmando requisito de norma que ninguem entregou."""
    # Montados em pedacos de proposito: escritos inteiros, eles apareceriam neste
    # arquivo e o proprio teste casaria com o que ele proibe.
    proibidos = CLAUSULAS_REAIS + ("ISO" + " 9001;", "ISO" + " 9001:",
                                   "ISO" + " 9001 2015", "ISO" + " 14001", "NBR" + " ")
    erros = []
    for arquivo in ARQUIVOS_DA_SKILL:
        conteudo = arquivo.read_text(encoding="utf-8")
        for proibido in proibidos:
            if proibido in conteudo:
                erros.append("%s traz %r, que afirma requisito de norma real"
                             % (arquivo.name, proibido))
    arquivos, aviso = arquivos_do_pacote()
    if aviso:
        avisos.append(aviso)
        return erros
    if not arquivos:
        erros.append("achei a raiz do kit em %s e nenhum arquivo de texto dentro: "
                     "a varredura do pacote nao conferiu nada" % RAIZ_DO_KIT)
        return erros
    for arquivo in arquivos:
        for achado in norma_real_no_arquivo(arquivo):
            erros.append("%s %s" % (arquivo.relative_to(RAIZ_DO_KIT), achado))
    avisos.append("varredura de norma real: %d arquivo(s) do pacote conferido(s)"
                  % len(arquivos))
    return erros


CASOS = [
    ("rodada de estrutura nunca sai com 0", caso_estrutura_nunca_sai_zero),
    ("requisito com origem em branco derruba", caso_origem_em_branco_derruba),
    ("requisito sem edicao derruba", caso_edicao_em_branco_derruba),
    ("nenhum requisito entregue derruba", caso_nenhum_requisito_entregue_derruba),
    ("procedimento sem secao derruba", caso_procedimento_sem_secao_derruba),
    ("historico de revisoes vazio e furo", caso_historico_presente_e_vazio),
    ("marcador de preenchimento nao e valor", caso_placeholder_nao_e_preenchido),
    ("rodape com conteudo fica mantido", caso_rodape_com_conteudo_fica_mantido),
    ("rodape sem conteudo e removido", caso_rodape_sem_conteudo_e_removido),
    ("secao numerada curta nao some", caso_secao_numerada_curta_nao_some),
    ("campo em tabela markdown vertical", caso_campo_em_tabela_markdown),
    ("tabela de controle horizontal e lida", caso_tabela_de_controle_horizontal),
    ("revisao 00 e valor preenchido", caso_revisao_zero_zero_e_valor),
    ("N.A. com pontos e campo vazio", caso_na_com_pontos_e_campo_vazio),
    ("rodape no requisitos.csv nao derruba", caso_rodape_no_requisitos_nao_derruba),
    ("--forcar nao apaga matriz julgada", caso_forcar_nao_apaga_matriz_julgada),
    ("--sem-valores nao vaza titulo de secao", caso_sem_valores_nao_vaza_secao),
    ("furo em requisito nao entregue derruba", caso_furo_em_requisito_nao_entregue_derruba),
    ("origem trocada na matriz derruba", caso_origem_trocada_na_matriz_derruba),
    ("recomendacao nao vira furo", caso_recomendacao_nao_vira_furo),
    ("atendido em requisito nao entregue derruba", caso_atendido_em_requisito_nao_entregue_derruba),
    ("linha sumida da matriz derruba", caso_linha_sumida_da_matriz_derruba),
    ("pendente no fechamento derruba", caso_pendente_no_fechamento_derruba),
    ("atendido sem evidencia derruba", caso_atendido_sem_evidencia_derruba),
    ("atendido em linha inexistente derruba", caso_atendido_em_linha_inexistente_derruba),
    ("atendido em linha branca derruba", caso_atendido_em_linha_branca_derruba),
    ("atendido em campo de controle do cabecalho passa",
     caso_atendido_em_campo_de_controle_no_cabecalho),
    ("procedimento alterado entre rodadas derruba", caso_procedimento_alterado_entre_rodadas_derruba),
    ("rodada invalida nao deixa entrega", caso_rodada_invalida_nao_deixa_entrega),
    ("estrutura invalida nao deixa matriz", caso_estrutura_invalida_nao_deixa_matriz),
    ("o_que_falta fora do vocabulario derruba", caso_o_que_falta_fora_do_vocabulario_derruba),
    ("furo de conteudo sai com 1", caso_furo_de_conteudo_sai_1),
    ("campo ausente vira furo de forma", caso_campo_ausente_vira_furo_de_forma),
    ("tudo atendido sai com 0", caso_tudo_atendido_sai_0),
    ("sem furo mas com a_conferir sai com 5", caso_sem_furo_mas_com_a_conferir_sai_5),
    ("estrito bloqueia a_conferir", caso_estrito_bloqueia_a_conferir),
    ("estrito com furo junto sai com 1", caso_estrito_com_furo_sai_1),
    ("--sem-valores nao grava nome de pessoa", caso_sem_valores_nao_grava_nome),
    ("rodape em todo artefato", caso_rodape_em_todo_artefato),
    ("dois procedimentos na mesma rodada consolidam", caso_dois_procedimentos_na_mesma_rodada),
    ("papelada da skill bate com o que existe", caso_papelada_da_skill),
    ("nenhuma clausula de norma real no pacote", caso_sem_clausula_de_norma_real),
]


def main():
    if not SCRIPT.exists():
        print("ERRO: nao achei %s" % SCRIPT)
        return 1
    for nome, funcao in CASOS:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                registrar(nome, funcao(Path(tmp)))
            except Exception as erro:  # noqa: BLE001
                registrar(nome, ["excecao no proprio teste: %r" % erro])
    print("")
    for aviso in avisos:
        print("aviso: %s" % aviso)
    print("%d caso(s), %d falha(s)" % (len(CASOS), len(falhas)))
    return 1 if falhas else 0


if __name__ == "__main__":
    sys.exit(main())
