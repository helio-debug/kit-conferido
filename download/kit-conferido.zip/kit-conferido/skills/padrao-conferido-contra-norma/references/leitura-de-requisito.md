# Leitura de requisito, sem reproduzir norma

Referência de `padrao-conferido-contra-norma`. Leia antes do passo 3, que é o passo em que
o requisito entregue pela pessoa vira linha de `requisitos.csv`.

---

## 1. A regra zero, e o que conta como reprodução

A skill nunca reproduz texto de norma, nem no arquivo nem na resposta. Reprodução não é só
copiar a frase entre aspas. Também é:

- **Enumerar as alíneas de uma cláusula na ordem dela.** A sequência das alíneas é a
  estrutura protegida do texto. Reescrever cada alínea com sinônimo e manter a ordem
  entrega a cláusula inteira.
- **Parafrasear frase a frase, na mesma sequência.** Se o parágrafo da skill acompanha o
  parágrafo da norma um a um, o que saiu foi uma tradução, não um resumo.
- **Reconstruir a cláusula em respostas sucessivas.** Um pedaço por rodada soma a mesma
  coisa.
- **Reproduzir tabela de valor, tolerância, dimensão, condição de ensaio ou critério
  numérico.** Em norma de produto e de ensaio, a tabela é o conteúdo.

O que a skill escreve é sempre da mesma forma: **nome da norma, ano da edição, número da
cláusula, o requisito em palavras próprias e em ordem própria, e a frase de conferência.**
Cláusula sem edição é um número, não um requisito, e é a lei de ferro 3.

O exemplo abaixo usa norma fictícia de propósito: escrever aqui o que uma cláusula de norma
real exige, sem a norma na mão e sem ninguém ter entregue o requisito, é o erro que a lei de
ferro 2 chama de pior possível, e este arquivo é o modelo que vai ser copiado em toda rodada.

```
NORMA-X, edição 2020, cláusula 4.2  [requisito entregue pela pessoa]
  o documento precisa carregar identificação, data, revisão e quem aprovou.
  Confira na edição vigente da sua empresa.
```

A marcação de quem entregou o requisito vai na coluna `origem` do `requisitos.csv`, e é ela
que autoriza `atendido` ou `furo`.

**Teste de três perguntas antes de gravar a linha.** Se qualquer resposta for não, a linha
não sai.

1. Um leitor que não tem a norma consegue entender o que precisa existir no procedimento?
2. Um leitor que tem a norma diria que esta linha substitui a leitura da cláusula? Se
   diria, a linha está longa demais.
3. A ordem dos assuntos aqui é minha, e não a ordem das alíneas?

---

## 2. As três origens de um requisito

A coluna `origem` é a única coisa que autoriza a skill a apontar furo. Ela não é
burocracia: é a diferença entre um achado e uma invenção.

| `origem` | O que significa | O que a skill pode dizer |
|---|---|---|
| `entregue` | A pessoa entregou o requisito: colou a cláusula, leu em voz alta, descreveu a exigência com as palavras dela, ou mostrou a página | `atendido` ou `furo`, com evidência |
| `sumario` | A pessoa tem só o índice ou o título da cláusula da edição que ela possui | Apenas `a_conferir`. Título de cláusula não diz o que a cláusula exige |
| `nao_entregue` | A skill acha que existe um requisito ali, e ele não está na mão | Apenas `a_conferir`. Nunca vira furo |

O script recusa qualquer outro veredito para `sumario` e `nao_entregue`, e derruba a rodada.
A trava é mecânica de propósito: o erro que ela evita é o único desta skill que não tem
conserto depois, porque quem assina é o engenheiro e quem é apontado como fonte é o kit.

---

## 3. Nove armadilhas de leitura de requisito

### 3.1 "Deve" contra "convém que"

Em texto normativo, `deve` é exigência e `convém que` é recomendação. Recomendação não
atendida **não é furo**. Se a pessoa entregou o requisito com as palavras dela e não disse
qual dos dois é, pergunte. Preencha a coluna `tipo` com `deve` ou `convem`. Na dúvida, a
linha sai como `convem`.

Esta não é uma regra de bom senso: o script recusa `veredito=furo` em linha `tipo=convem` e
derruba a rodada com código 3. A recomendação não atendida sai como `a_conferir` com o motivo,
e vira observação no plano de correção. Quem concluir que a exigência é obrigatória na edição
da empresa corrige o `tipo` no `requisitos.csv`, e não o veredito na matriz.

### 3.2 Informação documentada não é o mesmo que procedimento escrito

Boa parte das exigências de sistema pede **manter** ou **reter** informação documentada.
Um registro em sistema, uma ordem de serviço, um apontamento em planilha controlada podem
atender. Apontar "falta o procedimento escrito" onde a exigência pede registro retido é
furo falso, e é o furo falso mais comum de todos.

### 3.3 A cláusula foi renumerada entre edições

O mesmo assunto carrega números diferentes em edições diferentes. Por isso `edicao` é
coluna obrigatória e linha sem ela derruba a rodada. Número de cláusula vindo de outra
edição é outro requisito, não o mesmo requisito com outro nome.

### 3.4 Atendimento por remissão

O procedimento pode atender dizendo "conforme o documento X". Isso é atendimento válido
quando a remissão é explícita **e** o documento remetido existe e foi apresentado. Quando o
documento não aparece, o furo é `referencia_quebrada`, e ele é de rastreabilidade, não de
conteúdo: a exigência pode muito bem estar tratada, em lugar nenhum que se possa mostrar.

### 3.5 Exclusão de escopo

Exigência que não se aplica à empresa não é furo, desde que a não aplicação esteja
**declarada** em algum lugar controlado. Não declarada, o furo é
`exclusao_nao_declarada`, e o que falta é a declaração, não a atividade.

### 3.6 Nota não é requisito

Notas, exemplos e anexos informativos do texto normativo não são exigência. Requisito
derivado de nota sai como `convem`, ou não sai.

### 3.7 Requisito condicional

Parte das cláusulas amarra a exigência a uma condição de aplicabilidade, à pertinência do
caso ou a uma decisão prévia da organização. A condição vem antes da conferência. Preencha a
coluna `condicao` e resolva a condição com a pessoa antes de emitir o veredito. Condição não
resolvida sai como `a_conferir`, nunca como furo.

### 3.8 Norma de produto e de ensaio

Norma de sistema de gestão pede que exista processo, registro e critério, e isso se
confere sem o texto na mão desde que a pessoa tenha entregue a exigência. Norma de produto,
de ensaio e de dimensional pede **valores**: tolerância, faixa, tempo, temperatura, número
de corpos de prova. Sem a tabela na mão não existe conferência possível, e a skill não
tenta. A linha sai como `a_conferir` com o motivo escrito, e a pessoa confere na edição
dela.

### 3.9 Requisito que a empresa atende em outro documento

Antes de marcar `nao_tratado`, pergunte se existe outro procedimento da casa que trate o
assunto. Auditar um procedimento isolado produz furo que o sistema de documentos da empresa
não tem. Quando existir o outro documento e ele não estiver na mão, a linha é `a_conferir`
com o motivo, não furo.

---

## 4. Vocabulário fechado dos furos

O script recusa valor fora destas listas. Vocabulário aberto vira texto livre, e texto livre
não se conta nem se compara entre uma rodada e a seguinte.

### Furo de forma, um por campo de controle

| `o_que_falta` | O campo que faltou |
|---|---|
| `sem_codigo_de_documento` | Identificação do documento |
| `sem_titulo` | Título, quando exigido em `--campos` |
| `sem_identificacao_de_revisao` | Revisão ou versão |
| `sem_data_de_vigencia` | Data de vigência, emissão ou aprovação |
| `sem_registro_de_elaboracao` | Quem elaborou |
| `sem_registro_de_aprovacao` | Quem aprovou |
| `sem_dono` | Dono do processo |
| `sem_historico_de_revisao` | Histórico de revisões |
| `sem_registro_de_ciencia` | Lista de distribuição, ciência ou treinamento registrado |

Campo presente e vazio conta como furo, igual a campo ausente. Título de seção com nada
embaixo, seção cujo único conteúdo é `N.A.`, e campo preenchido com traço, `n/a` ou linha de
preenchimento, são a aparência do campo, não o campo.

O que **não** é campo vazio: revisão `0` e revisão `00`. É a identificação padrão da primeira
emissão de um documento controlado, e apontar furo contra ela manda o dono do procedimento
atrás de um problema que não existe.

### Furo de conteúdo

| `o_que_falta` | O que aconteceu |
|---|---|
| `nao_tratado` | Nada no procedimento trata a exigência |
| `tratado_parcial` | Parte está tratada, parte não. Diga qual parte, com palavras próprias |
| `tratado_sem_registro` | Manda fazer e não diz qual registro prova que foi feito |
| `tratado_sem_dono` | Ação sem responsável nomeado |
| `tratado_sem_criterio` | Manda conferir sem critério de aceitação nem frequência |
| `referencia_quebrada` | Atende por remissão a documento que não existe ou não foi apresentado |
| `exclusao_nao_declarada` | Na prática não se aplica, e a exclusão não está declarada |

Os quatro do meio são os que a conferência manual mais perde, porque o procedimento **fala
do assunto** e o olho dá por atendido. Exigência tratada sem registro, sem dono ou sem
critério é exatamente o que o auditor pede para ver e ninguém acha.

---

## 5. O que nunca vira furo

- Requisito que a pessoa não entregou.
- Requisito de edição diferente da que a empresa tem.
- Recomendação (`convem`).
- Nota e anexo informativo.
- Requisito condicional cuja condição não foi resolvida.
- Valor numérico de norma de produto ou de ensaio sem a tabela na mão.
- Exigência que o procedimento atende por remissão a documento que existe e foi apresentado.
- Assunto tratado em outro procedimento da casa, quando a pessoa confirmou que ele existe.

Todos estes saem em `a-conferir-na-sua-edicao.csv`, com o motivo e a frase de sempre:
confira na edição vigente da sua empresa.

---

Gerado com apoio de IA a partir do procedimento vigente e dos requisitos entregues pela
pessoa. Revisar antes de assinar. Não substitui responsabilidade técnica.
