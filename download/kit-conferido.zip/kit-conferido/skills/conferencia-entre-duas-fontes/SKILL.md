---
name: conferencia-entre-duas-fontes
description: >
  Recebe duas fontes de dado da mesma realidade (a planilha que a área mantém e o export
  do sistema) e devolve só as divergências, com a normalização declarada antes. A entrada
  é CSV: .xlsx e .xls precisam ser salvos como CSV, com a coluna-chave formatada como
  Texto, e a skill conduz essa conversão. Trata as armadilhas de planilha brasileira: zero
  à esquerda perdido, notação científica em código longo, vírgula contra ponto, data em
  três formatos, acento e caixa, célula mesclada, linha de total no rodapé, encoding
  trocado. Tem modo em que o conteúdo nunca sai da máquina. Use SEMPRE que aparecer:
  "confere essa planilha contra o sistema", "esses dois Excel não batem", "compara esses
  dois arquivos", "por que o total não bate", "cruza a lista do PCP com o export", "bate o
  estoque físico com o sistema", "confere o apontamento contra a ordem", "monta o de-para
  dessas duas listas", "preciso conciliar o sistema com a planilha", "toda semana eu
  confiro isso na mão", "acha o que mudou entre esses dois arquivos", "essas duas listas
  deveriam ser iguais", "esse relatório não fecha com a planilha". NÃO use para consolidar
  dois arquivos num só, nem para decidir qual das duas fontes está certa. NÃO use para
  extrair dado de PDF escaneado ou foto (extracao-de-documento-para-tabela), para triar
  caixa de e-mail (triagem-de-caixa-de-email), nem para comparar cotações
  (comparativo-de-cotacoes).
---

## Skills vizinhas

O kit prevê dez skills e esta versão traz dez. As remissões abaixo evitam que esta skill
ocupe o lugar das outras.

| Caso | Skill | Estado |
|---|---|---|
| Documento, PDF escaneado ou foto de folha preenchida à mão, que precisa virar tabela antes de qualquer conferência | `extracao-de-documento-para-tabela` | **Nesta versão.** Encadeie: extração medida contra gabarito primeiro, conferência depois |
| Cotações de fornecedores diferentes, cada uma na sua unidade | `comparativo-de-cotacoes` | **Nesta versão.** Lá o que se normaliza é unidade; aqui é chave |
| Caixa de e-mail que precisa ser triada | `triagem-de-caixa-de-email` | **Nesta versão** |
| Um único número, painel ou relatório cuja definição, fonte ou cálculo está em dúvida | `linha-de-base-antes-de-automatizar` | **Nesta versão.** O critério é a contagem de arquivos: dois arquivos que deveriam dizer a mesma coisa, aqui; um número só, lá |
| Refazer todo mês o mesmo relatório | `relatorio-recorrente` | **Nesta versão.** Ela consome a saída desta skill e não a substitui |
| Registrar um desvio de processo | `registro-de-anomalia` | **Nesta versão.** A divergência achada aqui é insumo do registro, não o registro |
| Descrever a área uma vez para as outras skills lerem | `ficha-da-area` | **Nesta versão.** Rode-a antes: ela escreve `~/.kit-industrial/ficha-da-area.md`, que o passo 1 desta lê |

---

# Conferência entre duas fontes

A pessoa tem dois arquivos que deveriam dizer a mesma coisa e não dizem. Ela abre os dois
lado a lado, roda o olho, acha três ou quatro diferenças e para quando cansa. Faz isso
toda semana e nunca sabe se achou tudo.

Esta skill termina em arquivo. A saída é sempre um conjunto de cinco arquivos gravados em
disco. Resposta em prosa dizendo "encontrei algumas diferenças" é falha de execução.

**Esta skill não acessa ERP e não acessa servidor de arquivos.** O export continua manual.
Ela compara os dois arquivos que recebeu, e diz isso na cara antes de começar.

---

## Leis de ferro

1. **A normalização é declarada antes de qualquer divergência.** Divergência gerada por
   normalização errada é pior que nenhuma conferência: a pessoa vai atrás de um problema
   que não existe, não encontra, e para de confiar no processo. A nota de normalização é o
   primeiro arquivo escrito, sempre.
2. **Normaliza para parear, compara e mostra o original.** A chave normalizada serve para
   encontrar o par. O que aparece na saída é o valor como está em cada arquivo, com a linha
   de origem dos dois lados.
3. **Diferença de formato não é divergência.** Se `01/02/2026` de um lado e `2026-02-01` do
   outro viram a mesma data depois da regra declarada, isso é formato: entra como contagem
   na nota e fica fora de `divergencias.csv`.
4. **Regra decidida por coluna, olhando a coluna inteira.** Decisão tomada célula a célula
   produz uma coluna com duas regras dentro dela, e ninguém descobre.
5. **Contagem que não fecha invalida a rodada.** As identidades da seção Fechamento são
   obrigatórias. Se não fecham, a conferência não é entregue.

---

## Passo 1: carregar a ficha da área

Leia `~/.kit-industrial/ficha-da-area.md`. Se existir, use o vocabulário da área, os
sistemas em uso e os relatórios que a área já extrai para escolher a chave e nomear as
colunas. Se não existir, declare em voz alta "rodando sem ficha da área" e siga normalmente.

A skill que escreve essa ficha é a `ficha-da-area`, nesta versão do kit. Rodar sem ficha não
degrada a conferência: só obriga a confirmar o nome da coluna-chave e a granularidade com a
pessoa, que é o passo 3.

**Critério de conclusão:** a primeira linha da resposta diz se a ficha foi carregada ou se
a conferência está rodando sem ficha e, carregada, repete o status gravado nela.

---

## Passo 2: perguntar o que tem dentro antes de abrir o arquivo

Três perguntas, nesta ordem:

1. **O dado é sensível?** Pessoa identificada, folha de pagamento, salário ou remuneração
   individual, preço de fornecedor identificado, dado de cliente identificado, projeto sob
   sigilo. Folha, salário e remuneração individual não entram em nenhum dos dois modos:
   peça o arquivo sem a coluna de remuneração, ou rode pelo script local, que não envia
   conteúdo. Se sim, ou se a pessoa não souber, vá
   para o **modo de dado sensível** e não leia o conteúdo. Ofereça sempre o modo derivado
   (trabalhar só com o cabeçalho e as linhas em questão).
2. **Essa conferência se repete?** Semanal ou mensal. Se sim, rode pelo script mesmo que
   caiba na leitura: o valor está em repetir igual, e leitura não repete igual.
3. **Quantas linhas tem cada arquivo?** Define leitura ou script pela tabela do passo 5.

**Critério de conclusão:** as três respostas estão registradas e a escolha entre leitura e
script está feita antes de qualquer arquivo ser aberto.

---

## Passo 3: declarar a chave e a granularidade

Diga qual coluna pareia as duas fontes e o que é uma linha em cada lado.

Se a fonte A tem uma linha por item e a B tem uma linha por item e lote, **as fontes não
têm a mesma granularidade e a conferência para aqui.** O sinal de alerta é taxa alta de
chave repetida em um lado só. Pergunte qual agregação a área usa em vez de agregar por
conta própria.

Se não existe coluna compartilhada que identifique a mesma entidade nos dois lados, diga
isso e pare. Chave composta só entra confirmada pela pessoa.

**Critério de conclusão:** a coluna-chave de cada lado está nomeada, a granularidade está
confirmada em uma frase, e a pessoa concordou com as duas.

---

## Passo 4: decidir regra por regra

Leia `references/normalizacao.md` e percorra os quatro grupos de armadilha. Cada decisão
tomada, e cada decisão deixada em aberto, entra na nota.

**Critério de conclusão:** existe uma decisão declarada para a chave e para cada campo
comparado, e as decisões ambíguas estão marcadas como ambíguas em vez de resolvidas no
chute.

---

## Passo 5: rodar

| Linhas na maior fonte | Como rodar |
|---|---|
| Até 150 | Leitura em contexto, com fechamento obrigatório |
| 151 a 400 | Leitura em contexto em modo contado: reemitir a lista completa de chaves dos dois lados e fechar as contagens. Custa quase o mesmo que rodar o script |
| Acima de 400 | Script obrigatório, sem exceção |
| Qualquer tamanho, se o dado é sensível | Script obrigatório |
| Qualquer tamanho, se a conferência se repete | Script obrigatório |
| Mais de 8 campos comparados, ou mais de 30 colunas | Script obrigatório |

**Por que 400 e não um número maior.** Duas fontes de 400 linhas industriais cabem na
janela de contexto com folga. O limite não é a janela, são três coisas que a leitura não
resolve:

- **Omissão silenciosa.** Pular uma linha na leitura não gera erro. A saída fica com cara
  de certa e a pessoa entrega errado. É a falha que esta skill existe para eliminar.
- **Não reprodutibilidade.** Duas leituras do mesmo par de arquivos podem devolver listas
  diferentes, e na semana seguinte ninguém repete o resultado.
- **Ausência de rastro.** Leitura não deixa linha de comando que alguém rode de novo.

O teste que decide: se não for possível reemitir a lista completa de chaves das duas fontes
e fechar as contagens, aquilo foi amostragem. Nesse caso diga que foi amostragem e rode o
script.

**Como rodar o script.** Dependência declarada: Python 3.8 ou superior, biblioteca padrão
apenas (`argparse`, `csv`, `datetime`, `decimal`, `re`, `sys`, `unicodedata`, `pathlib`).
Sem instalação, sem rede, sem escrita nos arquivos de entrada.

**Onde o script está depois de instalado.** A instalação copia a pasta da skill para
`~/.claude/skills/conferencia-entre-duas-fontes/`, e o script fica em
`~/.claude/skills/conferencia-entre-duas-fontes/scripts/conferir.py`. A rodada acontece na
pasta dos arquivos de trabalho, não na pasta da skill, e por isso o script é sempre chamado
pelo caminho completo. Caminho relativo como `scripts/conferir.py` só funciona de dentro da
pasta da skill: fora dela o Python responde `can't open file`.

No macOS e no Linux:

```
python3 ~/.claude/skills/conferencia-entre-duas-fontes/scripts/conferir.py \
    --fonte-a planilha.csv --fonte-b export.csv \
    --chave-a Codigo --chave-b Codigo --zeros-esquerda remover \
    --campos "Qtde:Quantidade,Dt Entr:Data de entrega,Descr:Descricao do item" \
    --saida conferencia-2026-04-30
```

No Windows, no PowerShell. Três diferenças: o executável é `py -3`, o caminho vai entre
aspas com `$env:USERPROFILE` no lugar do `~`, e a linha continua com acento grave no lugar
da barra invertida.

```
py -3 "$env:USERPROFILE\.claude\skills\conferencia-entre-duas-fontes\scripts\conferir.py" `
    --fonte-a planilha.csv --fonte-b export.csv `
    --chave-a Codigo --chave-b Codigo --zeros-esquerda remover `
    --campos "Qtde:Quantidade,Dt Entr:Data de entrega,Descr:Descricao do item" `
    --saida conferencia-2026-04-30
```

Nome de coluna igual nas duas fontes é exceção: a planilha da área escreve `Qtde` e
`Dt Entr`, o sistema escreve `Quantidade` e `Data de entrega`. Campo sem par derruba a
rodada com código 3 até que o par entre em `--campos`, porque coluna não comparada com
código 0 seria dizer que as fontes batem. A guarda é proporcional, não é "nenhuma coluna
emparelhou": no emparelhamento automático basta **uma** coluna sem par para a rodada cair.
Nome igual por acaso é a regra, não a exceção, em `Descricao`, `Setor`, `Obs` e `Data`, e
sem a guarda proporcional uma dessas coincidências deixaria a rodada seguir com todas as
outras colunas fora da comparação.

Com `--campos` a exclusão passa a ser decisão declarada: a rodada anda, e as colunas fora da
comparação saem nomeadas no bloco de verificações e na nota, marcadas como declaradas em
`--campos`. É a diferença entre não comparar por descuido e não comparar de propósito.

Antes de comparar, rode `--so-nota`: ele aplica a detecção e a normalização, escreve a nota
e a lista de linhas descartadas, e não compara. Serve para a pessoa aprovar as decisões antes
de olhar divergência.

### Ler o bloco ACHADOS antes de abrir divergencias.csv

O script fecha a saída com um bloco chamado `ACHADOS QUE NAO SAO AMBIGUIDADE`. Dois desses
achados mudam a rodada, e o passo é rodar de novo em vez de entregar o resultado:

- **Linhas sem par com chave parecida do outro lado.** Quando boa parte das órfãs de um lado
  tem sósia do outro, o que aconteceu não foi item faltante, foi a chave escrita de um jeito
  em cada fonte. Rode de novo com `--zeros-esquerda remover` ou `--zeros-esquerda completar`.
  Entregar a primeira rodada aqui é entregar dezenas de itens faltantes que não faltam.
- **Divergências que são só acento.** O mesmo texto escrito de duas formas no cadastro é
  achado real, e por isso a comparação de acento fica ligada por padrão. Mas quando ele
  domina a lista, a divergência que importa some no meio. Rode de novo com
  `--ignorar-acento-valor` para ver o resto, e relate as duas rodadas.

Esses dois achados aparecem sozinhos, com a contagem e o nome da opção. Rodada cujo bloco
ACHADOS traz um deles e não foi repetida está incompleta.

A nota sai no diretório de `--saida`, e a rodada de comparação grava no mesmo diretório. Por
isso repita o comando sem `--so-nota` e com `--forcar` no fim. Sem `--forcar` o script para
com código 3 e a mensagem de que o diretório já existe: é erro de entrada, não fechamento
que não fecha.

| Código de saída | Significado |
|---|---|
| 0 | Rodou, as duas fontes têm as mesmas chaves e nenhum valor diverge |
| 1 | Rodou, há divergências de valor |
| 2 | Ambiguidade não resolvida, em `--estrito` |
| 3 | Erro de entrada, fechamento que não fecha, nenhum par de campo, coluna sem par no emparelhamento automático, ou nenhuma chave pareada |
| 4 | Rodada em `--so-nota`, nenhuma comparação foi feita |
| 5 | Rodou, nenhum valor divergente, mas ficou dado fora da comparação de valor |

O código 3 para fechamento que não fecha é intencional: rodada cujas contagens não fecham
não é resultado parcial, é resultado inválido. Pelo mesmo motivo o código 3 cobre a rodada
que não comparou nada, e o código 4 existe para que `--so-nota` não devolva 0, que
significaria rodou e não há divergência.

O código 5 existe pelo mesmo motivo. Ele sai quando a comparação aconteceu e nenhum valor
divergiu, mas sobrou dado que nunca entrou nela: chave que existe só de um lado, chave que
repete na própria fonte com conteúdo diferente, chave vazia, chave irrecuperável, ou linha
com conteúdo derrubada na leitura por contagem de coluna diferente do cabeçalho. Tudo isso
sai nos arquivos, e é justamente por isso que a rodada não pode devolver o código que
dispensa a leitura deles. Numa rodada agendada, 0 é lido como "as fontes batem": só pode
sair quando as duas fontes têm as mesmas chaves e todos os valores comparados batem.

**Critério de conclusão:** na rodada `--so-nota` o diretório tem a
`nota-de-normalizacao.md`, com `status: so-nota, sem comparacao`, e a `linhas-descartadas.csv`,
e o código de saída é 4. Na rodada de comparação o diretório tem os cinco arquivos (seis com
`--formato-em-arquivo`), o bloco de fechamento impresso no terminal tem `fecha` em todas as
linhas, e no bloco de verificações `campos comparados` e `chaves pareadas nas duas fontes`
são maiores que zero. Código de saída 5 não é falha de rodada: é a rodada dizendo que o
resultado só fecha depois de alguém responder pelo dado que ficou fora da comparação.

---

## Passo 6: teste da linha plantada

Antes de entregar, cinco linhas são conferidas uma a uma. Há dois caminhos, e os dois
valem para leitura e para script.

**Caminho 1, a pessoa sabe.** Ela aponta **três linhas que já sabe que divergem e duas que
já sabe que batem.** Localize as cinco na saída e diga em que arquivo e em que linha cada
uma caiu.

**Caminho 2, a pessoa não sabe.** Quem roda a conferência pela primeira vez, ou roda toda
semana justamente para descobrir o que não sabe, não tem linhas para apontar, e isso não
trava a entrega. Monte o teste a partir da própria saída: escolha três linhas de
`divergencias.csv` e duas chaves que saíram como iguais, mostre os valores dos dois lados
com o número da linha de origem de cada um, e peça que ela confirme item por item.

Se qualquer uma das cinco estiver do lado errado, a conferência está errada e não é
entregue.

**Critério de conclusão:** está dito qual dos dois caminhos foi usado, e as cinco linhas
estão identificadas com arquivo e número de linha.

---

## Passo 7: fechamento

Confira as identidades. Todas devem fechar, e os números vão na nota:

```
registros_lidos_A   = descartadas_A + nao_chaveaveis_A + chaves_distintas_A + duplicatas_extras_A
registros_lidos_B   = descartadas_B + nao_chaveaveis_B + chaves_distintas_B + duplicatas_extras_B
chaves_distintas_A  = pareadas + so_em_A + nao_pareaveis_A
chaves_distintas_B  = pareadas + so_em_B + nao_pareaveis_B
pareadas            = iguais + com_divergencia
linhas em so-na-fonte-A.csv = so_em_A + linhas_de_duplicata_divergente_A + chave_vazia_A + irrecuperaveis_A
linhas em so-na-fonte-B.csv = so_em_B + linhas_de_duplicata_divergente_B + chave_vazia_B + irrecuperaveis_B
linhas em linhas-descartadas.csv = rodape_A + leitura_A + rodape_B + leitura_B
```

Onde `nao_chaveaveis` soma chave vazia e chave irrecuperável, e `nao_pareaveis` são as
chaves que repetem na própria fonte com conteúdo diferente. Uma célula com quebra de linha
dentro ocupa mais de uma linha no arquivo e continua sendo um registro: por isso o
fechamento conta registros lidos, não linhas do arquivo. As três últimas identidades conferem
o tamanho dos arquivos de saída, que contam linhas e não chaves.

As identidades saem dos mesmos contadores e fecham por construção: provam que a contabilidade
da rodada é consistente, não que a rodada prestou. O que pode falhar de fato vem no bloco
seguinte, impresso no terminal e repetido na nota: campos comparados, chaves pareadas nas duas
fontes, colunas sem par, colunas em padrão de célula mesclada, linhas descartadas, linhas com
conteúdo perdidas na leitura, conferência do total do rodapé, chaves irrecuperáveis e
duplicatas divergentes. Zero em campos comparados ou em chaves pareadas invalida a rodada, e
as outras exigem uma decisão registrada.

Essas verificações não ficam só no terminal. Quando sobra dado fora da comparação de valor,
o próprio código de saída diz: chave só de um lado, chave que repete com conteúdo diferente,
chave vazia, chave irrecuperável ou linha perdida na leitura fazem a rodada sair com 5, nunca
com 0.

**Critério de conclusão:** as oito identidades foram impressas com os números e todas fecham,
e cada linha do bloco de verificações foi lida e respondida. Se uma identidade quebrar, a
entrega para e o motivo é dito.

---

## Contrato de saída

Cinco arquivos num diretório com a data da rodada. Ordem de escrita: a nota e a
`linhas-descartadas.csv` saem antes de qualquer comparação, os três CSV de resultado saem
depois dela, e a nota é reescrita por último, com o fechamento. Um sexto arquivo sai só
quando pedido, e está no fim desta seção.

### 1. `nota-de-normalizacao.md`, primeiro, sempre

Escrita antes de qualquer comparação. Abre com `status: incompleto` e só vira
`status: completo` na última gravação, depois do fechamento. Os quatro valores possíveis são
`incompleto` (a rodada caiu no meio e a saída não vale), `so-nota, sem comparacao` (rodada
com `--so-nota`), `completo` (o fechamento fecha) e `invalido, nao fecha` (alguma identidade
quebrou, e a saída não é entregue).

Seções obrigatórias:

- **Fontes.** Nome, tamanho em bytes, data de modificação, linhas no arquivo e registros
  lidos depois do cabeçalho.
- **Leitura.** Encoding e por qual evidência, delimitador, linha do cabeçalho, linhas
  descartadas antes do cabeçalho e na leitura, rodapé descartado, e a conferência do total
  do rodapé contra a soma das linhas mantidas.
- **Chave e granularidade.** Coluna de cada lado, perfil aplicado, granularidade
  confirmada, e a contagem de chaves distintas antes e depois de cada regra da chave.
- **Regras aplicadas na chave.** Uma linha por regra, com quantas células a regra tocou em
  cada fonte. Regra que tocou zero célula fica na lista, declarada como zero. Regra que
  tocou 100% das células vira alerta: quase sempre indica coluna errada ou problema
  sistêmico, não normalização.
- **Regras aplicadas por campo comparado.** Mesmo formato, campo a campo, com o perfil e a
  evidência de cada lado.
- **O que não foi normalizado, por decisão.** Com o motivo.
- **Ambiguidades não resolvidas.** Cada uma com a coluna, o padrão do valor (sem o valor
  real) e o efeito na saída. São as únicas que o modo `--estrito` trata como bloqueio.
- **Achados que ficaram fora do pareamento.** O que nenhuma decisão de perfil resolve:
  total do rodapé que não confere, duplicata divergente, linha que saiu na leitura. É
  resultado da conferência, não ajuste de normalização.
- **Diferenças de formato ignoradas.** Contagem por campo e por regra que igualou.
- **Irrecuperáveis.** Células que perderam informação na origem e que nenhuma regra
  reconstrói. Contagem e linhas afetadas, fora do pareamento e reportadas à parte.
- **Fechamento.** As identidades com os números, o bloco de verificações que podem falhar
  de fato, e a tabela de quantas linhas cada arquivo de saída recebeu.
- **Limite declarado.** A frase de que o script não acessa ERP nem servidor de arquivos.

### 2. `divergencias.csv`

Chave pareada nos dois lados, com pelo menos um campo diferente após normalização.

| Coluna | Conteúdo |
|---|---|
| `chave_normalizada` | A chave depois das regras |
| `chave_original_a`, `chave_original_b` | Como está em cada arquivo |
| `linha_a`, `linha_b` | Número da linha física em cada arquivo |
| `campo` | Nome do campo comparado |
| `valor_a`, `valor_b` | Valor original de cada lado |
| `valor_a_norm`, `valor_b_norm` | Valor após a regra do campo |
| `regra_campo` | Perfil aplicado ao campo |
| `classe` | `certa` ou `suspeita` |
| `motivo_suspeita` | Vazio quando `certa`. Preenchido quando a normalização dependeu de decisão ambígua |

Uma linha por par chave e campo, não uma linha por chave. Ordenação: `suspeita` antes de
`certa`, depois por chave. O que é duvidoso é o que precisa de olho humano.

Unidade colada no valor (`12 kg` contra `12`) vira um campo próprio, `<campo> (unidade)`.
Descartar a unidade é como se perde a divergência entre `12 kg` e `12 g`.

### 3 e 4. `so-na-fonte-A.csv` e `so-na-fonte-B.csv`

| Coluna | Conteúdo |
|---|---|
| `chave_normalizada`, `chave_original`, `linha` | Identificação da linha na fonte |
| `causa_provavel` | Ver o vocabulário abaixo |
| `chave_parecida_do_outro_lado` | Preenchida quando existe candidata do outro lado |
| demais colunas | A linha inteira, como está na fonte |

Vocabulário de `causa_provavel`:

| Valor | Significado |
|---|---|
| `orfa` | Não existe do outro lado, e nenhuma candidata parecida foi encontrada |
| `possivel_erro_de_normalizacao` | Existe chave igual do outro lado depois de remover separadores, ou depois de remover zeros à esquerda. Sinal forte |
| `chave_parecida_por_uma_edicao` | Existe chave do outro lado a uma única edição de distância. Sinal fraco, pede olho humano |
| `duplicata_divergente` | A chave repete nesta fonte com conteúdo diferente, e por isso ficou fora do pareamento |
| `duplicata_divergente_no_outro_lado` | A chave existe aqui uma vez e repete divergente do outro lado |
| `chave_vazia` | Linha sem chave, que não é rodapé |
| `irrecuperavel` | Chave que perdeu dígitos na origem, tipicamente notação científica |
| `par_provavel_de_chave_irrecuperavel` | Do outro lado existe uma chave em notação científica cujos dígitos são prefixo desta. Não é item faltante, é a mesma chave com dígitos perdidos na origem |

**Esta coluna é o que evita a conclusão errada mais comum da conferência manual:** tratar
como item faltante o que é a mesma chave escrita de dois jeitos. Órfã com sósia do outro
lado é quase sempre falha de normalização, não item faltante.

O critério de uma edição roda apenas em chave que tem letra e pelo menos quatro
caracteres. Em chave puramente numérica, `141` e `101` estão a uma edição de distância sem
nenhuma relação entre os itens, e o sinal viraria ruído.

Cada CSV termina com uma linha iniciada por `#`, que é o rodapé do artefato e não um dado.

### 5. `linhas-descartadas.csv`

Escrita junto com a nota, antes de qualquer comparação, e por isso sai também na rodada
`--so-nota`. Uma linha por linha que saiu do pareamento, com `lado`, `linha`, `tipo`, `causa`
e `conteudo_da_linha`. Nenhuma linha sai do pareamento sem aparecer aqui, e o total dela
entra no fechamento: é o arquivo que impede o descarte silencioso. O rodapé sai por bloco:
a linha que carrega o marcador de total sai com a causa da linha de total, e a linha de
identificação abaixo dela, do tipo `Emitido em` ou `Página 1 de 1`, sai com a causa de bloco
de rodapé. Linha derrubada na leitura por contagem de coluna diferente do cabeçalho aparece
aqui com o conteúdo e faz a rodada sair com código 5, porque é dado que nunca foi comparado.

### 6. `diferencas-de-formato.csv`, opcional

Sai só com `--formato-em-arquivo`. Colunas: `chave_normalizada`, `linha_a`, `linha_b`,
`campo`, `valor_a`, `valor_b`, `valor_normalizado` e `regra_que_igualou`. Lista as
diferenças de formato que a lei de ferro 3 mantém fora de `divergencias.csv`. Serve para
auditar a normalização, e não entra nas contagens de fechamento.

### Rodapé de todo artefato

```
Gerado com apoio de IA a partir de <fonte>. Revisar antes de assinar. Não substitui
responsabilidade técnica.
```

---

## Modo de dado sensível

Ofereça os três níveis antes de pedir o arquivo. O padrão, quando a pessoa não decide, é o
nível 2.

**Nível 1, só o cabeçalho.** A pessoa cola apenas a linha de cabeçalho dos dois arquivos e,
se quiser, duas ou três linhas com os valores trocados por exemplos inventados que
preservem o formato (mesmo número de dígitos, mesma pontuação). Com isso dá para escolher a
chave, os perfis e os pares de campo, e devolver a linha de comando pronta. Nenhum valor
real é lido.

**Nível 2, script local (padrão).** A pessoa roda o script na máquina dela. O conteúdo nunca
chega ao modelo. Depois ela cola só a `nota-de-normalizacao.md`, que por construção não
contém valor de célula: só nome de arquivo, tamanho, data de modificação, nome de coluna,
nome de regra e contagem. Nome de arquivo em indústria costuma identificar o setor, o
fornecedor ou o projeto: se for o caso, renomeie os dois arquivos antes de rodar, ou apague
a seção 1 da nota antes de colar. O modelo confere as decisões e o fechamento e diz se a
rodada é válida. A opção `--amostras`, que colocaria
exemplos reais na nota, vem desligada e só é ligada por pedido explícito.

**Nível 3, nada sai.** O modelo entrega a linha de comando e a explicação de como ler os
cinco arquivos. A pessoa responde apenas "fechou" ou "não fechou" e, se não fechou, qual
identidade quebrou.

Regra que não se quebra: quando o dado é sensível, filtragem e leitura são locais. Nunca
peça o `divergencias.csv` colado para resumir.

---

## Falha honesta

Nos casos abaixo a skill declara o limite e para.

**Arquivo .xlsx binário.** O script é biblioteca padrão e não lê xlsx. A instrução é
converter para CSV, e a conversão é o próprio perigo: salvar como CSV com a coluna de código
formatada como número apaga zero à esquerda e converte código longo em notação científica,
de forma irreversível. Antes de salvar, formate a coluna-chave como Texto. Ao reimportar,
use a importação por colunas e marque a chave como Texto. Depois de converter, abra o CSV
num editor de texto e confirme que os zeros à esquerda continuam lá. O script detecta o
estrago e reporta como irrecuperável, e não desfaz.

**PDF escaneado ou foto de folha preenchida à mão.** Não é conferência, é extração.
Extração sem medição contra gabarito não serve de base para uma conferência cujo propósito
é achar divergência: qualquer erro de leitura vira divergência falsa. A skill que faz essa
extração medida está neste kit: `extracao-de-documento-para-tabela`. Ela devolve o CSV com
valor, confiança e origem por campo, e só libera o uso real depois que a taxa de acerto foi
medida contra gabarito. Encadeie as duas: extraia primeiro, traga o `tabela.csv` para cá
depois, e declare na nota que o lado A veio de extração, com a taxa medida. Não havendo o
documento em formato que a extração aceite, obtenha o mesmo dado já digital no sistema. Não
havendo nenhum dos dois, diga o que faltaria e pare.

**Célula mesclada.** Em CSV a mesclagem vira valor na primeira célula e vazio nas seguintes.
O script detecta o padrão e alerta sem preencher, porque preenchimento para baixo inventa
dado. Ele só preenche com `--preencher-para-baixo COLUNA`, ligado pela pessoa, e o fato
entra na nota com a contagem de células preenchidas. Enquanto não for preenchida, toda
divergência dessa coluna em que um dos lados está vazio sai com classe `suspeita` e o motivo
escrito: célula vazia ali pode ser mesclagem, não ausência. Com as duas células preenchidas e
diferentes, a divergência continua `certa`.

**Granularidade diferente entre as fontes.** Descrito no passo 3. Para.

**Sem chave compartilhada.** Para e diz. O script sai com código 3 e lista a medição coluna
por coluna em vez de escolher uma em silêncio. Quando duas candidatas empatam, ele também
para e pede `--chave-a` e `--chave-b`.

**Nenhum par de campo.** Se só a chave casa entre as duas fontes, o script sai com código 3
e lista as colunas dos dois lados: sair com 0 ali seria dizer que as fontes batem sem ter
comparado nada. Nome de coluna igual nos dois arquivos é exceção, não regra, e os pares vão
em `--campos`.

---

## Referência

A pasta da skill fica em `~/.claude/skills/conferencia-entre-duas-fontes/` depois de
instalada. Os arquivos de referência são lidos por esse caminho, e os scripts são chamados
pelo caminho completo.

| Arquivo | Cobre |
|---|---|
| `~/.claude/skills/conferencia-entre-duas-fontes/references/normalizacao.md` | Catálogo das armadilhas de chave e de valor em planilha brasileira, em quatro grupos, cada item com manifestação, detecção, correção e o risco de corrigir errado. Leia antes de decidir regra por regra. |
| `~/.claude/skills/conferencia-entre-duas-fontes/scripts/conferir.py` | Implementação da conferência em Python de biblioteca padrão. Leia o cabeçalho do arquivo e `--help` para a lista completa de opções. |
| `~/.claude/skills/conferencia-entre-duas-fontes/scripts/testar.py` | Teste de regressão do `conferir.py`, biblioteca padrão apenas. Gera os casos em diretório temporário, roda o script em cada um e compara a saída com o esperado. Um caso por defeito conhecido: item real com marcador de total na chave, nenhuma coluna coincidindo, linha de células vazias no fim do arquivo, rodapé registrado, chave detectada com rodapé ainda no arquivo, célula mesclada, notação científica, `--so-nota`, `--estrito`, zero chave pareada, e os casos de normalização. Mais seis casos contra o mesmo defeito em lugares diferentes, sair com código 0 depois de não comparar: rodapé de ERP com linha de identificação abaixo do total, uma única coluna emparelhando por acaso, coluna excluída por `--campos` sem aparecer na lista, a referência de normalização prescrevendo a detecção que o script rejeita, linha com conteúdo perdida na leitura, e chave que existe só de um lado ou repete com conteúdo diferente. Rode `python3 ~/.claude/skills/conferencia-entre-duas-fontes/scripts/testar.py` depois de qualquer mudança no script, ou `py -3 "$env:USERPROFILE\.claude\skills\conferencia-entre-duas-fontes\scripts\testar.py"` no PowerShell: sai com código 1 se um caso falhar. |

---

Kit Conferido. Autoria: Willy Azevedo, Artemis, Florianópolis, SC.
Uso, cópia e adaptação permitidos; ver `LICENSE.md` na pasta do kit.
Nenhuma skill deste kit substitui responsabilidade técnica nem decisão de auditoria.
