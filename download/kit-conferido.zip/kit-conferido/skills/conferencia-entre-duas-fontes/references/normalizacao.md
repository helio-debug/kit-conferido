# Armadilhas de normalização em planilha brasileira

Cada item traz como se manifesta, como se detecta, como se corrige, e o risco de corrigir
errado. O risco é a parte que costuma faltar, e é a que estraga a conferência.

Princípio geral: **a normalização é decidida por coluna, olhando a coluna inteira, nunca
célula a célula.** Decisão tomada célula a célula produz uma coluna com duas regras
diferentes dentro dela, e ninguém descobre.

Ordem de trabalho: primeiro o grupo 3 (o arquivo é uma tabela?), depois o grupo 1 (o valor
sobreviveu?), depois o grupo 2 (está escrito de outro jeito?), por último o grupo 4 (a chave
se comporta?).

---

## Grupo 1: o valor foi destruído na origem

### 1.1 Zero à esquerda perdido ao salvar como número

*Manifesta:* código `00123` vira `123`. Uma fonte tem `00123`, a outra tem `123`, e as duas
se referem ao mesmo item.

*Detecta:* na mesma coluna, comprimentos diferentes com o mesmo sufixo. Se uma fonte tem
largura fixa (todas as chaves com 6 dígitos) e a outra tem largura variável, a segunda
perdeu zeros.

*Corrige:* completar com zeros à esquerda até a largura da fonte que preservou, quando essa
largura é constante. A largura é declarada na nota.

*Risco:* se a largura não for constante na fonte de referência, completar com zeros cria
pareamento falso entre itens distintos. Quando a largura varia nos dois lados, pareie pelo
valor sem zeros à esquerda dos dois lados e declare que a comparação perdeu a distinção
entre `0123` e `123`. Se os dois existirem de fato na mesma fonte, pare: a chave não serve.

### 1.2 Notação científica em código longo

*Manifesta:* código de 13 a 18 dígitos (código de barras, chave de documento fiscal, número
de série) exibido como `1,23457E+14`.

*Detecta:* expressão regular de mantissa com expoente na coluna-chave.

*Corrige:* **na maioria dos casos não corrige.** A planilha guarda 15 dígitos
significativos, e a exibição com 6 dígitos de mantissa indica que a representação textual
perdeu o resto. Se a célula subjacente ainda tiver o número completo, reexportar com a
coluna formatada como Texto recupera. Se o CSV já veio com a mantissa curta, o dado acabou.

*Risco:* expandir `1,23457E+14` para `123457000000000` fabrica dado. A linha é marcada como
`irrecuperavel`, sai do pareamento e é listada na nota. Linha irrecuperável tratada como
órfã é conclusão errada com aparência de resultado.

*Regra implementada:* expande somente quando a mantissa tem dígitos significativos
suficientes para o expoente, o que garante que nada foi perdido. Fora disso, marca.

### 1.3 Encoding trocado

*Manifesta:* `Ã§` no lugar de `ç`, `Ã£` no lugar de `ã`, `AÃ‡O` no lugar de `AÇO`. Ou o
inverso: caractere de substituição, losango com interrogação, falha de decodificação.

*Detecta:* tentar decodificar em `utf-8-sig`, depois `utf-8`, depois `cp1252`, depois
`latin-1`, parando na primeira que decodifica sem erro. Complemento obrigatório: mesmo
decodificando sem erro, procurar as sequências típicas de mojibake (`Ã¡ Ã© Ã­ Ã³ Ãº Ã£ Ãµ
Ã§ Ã‡ Â°`). A presença delas indica arquivo UTF-8 que já foi aberto como cp1252 e salvo de
novo, e que precisa ser recodificado, não apenas decodificado.

*Corrige:* recodificar (`texto.encode('cp1252').decode('utf-8')`) quando o padrão aparece e
a operação não levanta erro.

*Risco:* aplicar a recodificação num arquivo que não é mojibake corrompe acentos corretos.
Use apenas sequências de dois caracteres na detecção: `Ã` sozinho aparece em palavra
legítima em português em caixa alta (`VEDAÇÃO`) e faz a heurística disparar a esmo. Registre
quantas ocorrências foram encontradas.

### 1.4 Marca de ordem de byte no início do arquivo

*Manifesta:* a primeira coluna do cabeçalho vira um nome com caractere invisível na frente e
nunca casa com a coluna equivalente da outra fonte. O sintoma é sempre o mesmo: só a
primeira coluna não é encontrada.

*Detecta:* primeiro caractere do arquivo invisível, ou nome da primeira coluna começando com
caractere invisível.

*Corrige:* ler com `utf-8-sig`.

*Risco:* nenhum. Esta é barata e fica sempre ligada.

### 1.5 A conversão de .xlsx para CSV, que é onde 1.1 e 1.2 acontecem

*Manifesta:* o arquivo chega em .xlsx e a comparação lê CSV. A conversão é o próprio
perigo: salvar como CSV com a coluna de código formatada como número apaga o zero à
esquerda e converte código longo em notação científica, de forma irreversível.

*Detecta:* depois de converter, abra o CSV num editor de texto, não na planilha, e confirme
que os zeros à esquerda continuam lá e que nenhum código virou mantissa com expoente.

*Corrige:* antes de salvar, formate a coluna-chave como Texto. Ao reimportar, use a
importação por colunas e marque a chave como Texto. Converta as duas fontes pelo mesmo
caminho, senão cada lado perde uma coisa diferente.

*Risco:* converter primeiro e conferir depois. O script detecta o estrago e reporta como
irrecuperável, e não desfaz: o que se perdeu na conversão só volta reexportando da origem.

---

## Grupo 2: o valor está inteiro, mas escrito de outro jeito

### 2.1 Vírgula contra ponto decimal

*Manifesta:* `1234,56` em uma fonte, `1234.56` na outra.

*Detecta:* na coluna numérica, presença de vírgula em uma fonte e ponto na outra.

*Corrige:* converter para um formato interno único, decidido pela coluna inteira.

*Risco:* está no item seguinte, que é o mesmo problema visto de outro ângulo.

### 2.2 Separador de milhar

*Manifesta:* `1.234` pode ser mil duzentos e trinta e quatro (ponto de milhar) ou um inteiro
e duzentos e trinta e quatro milésimos (ponto decimal). `1.234,56` é inequívoco, `1.234`
não é.

*Detecta:* varra a coluna inteira, nesta ordem de decisão:

1. Se alguma célula tem os dois sinais, o decimal é o sinal mais à direita e o outro é
   milhar. Vale para a coluna inteira.
2. Se algum sinal aparece repetido na mesma célula (`1.234.567`), aquele sinal é milhar.
3. Se só um sinal aparece e toda ocorrência tem exatamente três dígitos depois, a coluna é
   **ambígua**: a decisão é declarada, a coluna é marcada como suspeita, e toda divergência
   dela sai com o motivo preenchido.
4. Caso contrário, o sinal presente é o decimal.

*Corrige:* aplicar a regra da coluna, nunca da célula.

*Risco:* decidir célula a célula produz uma coluna em que `1.234` virou 1234 numa linha e
1,234 na outra. Erro de fator mil que passa despercebido porque o número continua plausível.

### 2.3 Negativo em formato contábil

*Manifesta:* `(1.234,56)` ou `1.234,56-` no lugar de `-1234,56`.

*Detecta:* valor numérico entre parênteses, ou com sinal à direita.

*Corrige:* converter para sinal à esquerda.

*Risco:* parênteses em campo de texto não são negativo. Aplique só em coluna já classificada
como numérica.

### 2.4 Unidade dentro da célula

*Manifesta:* `12 kg`, `12kg`, `12,0 KG` contra `12`.

*Detecta:* na coluna numérica, sufixo alfabético recorrente.

*Corrige:* separar valor e unidade, comparar o valor, e **comparar a unidade como campo
próprio**.

*Risco:* descartar a unidade em silêncio. É assim que se perde a divergência entre `12 kg` e
`12 g`. Nunca faça.

### 2.5 Percentual como fração

*Manifesta:* `0,15` de um lado e `15%` ou `15` do outro.

*Detecta:* uma coluna com todos os valores entre 0 e 1, a outra com os mesmos dados entre 0
e 100.

*Corrige:* declarar a escala de cada lado e converter. A conversão entra na nota com
destaque.

*Risco:* confundir uma coluna que legitimamente tem valores pequenos com uma coluna em
fração. Confirme com a pessoa antes de aplicar fator 100.

### 2.6 Formato de data

*Manifesta:* três formas na mesma realidade. `03/04/2026` (dia primeiro, padrão brasileiro),
`2026-04-03` (ISO, às vezes com hora ou fuso colado), e o serial da planilha (`46115`, um
inteiro contando dias a partir de 30/12/1899, com o defeito histórico de considerar 1900
bissexto, o que desloca datas anteriores a março de 1900).

*Detecta:*

- Serial: coluna de data cujos valores são inteiros numa faixa plausível (aproximadamente
  25000 a 60000 para datas entre 1968 e 2064). Exija também que o nome da coluna indique
  data, senão uma coluna de quantidade com valores nessa faixa vira data.
- ISO: padrão de quatro dígitos, hífen, dois, hífen, dois.
- Ambiguidade dia e mês: varra a coluna. Se existe alguma célula com o primeiro componente
  maior que 12, a coluna é dia primeiro. Se existe alguma com o segundo componente maior que
  12, é mês primeiro. Se não existe nenhuma das duas, a coluna é indecidível.

*Corrige:* converter tudo para ISO internamente. A decisão dia e mês é da coluna inteira.

*Risco:* coluna indecidível tratada como se fosse decidível. Nesse caso marque a coluna como
suspeita, converta assumindo o padrão brasileiro, declare a suposição na nota e reporte cada
divergência da coluna com o motivo. Um lote pequeno de datas no começo do mês cai exatamente
nesse buraco. Se as duas componentes forem maiores que 12 em células diferentes da mesma
coluna, há conflito real e a coluna mistura dois formatos.

### 2.7 Espaço nas pontas, espaço duplo e espaço invisível

*Manifesta:* `"ABC-123 "` não casa com `"ABC-123"`. Espaço duplo no meio da descrição.
Espaço não separável, que vem de dado colado de página web ou de sistema e é invisível em
qualquer visualização. Espaço de largura zero, idem.

*Detecta:* comparar o comprimento antes e depois de aparar as pontas. Procurar os
caracteres de espaço não separável, espaço de largura zero e marca de ordem de byte no meio
do texto. Procurar dois ou mais espaços consecutivos.

*Corrige:* trocar os espaços exóticos por espaço comum, aparar as pontas, colapsar espaços
internos em um só.

*Risco:* baixo na chave. Em campo de descrição, colapsar espaço interno pode esconder
diferença real de formatação que a área usa como sinal. Ligue na chave por padrão, e no
valor só quando declarado. Quem apara as pontas antes da contagem de regras esconde a
própria regra da nota: apare dentro da regra, para que a contagem apareça.

### 2.8 Acento e caixa

*Manifesta:* `AÇO INOX`, `Aço Inox`, `ACO INOX`, `aço inox`.

*Detecta:* o pareamento falha, mas casa depois de remover acento e baixar a caixa.

*Corrige:* decomposição canônica com descarte dos caracteres combinantes, mais redução de
caixa. Ligado por padrão na chave, desligado por padrão no valor.

*Risco:* em código, remover acento é seguro. Em texto livre, comparar sem acento e sem caixa
esconde divergência de cadastro que a área quer ver: a mesma peça cadastrada de duas formas
é, ela mesma, um achado. Por isso o padrão desligado no valor, e o operador liga se quiser.

### 2.9 Hífen, barra, ponto e espaço dentro do código

*Manifesta:* `ABC-123/01`, `ABC 123 01`, `ABC.123.01`, `ABC12301`.

*Detecta:* o pareamento falha, mas casa depois de remover os não alfanuméricos.

*Corrige:* perfil de código: remover tudo que não é letra ou dígito.

*Risco:* **o mais grave da lista.** Se `AB-C123` e `ABC-123` existem como itens distintos no
cadastro, remover separadores funde os dois. Antes de aplicar, conte quantas chaves distintas
existem antes e depois da remoção em cada fonte. Se o número cair, a regra está fundindo
itens: não aplique, e registre. Essa contagem é obrigatória e entra na nota.

### 2.10 Sufixo de revisão ou situação colado no código

*Manifesta:* `ABC-123` contra `ABC-123 REV B`, `ABC-123 (OBSOLETO)`, `ABC-123*`.

*Detecta:* uma fonte tem chaves que começam com a chave inteira da outra fonte, mais um
sufixo recorrente.

*Corrige:* pergunte se a revisão faz parte da identidade do item. Se não fizer, extraia o
sufixo para um campo próprio e compare também esse campo.

*Risco:* cortar o sufixo funde revisões diferentes do mesmo desenho, que é exatamente a
divergência que a conferência deveria encontrar.

### 2.11 Vazio, zero e marcador de ausência

*Manifesta:* célula vazia, `0`, `-`, `N/A`, `n/d`, `NULL`, `#N/D`, `.`, todos querendo dizer
"não tem".

*Detecta:* inventário dos valores distintos de baixa frequência na coluna.

*Corrige:* declarar a lista de marcadores tratados como ausente e normalizar todos para
vazio. **Zero fica de fora dessa lista por padrão**, porque zero é um valor. Quando um lado
traz marcador e o outro traz célula vazia, isso é diferença de formato: entra na contagem da
nota, fica fora de `divergencias.csv` e só aparece linha a linha em
`diferencas-de-formato.csv`, com `--formato-em-arquivo`.

*Risco:* tratar `0` como ausente apaga divergência real entre saldo zero e saldo não
informado. Só inclua zero na lista por pedido explícito, e registre.

---

## Grupo 3: o arquivo não é uma tabela

Este grupo trata de arquivo digital que já é tabela, ou quase. Folha preenchida à mão, foto
de folha e PDF escaneado não entram aqui: o dado precisa virar CSV antes, e é esse CSV que
volta para este catálogo. A skill que faz essa conversão medida, extracao-de-documento-para-tabela,
devolve o CSV com a coluna de confiança e a origem por campo, está neste kit, e a rodada
liberada só sai depois de medida contra gabarito. Encadeie as duas: extraia primeiro, traga
o `tabela.csv` para cá depois, e declare na nota que o lado veio de extração, com a taxa
medida.

### 3.1 Cabeçalho que não está na linha 1

*Manifesta:* as três ou quatro primeiras linhas trazem título do relatório, nome da empresa,
período, filtros aplicados, e uma linha em branco. O cabeçalho verdadeiro está na linha 5.

*Detecta:* varra as primeiras 20 linhas e escolha como cabeçalho a primeira linha que
satisfaça as três condições: maior número de células não vazias, nenhuma célula puramente
numérica, e as três linhas seguintes com a mesma quantidade de colunas.

*Corrige:* descartar tudo acima, registrando quantas linhas foram descartadas. O conteúdo da
primeira delas costuma dizer qual filtro o export usou, e isso é informação útil.

*Risco:* heurística acertando a linha errada em silêncio. Por isso o número da linha
escolhida vai na nota, e existe o modo `--so-nota`, que escreve só a nota para a pessoa
conferir antes. A rodada de comparação seguinte grava no mesmo diretório de saída e por isso
precisa de `--forcar`.

### 3.2 Linha de total no rodapé

*Manifesta:* a última linha tem a chave vazia e a coluna de quantidade somada. Às vezes com
`TOTAL`, `TOTAL GERAL`, `Soma`.

*Detecta:* últimas linhas que satisfaçam duas condições ao mesmo tempo: alguma célula igual a
`total`, `totais`, `total geral`, `soma` ou `subtotal` depois de tirar acento, caixa e
pontuação, e poucas células preenchidas na linha. Célula que apenas contém a palavra não
serve, porque `GERAL-500` e `TOTAL-7` são códigos de item real. Quando a chave está apenas
vazia, exija a mesma confirmação de poucas células preenchidas.

*Corrige:* descartar e registrar. **Guarde o total como verificação:** se a soma da coluna
nas linhas mantidas não bater com o total do rodapé, o arquivo tem linha perdida antes mesmo
da conferência começar, e isso é um achado que vai para a nota.

Rodapé de ERP tem linha abaixo do total, do tipo `Emitido em 30/04/2026 por PCP` ou
`Página 1 de 1`. Trate o bloco final de linhas com poucas células preenchidas como uma
unidade: sai inteiro se alguma delas carrega o marcador, fica inteiro se nenhuma carrega.
Decidindo linha a linha, a linha de identificação abaixo do total não é marcador nem chave
vazia, interrompe a varredura e protege o rodapé inteiro: a linha de total entra como item e
o total nunca é conferido.

*Risco:* descartar um item real cujo código contém "total". Confirme pela combinação de
critérios, nunca pelo texto sozinho.

### 3.3 Célula mesclada

*Manifesta:* em CSV a mesclagem vertical vira valor na primeira linha do bloco e vazio nas
demais. Típico de coluna de setor, de pedido ou de documento que agrupa várias linhas de item.

*Detecta:* sequências de vazios numa coluna, sempre precedidas de um valor, num padrão
regular. Sinal adicional: a coluna tem taxa alta de vazio e nenhuma outra coluna tem.

*Corrige:* **não corrige por conta própria.** Alerta, e preenche para baixo apenas com a
opção ligada pela pessoa, registrando na nota quantas células foram preenchidas.

*Risco:* preenchimento para baixo é invenção de dado quando o vazio significa ausência real
e não mesclagem. E se o arquivo foi ordenado depois da mesclagem, os blocos se misturaram e
o preenchimento distribui o valor errado. Sem preencher, cada linha vazia vira divergência
falsa contra a fonte que tem a coluna completa: as duas saídas são ruins, e por isso a
escolha é da pessoa, declarada.

### 3.4 Quebra de linha dentro da célula

*Manifesta:* uma descrição com quebra de linha faz o leitor de CSV ingênuo enxergar duas
linhas, e o arquivo passa a ter mais linhas que registros.

*Detecta:* o leitor de CSV da biblioteca padrão trata corretamente quando o campo está entre
aspas. O sintoma de problema é linha com número de colunas menor que o cabeçalho.

*Corrige:* usar o leitor de CSV da biblioteca padrão, nunca dividir o texto por quebra de
linha na mão. Nas linhas com contagem de colunas errada, registrar e descartar, listando os
números.

*Risco:* descarte silencioso. As linhas descartadas entram na contagem de fechamento e saem
uma a uma em `linhas-descartadas.csv`, com o lado, o número da linha, a causa e o conteúdo. E
o fechamento conta registros lidos, não linhas do arquivo, senão a identidade quebra sem que
nada esteja errado.

### 3.5 Delimitador

*Manifesta:* CSV brasileiro gerado por planilha usa ponto e vírgula, porque a vírgula é
separador decimal. Export de sistema costuma usar vírgula. Alguns usam tabulação ou barra
vertical.

*Detecta:* contar candidatos (`;`, `,`, tabulação, `|`) nas primeiras linhas não vazias e
escolher o que produz a mesma quantidade de colunas, maior que 1, na maior parte delas.

*Corrige:* aplicar por arquivo. Os dois arquivos podem ter delimitadores diferentes, e isso
é o normal, não a exceção.

*Risco:* escolher vírgula num arquivo de ponto e vírgula que contém vírgula decimal produz
um arquivo de uma coluna só, ou colunas trocadas. O número de colunas detectado vai na nota.

### 3.6 Coluna com nome repetido

*Manifesta:* duas colunas `Quantidade` no mesmo cabeçalho, ou `Qtde` e `QTDE`.

*Detecta:* nomes de cabeçalho repetidos após normalização de texto.

*Corrige:* sufixar por posição (`Quantidade__2`) e pedir que a pessoa escolha qual comparar.

*Risco:* pegar a primeira e comparar a coluna errada durante meses.

---

## Grupo 4: a chave não se comporta

### 4.1 Duplicata na chave

*Manifesta:* a mesma chave em mais de uma linha da mesma fonte.

*Detecta:* contagem por chave depois da normalização. Faça essa contagem **antes e depois**
de cada regra de chave: uma regra que cria duplicata estava fundindo itens distintos (ver
2.9).

*Corrige:* três saídas possíveis, e a escolha é da pessoa. (a) As duplicatas são linhas
repetidas idênticas: colapsa, registrando. (b) São linhas diferentes com a mesma chave: a
chave está incompleta e precisa de uma segunda coluna. (c) A granularidade das duas fontes é
diferente: a conferência para.

*Risco:* pegar a primeira ocorrência e seguir. Produz divergência falsa e esconde divergência
real ao mesmo tempo. Enquanto a pessoa não decide, a chave fica fora do pareamento e é
reportada como duplicata divergente, nunca pareada no chute.

### 4.2 Chave órfã dos dois lados

*Manifesta:* chave que existe só em A, e chave que existe só em B.

*Detecta:* diferença de conjuntos nos dois sentidos. A conferência que olha só um sentido
perde metade do problema, e é o erro mais comum da conferência manual.

*Corrige:* dois arquivos separados de saída, nunca um arquivo só de "não bateu".

*Risco:* concluir "faltam 12 itens no sistema" quando na verdade são 12 chaves normalizadas
de forma diferente. O antídoto é a coluna `causa_provavel`, que procura uma chave parecida do
outro lado por três critérios, em ordem de força:

1. Igual depois de remover separadores. Sinal forte.
2. Igual depois de remover zeros à esquerda. Sinal forte.
3. Uma única edição de distância. Sinal fraco, e **aplicável apenas em chave que tem letra e
   pelo menos quatro caracteres.** Em chave puramente numérica e densa, `141` e `101` estão a
   uma edição de distância sem nenhuma relação entre os itens, e o critério viraria ruído que
   destrói a confiança na coluna.

### 4.3 Chave vazia

*Manifesta:* linhas sem chave, que não são rodapé.

*Corrige:* nunca parear. Vão para o arquivo da fonte correspondente com
`causa_provavel: chave_vazia` e entram no fechamento.

*Risco:* somar essas linhas às órfãs infla o número de itens faltantes e leva a uma
conclusão errada sobre o cadastro.
