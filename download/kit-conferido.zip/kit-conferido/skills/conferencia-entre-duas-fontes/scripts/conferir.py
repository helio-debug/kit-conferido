#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
conferir.py, conferencia entre duas fontes de dado da mesma realidade.

Le dois arquivos CSV, aplica normalizacao declarada, e escreve cinco arquivos no
diretorio de --saida. Dois saem antes de qualquer comparacao, e por isso saem
tambem na rodada --so-nota: nota-de-normalizacao.md e linhas-descartadas.csv. Tres
saem na rodada de comparacao: divergencias.csv, so-na-fonte-A.csv e
so-na-fonte-B.csv. Um sexto, diferencas-de-formato.csv, sai apenas com
--formato-em-arquivo.

Depois da instalacao o script fica em
~/.claude/skills/conferencia-entre-duas-fontes/scripts/conferir.py, e a rodada
acontece na pasta dos arquivos de trabalho. Chame o script pelo caminho completo:
caminho relativo como scripts/conferir.py so funciona dentro da pasta da skill.

DEPENDENCIA DECLARADA: biblioteca padrao do Python 3.8 ou superior, e nada mais.
Modulos usados: argparse, csv, datetime, decimal, re, sys, unicodedata, pathlib.
Nao instala pacote, nao acessa rede, nao le xlsx, nao le PDF, nao escreve nos
arquivos de entrada (abre tudo em modo leitura).

O conteudo das celulas nunca vai para a saida padrao. O terminal recebe apenas o
bloco de fechamento e o caminho do diretorio gerado, para que a tela possa ser
copiada sem vazar dado.

Codigos de saida: 0 as duas fontes tem as mesmas chaves e nenhum valor diverge,
1 ha divergencia de valor, 2 ambiguidade nao resolvida em modo --estrito, 3 erro
de entrada, fechamento que nao fecha, nenhum par de campo, coluna sem par no
emparelhamento automatico ou nenhuma chave pareada, 4 rodada em --so-nota, que
nao compara nada, 5 a comparacao aconteceu, nenhum valor divergiu, e sobrou dado
fora da comparacao de valor.

Nenhuma linha sai do pareamento sem aparecer em linhas-descartadas.csv, e a
rodada nao termina em sucesso quando nao comparou nada.
"""

import argparse
import csv
import re
import sys
import unicodedata
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

VERSAO = "1.0"

# ---------------------------------------------------------------------------
# 1. Constantes
# ---------------------------------------------------------------------------

ENCODINGS_TENTADOS = ("utf-8-sig", "utf-8", "cp1252", "latin-1")

# Apenas sequencias de dois caracteres. "A" com tilde sozinho aparece em palavra
# legitima em portugues (VEDACAO em caixa alta) e faria a heuristica disparar a esmo.
SEQUENCIAS_MOJIBAKE = (
    "Ã¡", "Ã ", "Ã¢", "Ã£", "Ã©", "Ãª", "Ã­", "Ã³", "Ãµ", "Ã´", "Ãº", "Ã§",
    "Ã‡", "Ã‰", "Ã“", "Ãš", "Â°", "Âº", "Âª", "Â ",
)

ESPACOS_EXOTICOS = {
    " ": " ", " ": " ", " ": " ", " ": " ", " ": " ",
    " ": " ", "\t": " ",
}
INVISIVEIS = ("​", "‌", "‍", "﻿")

AUSENTES_PADRAO = "N/A,n/d,-,NULL,#N/D,#N/A,.,--,nao informado,não informado"

# Casam por igualdade com o nucleo da celula, nunca por substring: item real de
# codigo GERAL-500 ou TOTALIZADOR-3 nao pode ser lido como rodape. "geral" solto
# saiu da lista, "totalgeral" cobre o rodape escrito TOTAL GERAL.
MARCADORES_RODAPE = ("total", "totais", "totalgeral", "geraltotal", "soma", "subtotal")

DELIMITADORES_CANDIDATOS = (";", ",", "\t", "|")

RE_CIENTIFICA = re.compile(r"^[+-]?\d(?:[.,]\d+)?[eE][+-]?\d{1,3}$")
RE_ISO = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T ]\d.*)?$")
RE_DMY = re.compile(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})(?:[T ]\d.*)?$")
RE_SERIAL = re.compile(r"^\d{5}$")
RE_SO_NUMERO = re.compile(r"^[+-]?[\d][\d.,\s]*$")
RE_UNIDADE = re.compile(
    r"^\s*([+-]?\(?[\d][\d.,\s]*\)?-?)\s*([A-Za-zÀ-ÿ%º°/]"
    r"[A-Za-zÀ-ÿ%º°/0-9\.]*)\s*$"
)

RODAPE_ARTEFATO = (
    "Gerado com apoio de IA a partir de {fontes}. "
    "Revisar antes de assinar. Nao substitui responsabilidade tecnica."
)

# Rotulos de regra por perfil, para que regra de toque zero apareca na nota.
REGRAS_POR_PERFIL = {
    "codigo": ("espaco_exotico", "caractere_invisivel", "pontas", "espaco_interno",
               "acento", "caixa", "separadores", "zeros_removidos", "zeros_completados",
               "marcador_de_ausencia"),
    "texto": ("espaco_exotico", "caractere_invisivel", "pontas", "espaco_interno",
              "acento", "caixa", "marcador_de_ausencia"),
    "categoria": ("espaco_exotico", "caractere_invisivel", "pontas", "espaco_interno",
                  "acento", "caixa", "marcador_de_ausencia"),
    "numero": ("unidade_separada", "contabil", "milhar_removido", "decimal_convertido",
               "nao_numerico", "marcador_de_ausencia"),
    "data": ("iso", "dmy", "mdy", "serial", "hora_descartada", "data_invalida",
             "nao_data", "marcador_de_ausencia"),
}

# ---------------------------------------------------------------------------
# 2. Utilidades de texto
# ---------------------------------------------------------------------------


def sem_acento(texto):
    return "".join(
        c for c in unicodedata.normalize("NFKD", texto) if not unicodedata.combining(c)
    )


def chave_simples(texto):
    """Reduz um nome de coluna ou marcador ao nucleo comparavel."""
    return re.sub(r"[^a-z0-9]+", "", sem_acento(texto or "").casefold())


def norm_texto(valor, acento=False, caixa=False, colapsar=True):
    regras = set()
    v = valor if valor is not None else ""
    for ch, sub in ESPACOS_EXOTICOS.items():
        if ch in v:
            v = v.replace(ch, sub)
            regras.add("espaco_exotico")
    for ch in INVISIVEIS:
        if ch in v:
            v = v.replace(ch, "")
            regras.add("caractere_invisivel")
    if v != v.strip():
        regras.add("pontas")
    v = v.strip()
    if colapsar:
        v2 = re.sub(r"\s+", " ", v)
        if v2 != v:
            regras.add("espaco_interno")
        v = v2
    if acento:
        v2 = sem_acento(v)
        if v2 != v:
            regras.add("acento")
        v = v2
    if caixa:
        v2 = v.casefold()
        if v2 != v:
            regras.add("caixa")
        v = v2
    return v, regras


def norm_codigo(valor, zeros="preservar", largura=None, separadores=True):
    v, regras = norm_texto(valor, acento=True, caixa=True, colapsar=True)
    if separadores:
        v2 = re.sub(r"[^0-9a-z]+", "", v)
        if v2 != v:
            regras.add("separadores")
        v = v2
    if zeros == "remover" and v:
        v2 = v.lstrip("0") or "0"
        if v2 != v:
            regras.add("zeros_removidos")
        v = v2
    elif zeros == "completar" and v and largura and v.isdigit() and len(v) < largura:
        v = v.zfill(largura)
        regras.add("zeros_completados")
    return v, regras


def remover_zeros(valor):
    return valor.lstrip("0") or "0" if valor else valor


def so_alfanumerico(valor):
    return re.sub(r"[^0-9a-z]+", "", sem_acento(valor or "").casefold())


def distancia_um(a, b):
    """Verdadeiro quando a e b estao a uma unica edicao de distancia."""
    if a == b or abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        diferencas = 0
        for x, y in zip(a, b):
            if x != y:
                diferencas += 1
                if diferencas > 1:
                    return False
        return diferencas == 1
    curto, longo = (a, b) if len(a) < len(b) else (b, a)
    i = j = pulos = 0
    while i < len(curto) and j < len(longo):
        if curto[i] == longo[j]:
            i += 1
            j += 1
        else:
            pulos += 1
            if pulos > 1:
                return False
            j += 1
    return True


def separar_unidade(valor):
    m = RE_UNIDADE.match(valor or "")
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return (valor or "").strip(), ""


def tratar_contabil(valor):
    v = (valor or "").strip()
    negativo = False
    if v.startswith("(") and v.endswith(")"):
        v = v[1:-1].strip()
        negativo = True
    elif v.endswith("-"):
        v = v[:-1].strip()
        negativo = True
    return v, negativo


def fmt_num(d):
    if d is None:
        return ""
    s = format(d, "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s.replace(".", ",")


def detectar_notacao_cientifica(valor):
    return bool(RE_CIENTIFICA.match((valor or "").strip()))


def expandir_ou_marcar(valor):
    """Expande notacao cientifica apenas quando nada foi perdido na origem."""
    bruto = (valor or "").strip()
    if not detectar_notacao_cientifica(bruto):
        # Devolve o valor como estava. Aparar as pontas aqui esconderia a regra
        # "pontas" da contagem da nota, e regra que age sem aparecer na nota e
        # exatamente o que esta skill existe para evitar.
        return (valor or ""), "ok"
    texto = bruto.replace(",", ".")
    mantissa, _, expoente = texto.lower().partition("e")
    try:
        exp = int(expoente)
    except ValueError:
        return bruto, "irrecuperavel"
    digitos = len(mantissa.replace("-", "").replace("+", "").replace(".", ""))
    if exp > 0 and digitos >= exp + 1:
        try:
            return format(Decimal(texto), "f"), "ok"
        except InvalidOperation:
            return bruto, "irrecuperavel"
    return bruto, "irrecuperavel"

# ---------------------------------------------------------------------------
# 3. Leitura
# ---------------------------------------------------------------------------


class ErroDeEntrada(Exception):
    pass


def detectar_encoding(dados, forcado=None):
    if forcado and forcado != "auto":
        try:
            return forcado, dados.decode(forcado), "encoding informado na linha de comando"
        except (UnicodeDecodeError, LookupError) as exc:
            raise ErroDeEntrada("encoding %s nao decodifica o arquivo: %s" % (forcado, exc))
    escolhido = None
    texto = None
    for enc in ENCODINGS_TENTADOS:
        try:
            texto = dados.decode(enc)
        except UnicodeDecodeError:
            continue
        escolhido = enc
        break
    if escolhido is None:
        raise ErroDeEntrada("nenhum dos encodings tentados decodifica o arquivo")
    tem_bom = dados[:3] == b"\xef\xbb\xbf"
    ocorrencias = sum(texto.count(seq) for seq in SEQUENCIAS_MOJIBAKE)
    if ocorrencias:
        try:
            recodificado = texto.encode("cp1252").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            recodificado = None
        if recodificado is not None:
            evid = ("padrao de mojibake em %d ocorrencias. O arquivo e UTF-8 que foi "
                    "aberto como cp1252 e salvo de novo. Decodificado como %s e "
                    "recodificado" % (ocorrencias, escolhido))
            return "mojibake recodificado para utf-8", recodificado, evid
    evid = "primeiro encoding da ordem que decodifica sem erro"
    if tem_bom:
        evid += ", com marca de ordem de byte no inicio"
    return escolhido, texto, evid


def detectar_delimitador(texto, forcado=None):
    if forcado and forcado != "auto":
        delim = {"tab": "\t", "\\t": "\t"}.get(forcado, forcado)
        return delim, 0, "delimitador informado na linha de comando"
    amostra = [l for l in texto.splitlines() if l.strip()][:20]
    if not amostra:
        raise ErroDeEntrada("arquivo sem linha nao vazia")
    melhor = None
    for cand in DELIMITADORES_CANDIDATOS:
        contagens = []
        for linha in amostra:
            try:
                campos = next(csv.reader([linha], delimiter=cand))
            except csv.Error:
                campos = linha.split(cand)
            contagens.append(len(campos))
        moda = max(set(contagens), key=contagens.count)
        if moda < 2:
            continue
        consistencia = contagens.count(moda) / float(len(contagens))
        escore = (consistencia, moda)
        if melhor is None or escore > melhor[0]:
            melhor = (escore, cand, moda, consistencia)
    if melhor is None:
        raise ErroDeEntrada("nenhum delimitador candidato produz mais de uma coluna")
    _, cand, moda, consistencia = melhor
    nome = {"\t": "tabulacao"}.get(cand, cand)
    evid = "%d colunas em %d%% das primeiras linhas" % (moda, round(consistencia * 100))
    return cand, moda, "delimitador %s, %s" % (nome, evid)


def parsear(texto, delimitador):
    """Devolve [(linha_fisica_final, campos)], com campo entre aspas em varias linhas."""
    linhas = texto.splitlines(True)
    leitor = csv.reader(linhas, delimiter=delimitador)
    saida = []
    for campos in leitor:
        saida.append((leitor.line_num, campos))
    return saida


def celula_numerica(valor):
    v = (valor or "").strip()
    return bool(v) and bool(RE_SO_NUMERO.match(v))


def localizar_cabecalho(linhas, forcado=None, max_varredura=20):
    if forcado not in (None, "auto"):
        alvo = int(forcado)
        for idx, (fisica, _campos) in enumerate(linhas):
            if fisica == alvo:
                return idx, "linha do cabecalho informada na linha de comando"
        raise ErroDeEntrada("linha de cabecalho %d nao existe no arquivo" % alvo)
    candidatos = []
    limite = min(max_varredura, len(linhas))
    for idx in range(limite):
        campos = linhas[idx][1]
        preenchidas = [c for c in campos if (c or "").strip()]
        if len(preenchidas) < 2:
            continue
        if any(celula_numerica(c) for c in campos):
            continue
        seguintes = [len(linhas[k][1]) for k in range(idx + 1, min(idx + 4, len(linhas)))]
        if not seguintes or len(set(seguintes)) != 1 or seguintes[0] != len(campos):
            continue
        candidatos.append((len(preenchidas), -idx, idx))
    if not candidatos:
        raise ErroDeEntrada(
            "nao foi possivel localizar o cabecalho nas primeiras %d linhas, "
            "informe com --cabecalho" % limite
        )
    candidatos.sort(reverse=True)
    escolhido = candidatos[0][2]
    evid = ("linha com mais celulas preenchidas, nenhuma puramente numerica, e "
            "tres linhas seguintes com a mesma contagem de colunas")
    return escolhido, evid


def nomear_colunas(campos):
    nomes = []
    vistos = {}
    for pos, bruto in enumerate(campos, start=1):
        nome, _ = norm_texto(bruto or "")
        if not nome:
            nome = "coluna_%d" % pos
        base = chave_simples(nome)
        vistos[base] = vistos.get(base, 0) + 1
        if vistos[base] > 1:
            nome = "%s__%d" % (nome, vistos[base])
        nomes.append(nome)
    return nomes


class Fonte(object):
    def __init__(self, rotulo, caminho):
        self.rotulo = rotulo
        self.caminho = Path(caminho)
        if not self.caminho.is_file():
            raise ErroDeEntrada("arquivo da fonte %s nao encontrado: %s" % (rotulo, caminho))
        if self.caminho.suffix.lower() in (".xlsx", ".xls", ".xlsm", ".ods", ".pdf"):
            raise ErroDeEntrada(
                "a fonte %s tem extensao %s. Este script le CSV. Converta para CSV com a "
                "coluna-chave formatada como Texto e confira os zeros a esquerda no editor "
                "de texto antes de rodar" % (rotulo, self.caminho.suffix)
            )
        self.bytes = self.caminho.stat().st_size
        self.mtime = date.fromtimestamp(self.caminho.stat().st_mtime).isoformat()
        self.encoding = None
        self.evidencia_encoding = ""
        self.delimitador = None
        self.evidencia_delimitador = ""
        self.linha_cabecalho = None
        self.evidencia_cabecalho = ""
        self.colunas = []
        self.registros = []
        self.descartes = []
        # Descarte de leitura com conteudo e dado que nunca foi comparado. Fica
        # separado do descarte de linha em branco, que nao carrega dado.
        self.descartes_com_conteudo = 0
        self.pre_cabecalho = 0
        self.rodape = []
        self.total_rodape = {}
        self.registros_lidos = 0
        self.linhas_arquivo = 0
        self.mesclagem = []
        self.preenchidas_para_baixo = {}

    def carregar(self, args):
        dados = self.caminho.read_bytes()
        forcado_enc = getattr(args, "encoding_" + self.rotulo.lower())
        self.encoding, texto, self.evidencia_encoding = detectar_encoding(dados, forcado_enc)
        forcado_delim = getattr(args, "delimitador_" + self.rotulo.lower())
        self.delimitador, _, self.evidencia_delimitador = detectar_delimitador(
            texto, forcado_delim
        )
        linhas = parsear(texto, self.delimitador)
        if not linhas:
            raise ErroDeEntrada("fonte %s esta vazia" % self.rotulo)
        forcado_cab = getattr(args, "cabecalho_" + self.rotulo.lower())
        idx, self.evidencia_cabecalho = localizar_cabecalho(linhas, forcado_cab)
        self.linha_cabecalho = linhas[idx][0]
        self.pre_cabecalho = idx
        self.colunas = nomear_colunas(linhas[idx][1])
        corpo = linhas[idx + 1:]
        self.registros_lidos = len(corpo)
        self.linhas_arquivo = len(texto.splitlines())
        for fisica, campos in corpo:
            if len(campos) != len(self.colunas):
                # O conteudo vai junto: linha descartada sem rastro do que estava
                # nela e perda de dado em silencio, que esta skill existe para eliminar.
                if not any((c or "").strip() for c in campos):
                    self.descartes.append((fisica, "linha em branco", list(campos)))
                else:
                    self.descartes.append(
                        (fisica, "linha com %d colunas, cabecalho tem %d"
                         % (len(campos), len(self.colunas)), list(campos))
                    )
                    self.descartes_com_conteudo += 1
                continue
            self.registros.append(
                {"_linha": fisica, "_valores": dict(zip(self.colunas, campos))}
            )

# ---------------------------------------------------------------------------
# 4. Rodape, mesclagem e perfilamento de coluna
# ---------------------------------------------------------------------------


def numero_solto(valor):
    """Devolve os valores possiveis de uma celula numerica nas duas convencoes."""
    v, _unidade = separar_unidade((valor or "").strip())
    v, negativo = tratar_contabil(v)
    v = v.replace(" ", "").replace(" ", "")
    if not v or not re.match(r"^[+-]?[\d.,]+$", v):
        return None
    candidatos = []
    for dec, mil in ((",", "."), (".", ",")):
        texto = v.replace(mil, "").replace(dec, ".")
        try:
            d = Decimal(texto)
        except InvalidOperation:
            continue
        candidatos.append(-d if negativo else d)
    return candidatos or None


def eh_data(valor, com_serial=False):
    v = (valor or "").strip()
    if RE_ISO.match(v) or RE_DMY.match(v):
        return True
    if com_serial and RE_SERIAL.match(v) and 20000 <= int(v) <= 60000:
        return True
    return False


def detectar_rodape(fonte, modo="auto", coluna_chave=None):
    """Tira o rodape do fim do arquivo e registra cada linha que saiu.

    Roda duas vezes por fonte: antes da deteccao de chave, com os criterios que
    nao dependem dela, e depois, com o criterio de chave vazia. Quem decide o
    descarte e a combinacao de criterios, nunca o texto sozinho: marcador de
    total mais poucas celulas preenchidas. A decisao e por bloco, nao linha a
    linha, porque rodape de ERP tem linha de identificacao abaixo do total. Na
    duvida a linha fica e vai para a conferencia, porque descartar item real em
    silencio e o pior resultado. Toda linha descartada sai em
    linhas-descartadas.csv.
    """
    if modo == "manter":
        return
    if modo != "auto":
        if coluna_chave is not None:
            return
        try:
            quantas = int(modo)
        except ValueError:
            raise ErroDeEntrada("--rodape aceita auto, manter ou um numero")
        for _ in range(min(quantas, len(fonte.registros))):
            reg = fonte.registros.pop()
            fonte.rodape.append((reg["_linha"], "descartada por --rodape %d" % quantas,
                                 reg["_valores"]))
            fonte.total_rodape[reg["_linha"]] = reg["_valores"]
        return
    limite = max(2, len(fonte.colunas) // 2)

    def preenchidas(reg):
        return sum(1 for v in reg["_valores"].values() if (v or "").strip())

    def tem_marcador(reg):
        return any(chave_simples(v) in MARCADORES_RODAPE
                   for v in reg["_valores"].values())

    # "Poucas celulas preenchidas" so distingue rodape de item quando existe no
    # arquivo alguma linha densa para servir de contraste. Em arquivo de duas
    # colunas toda linha e pouca, e ai o criterio nao decide nada: o bloco nao
    # se forma, a linha de total fica, e a rodada avisa que nao conferiu o total
    # em vez de varrer itens reais. Linha densa nunca e descartada por nenhum dos
    # tres criterios, por isso a medida vale para o laco inteiro.
    tem_linha_densa = any(
        sum(1 for v in reg["_valores"].values() if (v or "").strip()) > limite
        for reg in fonte.registros
    )
    mudou = True
    while mudou and fonte.registros:
        mudou = False
        # Linha de celulas vazias no fim do arquivo e o que o Excel escreve
        # quando a area usada passa do ultimo dado. Antes ela interrompia a
        # deteccao e o rodape inteiro entrava como item.
        while fonte.registros and preenchidas(fonte.registros[-1]) == 0:
            reg = fonte.registros.pop()
            fonte.descartes.append((reg["_linha"],
                                    "linha de celulas vazias no fim do arquivo",
                                    [reg["_valores"].get(c, "") for c in fonte.colunas]))
            mudou = True
        # Decisao por BLOCO, nao linha a linha. Rodape de ERP tem linha de
        # identificacao abaixo do total ("Emitido em 30/04/2026 por PCP",
        # "Pagina 1 de 1"). Decidindo linha a linha, essa linha nao e marcador
        # nem chave vazia, interrompe a varredura e protege o rodape inteiro:
        # a linha de total entra como item, o total nunca e conferido e a
        # rodada sai com codigo 0. O bloco final de linhas com poucas celulas
        # preenchidas sai inteiro do primeiro marcador para baixo. As linhas do
        # bloco acima do marcador ficam, porque item real com celula em branco
        # tambem cai no limite de poucas celulas.
        inicio = len(fonte.registros)
        if tem_linha_densa:
            while inicio > 0 and preenchidas(fonte.registros[inicio - 1]) <= limite:
                inicio -= 1
        corte = None
        for i in range(inicio, len(fonte.registros)):
            if tem_marcador(fonte.registros[i]):
                corte = i
                break
        if corte is not None:
            saindo = fonte.registros[corte:]
            del fonte.registros[corte:]
            for reg in saindo:
                if tem_marcador(reg):
                    motivo = ("linha de total no fim do arquivo, celula com marcador de "
                              "total e poucas celulas preenchidas")
                    fonte.total_rodape[reg["_linha"]] = reg["_valores"]
                else:
                    motivo = "linha do bloco de rodape, abaixo da linha de total"
                fonte.rodape.append((reg["_linha"], motivo, reg["_valores"]))
            mudou = True
            continue
        if coluna_chave is None:
            continue
        while fonte.registros:
            reg = fonte.registros[-1]
            if preenchidas(reg) > limite:
                break
            if chave_simples(reg["_valores"].get(coluna_chave, "")):
                break
            fonte.registros.pop()
            fonte.rodape.append((reg["_linha"],
                                 "chave vazia e poucas celulas preenchidas no fim do "
                                 "arquivo", reg["_valores"]))
            fonte.total_rodape[reg["_linha"]] = reg["_valores"]
            mudou = True


def verificar_total_rodape(fonte):
    """Compara o total declarado no rodape com a soma das linhas mantidas."""
    resultado = []
    for linha, valores in fonte.total_rodape.items():
        for col in fonte.colunas:
            declarado = numero_solto(valores.get(col, ""))
            if not declarado:
                continue
            somas = [Decimal(0), Decimal(0)]
            vistos = 0
            for reg in fonte.registros:
                cands = numero_solto(reg["_valores"].get(col, ""))
                if not cands:
                    continue
                vistos += 1
                somas[0] += cands[0]
                if len(cands) > 1:
                    somas[1] += cands[1]
                else:
                    somas[1] += cands[0]
            if not vistos:
                continue
            confere = any(
                abs(d - s) <= (abs(s) * Decimal("0.0001") + Decimal("0.01"))
                for d in declarado for s in somas
            )
            resultado.append((linha, col, confere))
    return resultado


def status_total_rodape(fonte, resultados):
    """Frase unica sobre a conferencia do total, inclusive quando ela nao aconteceu.

    "Nenhuma linha de total encontrada" so pode ser dito quando de fato nao ha
    marcador de total no fim do arquivo. Dizer isso com a linha de total ainda
    dentro dos registros mantidos e afirmacao falsa no lugar exato onde a pessoa
    confia que a conferencia foi feita.
    """
    if not fonte.total_rodape:
        for reg in fonte.registros[-5:]:
            if any(chave_simples(v) in MARCADORES_RODAPE
                   for v in reg["_valores"].values()):
                return ("linha com marcador de total encontrada no fim do arquivo e nao "
                        "descartada, conferencia do total nao foi feita")
        return "nenhuma linha de total encontrada, conferencia do total nao foi feita"
    if not resultados:
        return "linha de total encontrada, nenhuma coluna somavel para conferir"
    if all(confere for _linha, _col, confere in resultados):
        return "confere com a soma das linhas mantidas"
    return "NAO confere com a soma das linhas mantidas"


def detectar_mesclagem(fonte):
    total = len(fonte.registros)
    if total < 6:
        return
    taxas = {}
    for col in fonte.colunas:
        vazios = sum(1 for r in fonte.registros if not (r["_valores"].get(col) or "").strip())
        taxas[col] = vazios / float(total)
    for col in fonte.colunas:
        taxa = taxas[col]
        if taxa < 0.3 or taxa > 0.9:
            continue
        # A guarda de mediana desligava a deteccao inteira por causa de uma unica
        # coluna de observacao vazia. O julgamento agora e coluna por coluna, e o
        # unico caso descartado e o arquivo esparso inteiro, onde nenhuma coluna
        # se destaca.
        outras = [t for c, t in taxas.items() if c != col]
        if outras and min(outras) > 0.3:
            continue
        anterior = ""
        regular = True
        blocos = 0
        for reg in fonte.registros:
            v = (reg["_valores"].get(col) or "").strip()
            if not v and not anterior:
                regular = False
                break
            if v:
                blocos += 1
            anterior = v or anterior
        if regular:
            fonte.mesclagem.append((col, round(taxa * 100), blocos))


def preencher_para_baixo(fonte, colunas):
    for col in colunas:
        if col not in fonte.colunas:
            raise ErroDeEntrada(
                "coluna %s de --preencher-para-baixo nao existe na fonte %s"
                % (col, fonte.rotulo)
            )
        anterior = ""
        contagem = 0
        for reg in fonte.registros:
            v = (reg["_valores"].get(col) or "").strip()
            if v:
                anterior = v
            elif anterior:
                reg["_valores"][col] = anterior
                contagem += 1
        fonte.preenchidas_para_baixo[col] = contagem


def amostrar(fonte, coluna, limite=600):
    valores = []
    for reg in fonte.registros:
        v = (reg["_valores"].get(coluna) or "").strip()
        if v:
            valores.append(v)
        if len(valores) >= limite:
            break
    return valores


def perfilar_coluna_numerica(valores, forcado="auto"):
    evidencia = []
    ambiguo = False
    if forcado == "virgula":
        return {"decimal": ",", "milhar": ".", "ambiguo": False,
                "evidencia": "decimal informado na linha de comando"}
    if forcado == "ponto":
        return {"decimal": ".", "milhar": ",", "ambiguo": False,
                "evidencia": "decimal informado na linha de comando"}
    ambos = virg_dir = ponto_dir = 0
    so_v = so_p = 0
    v_tres = v_outro = p_tres = p_outro = 0
    multi_v = multi_p = 0
    for bruto in valores:
        v, _ = separar_unidade(bruto)
        v, _ = tratar_contabil(v)
        v = v.replace(" ", "")
        tem_v, tem_p = "," in v, "." in v
        if tem_v and tem_p:
            ambos += 1
            if v.rfind(",") > v.rfind("."):
                virg_dir += 1
            else:
                ponto_dir += 1
        elif tem_v:
            so_v += 1
            if v.count(",") > 1:
                multi_v += 1
            elif len(v.split(",")[-1]) == 3:
                v_tres += 1
            else:
                v_outro += 1
        elif tem_p:
            so_p += 1
            if v.count(".") > 1:
                multi_p += 1
            elif len(v.split(".")[-1]) == 3:
                p_tres += 1
            else:
                p_outro += 1
    if ambos:
        if virg_dir >= ponto_dir:
            dec, mil = ",", "."
        else:
            dec, mil = ".", ","
        evidencia.append(
            "celulas com os dois sinais: %d, decimal e o sinal mais a direita" % ambos
        )
    elif multi_p and not multi_v:
        dec, mil = ",", "."
        evidencia.append("ponto repetido na mesma celula, ponto e separador de milhar")
    elif multi_v and not multi_p:
        dec, mil = ".", ","
        evidencia.append("virgula repetida na mesma celula, virgula e separador de milhar")
    elif so_v and not so_p:
        dec, mil = ",", "."
        if v_outro == 0 and v_tres:
            ambiguo = True
            evidencia.append(
                "toda virgula da coluna tem exatamente 3 digitos depois, pode ser milhar, "
                "assumida como decimal"
            )
        else:
            evidencia.append("apenas virgula na coluna, tratada como decimal")
    elif so_p and not so_v:
        if p_outro == 0 and p_tres:
            dec, mil = ",", "."
            ambiguo = True
            evidencia.append(
                "todo ponto da coluna tem exatamente 3 digitos depois, tratado como "
                "separador de milhar, decisao ambigua"
            )
        else:
            dec, mil = ".", ","
            evidencia.append("apenas ponto na coluna, tratado como decimal")
    elif so_v and so_p:
        if p_outro == 0 and p_tres:
            dec, mil = ",", "."
            evidencia.append(
                "coluna mista, todo ponto com 3 digitos depois tratado como milhar"
            )
        else:
            dec, mil = ",", "."
            ambiguo = True
            evidencia.append(
                "coluna mista, celulas com virgula e celulas com ponto, sem celula que "
                "decida, assumido padrao brasileiro"
            )
    else:
        dec, mil = ",", "."
        evidencia.append("coluna sem separador decimal")
    return {"decimal": dec, "milhar": mil, "ambiguo": ambiguo,
            "evidencia": "; ".join(evidencia)}


def perfilar_coluna_data(valores, forcado="auto"):
    if forcado in ("dmy", "mdy"):
        return {"ordem": forcado, "ambiguo": False,
                "evidencia": "ordem informada na linha de comando"}
    if forcado in ("iso", "serial"):
        return {"ordem": "dmy", "ambiguo": False,
                "evidencia": "formato %s informado na linha de comando" % forcado}
    prim = seg = reconhecidas = 0
    for bruto in valores:
        m = RE_DMY.match(bruto.strip())
        if not m:
            continue
        reconhecidas += 1
        a, b = int(m.group(1)), int(m.group(2))
        if a > 12:
            prim += 1
        if b > 12:
            seg += 1
    if prim and not seg:
        return {"ordem": "dmy", "ambiguo": False,
                "evidencia": "celulas com o primeiro componente maior que 12: %d" % prim}
    if seg and not prim:
        return {"ordem": "mdy", "ambiguo": False,
                "evidencia": "celulas com o segundo componente maior que 12: %d" % seg}
    if prim and seg:
        return {"ordem": "dmy", "ambiguo": True,
                "evidencia": "conflito, ha celulas com o primeiro e com o segundo "
                             "componente maiores que 12, assumido dia primeiro"}
    if reconhecidas:
        return {"ordem": "dmy", "ambiguo": True,
                "evidencia": "nenhuma celula decide dia ou mes, assumido padrao "
                             "brasileiro dia primeiro"}
    return {"ordem": "dmy", "ambiguo": False,
            "evidencia": "coluna sem data no formato com separador"}


def norm_numero(valor, perfil):
    regras = set()
    bruto = (valor or "").strip()
    if not bruto:
        return None, regras, "", "vazio"
    v, unidade = separar_unidade(bruto)
    if unidade:
        regras.add("unidade_separada")
    v, negativo = tratar_contabil(v)
    if negativo:
        regras.add("contabil")
    v = v.replace(" ", "").replace(" ", "")
    if perfil["milhar"] and perfil["milhar"] in v:
        v = v.replace(perfil["milhar"], "")
        regras.add("milhar_removido")
    if perfil["decimal"] and perfil["decimal"] in v:
        v = v.replace(perfil["decimal"], ".")
        regras.add("decimal_convertido")
    try:
        d = Decimal(v)
    except InvalidOperation:
        regras.add("nao_numerico")
        return None, regras, unidade, "nao reconhecido como numero"
    if negativo:
        d = -d
    return d, regras, unidade, ""


def norm_data(valor, perfil):
    regras = set()
    v = (valor or "").strip()
    if not v:
        return None, regras, "vazio"
    m = RE_ISO.match(v)
    if m:
        regras.add("iso")
        if len(v) > 10:
            regras.add("hora_descartada")
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat(), regras, ""
        except ValueError:
            regras.add("data_invalida")
            return None, regras, "data invalida"
    m = RE_DMY.match(v)
    if m:
        p1, p2, ano = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if ano < 100:
            ano += 2000 if ano < 70 else 1900
        if perfil["ordem"] == "mdy":
            mes, dia = p1, p2
        else:
            dia, mes = p1, p2
        regras.add(perfil["ordem"])
        if len(v) > 10:
            regras.add("hora_descartada")
        try:
            return date(ano, mes, dia).isoformat(), regras, ""
        except ValueError:
            regras.add("data_invalida")
            return None, regras, "data invalida"
    if RE_SERIAL.match(v) and 20000 <= int(v) <= 60000:
        regras.add("serial")
        return (date(1899, 12, 30) + timedelta(days=int(v))).isoformat(), regras, ""
    regras.add("nao_data")
    return None, regras, "nao reconhecido como data"

# ---------------------------------------------------------------------------
# 5. Chave, indexacao e duplicatas
# ---------------------------------------------------------------------------


def aplicar_ausentes(valor, marcadores):
    """Marcador de ausencia vira vazio. Zero nunca entra nesta lista por padrao."""
    v = (valor or "").strip()
    if not v:
        return ""
    nucleo = chave_simples(v)
    if v in marcadores or v.casefold() in marcadores or (nucleo and nucleo in marcadores):
        return ""
    return valor


def resolver_coluna(fonte, indicado):
    """Aceita nome de coluna, nome equivalente ou indice com prefixo #."""
    if indicado is None:
        return None
    if indicado.startswith("#"):
        pos = int(indicado[1:])
        if pos < 1 or pos > len(fonte.colunas):
            raise ErroDeEntrada("indice de coluna %s fora da fonte %s" % (indicado, fonte.rotulo))
        return fonte.colunas[pos - 1]
    for col in fonte.colunas:
        if col == indicado or chave_simples(col) == chave_simples(indicado):
            return col
    raise ErroDeEntrada(
        "coluna %s nao existe na fonte %s. Colunas: %s"
        % (indicado, fonte.rotulo, ", ".join(fonte.colunas))
    )


def perfil_candidata(fonte, coluna):
    total = len(fonte.registros)
    if not total:
        return None
    valores = [(r["_valores"].get(coluna) or "").strip() for r in fonte.registros]
    cheios = [v for v in valores if v]
    if not cheios:
        return None
    distintos = len(set(so_alfanumerico(v) for v in cheios)) / float(len(cheios))
    vazios = 1.0 - (len(cheios) / float(total))
    return distintos, vazios


def detectar_chave(fonte_a, fonte_b):
    mapa_b = dict((chave_simples(c), c) for c in fonte_b.colunas)
    candidatos = []
    medidas = []
    for col_a in fonte_a.colunas:
        nucleo = chave_simples(col_a)
        if nucleo not in mapa_b:
            continue
        col_b = mapa_b[nucleo]
        pa, pb = perfil_candidata(fonte_a, col_a), perfil_candidata(fonte_b, col_b)
        if not pa or not pb:
            medidas.append("%s/%s: coluna sem nenhum valor preenchido" % (col_a, col_b))
            continue
        distintos = min(pa[0], pb[0])
        vazios = max(pa[1], pb[1])
        medidas.append("%s/%s: %d%% de valores distintos, %d%% de vazio"
                       % (col_a, col_b, round(distintos * 100), round(vazios * 100)))
        # Coluna de data tem quase 100% de distintos e 0% de vazio em qualquer
        # relatorio, e viraria chave com a evidencia parecendo boa.
        amostra = amostrar(fonte_a, col_a) + amostrar(fonte_b, col_b)
        if inferir_tipo(col_a, amostra) == "data":
            medidas[-1] += ", recusada por ser coluna de data"
            continue
        if distintos < 0.9 or vazios > 0.05:
            continue
        candidatos.append((distintos, -vazios, col_a, col_b))
    if not candidatos:
        raise ErroDeEntrada(
            "nenhuma coluna compartilhada serve de chave (exigencia: presente nas duas "
            "fontes, mais de 90%% de valores distintos, menos de 5%% de vazio, e nao ser "
            "coluna de data). Medicao coluna por coluna: %s. Informe com --chave-a e "
            "--chave-b"
            % ("; ".join(medidas)
               or "nenhuma coluna tem nome equivalente nas duas fontes")
        )
    candidatos.sort(reverse=True)
    if len(candidatos) > 1 and (candidatos[0][0] - candidatos[1][0]) < 0.02:
        nomes = ", ".join("%s/%s" % (c[2], c[3]) for c in candidatos[:5])
        raise ErroDeEntrada(
            "deteccao de chave nao e inequivoca. Candidatas empatadas: %s. "
            "Escolha com --chave-a e --chave-b" % nomes
        )
    return candidatos[0][2], candidatos[0][3], (
        "coluna presente nas duas fontes, com %d%% de valores distintos e %d%% de vazio"
        % (round(candidatos[0][0] * 100), round(-candidatos[0][1] * 100))
    )


def largura_constante(fonte, coluna):
    larguras = set()
    for reg in fonte.registros:
        v = so_alfanumerico(reg["_valores"].get(coluna, ""))
        if not v:
            continue
        if not v.isdigit():
            return None
        larguras.add(len(v))
    if len(larguras) == 1:
        return larguras.pop()
    return None


def contar_fusao(fonte, coluna, opcoes):
    """Chaves distintas depois de cada regra da chave.

    Exclui o que a indexacao tambem exclui, chave irrecuperavel e marcador de
    ausencia, para que esta tabela feche com a linha Chaves distintas da nota.
    Dois numeros diferentes para a mesma coisa na mesma secao derruba a nota.
    """
    antes, sem_sep, com_zeros = set(), set(), set()
    for reg in fonte.registros:
        valor, estado = expandir_ou_marcar(reg["_valores"].get(coluna, ""))
        if estado == "irrecuperavel":
            continue
        bruto = aplicar_ausentes(valor, opcoes["ausentes"])
        a, _ = norm_texto(bruto, acento=True, caixa=True)
        if not a:
            continue
        antes.add(a)
        s, _ = norm_codigo(bruto, zeros="preservar")
        if s:
            sem_sep.add(s)
        z, _ = norm_codigo(bruto, zeros=opcoes["zeros"], largura=opcoes["largura"])
        if z:
            com_zeros.add(z)
    return len(antes), len(sem_sep), len(com_zeros)


def indexar(fonte, coluna, perfil_nome, opcoes):
    indice = {}
    vazias = []
    irrecuperaveis = []
    contadores = dict((r, 0) for r in REGRAS_POR_PERFIL[perfil_nome])
    for reg in fonte.registros:
        bruto = reg["_valores"].get(coluna, "") or ""
        reg["_chave_bruta"] = bruto
        valor, estado = expandir_ou_marcar(bruto)
        if estado == "irrecuperavel":
            reg["_chave"] = None
            irrecuperaveis.append(reg)
            continue
        depois = aplicar_ausentes(valor, opcoes["ausentes"])
        if depois != valor:
            contadores["marcador_de_ausencia"] += 1
        if perfil_nome == "codigo":
            chave, regras = norm_codigo(depois, zeros=opcoes["zeros"], largura=opcoes["largura"])
        elif perfil_nome == "numero":
            d, regras, _u, _m = norm_numero(depois, opcoes["perfil_num"])
            chave = fmt_num(d) if d is not None else ""
        else:
            chave, regras = norm_texto(depois, acento=True, caixa=True)
        for r in regras:
            contadores[r] = contadores.get(r, 0) + 1
        if not chave:
            reg["_chave"] = None
            vazias.append(reg)
            continue
        reg["_chave"] = chave
        indice.setdefault(chave, []).append(reg)
    return indice, vazias, irrecuperaveis, contadores


def resolver_duplicatas(indice):
    unico = {}
    divergentes = {}
    colapsadas = 0
    extras = 0
    for chave, regs in indice.items():
        if len(regs) == 1:
            unico[chave] = regs[0]
            continue
        extras += len(regs) - 1
        base = regs[0]["_valores"]
        if all(r["_valores"] == base for r in regs[1:]):
            unico[chave] = regs[0]
            colapsadas += 1
        else:
            divergentes[chave] = regs
    return unico, divergentes, colapsadas, extras

# ---------------------------------------------------------------------------
# 6. Comparacao
# ---------------------------------------------------------------------------


class Par(object):
    def __init__(self, label, col_a, col_b, tipo):
        self.label = label
        self.col_a = col_a
        self.col_b = col_b
        self.tipo = tipo
        self.perfil_a = None
        self.perfil_b = None
        self.ambiguo = False
        self.motivo = ""
        self.regras_a = dict((r, 0) for r in REGRAS_POR_PERFIL[tipo])
        self.regras_b = dict((r, 0) for r in REGRAS_POR_PERFIL[tipo])


def inferir_tipo(nome, valores):
    if not valores:
        return "texto"
    dica_data = any(p in chave_simples(nome) for p in
                    ("data", "dt", "emissao", "vencimento", "prazo", "entrega", "competencia"))
    datas = sum(1 for v in valores if eh_data(v, com_serial=dica_data))
    if datas >= 0.8 * len(valores):
        return "data"
    numeros = sum(1 for v in valores if numero_solto(v) is not None)
    if numeros >= 0.8 * len(valores):
        return "numero"
    return "texto"


def montar_pares(fonte_a, fonte_b, chave_a, chave_b, args):
    tipos_pedidos = {}
    if args.perfil_campo:
        for item in args.perfil_campo.split(","):
            if not item.strip():
                continue
            nome, _, tipo = item.partition(":")
            tipo = tipo.strip() or "texto"
            if tipo not in REGRAS_POR_PERFIL:
                raise ErroDeEntrada("perfil de campo desconhecido: %s" % tipo)
            tipos_pedidos[chave_simples(nome)] = tipo
    pares = []
    sem_par = []
    if args.campos:
        origem = "campos"
        for item in args.campos.split(","):
            if not item.strip():
                continue
            lado_a, _, lado_b = item.partition(":")
            col_a = resolver_coluna(fonte_a, lado_a.strip())
            col_b = resolver_coluna(fonte_b, (lado_b.strip() or lado_a.strip()))
            pares.append((col_a, col_b))
        # Com --campos a lista de colunas sem par tambem precisa ser calculada.
        # Vazia, o bloco de verificacoes imprimia "colunas sem par: nenhuma" com
        # colunas de fato fora da comparacao: falsa garantia no unico bloco que a
        # skill apresenta como o que pode falhar de fato.
        usadas_a = set(c for c, _ in pares)
        usadas_b = set(c for _, c in pares)
        sem_par = (["A:" + c for c in fonte_a.colunas
                    if c != chave_a and c not in usadas_a]
                   + ["B:" + c for c in fonte_b.colunas
                      if c != chave_b and c not in usadas_b])
    else:
        origem = "auto"
        mapa_b = dict((chave_simples(c), c) for c in fonte_b.colunas)
        for col_a in fonte_a.colunas:
            if col_a == chave_a:
                continue
            nucleo = chave_simples(col_a)
            if nucleo in mapa_b and mapa_b[nucleo] != chave_b:
                pares.append((col_a, mapa_b[nucleo]))
            else:
                sem_par.append("A:" + col_a)
        mapa_a = dict((chave_simples(c), c) for c in fonte_a.colunas)
        for col_b in fonte_b.colunas:
            if col_b != chave_b and chave_simples(col_b) not in mapa_a:
                sem_par.append("B:" + col_b)
    montados = []
    for col_a, col_b in pares:
        label = col_a
        valores = amostrar(fonte_a, col_a) + amostrar(fonte_b, col_b)
        tipo = tipos_pedidos.get(chave_simples(col_a)) or inferir_tipo(col_a, valores)
        par = Par(label, col_a, col_b, tipo)
        if tipo == "numero":
            par.perfil_a = perfilar_coluna_numerica(amostrar(fonte_a, col_a), args.decimal)
            par.perfil_b = perfilar_coluna_numerica(amostrar(fonte_b, col_b), args.decimal)
            if par.perfil_a["ambiguo"] or par.perfil_b["ambiguo"]:
                par.ambiguo = True
                par.motivo = "separador decimal ambiguo na coluna"
        elif tipo == "data":
            par.perfil_a = perfilar_coluna_data(amostrar(fonte_a, col_a), args.data)
            par.perfil_b = perfilar_coluna_data(amostrar(fonte_b, col_b), args.data)
            if par.perfil_a["ambiguo"] or par.perfil_b["ambiguo"]:
                par.ambiguo = True
                par.motivo = "ordem dia e mes indecidivel na coluna"
        montados.append(par)
    return montados, sem_par, origem


def normalizar_campo(par, lado, bruto, args, opcoes):
    regras_alvo = par.regras_a if lado == "a" else par.regras_b
    perfil = par.perfil_a if lado == "a" else par.perfil_b
    depois = aplicar_ausentes(bruto, opcoes["ausentes"])
    if depois != bruto:
        regras_alvo["marcador_de_ausencia"] += 1
    extra = {"unidade": "", "motivo": "", "cientifica": False}
    if detectar_notacao_cientifica(depois):
        valor, estado = expandir_ou_marcar(depois)
        if estado == "irrecuperavel":
            extra["cientifica"] = True
        depois = valor
    if par.tipo == "numero":
        d, regras, unidade, motivo = norm_numero(depois, perfil)
        extra["unidade"] = unidade
        extra["motivo"] = motivo
        for r in regras:
            regras_alvo[r] = regras_alvo.get(r, 0) + 1
        return d, extra
    if par.tipo == "data":
        iso, regras, motivo = norm_data(depois, perfil)
        extra["motivo"] = motivo
        for r in regras:
            regras_alvo[r] = regras_alvo.get(r, 0) + 1
        return iso, extra
    if par.tipo == "codigo":
        v, regras = norm_codigo(depois, zeros="preservar")
    elif par.tipo == "categoria":
        v, regras = norm_texto(depois, acento=True, caixa=True)
    else:
        v, regras = norm_texto(depois, acento=args.ignorar_acento_valor,
                               caixa=args.ignorar_caixa_valor)
    for r in regras:
        regras_alvo[r] = regras_alvo.get(r, 0) + 1
    return v, extra


def iguais_numericos(a, b, args):
    if a is None or b is None:
        return a is None and b is None
    diferenca = abs(a - b)
    if diferenca == 0:
        return True
    if args.tolerancia_numerica and diferenca <= Decimal(str(args.tolerancia_numerica)):
        return True
    if args.tolerancia_relativa:
        maior = max(abs(a), abs(b))
        if maior and diferenca / maior <= Decimal(str(args.tolerancia_relativa)):
            return True
    return False


def texto_saida(par, valor):
    if valor is None:
        return ""
    if par.tipo == "numero":
        return fmt_num(valor)
    return str(valor)


def classificar_formato(par, bruto_a, bruto_b, ausentes):
    vazio_a = aplicar_ausentes(bruto_a, ausentes).strip() == ""
    vazio_b = aplicar_ausentes(bruto_b, ausentes).strip() == ""
    if vazio_a and vazio_b and (bruto_a.strip() == "") != (bruto_b.strip() == ""):
        return "marcador de ausencia contra celula vazia"
    if par.tipo == "data":
        return "formato de data"
    if par.tipo == "numero":
        return "formato numerico"
    a1, _ = norm_texto(bruto_a)
    b1, _ = norm_texto(bruto_b)
    if a1 == b1:
        return "espaco nas pontas ou espaco interno"
    if a1.casefold() == b1.casefold():
        return "caixa"
    if sem_acento(a1).casefold() == sem_acento(b1).casefold():
        return "acento"
    return "regra do perfil %s" % par.tipo


def comparar(pares, unico_a, unico_b, args, opcoes, chave_fusao_suspeita, mescladas):
    divergencias = []
    formato = {}
    exemplos_formato = []
    iguais = 0
    com_divergencia = 0
    for chave in sorted(set(unico_a) & set(unico_b)):
        ra, rb = unico_a[chave], unico_b[chave]
        linhas = []
        for par in pares:
            bruto_a = ra["_valores"].get(par.col_a, "") or ""
            bruto_b = rb["_valores"].get(par.col_b, "") or ""
            norm_a, extra_a = normalizar_campo(par, "a", bruto_a, args, opcoes)
            norm_b, extra_b = normalizar_campo(par, "b", bruto_b, args, opcoes)
            if par.tipo == "numero":
                igual = iguais_numericos(norm_a, norm_b, args)
            else:
                igual = norm_a == norm_b
            motivos = []
            if par.ambiguo:
                motivos.append(par.motivo)
            if chave_fusao_suspeita:
                motivos.append("regra da chave reduziu a contagem de chaves distintas")
            # Em coluna com padrao de celula mesclada, celula vazia de um lado
            # so pode ser mesclagem, e a divergencia contra o outro lado e falsa
            # ate alguem olhar. Com as duas celulas preenchidas a mesclagem nao
            # explica nada e a divergencia continua certa.
            for rot_m, col_m, bruto_m in (("A", par.col_a, bruto_a),
                                          ("B", par.col_b, bruto_b)):
                if col_m in mescladas.get(rot_m, ()) and not bruto_m.strip():
                    motivos.append(
                        "coluna em padrao de celula mesclada na fonte %s, celula vazia "
                        "pode ser mesclagem e nao ausencia" % rot_m)
            if extra_a["cientifica"] or extra_b["cientifica"]:
                motivos.append("notacao cientifica irrecuperavel no campo")
            if extra_a["motivo"] or extra_b["motivo"]:
                sujo = [m for m in (extra_a["motivo"], extra_b["motivo"])
                        if m and m != "vazio"]
                if sujo:
                    motivos.append("; ".join(sujo))
            if igual:
                if bruto_a != bruto_b:
                    motivo_fmt = classificar_formato(par, bruto_a, bruto_b,
                                                     opcoes["ausentes"])
                    chave_fmt = (par.label, motivo_fmt)
                    formato[chave_fmt] = formato.get(chave_fmt, 0) + 1
                    exemplos_formato.append(
                        [chave, str(ra["_linha"]), str(rb["_linha"]), par.label,
                         bruto_a, bruto_b, texto_saida(par, norm_a), motivo_fmt]
                    )
            else:
                classe = "suspeita" if motivos else "certa"
                linhas.append([
                    chave, ra["_chave_bruta"], rb["_chave_bruta"],
                    str(ra["_linha"]), str(rb["_linha"]), par.label,
                    bruto_a, bruto_b,
                    texto_saida(par, norm_a), texto_saida(par, norm_b),
                    par.tipo, classe, "; ".join(motivos),
                ])
            if par.tipo == "numero":
                ua = (extra_a["unidade"] or "").casefold()
                ub = (extra_b["unidade"] or "").casefold()
                if ua != ub:
                    linhas.append([
                        chave, ra["_chave_bruta"], rb["_chave_bruta"],
                        str(ra["_linha"]), str(rb["_linha"]), par.label + " (unidade)",
                        bruto_a, bruto_b, extra_a["unidade"], extra_b["unidade"],
                        "unidade", "certa",
                        "unidade comparada como campo proprio, nao descartada",
                    ])
        if linhas:
            com_divergencia += 1
            divergencias.extend(linhas)
        else:
            iguais += 1
    return divergencias, formato, exemplos_formato, iguais, com_divergencia


def indices_auxiliares(indice):
    por_sep, por_zero, por_tam = {}, {}, {}
    for chave in indice:
        por_sep.setdefault(so_alfanumerico(chave), chave)
        por_zero.setdefault(remover_zeros(chave), chave)
        por_tam.setdefault(len(chave), []).append(chave)
    return por_sep, por_zero, por_tam


def digitos_de_mantissa(bruto):
    """Digitos da mantissa de um valor em notacao cientifica: 7,89123E+12 vira 789123."""
    base = (bruto or "").strip().lower().split("e")[0]
    return re.sub(r"\D", "", base)


def par_de_irrecuperavel(chave, irrecuperaveis_outro):
    """Chave longa deste lado contra chave em notacao cientifica do outro lado.

    O lado que preservou o codigo longo saia como orfa, e o engenheiro concluia
    que o item faltava. Ele esta la, com digitos perdidos na origem.
    """
    for reg in irrecuperaveis_outro:
        dig = digitos_de_mantissa(reg.get("_chave_bruta"))
        if len(dig) >= 4 and chave.startswith(dig):
            return reg["_chave_bruta"]
    return ""


def chave_longa_do_outro_lado(bruto, indice_outro):
    """Caminho inverso: da chave em notacao cientifica para a chave longa do outro lado."""
    dig = digitos_de_mantissa(bruto)
    if len(dig) < 4:
        return ""
    for chave in indice_outro:
        if chave.startswith(dig):
            return chave
    return ""


def buscar_sosia(chave, aux, orcamento, irrecuperaveis_outro=()):
    por_sep, por_zero, por_tam = aux
    alvo = so_alfanumerico(chave)
    if alvo in por_sep:
        return por_sep[alvo], "separadores"
    zero = remover_zeros(chave)
    if zero in por_zero:
        return por_zero[zero], "zeros"
    irr = par_de_irrecuperavel(chave, irrecuperaveis_outro)
    if irr:
        return irr, "irrecuperavel"
    # O criterio de uma edicao informa pouco em chave puramente numerica: em base
    # densa, "141" e "101" estao a uma edicao de distancia sem nenhuma relacao entre
    # os itens. Aplicado so em chave com letra e com pelo menos 4 caracteres.
    if chave.isdigit() or len(chave) < 4:
        return None, ""
    if orcamento[0] <= 0:
        return None, ""
    for tam in (len(chave) - 1, len(chave), len(chave) + 1):
        for outra in por_tam.get(tam, ()):
            orcamento[0] -= 1
            if orcamento[0] <= 0:
                return None, ""
            if distancia_um(chave, outra):
                return outra, "edicao"
    return None, ""

# ---------------------------------------------------------------------------
# 7. Fechamento e escrita
# ---------------------------------------------------------------------------


def montar_ausentes(texto):
    marcadores = set()
    for item in (texto or "").split(","):
        it = item.strip()
        if not it:
            continue
        marcadores.add(it)
        marcadores.add(it.casefold())
        nucleo = chave_simples(it)
        if nucleo:
            marcadores.add(nucleo)
    return marcadores


def fechar_contagens(ctx):
    linhas = []
    fecha = True
    for rot in ("A", "B"):
        d = ctx["lado"][rot]
        esq = d["registros_lidos"]
        dir_ = (d["descartadas"] + d["nao_chaveaveis"] + d["chaves_distintas"]
                + d["duplicatas_extras"])
        ok = esq == dir_
        fecha = fecha and ok
        linhas.append(
            "registros_lidos_%s = descartadas_%s + nao_chaveaveis_%s + chaves_distintas_%s "
            "+ duplicatas_extras_%s  ->  %d = %d + %d + %d + %d  [%s]"
            % (rot, rot, rot, rot, rot, esq, d["descartadas"], d["nao_chaveaveis"],
               d["chaves_distintas"], d["duplicatas_extras"], "fecha" if ok else "QUEBRA")
        )
    for rot in ("A", "B"):
        d = ctx["lado"][rot]
        esq = d["chaves_distintas"]
        dir_ = ctx["pareadas"] + d["so_em"] + d["nao_pareaveis"]
        ok = esq == dir_
        fecha = fecha and ok
        linhas.append(
            "chaves_distintas_%s = pareadas + so_em_%s + nao_pareaveis_%s  ->  "
            "%d = %d + %d + %d  [%s]"
            % (rot, rot, rot, esq, ctx["pareadas"], d["so_em"], d["nao_pareaveis"],
               "fecha" if ok else "QUEBRA")
        )
    ok = ctx["pareadas"] == ctx["iguais"] + ctx["com_divergencia"]
    fecha = fecha and ok
    linhas.append(
        "pareadas = iguais + com_divergencia  ->  %d = %d + %d  [%s]"
        % (ctx["pareadas"], ctx["iguais"], ctx["com_divergencia"],
           "fecha" if ok else "QUEBRA")
    )
    for rot in ("A", "B"):
        d = ctx["lado"][rot]
        esq = d["linhas_no_arquivo_orfas"]
        dir_ = d["so_em"] + d["linhas_duplicata_divergente"] + d["chave_vazia"] + d["irrecuperaveis"]
        ok = esq == dir_
        fecha = fecha and ok
        linhas.append(
            "linhas em so-na-fonte-%s.csv = so_em_%s + linhas_de_duplicata_divergente_%s "
            "+ chave_vazia_%s + irrecuperaveis_%s  ->  %d = %d + %d + %d + %d  [%s]"
            % (rot, rot, rot, rot, rot, esq, d["so_em"], d["linhas_duplicata_divergente"],
               d["chave_vazia"], d["irrecuperaveis"], "fecha" if ok else "QUEBRA")
        )
    esq = ctx["n_descartadas"]
    dir_ = sum(ctx["lado"][r]["rodape"] + ctx["lado"][r]["descartes_leitura"]
               for r in ("A", "B"))
    ok = esq == dir_
    fecha = fecha and ok
    linhas.append(
        "linhas em linhas-descartadas.csv = rodape_A + leitura_A + rodape_B + leitura_B "
        " ->  %d = %d + %d + %d + %d  [%s]"
        % (esq, ctx["lado"]["A"]["rodape"], ctx["lado"]["A"]["descartes_leitura"],
           ctx["lado"]["B"]["rodape"], ctx["lado"]["B"]["descartes_leitura"],
           "fecha" if ok else "QUEBRA")
    )
    return linhas, fecha


def escrever_csv(caminho, cabecalho, linhas, rodape):
    with caminho.open("w", encoding="utf-8-sig", newline="") as fh:
        escritor = csv.writer(fh, delimiter=";", quoting=csv.QUOTE_MINIMAL,
                              lineterminator="\r\n")
        escritor.writerow(cabecalho)
        for linha in linhas:
            escritor.writerow(linha)
        escritor.writerow(["# " + rodape] + [""] * (len(cabecalho) - 1))


def tabela_regras(titulo, regras, contagens_a, contagens_b, total_a, total_b):
    linhas = ["| Regra | Tocou em A | Tocou em B | Observacao |",
              "|---|---|---|---|"]
    for regra in regras:
        ca = contagens_a.get(regra, 0)
        cb = contagens_b.get(regra, 0)
        obs = []
        if ca == 0 and cb == 0:
            obs.append("nenhuma celula tocada")
        if total_a and ca == total_a:
            obs.append("alerta: tocou 100% das celulas de A")
        if total_b and cb == total_b:
            obs.append("alerta: tocou 100% das celulas de B")
        linhas.append("| %s | %d | %d | %s |" % (regra, ca, cb, ", ".join(obs)))
    return [titulo, ""] + linhas + [""]


def escrever_nota(caminho, ctx, status):
    L = []
    L.append("---")
    L.append("status: %s" % status)
    L.append("gerado_por: conferir.py %s" % VERSAO)
    L.append("data: %s" % ctx["hoje"])
    L.append("---")
    L.append("")
    L.append("# Nota de normalizacao")
    L.append("")
    L.append("Esta nota sai antes da lista de divergencias. Divergencia gerada por "
             "normalizacao errada e pior que nenhuma conferencia, por isso as decisoes "
             "abaixo sao conferidas primeiro.")
    L.append("")
    if status == "incompleto":
        L.append("A rodada ainda estava em andamento quando esta versao foi escrita. "
                 "Nota que permanece incompleta significa que a rodada caiu no meio e a "
                 "saida nao vale.")
        L.append("")

    L.append("## 1. Fontes")
    L.append("")
    L.append("| Lado | Arquivo | Bytes | Modificado em | Linhas no arquivo | "
             "Registros depois do cabecalho |")
    L.append("|---|---|---|---|---|---|")
    for rot in ("A", "B"):
        f = ctx["fonte"][rot]
        L.append("| %s | %s | %d | %s | %d | %d |" % (rot, f.caminho.name, f.bytes,
                                                      f.mtime, f.linhas_arquivo,
                                                      f.registros_lidos))
    L.append("")
    L.append("Registros depois do cabecalho conta as linhas descartadas e a linha de "
             "rodape, e e a base do fechamento. Uma celula com quebra de linha dentro "
             "ocupa mais de uma linha no arquivo e continua sendo um registro, por isso "
             "as duas colunas podem nao bater.")
    L.append("")

    L.append("## 2. Leitura")
    L.append("")
    L.append("| Lado | Encoding | Evidencia | Delimitador | Cabecalho na linha | "
             "Linhas antes do cabecalho | Linhas descartadas | Rodape |")
    L.append("|---|---|---|---|---|---|---|---|")
    for rot in ("A", "B"):
        f = ctx["fonte"][rot]
        delim = {"\t": "tabulacao"}.get(f.delimitador, f.delimitador)
        L.append("| %s | %s | %s | %s | %d | %d | %d | %d |" % (
            rot, f.encoding, f.evidencia_encoding, delim, f.linha_cabecalho,
            f.pre_cabecalho, len(f.descartes), len(f.rodape)))
    L.append("")
    for rot in ("A", "B"):
        f = ctx["fonte"][rot]
        L.append("Fonte %s, deteccao do cabecalho: %s." % (rot, f.evidencia_cabecalho))
        if f.descartes:
            L.append("Fonte %s, linhas descartadas na leitura (%d): %s%s" % (
                rot, len(f.descartes),
                "; ".join("linha %d, %s" % (d[0], d[1]) for d in f.descartes[:30]),
                ". Lista completa em linhas-descartadas.csv."
                if len(f.descartes) > 30 else "."))
        if f.rodape:
            L.append("Fonte %s, rodape descartado (%d): %s." % (
                rot, len(f.rodape),
                "; ".join("linha %d, %s" % (r[0], r[1]) for r in f.rodape)))
        if not ctx["total_rodape"][rot]:
            L.append("Fonte %s, conferencia do total do rodape: %s." % (
                rot, ctx["status_total"][rot]))
        for linha, col, confere in ctx["total_rodape"][rot]:
            if confere:
                L.append(
                    "Fonte %s, total declarado na linha %d, coluna %s: confere com a soma "
                    "das linhas mantidas." % (rot, linha, col))
            else:
                L.append(
                    "Fonte %s, total declarado na linha %d, coluna %s: NAO confere com a "
                    "soma das linhas mantidas. Achado: o arquivo pode ter linha perdida "
                    "antes da conferencia comecar." % (rot, linha, col))
        if f.mesclagem:
            for col, taxa, blocos in f.mesclagem:
                L.append(
                    "Fonte %s, coluna %s com %d%% de celulas vazias em padrao de celula "
                    "mesclada (%d blocos). Nao foi preenchida. Preenchimento para baixo "
                    "inventa dado e so roda com --preencher-para-baixo."
                    % (rot, col, taxa, blocos))
        for col, quantas in f.preenchidas_para_baixo.items():
            L.append("Fonte %s, coluna %s preenchida para baixo por pedido explicito, "
                     "%d celulas preenchidas." % (rot, col, quantas))
    L.append("")
    L.append("Toda linha que saiu do pareamento, por rodape ou na leitura, esta em "
             "linhas-descartadas.csv com o numero da linha, a causa e o conteudo. "
             "Descarte sem rastro no arquivo e perda de dado em silencio.")
    L.append("")

    L.append("## 3. Chave e granularidade")
    L.append("")
    L.append("| Item | Fonte A | Fonte B |")
    L.append("|---|---|---|")
    L.append("| Coluna-chave | %s | %s |" % (ctx["chave_a"], ctx["chave_b"]))
    L.append("| Perfil da chave | %s | %s |" % (ctx["perfil_chave"], ctx["perfil_chave"]))
    L.append("| Chaves distintas | %d | %d |" % (ctx["lado"]["A"]["chaves_distintas"],
                                                 ctx["lado"]["B"]["chaves_distintas"]))
    L.append("| Chaves repetidas na propria fonte | %d | %d |" % (
        ctx["lado"]["A"]["colapsadas"] + ctx["lado"]["A"]["nao_pareaveis"],
        ctx["lado"]["B"]["colapsadas"] + ctx["lado"]["B"]["nao_pareaveis"]))
    L.append("")
    L.append("Deteccao da chave: %s" % ctx["evidencia_chave"])
    L.append("")
    L.append("Granularidade: uma linha por chave em cada fonte. %s" % ctx["nota_granularidade"])
    L.append("")
    L.append("| Contagem de chaves distintas | Fonte A | Fonte B |")
    L.append("|---|---|---|")
    L.append("| Depois de espaco, acento e caixa | %d | %d |" % (ctx["fusao"]["A"][0],
                                                                ctx["fusao"]["B"][0]))
    L.append("| Depois de remover separadores | %d | %d |" % (ctx["fusao"]["A"][1],
                                                              ctx["fusao"]["B"][1]))
    L.append("| Depois da regra de zeros a esquerda | %d | %d |" % (ctx["fusao"]["A"][2],
                                                                    ctx["fusao"]["B"][2]))
    L.append("")
    L.append("Esta contagem exclui a chave irrecuperavel, o marcador de ausencia e a linha "
             "de chave vazia, o mesmo que a indexacao exclui, e por isso fecha com a linha "
             "Chaves distintas acima.")
    L.append("")
    if ctx["fusao_suspeita"]:
        L.append("**Alerta de fusao.** A contagem de chaves distintas caiu depois de uma "
                 "regra da chave. A regra esta juntando itens que o cadastro distingue. "
                 "Toda divergencia desta rodada sai classificada como suspeita.")
    else:
        L.append("Nenhuma regra da chave reduziu a contagem de chaves distintas.")
    L.append("")

    L.extend(tabela_regras(
        "## 4. Regras aplicadas na chave", REGRAS_POR_PERFIL[ctx["perfil_chave"]],
        ctx["regras_chave_a"], ctx["regras_chave_b"],
        len(ctx["fonte"]["A"].registros), len(ctx["fonte"]["B"].registros)))

    L.append("## 5. Regras aplicadas por campo comparado")
    L.append("")
    if not ctx["pares"]:
        L.append("Nenhum campo comparado.")
        L.append("")
    for par in ctx["pares"]:
        L.append("### Campo %s (A: %s, B: %s), perfil %s" % (par.label, par.col_a,
                                                             par.col_b, par.tipo))
        L.append("")
        if par.perfil_a:
            L.append("Perfil em A: %s. Perfil em B: %s." % (par.perfil_a["evidencia"],
                                                            par.perfil_b["evidencia"]))
            L.append("")
        L.extend(tabela_regras("", REGRAS_POR_PERFIL[par.tipo], par.regras_a, par.regras_b,
                               0, 0)[2:])
    L.append("")

    L.append("## 6. O que nao foi normalizado, por decisao")
    L.append("")
    for item in ctx["nao_normalizado"]:
        L.append("- %s" % item)
    L.append("")

    L.append("## 7. Ambiguidades nao resolvidas")
    L.append("")
    L.append("Decisoes de perfil que o arquivo nao decide. Sao as unicas que o modo "
             "--estrito trata como bloqueio.")
    L.append("")
    if not ctx["ambiguidades"]:
        L.append("Nenhuma.")
    for item in ctx["ambiguidades"]:
        L.append("- %s" % item)
    L.append("")

    L.append("## 7b. Achados que ficaram fora do pareamento")
    L.append("")
    L.append("Nao sao ambiguidade de normalizacao e nenhuma decisao de perfil resolve. "
             "Sao resultado da conferencia e pedem decisao de quem conhece o processo.")
    L.append("")
    if not ctx["achados"]:
        L.append("Nenhum.")
    for item in ctx["achados"]:
        L.append("- %s" % item)
    L.append("")

    L.append("## 8. Diferencas de formato ignoradas")
    L.append("")
    L.append("Nao sao divergencias. Os originais diferem, os valores normalizados sao "
             "iguais, e por isso ficam fora de divergencias.csv.")
    L.append("")
    if ctx["formato"]:
        L.append("| Campo | Regra que igualou | Ocorrencias |")
        L.append("|---|---|---|")
        for (campo, motivo), quantas in sorted(ctx["formato"].items()):
            L.append("| %s | %s | %d |" % (campo, motivo, quantas))
    else:
        L.append("Nenhuma.")
    L.append("")

    L.append("## 9. Irrecuperaveis")
    L.append("")
    L.append("Celulas que perderam informacao na origem e que nenhuma regra reconstroi. "
             "O caso classico e codigo longo salvo em notacao cientifica. Estas linhas "
             "ficam fora do pareamento e sao reportadas a parte, nao como orfas.")
    L.append("")
    total_irr = ctx["lado"]["A"]["irrecuperaveis"] + ctx["lado"]["B"]["irrecuperaveis"]
    if total_irr:
        for rot in ("A", "B"):
            linhas_irr = ctx["linhas_irrecuperaveis"][rot]
            if linhas_irr:
                L.append("- Fonte %s, linhas afetadas (%d): %s" % (
                    rot, len(linhas_irr), ", ".join(str(n) for n in linhas_irr[:50])))
    else:
        L.append("Nenhuma.")
    L.append("")

    L.append("## 10. Fechamento")
    L.append("")
    L.append("```")
    for linha in ctx["fechamento"]:
        L.append(linha)
    L.append("```")
    L.append("")
    if ctx.get("fecha") is False:
        L.append("**As contagens nao fecham. A rodada e invalida e nao deve ser "
                 "entregue.** Resultado que nao fecha nao e resultado parcial.")
        L.append("")
    L.append("As identidades acima saem dos mesmos contadores e fecham por construcao: "
             "elas provam que a contabilidade da rodada e consistente, nao que a rodada "
             "prestou. As verificacoes abaixo podem falhar de fato, e cada uma precisa de "
             "uma decisao registrada.")
    L.append("")
    for linha in (ctx["alertas"] or ["ainda nao calculado"]):
        L.append("- %s" % linha)
    L.append("")
    L.append("| Saida | Linhas |")
    L.append("|---|---|")
    L.append("| divergencias.csv | %d |" % ctx["n_divergencias"])
    L.append("| so-na-fonte-A.csv | %d |" % ctx["lado"]["A"]["linhas_no_arquivo_orfas"])
    L.append("| so-na-fonte-B.csv | %d |" % ctx["lado"]["B"]["linhas_no_arquivo_orfas"])
    L.append("| linhas-descartadas.csv | %d |" % ctx["n_descartadas"])
    L.append("")
    L.append("Cada CSV termina com uma linha de rodape iniciada por `#`. Ela e o rodape "
             "do artefato, nao um dado, e nao entra nas contagens acima.")
    L.append("")
    L.append("Vocabulario da coluna causa_provavel nos arquivos de fonte: `orfa` (nao "
             "existe do outro lado), `possivel_erro_de_normalizacao` (existe chave igual "
             "do outro lado depois de remover separadores ou zeros a esquerda), "
             "`chave_parecida_por_uma_edicao` (sinal fraco, pede olho humano), "
             "`duplicata_divergente` (a chave repete nesta fonte com conteudo diferente), "
             "`duplicata_divergente_no_outro_lado`, `chave_vazia`, `irrecuperavel`, "
             "`par_provavel_de_chave_irrecuperavel` (do outro lado existe uma chave em "
             "notacao cientifica cujos digitos sao prefixo desta. Nao e item faltante, e a "
             "mesma chave com digitos perdidos na origem).")
    L.append("")
    L.append("## 11. Limite declarado")
    L.append("")
    L.append("Este script nao acessa ERP e nao acessa servidor de arquivos. O export "
             "continua manual. Ele compara os dois arquivos que recebeu, nada mais.")
    L.append("")
    L.append(ctx["rodape"])
    L.append("")
    caminho.write_text("\n".join(L), encoding="utf-8")

# ---------------------------------------------------------------------------
# 8. Linha de comando
# ---------------------------------------------------------------------------


def construir_parser():
    p = argparse.ArgumentParser(
        prog="conferir.py",
        description="Confere duas fontes CSV da mesma realidade e devolve so as "
                    "divergencias, com a normalizacao declarada antes.",
        epilog="Codigos de saida: 0 as duas fontes tem as mesmas chaves e nenhum valor "
               "diverge, 1 ha divergencia de valor, 2 ambiguidade nao resolvida em modo "
               "--estrito, 3 erro de entrada, fechamento que nao fecha, nenhum par de "
               "campo, coluna sem par no emparelhamento automatico ou nenhuma chave "
               "pareada, 4 rodada em --so-nota, que nao compara nada, 5 a comparacao "
               "aconteceu, nenhum valor divergiu, e sobrou dado fora da comparacao de "
               "valor. Biblioteca padrao do Python 3.8 ou superior, sem instalacao.",
    )
    p.add_argument("--fonte-a", required=True, help="arquivo CSV da fonte A")
    p.add_argument("--fonte-b", required=True, help="arquivo CSV da fonte B")
    p.add_argument("--chave-a", help="coluna-chave em A, por nome ou por indice com #")
    p.add_argument("--chave-b", help="coluna-chave em B, por nome ou por indice com #")
    p.add_argument("--campos", help='pares de colunas a comparar, "a1:b1,a2:b2"')
    p.add_argument("--perfil-chave", choices=("codigo", "texto", "numero"), default="codigo")
    p.add_argument("--perfil-campo", help='tipo por campo, "campo:data,campo:numero"')
    p.add_argument("--zeros-esquerda", choices=("preservar", "completar", "remover"),
                   default="preservar")
    p.add_argument("--decimal", choices=("auto", "virgula", "ponto"), default="auto")
    p.add_argument("--data", choices=("auto", "dmy", "mdy", "iso", "serial"), default="auto")
    p.add_argument("--ausentes", default=AUSENTES_PADRAO,
                   help="marcadores tratados como vazio. Zero nunca entra por padrao")
    p.add_argument("--ignorar-acento-valor", action="store_true")
    p.add_argument("--ignorar-caixa-valor", action="store_true")
    p.add_argument("--tolerancia-numerica", default="0")
    p.add_argument("--tolerancia-relativa", default="0")
    p.add_argument("--preencher-para-baixo", default="")
    p.add_argument("--encoding-a", default="auto")
    p.add_argument("--encoding-b", default="auto")
    p.add_argument("--delimitador-a", default="auto")
    p.add_argument("--delimitador-b", default="auto")
    p.add_argument("--cabecalho-a", default="auto")
    p.add_argument("--cabecalho-b", default="auto")
    p.add_argument("--rodape", default="auto", help="auto, manter, ou o numero de linhas")
    p.add_argument("--saida", default=None)
    p.add_argument("--so-nota", action="store_true",
                   help="roda deteccao e normalizacao, escreve so a nota, nao compara")
    p.add_argument("--estrito", action="store_true")
    p.add_argument("--amostras", action="store_true",
                   help="inclui exemplos de valores reais na nota. Desligado por causa do "
                        "modo de dado sensivel")
    p.add_argument("--formato-em-arquivo", action="store_true")
    p.add_argument("--forcar", action="store_true")
    return p


CAB_DIVERGENCIAS = ["chave_normalizada", "chave_original_a", "chave_original_b",
                    "linha_a", "linha_b", "campo", "valor_a", "valor_b",
                    "valor_a_norm", "valor_b_norm", "regra_campo", "classe",
                    "motivo_suspeita"]
CAB_ORFAS = ["chave_normalizada", "chave_original", "linha", "causa_provavel",
             "chave_parecida_do_outro_lado"]
CAB_FORMATO = ["chave_normalizada", "linha_a", "linha_b", "campo", "valor_a", "valor_b",
               "valor_normalizado", "regra_que_igualou"]
CAB_DESCARTES = ["lado", "linha", "tipo", "causa", "conteudo_da_linha"]


def linhas_descartadas(fonte, rot):
    """Uma linha por registro que saiu do pareamento, com a causa e o conteudo."""
    linhas = []
    for linha, motivo, valores in fonte.rodape:
        conteudo = " | ".join((valores.get(c) or "") for c in fonte.colunas)
        linhas.append([rot, str(linha), "rodape", motivo, conteudo])
    for linha, motivo, campos in fonte.descartes:
        conteudo = " | ".join((c or "") for c in campos)
        linhas.append([rot, str(linha), "leitura", motivo, conteudo])
    linhas.sort(key=lambda l: int(l[1]))
    return linhas


def executar(args):
    hoje = date.today().isoformat()
    fonte = {"A": Fonte("A", args.fonte_a), "B": Fonte("B", args.fonte_b)}
    fonte["A"].carregar(args)
    fonte["B"].carregar(args)
    fa, fb = fonte["A"], fonte["B"]
    ausentes = montar_ausentes(args.ausentes)
    try:
        args.tolerancia_numerica = Decimal(str(args.tolerancia_numerica).replace(",", "."))
        args.tolerancia_relativa = Decimal(str(args.tolerancia_relativa).replace(",", "."))
    except InvalidOperation:
        raise ErroDeEntrada("tolerancia precisa ser numero")

    # O rodape sai antes da deteccao de chave. Linha de total e linha sem codigo
    # contam como vazio na medicao das candidatas e reprovam a coluna certa pelo
    # limite de 5% de vazio, num arquivo cuja chave se chama Codigo.
    detectar_rodape(fa, args.rodape)
    detectar_rodape(fb, args.rodape)

    if args.chave_a or args.chave_b:
        chave_a = resolver_coluna(fa, args.chave_a or args.chave_b)
        chave_b = resolver_coluna(fb, args.chave_b or args.chave_a)
        evidencia_chave = "coluna-chave informada na linha de comando"
    else:
        chave_a, chave_b, evidencia_chave = detectar_chave(fa, fb)

    detectar_rodape(fa, args.rodape, chave_a)
    detectar_rodape(fb, args.rodape, chave_b)
    total_rodape = {"A": verificar_total_rodape(fa), "B": verificar_total_rodape(fb)}
    status_total = {"A": status_total_rodape(fa, total_rodape["A"]),
                    "B": status_total_rodape(fb, total_rodape["B"])}
    detectar_mesclagem(fa)
    detectar_mesclagem(fb)
    for nome in [c.strip() for c in args.preencher_para_baixo.split(",") if c.strip()]:
        achou = False
        for f in (fa, fb):
            alvo = None
            for col in f.colunas:
                if chave_simples(col) == chave_simples(nome):
                    alvo = col
                    break
            if alvo:
                preencher_para_baixo(f, [alvo])
                achou = True
        if not achou:
            raise ErroDeEntrada("coluna %s de --preencher-para-baixo nao existe nas fontes"
                                % nome)

    largura = None
    if args.zeros_esquerda == "completar":
        largura = largura_constante(fa, chave_a) or largura_constante(fb, chave_b)
        if not largura:
            raise ErroDeEntrada(
                "--zeros-esquerda completar exige largura constante em uma das fontes. "
                "Nenhuma das duas tem chave numerica de largura unica. Use remover ou "
                "preservar e declare o efeito na nota"
            )
    perfil_num_chave = None
    if args.perfil_chave == "numero":
        perfil_num_chave = perfilar_coluna_numerica(amostrar(fa, chave_a), args.decimal)
    opcoes = {"ausentes": ausentes, "zeros": args.zeros_esquerda, "largura": largura,
              "perfil_num": perfil_num_chave}

    fusao = {}
    for rot, f, col in (("A", fa, chave_a), ("B", fb, chave_b)):
        if args.perfil_chave == "codigo":
            fusao[rot] = contar_fusao(f, col, opcoes)
        else:
            vistos = set()
            for r in f.registros:
                valor, estado = expandir_ou_marcar(r["_valores"].get(col, ""))
                if estado == "irrecuperavel":
                    continue
                v, _ = norm_texto(aplicar_ausentes(valor, ausentes),
                                  acento=True, caixa=True)
                if v:
                    vistos.add(v)
            distintos = len(vistos)
            fusao[rot] = (distintos, distintos, distintos)
    fusao_suspeita = any(v[1] < v[0] or v[2] < v[1] for v in fusao.values())

    ind_a, vazias_a, irr_a, regras_chave_a = indexar(fa, chave_a, args.perfil_chave, opcoes)
    ind_b, vazias_b, irr_b, regras_chave_b = indexar(fb, chave_b, args.perfil_chave, opcoes)
    unico_a, dup_div_a, colaps_a, extras_a = resolver_duplicatas(ind_a)
    unico_b, dup_div_b, colaps_b, extras_b = resolver_duplicatas(ind_b)
    pares, sem_par, origem_pares = montar_pares(fa, fb, chave_a, chave_b, args)
    if not pares:
        raise ErroDeEntrada(
            "nenhum campo ficou emparelhado entre as duas fontes, so a chave. Sair com "
            "codigo 0 aqui seria dizer que as fontes batem sem ter comparado nada. Nome de "
            "coluna igual nas duas fontes e excecao, nao regra. Colunas de A: %s. Colunas "
            'de B: %s. Informe os pares com --campos "colunaA:colunaB,..."'
            % (", ".join(fa.colunas), ", ".join(fb.colunas)))
    # Guarda proporcional, nao "zero coluna emparelhada". Uma unica coluna com
    # nome igual por acaso (Descricao, Setor, Obs, Data) bastava para a rodada
    # seguir com todas as outras fora da comparacao e sair com codigo 0. No
    # emparelhamento automatico, qualquer coluna sem par derruba a rodada. Com
    # --campos a exclusao e decisao declarada e so e impressa.
    if sem_par and origem_pares == "auto":
        raise ErroDeEntrada(
            "no emparelhamento automatico ficaram colunas sem par, fora da comparacao: "
            "%s. Sair com codigo 0 aqui seria dizer que as fontes batem sem ter comparado "
            "estas colunas. Colunas de A: %s. Colunas de B: %s. Informe os pares com "
            '--campos "colunaA:colunaB,...", e o que ficar fora de --campos fica fora por '
            "decisao declarada."
            % (", ".join(sem_par), ", ".join(fa.colunas), ", ".join(fb.colunas)))

    granularidade = ""
    if dup_div_a or dup_div_b:
        granularidade = (
            "Atencao. Chaves que repetem com conteudo diferente: A, %d; B, %d. "
            "Essas chaves nao foram pareadas e saem nos arquivos de fonte com causa "
            "duplicata_divergente. Se a repeticao for a regra e nao a excecao, as fontes "
            "nao tem a mesma granularidade e a conferencia precisa parar."
            % (len(dup_div_a), len(dup_div_b))
        )
    else:
        granularidade = "Nenhuma chave repete com conteudo diferente nas duas fontes."

    nao_normalizado = [
        "Zeros a esquerda na chave: regra %s." % args.zeros_esquerda,
        "Acento no valor comparado: %s." % ("ignorado por pedido" if args.ignorar_acento_valor
                                            else "comparado, cadastro escrito de duas "
                                                 "formas aparece como divergencia"),
        "Caixa no valor comparado: %s." % ("ignorada por pedido" if args.ignorar_caixa_valor
                                          else "comparada"),
        "Tolerancia numerica absoluta: %s. Tolerancia relativa: %s."
        % (fmt_num(args.tolerancia_numerica), fmt_num(args.tolerancia_relativa)),
        "Marcadores tratados como ausencia: %s." % args.ausentes,
        "Zero nao entra na lista de ausentes. Zero e um valor, e saldo zero contra saldo "
        "nao informado e divergencia real.",
        "Preenchimento para baixo de celula mesclada: %s."
        % (args.preencher_para_baixo or "desligado"),
        "Exemplos de valor real na nota: %s." % ("ligados por pedido explicito"
                                                 if args.amostras else "desligados"),
        "Busca de chave parecida do outro lado: sempre por separadores e por zeros a "
        "esquerda. O criterio de uma unica edicao roda apenas em chave com letra e com "
        "pelo menos 4 caracteres, porque em chave puramente numerica uma diferenca de um "
        "digito nao indica erro de normalizacao, indica outro item.",
    ]
    if sem_par:
        nao_normalizado.append(
            "Colunas sem par, fora da comparacao: %s. A exclusao foi declarada em "
            "--campos." % ", ".join(sem_par))

    ambiguidades = []
    for par in pares:
        if par.ambiguo:
            padrao = ("padrao dd/mm/aaaa com dia e mes menores ou iguais a 12"
                      if par.tipo == "data"
                      else "padrao com separador de 3 digitos, sem celula que decida "
                           "milhar ou decimal")
            extra = ""
            if args.amostras:
                extra = " Exemplos reais: %s." % ", ".join(amostrar(fa, par.col_a)[:3])
            ambiguidades.append(
                "Campo %s: %s (%s). Efeito na saida: toda divergencia do campo sai com "
                "classe suspeita.%s" % (par.label, par.motivo, padrao, extra))
    if fusao_suspeita:
        ambiguidades.append(
            "Chave: alguma regra reduziu a contagem de chaves distintas, sinal de fusao de "
            "itens que o cadastro distingue. Efeito: toda divergencia sai como suspeita.")
    for rot in ("A", "B"):
        for col, taxa, _blocos in fonte[rot].mesclagem:
            ambiguidades.append(
                "Fonte %s, coluna %s: %d%% de vazios em padrao de celula mesclada. Efeito: "
                "nada foi preenchido, a coluna pode estar incompleta na comparacao."
                % (rot, col, taxa))
    # Duplicata divergente, irrecuperavel, total que nao confere e linha descartada
    # nao sao ambiguidade de normalizacao: nenhuma decisao de perfil resolve. Ficam
    # separados para que --estrito nao derrube a rodada por causa deles.
    achados = []
    if dup_div_a or dup_div_b:
        achados.append(
            "Duplicatas divergentes, chaves que repetem com conteudo diferente e ficaram "
            "fora do pareamento: A, %d; B, %d. Saem em so-na-fonte-X.csv com causa "
            "duplicata_divergente." % (len(dup_div_a), len(dup_div_b)))
    if irr_a or irr_b:
        achados.append(
            "Irrecuperaveis, linhas com chave em notacao cientifica sem digitos "
            "suficientes, fora do pareamento: A, %d; B, %d. Cada uma sai em "
            "so-na-fonte-X.csv com a chave longa do outro lado quando existe."
            % (len(irr_a), len(irr_b)))
    for rot in ("A", "B"):
        f = fonte[rot]
        if f.descartes_com_conteudo:
            achados.append(
                "Fonte %s, linhas com conteudo que sairam na leitura por contagem de "
                "coluna diferente do cabecalho: %d. Elas nunca entraram na comparacao. "
                "Causa comum: o delimitador aparece dentro de uma celula sem aspas. "
                "Estao em linhas-descartadas.csv com o conteudo."
                % (rot, f.descartes_com_conteudo))
    for rot in ("A", "B"):
        for linha, col, confere in total_rodape[rot]:
            if not confere:
                achados.append(
                    "Fonte %s, total declarado na linha %d, coluna %s: NAO confere com a "
                    "soma das linhas mantidas. Confira se o arquivo perdeu linha antes da "
                    "conferencia comecar." % (rot, linha, col))
        f = fonte[rot]
        if f.rodape or f.descartes:
            achados.append(
                "Fonte %s, linhas que sairam do pareamento: %d de rodape, %d na leitura. "
                "Todas estao em linhas-descartadas.csv, com a linha, a causa e o conteudo."
                % (rot, len(f.rodape), len(f.descartes)))

    saida = Path(args.saida) if args.saida else Path("conferencia-%s" % hoje)
    if saida.exists() and not args.forcar:
        raise ErroDeEntrada(
            "o diretorio de saida %s ja existe. Use --saida com outro nome ou --forcar"
            % saida)
    saida.mkdir(parents=True, exist_ok=True)

    lado = {}
    for rot, f, ind, vazias, irr, colaps, extras, dup_div in (
        ("A", fa, ind_a, vazias_a, irr_a, colaps_a, extras_a, dup_div_a),
        ("B", fb, ind_b, vazias_b, irr_b, colaps_b, extras_b, dup_div_b),
    ):
        lado[rot] = {
            "registros_lidos": f.registros_lidos,
            "descartadas": len(f.descartes) + len(f.rodape),
            "chave_vazia": len(vazias),
            "irrecuperaveis": len(irr),
            "nao_chaveaveis": len(vazias) + len(irr),
            "chaves_distintas": len(ind),
            "duplicatas_extras": extras,
            "colapsadas": colaps,
            "nao_pareaveis": len(dup_div),
            "linhas_duplicata_divergente": sum(len(v) for v in dup_div.values()),
            "rodape": len(f.rodape),
            "descartes_leitura": len(f.descartes),
            "so_em": 0,
            "linhas_no_arquivo_orfas": 0,
        }

    alertas = [
        "campos comparados: %d (zero invalida a rodada)" % len(pares),
        "colunas sem par, fora da comparacao: %s" % (
            (", ".join(sem_par) + " (declaradas em --campos)") if sem_par else "nenhuma"),
        "colunas em padrao de celula mesclada: A %s | B %s" % (
            ", ".join(c for c, _t, _b in fa.mesclagem) or "nenhuma",
            ", ".join(c for c, _t, _b in fb.mesclagem) or "nenhuma"),
        "linhas descartadas: rodape A %d, B %d | leitura A %d, B %d, todas em "
        "linhas-descartadas.csv" % (len(fa.rodape), len(fb.rodape),
                                    len(fa.descartes), len(fb.descartes)),
        "linhas com conteudo perdidas na leitura, nunca comparadas: A %d, B %d"
        % (fa.descartes_com_conteudo, fb.descartes_com_conteudo),
        "total do rodape: A, %s | B, %s" % (status_total["A"], status_total["B"]),
        "chaves irrecuperaveis: A %d, B %d" % (len(irr_a), len(irr_b)),
        "duplicatas divergentes: A %d, B %d" % (len(dup_div_a), len(dup_div_b)),
    ]

    ctx = {
        "hoje": hoje, "fonte": fonte, "lado": lado, "pares": pares,
        "chave_a": chave_a, "chave_b": chave_b, "perfil_chave": args.perfil_chave,
        "evidencia_chave": evidencia_chave, "nota_granularidade": granularidade,
        "fusao": fusao, "fusao_suspeita": fusao_suspeita,
        "regras_chave_a": regras_chave_a, "regras_chave_b": regras_chave_b,
        "nao_normalizado": nao_normalizado, "ambiguidades": ambiguidades,
        "achados": achados, "alertas": alertas, "status_total": status_total,
        "n_descartadas": sum(len(f.rodape) + len(f.descartes) for f in (fa, fb)),
        "formato": {}, "total_rodape": total_rodape,
        "linhas_irrecuperaveis": {"A": [r["_linha"] for r in irr_a],
                                  "B": [r["_linha"] for r in irr_b]},
        "pareadas": 0, "iguais": 0, "com_divergencia": 0, "n_divergencias": 0,
        "fechamento": ["ainda nao calculado"],
        "rodape": RODAPE_ARTEFATO.format(
            fontes="%s e %s" % (fa.caminho.name, fb.caminho.name)),
    }

    caminho_nota = saida / "nota-de-normalizacao.md"
    escrever_nota(caminho_nota, ctx, "incompleto")
    escrever_csv(saida / "linhas-descartadas.csv", CAB_DESCARTES,
                 linhas_descartadas(fa, "A") + linhas_descartadas(fb, "B"), ctx["rodape"])
    if args.so_nota:
        ctx["fechamento"] = ["rodada em modo --so-nota, nenhuma comparacao foi feita"]
        escrever_nota(caminho_nota, ctx, "so-nota, sem comparacao")
        sys.stdout.write(
            "modo --so-nota: decisoes de leitura e normalizacao escritas, nenhuma "
            "comparacao feita. Codigo de saida 4, que nao e 0: 0 significaria rodou e "
            "nao ha divergencia.\ndiretorio: %s\n" % saida.resolve())
        for linha in alertas:
            sys.stdout.write("  %s\n" % linha)
        return 4

    mescladas = {"A": set(c for c, _t, _b in fa.mesclagem),
                 "B": set(c for c, _t, _b in fb.mesclagem)}
    divergencias, formato, exemplos_formato, iguais, com_div = comparar(
        pares, unico_a, unico_b, args, opcoes, fusao_suspeita, mescladas)
    divergencias.sort(key=lambda l: (0 if l[11] == "suspeita" else 1, l[0], l[5]))

    pareaveis_a, pareaveis_b = set(unico_a), set(unico_b)
    pareadas = pareaveis_a & pareaveis_b
    so_a = sorted(pareaveis_a - pareaveis_b)
    so_b = sorted(pareaveis_b - pareaveis_a)
    orcamento = [2000000]
    aux_a = indices_auxiliares(ind_a)
    aux_b = indices_auxiliares(ind_b)

    def linhas_orfas(chaves, unico, dup_div, vazias, irr, aux_outro, ind_outro, f,
                     irr_outro):
        linhas = []
        for chave in chaves:
            reg = unico[chave]
            if chave in ind_outro:
                causa, parecida = "duplicata_divergente_no_outro_lado", chave
            else:
                sosia, criterio = buscar_sosia(chave, aux_outro, orcamento, irr_outro)
                if criterio == "irrecuperavel":
                    causa, parecida = "par_provavel_de_chave_irrecuperavel", sosia
                elif sosia and criterio == "edicao":
                    causa, parecida = "chave_parecida_por_uma_edicao", sosia
                elif sosia:
                    causa, parecida = "possivel_erro_de_normalizacao", sosia
                else:
                    causa, parecida = "orfa", ""
            linhas.append([chave, reg["_chave_bruta"], str(reg["_linha"]), causa, parecida]
                          + [reg["_valores"].get(c, "") for c in f.colunas])
        for chave in sorted(dup_div):
            for reg in dup_div[chave]:
                linhas.append([chave, reg["_chave_bruta"], str(reg["_linha"]),
                               "duplicata_divergente", ""]
                              + [reg["_valores"].get(c, "") for c in f.colunas])
        for reg in vazias:
            linhas.append(["", reg["_chave_bruta"], str(reg["_linha"]), "chave_vazia", ""]
                          + [reg["_valores"].get(c, "") for c in f.colunas])
        for reg in irr:
            linhas.append(["", reg["_chave_bruta"], str(reg["_linha"]), "irrecuperavel",
                           chave_longa_do_outro_lado(reg["_chave_bruta"], ind_outro)]
                          + [reg["_valores"].get(c, "") for c in f.colunas])
        return linhas

    orfas_a = linhas_orfas(so_a, unico_a, dup_div_a, vazias_a, irr_a, aux_b, ind_b, fa,
                           irr_b)
    orfas_b = linhas_orfas(so_b, unico_b, dup_div_b, vazias_b, irr_b, aux_a, ind_a, fb,
                           irr_a)

    # Achado agregado de acento: na primeira rodada de um cadastro escrito de
    # duas formas, a maioria das divergencias de texto e so o acento. A regra de
    # comparar acento e a correta por padrao (cadastro divergente e achado), mas
    # sem esta linha o ruido esconde a divergencia de verdade.
    if not args.ignorar_acento_valor and divergencias:
        def _sem_acento(t):
            d = unicodedata.normalize("NFD", t)
            return "".join(c for c in d if unicodedata.category(c) != "Mn").casefold()
        so_acento = sum(1 for d in divergencias
                        if d[6] != d[7] and _sem_acento(d[6]) == _sem_acento(d[7]))
        if so_acento and so_acento >= max(3, len(divergencias) // 2):
            achados.append(
                "%d das %d divergencias sao diferenca de acento apenas, o mesmo texto "
                "escrito de duas formas no cadastro. Isso e achado real (o cadastro "
                "diverge), e nao erro da conferencia. Para ver so o resto, rode de novo "
                "com --ignorar-acento-valor." % (so_acento, len(divergencias)))

    # Achado agregado: quando boa parte das orfas de um lado tem sosia do outro
    # lado, o que aconteceu nao foi item faltante, foi chave normalizada de um
    # jeito em cada fonte. Sem esta linha a pessoa le "25 orfas" no resumo e
    # conclui que a conferencia nao funcionou, embora cada linha do arquivo ja
    # traga a causa e a chave parecida.
    for rot, orfas in (("A", orfas_a), ("B", orfas_b)):
        suspeitas = sum(1 for l in orfas
                        if l[3] in ("possivel_erro_de_normalizacao",
                                    "par_provavel_de_chave_irrecuperavel"))
        if suspeitas and orfas and suspeitas >= max(3, len(orfas) // 2):
            achados.append(
                "Fonte %s, %d das %d linhas sem par tem chave parecida do outro lado "
                "(coluna chave_parecida_do_outro_lado em so-na-fonte-%s.csv). Isso e "
                "chave escrita de um jeito em cada fonte, nao item faltante. Confira a "
                "secao de zeros a esquerda da nota e rode de novo com "
                "--zeros-esquerda remover ou --zeros-esquerda completar."
                % (rot, suspeitas, len(orfas), rot))

    lado["A"]["so_em"] = len(so_a)
    lado["B"]["so_em"] = len(so_b)
    lado["A"]["linhas_no_arquivo_orfas"] = len(orfas_a)
    lado["B"]["linhas_no_arquivo_orfas"] = len(orfas_b)
    alertas.insert(1, "chaves pareadas nas duas fontes: %d (zero invalida a rodada)"
                   % len(pareadas))
    ctx["pareadas"] = len(pareadas)
    ctx["iguais"] = iguais
    ctx["com_divergencia"] = com_div
    ctx["n_divergencias"] = len(divergencias)
    ctx["formato"] = formato

    escrever_csv(saida / "divergencias.csv", CAB_DIVERGENCIAS, divergencias, ctx["rodape"])
    escrever_csv(saida / "so-na-fonte-A.csv", CAB_ORFAS + fa.colunas, orfas_a, ctx["rodape"])
    escrever_csv(saida / "so-na-fonte-B.csv", CAB_ORFAS + fb.colunas, orfas_b, ctx["rodape"])
    if args.formato_em_arquivo:
        escrever_csv(saida / "diferencas-de-formato.csv", CAB_FORMATO, exemplos_formato,
                     ctx["rodape"])

    fechamento, fecha = fechar_contagens(ctx)
    ctx["fechamento"] = fechamento
    ctx["fecha"] = fecha
    escrever_nota(caminho_nota, ctx, "completo" if fecha else "invalido, nao fecha")

    sys.stdout.write("FECHAMENTO\n")
    for linha in fechamento:
        sys.stdout.write("  %s\n" % linha)
    sys.stdout.write(
        "  divergencias: %d linhas (%d chaves), suspeitas: %d\n"
        % (len(divergencias), com_div,
           sum(1 for l in divergencias if l[11] == "suspeita")))
    sys.stdout.write("  so na fonte A: %d linhas | so na fonte B: %d linhas\n"
                     % (len(orfas_a), len(orfas_b)))
    sys.stdout.write("  diferencas de formato ignoradas: %d\n"
                     % sum(formato.values()))
    sys.stdout.write("VERIFICACOES QUE PODEM FALHAR DE FATO\n")
    for linha in alertas:
        sys.stdout.write("  %s\n" % linha)
    if achados:
        sys.stdout.write("ACHADOS QUE NAO SAO AMBIGUIDADE\n")
        for item in achados:
            sys.stdout.write("  %s\n" % item)
    sys.stdout.write("diretorio: %s\n" % saida.resolve())
    sys.stdout.write("leia nota-de-normalizacao.md antes de divergencias.csv\n")

    if not fecha:
        sys.stderr.write("as contagens nao fecham, a rodada e invalida\n")
        return 3
    if not pareadas:
        sys.stderr.write(
            "nenhuma chave pareou entre as duas fontes: nada foi comparado, a rodada nao "
            "vale. Confira a coluna-chave dos dois lados e a regra de zeros a esquerda. As "
            "linhas de cada lado estao em so-na-fonte-A.csv e so-na-fonte-B.csv\n")
        return 3
    if args.estrito and ambiguidades:
        sys.stderr.write("modo estrito: %d ambiguidades nao resolvidas\n" % len(ambiguidades))
        return 2
    if divergencias:
        return 1
    # Codigo 0 significa "as duas fontes tem as mesmas chaves e nenhum valor
    # diverge". Nao pode ser devolvido com linha que nunca entrou na comparacao
    # de valor: linha perdida na leitura, chave que existe so de um lado, chave
    # que repete com conteudo diferente, chave vazia ou chave irrecuperavel. Sao
    # linhas visiveis nos arquivos de saida, e por isso mesmo a rodada nao pode
    # sair com o codigo que dispensa a leitura deles.
    fora = []
    for rot, f, so_em, dup_div, vazias, irr in (
        ("A", fa, so_a, dup_div_a, vazias_a, irr_a),
        ("B", fb, so_b, dup_div_b, vazias_b, irr_b),
    ):
        if f.descartes_com_conteudo:
            fora.append("fonte %s, %d linha(s) com conteudo perdida(s) na leitura"
                        % (rot, f.descartes_com_conteudo))
        if so_em:
            fora.append("fonte %s, %d chave(s) que existem so nela" % (rot, len(so_em)))
        if dup_div:
            fora.append("fonte %s, %d chave(s) que repetem com conteudo diferente"
                        % (rot, len(dup_div)))
        if vazias:
            fora.append("fonte %s, %d linha(s) de chave vazia" % (rot, len(vazias)))
        if irr:
            fora.append("fonte %s, %d chave(s) irrecuperavel(is)" % (rot, len(irr)))
    if fora:
        sys.stderr.write(
            "nenhum valor divergente entre as chaves que existem nas duas fontes, mas "
            "ficou dado fora dessa comparacao: %s. Codigo 5, que nao e 0: 0 diria que as "
            "duas fontes tem as mesmas chaves e nenhum valor diverge. Confira "
            "linhas-descartadas.csv, so-na-fonte-A.csv e so-na-fonte-B.csv antes de "
            "fechar\n" % "; ".join(fora))
        return 5
    return 0


def main(argv=None):
    args = construir_parser().parse_args(argv)
    try:
        return executar(args)
    except ErroDeEntrada as exc:
        sys.stderr.write("erro de entrada: %s\n" % exc)
        return 3


if __name__ == "__main__":
    sys.exit(main())
