#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""testar.py, teste de regressao de conferir.py.

Gera os casos em diretorio temporario, roda conferir.py em cada um e confere a
saida contra o esperado. Um caso por defeito que passou pela revisao: item real
cuja chave contem marcador de total, nenhuma coluna coincidindo entre as fontes,
linha de celulas vazias no fim do arquivo, rodape descartado sem rastro, chave
detectada com rodape ainda no arquivo, celula mesclada, notacao cientifica dos
dois lados, e os casos de normalizacao que a skill promete tratar.

Os seis ultimos casos cobrem a mesma doenca em lugares diferentes: caminho em que
o script sai com codigo 0 depois de nao comparar dado. Rodape de ERP com linha de
identificacao abaixo do total, uma unica coluna emparelhando por acaso, coluna
excluida por --campos sem aparecer na lista, a referencia de normalizacao
prescrevendo a deteccao que o script rejeita, linha com conteudo perdida na
leitura, e chave que existe so de um lado ou repete com conteudo diferente.

DEPENDENCIA DECLARADA: biblioteca padrao do Python 3.8 ou superior.

Depois da instalacao a skill fica em ~/.claude/skills/conferencia-entre-duas-fontes/.
Chame pelo caminho completo, porque a rodada acontece na pasta dos arquivos de
trabalho e nao na pasta da skill:

    python3 ~/.claude/skills/conferencia-entre-duas-fontes/scripts/testar.py

No Windows, no PowerShell:

    py -3 "$env:USERPROFILE\.claude\skills\conferencia-entre-duas-fontes\scripts\testar.py"

Sai com codigo 0 quando todos os casos passam, 1 quando qualquer um falha.
"""

import csv
import io
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
CONFERIR = AQUI / "conferir.py"


# ---------------------------------------------------------------------------
# Andaime
# ---------------------------------------------------------------------------


class Caso(object):
    def __init__(self, nome):
        self.nome = nome
        self.checagens = []

    def exigir(self, o_que, esperado, veio):
        self.checagens.append((esperado == veio, o_que, esperado, veio))

    def quebrou(self, exc):
        self.checagens.append((False, "o caso rodou sem excecao", "sem excecao",
                               "%s: %s" % (type(exc).__name__, exc)))

    @property
    def passou(self):
        return all(c[0] for c in self.checagens) and bool(self.checagens)

    def imprimir(self):
        sys.stdout.write("\n%s: %s\n" % ("PASSOU" if self.passou else "FALHOU", self.nome))
        for ok, o_que, esperado, veio in self.checagens:
            sys.stdout.write("  %-6s %s\n" % ("PASSOU" if ok else "FALHOU", o_que))
            if not ok:
                sys.stdout.write("         esperado: %r\n" % (esperado,))
                sys.stdout.write("         veio:     %r\n" % (veio,))


def escrever(caminho, linhas, encoding="utf-8"):
    with io.open(str(caminho), "w", encoding=encoding, newline="\n") as fh:
        fh.write("\n".join(linhas) + "\n")


def rodar(base, nome_saida, extra, arquivo_a="a.csv", arquivo_b="b.csv"):
    saida = base / nome_saida
    cmd = [sys.executable, str(CONFERIR),
           "--fonte-a", str(base / arquivo_a), "--fonte-b", str(base / arquivo_b),
           "--saida", str(saida)] + list(extra)
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = p.stdout.decode("utf-8", "replace")
    err = p.stderr.decode("utf-8", "replace")
    return p.returncode, out, err, saida


def ler_texto(caminho):
    if not Path(str(caminho)).exists():
        return ""
    with io.open(str(caminho), encoding="utf-8-sig") as fh:
        return fh.read()


def ler_csv(caminho):
    """Linhas de um CSV de saida, sem a linha de rodape do artefato."""
    if not Path(str(caminho)).exists():
        return []
    with io.open(str(caminho), encoding="utf-8-sig", newline="") as fh:
        leitor = csv.DictReader(fh, delimiter=";")
        linhas = []
        for linha in leitor:
            primeira = (list(linha.values())[0] or "")
            if primeira.startswith("#"):
                continue
            linhas.append(linha)
        return linhas


def causas(linhas):
    return dict((l["chave_original"], l["causa_provavel"]) for l in linhas)


# ---------------------------------------------------------------------------
# Casos
# ---------------------------------------------------------------------------


def caso_marcador_na_chave(base):
    """Item real cuja chave contem GERAL, TOTAL, SOMA ou SUBTOTAL nao e descartado."""
    c = Caso("item real com marcador de total na chave aparece na saida")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "TOTAL-7;Barra total;5",
        "SOMA-3;Kit soma;7",
        "SUBTOTAL-9;Peca subtotal;4",
        "GERAL-500;Suporte geral;30",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "TOTAL-7;Barra total;6",
        "SOMA-3;Kit soma;7",
        "SUBTOTAL-9;Peca subtotal;4",
        "GERAL-500;Suporte geral;31",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    div = ler_csv(saida / "divergencias.csv")
    descartadas = ler_texto(saida / "linhas-descartadas.csv")
    chaves = set(l["chave_normalizada"] for l in div)
    c.exigir("codigo de saida 1, ha divergencia", 1, rc)
    c.exigir("GERAL-500 aparece em divergencias.csv", True, "geral500" in chaves)
    c.exigir("TOTAL-7 aparece em divergencias.csv", True, "total7" in chaves)
    c.exigir("nenhum item foi para linhas-descartadas.csv", 0,
             len(ler_csv(saida / "linhas-descartadas.csv")))
    for marcador in ("GERAL-500", "TOTAL-7", "SOMA-3", "SUBTOTAL-9"):
        c.exigir("%s fora de linhas-descartadas.csv" % marcador, False,
                 marcador in descartadas)
    c.exigir("o bloco de verificacoes foi impresso", True,
             "VERIFICACOES QUE PODEM FALHAR DE FATO" in out)
    c.exigir("o terminal diz quantos campos foram comparados", True,
             "campos comparados: 2" in out)
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_nenhuma_coluna_coincide(base):
    """Sem par de campo, a rodada falha alto em vez de imprimir fecha."""
    c = Caso("nenhum nome de coluna coincide entre as fontes")
    escrever(base / "a.csv", [
        "Codigo;Descr;Qtde",
        "100;Eixo;99",
        "200;Bucha;30",
    ])
    escrever(base / "b.csv", [
        "Codigo,Descricao do item,Quantidade",
        "100,Eixo,50",
        "200,Bucha,31",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    c.exigir("codigo de saida diferente de zero", True, rc != 0)
    c.exigir("codigo de saida 3", 3, rc)
    c.exigir("mensagem diz que nenhum campo emparelhou", True,
             "nenhum campo ficou emparelhado" in err)
    c.exigir("mensagem lista as colunas de A", True, "Qtde" in err)
    c.exigir("mensagem lista as colunas de B", True, "Quantidade" in err)
    c.exigir("mensagem ensina o --campos", True, "--campos" in err)
    c.exigir("nao imprimiu fecha", False, "fecha" in out)
    c.exigir("nao escreveu diretorio de saida", False, saida.exists())
    return c


def caso_linha_vazia_no_fim(base):
    """A linha de celulas vazias do Excel nao desliga a deteccao de rodape."""
    c = Caso("linha de celulas vazias no fim do arquivo")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
        "TOTAL GERAL;;30",
        ";;",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    desc = ler_csv(saida / "linhas-descartadas.csv")
    tipos = dict((l["linha"], l["tipo"]) for l in desc)
    orfas_a = ler_csv(saida / "so-na-fonte-A.csv")
    c.exigir("codigo de saida 0, sem divergencia", 0, rc)
    c.exigir("a linha de total foi reconhecida como rodape", "rodape", tipos.get("4"))
    c.exigir("a linha vazia foi registrada como descarte de leitura", "leitura",
             tipos.get("5"))
    c.exigir("a conferencia do total do rodape aconteceu", True,
             "total declarado na linha 4" in nota)
    c.exigir("o total do rodape confere com a soma das linhas mantidas", True,
             "coluna Quantidade: confere com a soma das linhas mantidas" in nota)
    c.exigir("TOTAL GERAL nao entrou como item orfao", False,
             any("TOTAL GERAL" in (l["chave_original"] or "") for l in orfas_a))
    c.exigir("a fonte B declara que nao tem linha de total", True,
             "Fonte B, conferencia do total do rodape: nenhuma linha de total" in nota)
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_rodape_registrado(base):
    """Rodape de chave vazia sai no arquivo, com a causa, e --rodape N nao descarta duas vezes."""
    c = Caso("rodape descartado aparece na saida com a causa")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
        ";Fechamento do mes;",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    desc = ler_csv(saida / "linhas-descartadas.csv")
    por_linha = dict((l["linha"], l) for l in desc)
    c.exigir("codigo de saida 0", 0, rc)
    c.exigir("uma linha descartada registrada", 1, len(desc))
    c.exigir("a causa do descarte esta escrita", True,
             "chave vazia" in (por_linha.get("4", {}).get("causa") or ""))
    c.exigir("o conteudo da linha descartada esta no arquivo", True,
             "Fechamento do mes" in (por_linha.get("4", {}).get("conteudo_da_linha") or ""))
    c.exigir("o terminal aponta o arquivo de descartes", True,
             "linhas-descartadas.csv" in out)
    rc2, out2, err2, saida2 = rodar(base, "r2", ["--chave-a", "Codigo", "--chave-b", "Codigo",
                                                 "--rodape", "1"])
    desc2 = ler_csv(saida2 / "linhas-descartadas.csv")
    c.exigir("--rodape 1 descarta exatamente uma linha em A", 1,
             len([l for l in desc2 if l["lado"] == "A"]))
    c.exigir("--rodape 1 descarta exatamente uma linha em B", 1,
             len([l for l in desc2 if l["lado"] == "B"]))
    c.exigir("fechamento sem QUEBRA em --rodape 1", False, "QUEBRA" in out2)
    return c


def caso_chave_detectada_com_rodape(base):
    """A deteccao de chave roda depois do rodape e nao escolhe coluna de data."""
    c = Caso("chave detectada com rodape no arquivo e coluna de data presente")
    linhas_a = [
        "Codigo;Descricao;Quantidade;Data Entrega",
        "100;Eixo;10;2026-04-01",
        "200;Bucha;10;2026-04-02",
        "300;Eixo;10;2026-04-03",
        "400;Mancal;5;2026-04-04",
        "500;Flange;5;2026-04-05",
        "600;Tampa;5;2026-04-06",
        ";TOTAL GERAL;45;",
    ]
    escrever(base / "a.csv", linhas_a)
    escrever(base / "b.csv", linhas_a)
    rc, out, err, saida = rodar(base, "r", [])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    c.exigir("a rodada nao morreu na deteccao de chave", True, rc in (0, 1))
    c.exigir("a chave escolhida foi Codigo", True,
             "| Coluna-chave | Codigo | Codigo |" in nota)
    c.exigir("a coluna de data nao virou chave", False,
             "| Coluna-chave | Data Entrega" in nota)
    c.exigir("o rodape saiu antes da deteccao", 1,
             len([l for l in ler_csv(saida / "linhas-descartadas.csv") if l["lado"] == "A"]))
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_normalizacao(base):
    """Zero a esquerda, virgula decimal, data em dois formatos, encoding, duplicata, orfa."""
    c = Caso("casos de normalizacao: zeros, decimal, data, encoding, duplicata, orfa")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade;Data Entrega",
        "001150;Válvula;1.234,50;05/04/2026",
        "002200;Bucha;10;06/04/2026",
        "003300;Eixo;7;25/04/2026",
        "004400;Mancal;3;01/03/2026",
        "005500;Flange;12;02/03/2026",
        "005500;Flange grande;12;02/03/2026",
    ], encoding="cp1252")
    escrever(base / "b.csv", [
        "Codigo,Descricao,Quantidade,Data Entrega",
        "1150,Válvula,1234.50,2026-04-05",
        "2200,Bucha,11,2026-04-06",
        "3300,Eixo,7,2026-05-25",
        "5500,Flange,12,2026-03-02",
        "006600,Tampa,9,2026-03-05",
    ], encoding="utf-8")
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo",
                                            "--zeros-esquerda", "remover"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    div = ler_csv(saida / "divergencias.csv")
    achado = set((l["chave_normalizada"], l["campo"]) for l in div)
    classes = dict(((l["chave_normalizada"], l["campo"]), l["classe"]) for l in div)
    ca = causas(ler_csv(saida / "so-na-fonte-A.csv"))
    cb = causas(ler_csv(saida / "so-na-fonte-B.csv"))
    c.exigir("codigo de saida 1", 1, rc)
    c.exigir("encoding de A detectado como cp1252", True, "| A | cp1252 |" in nota)
    c.exigir("delimitador de A detectado", True, "| ; |" in nota)
    c.exigir("delimitador de B detectado", True, "| , |" in nota)
    c.exigir("zero a esquerda pareou 001150 com 1150", False,
             any(k == "1150" for k, _campo in achado))
    c.exigir("virgula contra ponto nao virou divergencia", False, ("1150", "Quantidade") in achado)
    c.exigir("data em dois formatos nao virou divergencia", False,
             ("1150", "Data Entrega") in achado)
    c.exigir("diferenca de formato numerico registrada na nota", True,
             "formato numerico" in nota)
    c.exigir("diferenca de formato de data registrada na nota", True,
             "formato de data" in nota)
    c.exigir("divergencia de quantidade encontrada", True, ("2200", "Quantidade") in achado)
    c.exigir("divergencia de quantidade classificada como certa", "certa",
             classes.get(("2200", "Quantidade")))
    c.exigir("divergencia de data encontrada", True, ("3300", "Data Entrega") in achado)
    c.exigir("nenhuma divergencia a mais", 2, len(achado))
    c.exigir("chave orfa da fonte A", "orfa", ca.get("004400"))
    c.exigir("chave orfa da fonte B", "orfa", cb.get("006600"))
    c.exigir("duplicata divergente em A", "duplicata_divergente", ca.get("005500"))
    c.exigir("o outro lado sabe da duplicata", "duplicata_divergente_no_outro_lado",
             cb.get("5500"))
    c.exigir("duplicata fora do pareamento aparece como achado", True,
             "Duplicatas divergentes" in nota)
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_estrito_com_duplicata(base):
    """Duplicata e irrecuperavel nao sao ambiguidade e nao derrubam o modo estrito."""
    c = Caso("modo --estrito nao cai por duplicata divergente")
    rc, out, err, saida = rodar(base, "r3", ["--chave-a", "Codigo", "--chave-b", "Codigo",
                                             "--zeros-esquerda", "remover", "--estrito"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    c.exigir("codigo de saida 1, nao 2", 1, rc)
    c.exigir("nao reclamou de ambiguidade", False, "ambiguidades nao resolvidas" in err)
    c.exigir("a nota separa achado de ambiguidade", True,
             "## 7b. Achados que ficaram fora do pareamento" in nota)
    c.exigir("o achado esta na secao 7b", True,
             nota.index("Duplicatas divergentes") > nota.index("## 7b."))
    return c


def caso_mesclagem(base):
    """Coluna em padrao de celula mesclada gera alerta e classe suspeita."""
    c = Caso("coluna mesclada alerta e a divergencia sai como suspeita")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade;Data Entrega;Setor;Obs",
        "100;Eixo;10;2026-04-01;Usinagem;",
        "101;Bucha;20;2026-04-02;;",
        "102;Mancal;5;2026-04-03;;",
        ";Sem codigo;1;2026-04-04;;",
        "103;Flange;7;2026-04-05;Montagem;",
        "104;Tampa;9;2026-04-06;;",
        "105;Pino;4;2026-04-07;;",
        "106;Anel;3;2026-04-08;;",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade;Data Entrega;Setor;Obs",
        "100;Eixo;10;2026-04-01;Usinagem;",
        "101;Bucha;20;2026-04-02;Usinagem;",
        "102;Mancal;5;2026-04-03;Usinagem;",
        "103;Flange;7;2026-04-05;Usinagem;",
        "104;Tampa;9;2026-04-06;Montagem;",
        "105;Pino;4;2026-04-07;Montagem;",
        "106;Anel;3;2026-04-08;Montagem;",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    div = ler_csv(saida / "divergencias.csv")
    setor = dict((l["chave_normalizada"], l) for l in div if l["campo"] == "Setor")
    c.exigir("codigo de saida 1", 1, rc)
    c.exigir("a nota alerta o padrao de celula mesclada", True,
             "padrao de celula mesclada" in nota)
    c.exigir("o alerta nomeia a coluna Setor", True, "coluna Setor com" in nota)
    c.exigir("o terminal lista a coluna mesclada", True,
             "colunas em padrao de celula mesclada: A Setor" in out)
    c.exigir("celula vazia contra preenchida sai como suspeita", "suspeita",
             setor.get("101", {}).get("classe"))
    c.exigir("o motivo da suspeita cita a mesclagem", True,
             "celula mesclada" in (setor.get("101", {}).get("motivo_suspeita") or ""))
    c.exigir("duas celulas preenchidas e diferentes seguem como divergencia certa",
             "certa", setor.get("103", {}).get("classe"))
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_notacao_cientifica(base):
    """Os dois lados da chave em notacao cientifica apontam um para o outro."""
    c = Caso("chave em notacao cientifica aponta para a chave longa do outro lado")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade",
        "7,89123E+12;PARAFUSO M8 GALV;250",
        "100;Eixo;10",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade",
        "7891234567890;PARAFUSO M8 GALV;250",
        "100;Eixo;10",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    orfas_a = ler_csv(saida / "so-na-fonte-A.csv")
    orfas_b = ler_csv(saida / "so-na-fonte-B.csv")
    linha_a = dict((l["chave_original"], l) for l in orfas_a).get("7,89123E+12", {})
    linha_b = dict((l["chave_original"], l) for l in orfas_b).get("7891234567890", {})
    c.exigir("a chave curta ficou como irrecuperavel", "irrecuperavel",
             linha_a.get("causa_provavel"))
    c.exigir("a irrecuperavel aponta a chave longa do outro lado", "7891234567890",
             linha_a.get("chave_parecida_do_outro_lado"))
    c.exigir("a chave longa nao saiu como orfa", "par_provavel_de_chave_irrecuperavel",
             linha_b.get("causa_provavel"))
    c.exigir("a chave longa aponta a chave em notacao cientifica", "7,89123E+12",
             linha_b.get("chave_parecida_do_outro_lado"))
    c.exigir("o vocabulario novo esta explicado na nota", True,
             "par_provavel_de_chave_irrecuperavel" in nota)

    def celulas(prefixo):
        for linha in nota.splitlines():
            if linha.startswith(prefixo):
                return [p.strip() for p in linha.strip("|").split("|")][1:3]
        return None
    c.exigir("a contagem de chaves distintas fecha com a tabela de fusao",
             celulas("| Chaves distintas |"),
             celulas("| Depois de espaco, acento e caixa |"))
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_so_nota(base):
    """--so-nota nao pode devolver o codigo de quem comparou e nao achou divergencia."""
    c = Caso("--so-nota sai com codigo proprio")
    escrever(base / "a.csv", ["Codigo;Descricao;Quantidade", "100;Eixo;10", "200;Bucha;20"])
    escrever(base / "b.csv", ["Codigo;Descricao;Quantidade", "100;Eixo;10", "200;Bucha;20"])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo",
                                            "--so-nota"])
    c.exigir("codigo de saida 4", 4, rc)
    c.exigir("a nota foi escrita", True, (saida / "nota-de-normalizacao.md").exists())
    c.exigir("nenhuma comparacao foi escrita", False, (saida / "divergencias.csv").exists())
    c.exigir("o terminal diz que nada foi comparado", True, "nenhuma comparacao" in out)
    return c


def caso_nenhuma_chave_pareia(base):
    """Zero chave pareada nao pode terminar em sucesso."""
    c = Caso("nenhuma chave pareia entre as duas fontes")
    escrever(base / "a.csv", ["Codigo;Descricao;Quantidade", "100;Eixo;10", "200;Bucha;20"])
    escrever(base / "b.csv", ["Codigo;Descricao;Quantidade", "800;Eixo;10", "900;Bucha;20"])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    c.exigir("codigo de saida 3", 3, rc)
    c.exigir("a mensagem diz que nada foi comparado", True, "nada foi comparado" in err)
    c.exigir("as linhas dos dois lados foram escritas", 2,
             len(ler_csv(saida / "so-na-fonte-A.csv")))
    return c


def caso_rodape_de_erp_com_linha_abaixo_do_total(base):
    """Linha de identificacao abaixo do total nao pode proteger o rodape inteiro."""
    c = Caso("rodape de ERP com linha de identificacao abaixo da linha de total")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
        "300;Mancal;24",
        "TOTAL GERAL;;54",
        "Emitido em 30/04/2026 por PCP;;",
        "Pagina 1 de 1;;",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
        "300;Mancal;24",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    desc = ler_csv(saida / "linhas-descartadas.csv")
    rodape_a = [l for l in desc if l["lado"] == "A" and l["tipo"] == "rodape"]
    causas_por_linha = dict((l["linha"], l["causa"]) for l in rodape_a)
    orfas_a = ler_csv(saida / "so-na-fonte-A.csv")
    c.exigir("codigo de saida 0, as tres linhas de item batem", 0, rc)
    c.exigir("o bloco de rodape saiu inteiro, tres linhas", 3, len(rodape_a))
    c.exigir("a linha de total saiu como linha de total", True,
             "linha de total no fim do arquivo" in (causas_por_linha.get("5") or ""))
    c.exigir("a linha de identificacao saiu como bloco de rodape", True,
             "abaixo da linha de total" in (causas_por_linha.get("6") or ""))
    c.exigir("a linha de pagina saiu como bloco de rodape", True,
             "abaixo da linha de total" in (causas_por_linha.get("7") or ""))
    c.exigir("o terminal conta tres linhas de rodape em A", True,
             "linhas descartadas: rodape A 3, B 0" in out)
    c.exigir("TOTAL GERAL nao entrou como item orfao", False,
             any("TOTAL GERAL" in (l["chave_original"] or "") for l in orfas_a))
    c.exigir("nenhuma linha de rodape entrou em so-na-fonte-A.csv", 0, len(orfas_a))
    c.exigir("a conferencia do total aconteceu", True,
             "total do rodape: A, confere com a soma das linhas mantidas" in out)
    c.exigir("a nota aponta a linha do total conferido", True,
             "total declarado na linha 5" in nota)
    c.exigir("as celulas vazias do rodape nao geraram alerta falso de mesclagem", True,
             "colunas em padrao de celula mesclada: A nenhuma" in out)
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)

    # Marcador de total que nao cabe no bloco de rodape: a linha fica, e a nota
    # nao pode dizer que nao existe linha de total.
    escrever(base / "a2.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
        "300;Mancal;24",
        "TOTAL GERAL;Resumo do mes;54",
    ])
    rc2, out2, err2, saida2 = rodar(base, "r2", ["--chave-a", "Codigo", "--chave-b", "Codigo"],
                                    arquivo_a="a2.csv")
    c.exigir("marcador de total nao descartado nao sai com codigo 0", 5, rc2)
    c.exigir("a nota nao afirma que nao existe linha de total", False,
             "A, nenhuma linha de total encontrada" in out2)
    c.exigir("a nota diz que a linha de total ficou no arquivo", True,
             "linha com marcador de total encontrada no fim do arquivo e nao descartada"
             in out2)

    # Arquivo de duas colunas: toda linha tem poucas celulas preenchidas, o
    # criterio nao distingue nada, e o bloco nao pode varrer item real.
    escrever(base / "a3.csv", [
        "Codigo;Quantidade",
        "100;10",
        "200;20",
        "TOTAL;30",
    ])
    escrever(base / "b3.csv", [
        "Codigo;Quantidade",
        "100;10",
        "200;20",
    ])
    rc3, out3, err3, saida3 = rodar(base, "r3", ["--chave-a", "Codigo", "--chave-b", "Codigo"],
                                    arquivo_a="a3.csv", arquivo_b="b3.csv")
    desc3 = ler_csv(saida3 / "linhas-descartadas.csv")
    c.exigir("em arquivo de duas colunas nada foi descartado por bloco", 0, len(desc3))
    c.exigir("a rodada de duas colunas nao sai com codigo 0", 5, rc3)
    c.exigir("a rodada de duas colunas diz que nao conferiu o total", True,
             "nao descartada, conferencia do total nao foi feita" in out3)
    return c


def caso_uma_coluna_coincide_por_acaso(base):
    """Uma coluna com nome igual por acaso nao pode restaurar a omissao silenciosa."""
    c = Caso("uma unica coluna emparelha por acaso e as outras ficam fora")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Qtde;Setor",
        "100;Eixo;99;Usinagem",
        "200;Bucha;30;Montagem",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade;Setor",
        "100;Eixo;50;Usinagem",
        "200;Bucha;31;Montagem",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    c.exigir("codigo de saida diferente de zero", True, rc != 0)
    c.exigir("codigo de saida 3", 3, rc)
    c.exigir("a mensagem nomeia a coluna sem par de A", True, "A:Qtde" in err)
    c.exigir("a mensagem nomeia a coluna sem par de B", True, "B:Quantidade" in err)
    c.exigir("a mensagem ensina o --campos", True, "--campos" in err)
    c.exigir("a mensagem diz por que zero seria mentira", True,
             "seria dizer que as fontes batem" in err)
    c.exigir("nao imprimiu fecha", False, "fecha" in out)
    c.exigir("nao escreveu diretorio de saida", False, saida.exists())
    rc2, out2, err2, saida2 = rodar(base, "r2", ["--chave-a", "Codigo", "--chave-b", "Codigo",
                                                 "--campos", "Qtde:Quantidade"])
    div = ler_csv(saida2 / "divergencias.csv")
    c.exigir("com --campos a rodada anda e acha as duas divergencias", 2, len(div))
    c.exigir("com --campos o codigo de saida e 1", 1, rc2)
    return c


def caso_sem_par_declarado_em_campos(base):
    """Com --campos, coluna fora da comparacao aparece na lista, nao como nenhuma."""
    c = Caso("coluna fora da comparacao por --campos aparece no bloco de verificacoes")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Qtde;Setor",
        "100;Eixo;99;Usinagem",
        "200;Bucha;30;Montagem",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade;Setor",
        "100;Eixo;50;Usinagem",
        "200;Bucha;31;Montagem",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo",
                                            "--campos", "Qtde:Quantidade"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    linha = [l.strip() for l in out.splitlines() if l.strip().startswith("colunas sem par")]
    c.exigir("codigo de saida 1", 1, rc)
    c.exigir("a linha de colunas sem par foi impressa", 1, len(linha))
    c.exigir("a linha nao diz nenhuma", False, "nenhuma" in (linha[0] if linha else ""))
    c.exigir("Descricao de A esta na lista", True, "A:Descricao" in (linha[0] if linha else ""))
    c.exigir("Setor de A esta na lista", True, "A:Setor" in (linha[0] if linha else ""))
    c.exigir("Descricao de B esta na lista", True, "B:Descricao" in (linha[0] if linha else ""))
    c.exigir("Setor de B esta na lista", True, "B:Setor" in (linha[0] if linha else ""))
    c.exigir("a linha diz que a exclusao foi declarada", True,
             "declaradas em --campos" in (linha[0] if linha else ""))
    c.exigir("a nota tambem registra a exclusao declarada", True,
             "A exclusao foi declarada em --campos" in nota)
    c.exigir("so um campo foi comparado", True, "campos comparados: 1" in out)
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_referencia_de_rodape(base):
    """A referencia de normalizacao nao pode prescrever a regra que o script rejeita."""
    c = Caso("references/normalizacao.md descreve a deteccao de rodape que o script usa")
    texto = ler_texto(AQUI.parent / "references" / "normalizacao.md")
    inicio = texto.find("### 3.2")
    fim = texto.find("### 3.3")
    trecho = texto[inicio:fim] if inicio >= 0 and fim > inicio else ""
    c.exigir("a secao 3.2 existe", True, bool(trecho))
    c.exigir("nao prescreve mais deteccao por substring", False, "chave contendo" in trecho)
    c.exigir("o marcador solto geral saiu da regra", False, "`geral` ou" in trecho)
    c.exigir("exige celula igual ao marcador", True, "alguma célula igual a" in trecho)
    c.exigir("exige poucas celulas preenchidas", True, "poucas células preenchidas" in trecho)
    c.exigir("diz que conter a palavra nao serve", True, "apenas contém a palavra" in trecho)
    c.exigir("cita o codigo de item real que a regra antiga apagava", True,
             "GERAL-500" in trecho)
    c.exigir("descreve o rodape de ERP com linha abaixo do total", True,
             "Rodapé de ERP tem linha abaixo do total" in trecho)
    c.exigir("manda tratar o bloco final como unidade", True,
             "como uma\nunidade" in trecho or "como uma unidade" in trecho)
    return c


def caso_linha_perdida_na_leitura(base):
    """Linha derrubada na leitura por delimitador dentro da celula nao sai com codigo 0."""
    c = Caso("linha com conteudo perdida na leitura nao sai com codigo 0")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "300;Mancal;5",
        "400;Flange;7",
        "200;Bucha; furada;20",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "300;Mancal;5",
        "400;Flange;7",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    nota = ler_texto(saida / "nota-de-normalizacao.md")
    desc = ler_csv(saida / "linhas-descartadas.csv")
    perdidas = [l for l in desc if l["lado"] == "A" and l["tipo"] == "leitura"]
    c.exigir("codigo de saida diferente de zero", True, rc != 0)
    c.exigir("codigo de saida 5", 5, rc)
    c.exigir("nenhuma divergencia foi encontrada no que foi comparado", True,
             "divergencias: 0 linhas" in out)
    c.exigir("a linha perdida esta registrada", 1, len(perdidas))
    c.exigir("o conteudo da linha perdida esta no arquivo", True,
             "Bucha" in (perdidas[0]["conteudo_da_linha"] if perdidas else ""))
    c.exigir("o terminal conta a linha perdida", True,
             "linhas com conteudo perdidas na leitura, nunca comparadas: A 1, B 0" in out)
    c.exigir("a mensagem de saida explica por que nao e zero", True,
             "Codigo 5, que nao e 0" in err)
    c.exigir("a mensagem nomeia a perda na leitura", True,
             "linha(s) com conteudo perdida(s) na leitura" in err)
    c.exigir("a nota registra o achado", True,
             "contagem de coluna diferente do cabecalho" in nota)
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    return c


def caso_chave_nao_comparada_sem_divergencia(base):
    """Chave que existe so de um lado, ou que repete com conteudo diferente, nao sai com 0."""
    c = Caso("chave nao comparada sem nenhuma divergencia de valor nao sai com codigo 0")
    escrever(base / "a.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
        "200;Bucha grande;21",
    ])
    escrever(base / "b.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "200;Bucha;20",
    ])
    rc, out, err, saida = rodar(base, "r", ["--chave-a", "Codigo", "--chave-b", "Codigo"])
    c.exigir("codigo de saida diferente de zero", True, rc != 0)
    c.exigir("codigo de saida 5", 5, rc)
    c.exigir("nenhuma divergencia de valor foi encontrada", True,
             "divergencias: 0 linhas" in out)
    c.exigir("a mensagem nomeia a chave que repete com conteudo diferente", True,
             "chave(s) que repetem com conteudo diferente" in err)
    c.exigir("fechamento sem QUEBRA", False, "QUEBRA" in out)
    escrever(base / "b2.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
    ])
    escrever(base / "a2.csv", [
        "Codigo;Descricao;Quantidade",
        "100;Eixo;10",
        "900;Tampa;3",
    ])
    rc2, out2, err2, saida2 = rodar(base, "r2", ["--chave-a", "Codigo", "--chave-b", "Codigo"],
                                    arquivo_a="a2.csv", arquivo_b="b2.csv")
    c.exigir("chave que existe so em A nao sai com codigo 0", 5, rc2)
    c.exigir("nenhuma divergencia de valor na segunda rodada", True,
             "divergencias: 0 linhas" in out2)
    c.exigir("a mensagem nomeia a chave que existe so em uma fonte", True,
             "chave(s) que existem so nela" in err2)
    c.exigir("a chave orfa esta no arquivo de saida", 1,
             len(ler_csv(saida2 / "so-na-fonte-A.csv")))
    return c


CASOS = [
    caso_marcador_na_chave,
    caso_nenhuma_coluna_coincide,
    caso_linha_vazia_no_fim,
    caso_rodape_registrado,
    caso_chave_detectada_com_rodape,
    caso_normalizacao,
    caso_estrito_com_duplicata,
    caso_mesclagem,
    caso_notacao_cientifica,
    caso_so_nota,
    caso_nenhuma_chave_pareia,
    caso_rodape_de_erp_com_linha_abaixo_do_total,
    caso_uma_coluna_coincide_por_acaso,
    caso_sem_par_declarado_em_campos,
    caso_referencia_de_rodape,
    caso_linha_perdida_na_leitura,
    caso_chave_nao_comparada_sem_divergencia,
]


def main():
    if not CONFERIR.is_file():
        sys.stderr.write("conferir.py nao encontrado em %s\n" % AQUI)
        return 1
    raiz = Path(tempfile.mkdtemp(prefix="testar-conferir-"))
    resultados = []
    try:
        base_normalizacao = None
        for i, fabricar in enumerate(CASOS, start=1):
            if fabricar is caso_estrito_com_duplicata:
                base = base_normalizacao
            else:
                base = raiz / ("caso-%02d" % i)
                base.mkdir()
            try:
                caso = fabricar(base)
            except Exception as exc:
                caso = Caso(fabricar.__name__)
                caso.quebrou(exc)
            if fabricar is caso_normalizacao:
                base_normalizacao = base
            resultados.append(caso)
            caso.imprimir()
    finally:
        shutil.rmtree(str(raiz), ignore_errors=True)
    falhos = [c for c in resultados if not c.passou]
    total_checagens = sum(len(c.checagens) for c in resultados)
    sys.stdout.write("\n%d casos, %d checagens, %d casos falhos\n"
                     % (len(resultados), total_checagens, len(falhos)))
    for c in falhos:
        sys.stdout.write("  FALHOU: %s\n" % c.nome)
    return 1 if falhos else 0


if __name__ == "__main__":
    sys.exit(main())
