# Licença de uso e autoria

**Kit Conferido.** Autoria: Willy Azevedo, Artemis. Florianópolis, SC.

**Versão 1, de 20 de setembro de 2026.**

## Permissão concedida

Esta versão do kit é distribuída publicamente pelo autor. Quem a recebeu, por qualquer canal, pode usar, copiar, instalar, adaptar e repassar todo o conteúdo dela, sem pedir autorização.

A permissão inclui: usar dentro da empresa em que trabalha, alterar o texto das skills, mudar critérios, trocar o vocabulário pelo da própria casa, corrigir o que estiver errado, e repassar a pasta, alterada ou não, a quem quiser, dentro ou fora da sua empresa.

Nas cópias e nas versões alteradas, mantenha esta autoria e diga que houve alteração.

Os arquivos que as skills geram são seus. O autor não reivindica nada sobre eles.

## Fora da permissão

Revender o kit, licenciá-lo a terceiros, ou usá-lo como produto próprio ou como serviço prestado a outra empresa depende de autorização por escrito do autor. Usar o kit no seu próprio trabalho, inclusive em trabalho que a sua empresa presta a clientes, está dentro da permissão: o que fica de fora é vender o kit, não trabalhar com ele.

## Sem garantia

O material é fornecido como está, sem garantia de qualquer natureza. O autor não responde por erro de saída, perda de dado, decisão tomada a partir de um arquivo gerado, ou prejuízo decorrente do uso.

## Responsabilidade técnica

Nenhuma skill deste kit substitui responsabilidade técnica, decisão de auditoria ou aprovação de documento no sistema de gestão da empresa. Todo arquivo que sai daqui é rascunho até alguém competente ler, corrigir e assinar.

## Marca

Claude é marca da Anthropic, que não tem vínculo com este kit.

## Contato

Para o que depende de autorização por escrito, escreva para o autor.

E-mail: helio@studioartemis.co
